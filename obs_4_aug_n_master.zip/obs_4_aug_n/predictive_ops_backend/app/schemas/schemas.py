from pydantic import BaseModel
from typing import List, Optional

class SubjourneyOut(BaseModel):
    id: str
    name: str
    journey_id: str
    mapping_name: str
    
    # DB populated fields
    status: Optional[str] = "ok"
    resp: Optional[int] = 0
    p95: Optional[int] = 0
    avail: Optional[float] = 100.0
    errRate: Optional[float] = 0.0
    happy: Optional[int] = 0
    unhappy: Optional[int] = 0
    frustrated: Optional[int] = 0
    alerts: Optional[int] = 0
    
    class Config:
        from_attributes = True

class JourneyOut(BaseModel):
    id: str
    name: str
    
    # DB populated fields
    status: Optional[str] = "ok"
    users: Optional[int] = 0
    happy: Optional[int] = 0
    unhappy: Optional[int] = 0
    frustrated: Optional[int] = 0
    avail: Optional[float] = 100.0
    alerts: Optional[int] = 0
    subJourneysCount: int = 0
    
    class Config:
        from_attributes = True
