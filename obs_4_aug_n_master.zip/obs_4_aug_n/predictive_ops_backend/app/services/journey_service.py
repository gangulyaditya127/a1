from sqlalchemy.orm import Session
from app.models.models import Journey, Subjourney
from app.schemas import schemas

def get_journeys(db: Session):
    journeys = db.query(Journey).all()
    # We could count subjourneys dynamically if needed, but we'll let schema handle defaults for now
    result = []
    for j in journeys:
        count = db.query(Subjourney).filter(Subjourney.journey_id == j.id).count()
        j_out = schemas.JourneyOut.model_validate(j)
        j_out.subJourneysCount = count
        result.append(j_out)
    return result

def get_subjourneys_by_journey_id(db: Session, journey_id: str):
    subjourneys = db.query(Subjourney).filter(Subjourney.journey_id == journey_id).all()
    return [schemas.SubjourneyOut.model_validate(s) for s in subjourneys]
