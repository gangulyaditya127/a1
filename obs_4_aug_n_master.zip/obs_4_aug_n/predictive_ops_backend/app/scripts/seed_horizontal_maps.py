# """
# Seed Service Map Objects into DB for Horizontal Correlation.
# Run:
#     python -m app.scripts.seed_horizontal_maps
# """
# from sqlalchemy import Column, String, Integer, Boolean
# from app.database import SessionLocal, engine
# from app.models.models import Base

# class ServiceCorrelationMap(Base):
#     __tablename__ = 'service_correlation_maps'
    
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     map_id = Column(String(50), index=True, nullable=False)        # e.g. "MAP-BENEFITS-CORE"
#     map_name = Column(String(255), nullable=False)                 # e.g. "Benefits & Automation Core Map"
#     service_name = Column(String(255), index=True, nullable=False) # e.g. "Benefits - AS"
#     subjourney_id = Column(String(50), nullable=True)              # e.g. "S3_2"
#     is_active = Column(Boolean, default=True)

# MAP_OBJECTS = [
#     {
#         "map_id": "MAP-BENEFITS-DEBS-AUTO",
#         "map_name": "Benefits, DEBS & Automation Core Map",
#         "services": [
#             {"name": "Benefits - AS", "subjourney_id": "S3_2"},
#             {"name": "Data Entry Benefits System - AS", "subjourney_id": "S3_1"},
#             {"name": "Automation - AS", "subjourney_id": "S3_3"},
            
#         ]
#     },
#     {
#         "map_id": "MAP-GNPA-ENROLMENT",
#         "map_name": "GroupNet & eEnrolment Portal Map",
#         "services": [
#             {"name": "GroupNet for Plan Administration - AS", "subjourney_id": "S2_1"},
#             {"name": "GC eEnrolment Member Application - AS", "subjourney_id": "S1_2"},
#             {"name": "Enrollment Administration System - AS", "subjourney_id": "S1_1"}
#         ]
#     }
# ]

# def seed_horizontal_maps():
#     Base.metadata.create_all(bind=engine)
#     db = SessionLocal()
#     try:
#         db.query(ServiceCorrelationMap).delete()
#         for m in MAP_OBJECTS:
#             for item in m["services"]:
#                 db.add(ServiceCorrelationMap(
#                     map_id=m["map_id"],
#                     map_name=m["map_name"],
#                     service_name=item["name"],
#                     subjourney_id=item["subjourney_id"],
#                     is_active=True
#                 ))
#         db.commit()
#         print(f"[OK] Seeded {len(MAP_OBJECTS)} Service Correlation Map Objects.")
#     finally:
#         db.close()

# if __name__ == "__main__":
#     seed_horizontal_maps()