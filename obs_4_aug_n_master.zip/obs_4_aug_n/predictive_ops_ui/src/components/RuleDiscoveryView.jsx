// AI Rule Discovery — faithful React port of ai-rule-discovery-explainer.html
// Path: src/components/RuleDiscoveryView.jsx
//
// Renders the same 5-stage walkthrough as the HTML:
//   1. Discover  - CMDB CIs + signal graph
//   2. Mine      - Streaming alerts (dark terminal) + pattern cards
//   3. Synthesize- 3-column flow (Input -> GPT log -> Output)
//   4. Review    - Rule proposal cards with 4-cell meta + Approve/Tune/Reject
//   5. Deploy    - Pending -> Live counters + deployment log
//
// All stage-specific styles are scoped inside `.rd-root` and injected once
// via a <style> tag, so this component does NOT depend on ANY change to
// styles.css. Ashish's global classes (view, back-btn, eyebrow, timestamp,
// cta-btn) are ALSO used — those already exist in his theme.

import { useEffect, useRef, useState } from 'react';
import { observabilityService } from '../services/observabilityService';

// ------------------------------------------------------------------
// Static demo data — verbatim from the HTML explainer
// ------------------------------------------------------------------
const CI_DATA = [
    { name: 'Policy Admin DB', tools: [['oem', 'Oracle EM'], ['appd', 'AppD DB'], ['splunk', 'Splunk'], ['dyn', 'Dynatrace']] },
    { name: 'Claims Service', tools: [['appd', 'AppDynamics'], ['splunk', 'Splunk']] },
    { name: 'Enterprise Bus', tools: [['hawk', 'TIBCO Hawk'], ['appd', 'AppDynamics'], ['splunk', 'Splunk']] },
    { name: 'Rating Engine', tools: [['appd', 'AppDynamics'], ['splunk', 'Splunk']] },
    { name: 'Document Store', tools: [['fnet', 'FileNet Admin'], ['splunk', 'Splunk']] },
];

const STREAM_LINES = [
    { ts: '10:20:15', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '10:25:17', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '10:30:18', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '10:35:16', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '10:50:16', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '11:10:19', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '11:10:34', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '11:10:36', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '11:20:18', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
    { ts: '11:25:00', tool: 'ITSI', sig: 'ADS health score is HIGH', crit: false },
    { ts: '11:35:00', tool: 'ITSI', sig: 'ADS health score is CRITICAL', crit: true },
    { ts: '11:40:18', tool: 'ITSI', sig: 'PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED', crit: true },
];

const PATTERNS_DEMO = [
    {
        title: 'Recurring Event: Transaction Abend (GS49RLC1)',
        meta: '<b>Job Name:</b> GS49RLC1<br/><b>10 incidents</b> detected in selected 2-hour window<br/>Avg Δt <b>12m</b>, tightly correlated'
    },
    {
        title: 'Recurring Event: Health Score (ADS)',
        meta: '<b>App Name:</b> ADS<br/><b>3 incidents</b> detected in selected 2-hour window<br/>Repeated alerts indicating ongoing service degradation'
    }
];

const GPT_LOG_LINES = [
    ['prompt', 'system: You synthesize AIOps correlation rules from CMDB + alert patterns.'],
    ['prompt', 'user: Pattern P-101 with 150 incidents matching PAGER Transaction Abend…'],
    ['comp', '{'],
    ['comp', '  "rule_id": "RULE-AI-101",'],
    ['comp', '  "name": "Transaction Abend Cascade",'],
    ['comp', '  "trigger_when": "ITSI · PAGER79 309B TRANSACTION <JOBNAME> HAS ABENDED",'],
    ['comp', '  "combine_logic": "AND within 65 min AND matching <JOBNAME>",'],
    ['comp', '  "confidence_score": 0.94,'],
    ['comp', '  "expected_precision": 0.95,'],
    ['comp', '  "involves": ["Benefits - AS"]'],
    ['comp', '}'],
    ['out', '→ Rule proposal accepted by schema validator'],
    ['out', '→ Estimated noise reduction: 4 alerts → 1 incident'],
];

const REVIEW_RULES_DEMO = [
    {
        id: 'RULE-AI-101', conf: 0.94, name: 'Transaction Abend Cascade',
        plain: 'When PAGER79 detects a Transaction Abend for a specific Job Name (e.g., GS49RLC1), it correlates subsequent abends matching the same Job Name within 65 minutes.',
        m: [['1', 'tool'], ['65m', 'window'], ['150×', 'support'], ['95%', 'precision']]
    },
    {
        id: 'RULE-AI-103', conf: 0.88, name: 'CICS Cross-Family Cascade',
        plain: 'CICS System Events trigger IEF Job Failures and PAGER Job Abends tied to the same region. Groups these cascading failures into a single root cause incident.',
        m: [['1', 'tool'], ['35m', 'window'], ['6×', 'support'], ['88%', 'precision']]
    },
    {
        id: 'RULE-AI-102', conf: 0.74, name: 'Health Score Degradation grouped by App',
        plain: 'Groups multiple Health Score alerts (CRITICAL, HIGH, MEDIUM) for the same App Name (e.g., DCT) occurring within 30 minutes to reduce alert fatigue.',
        m: [['1', 'tool'], ['30m', 'window'], ['320×', 'support'], ['81%', 'precision']]
    },
];

const DEPLOY_LOG_LINES = [
    ['act', 'Loading approved rules from review queue…'],
    ['ok', 'Rule <b>RULE-AI-014</b> written to correlation_rules'],
    ['ok', '3 inputs written to rule_combine_inputs'],
    ['ok', '2 explanation paragraphs written to rule_explanations'],
    ['ok', 'Rule marked <b>active=false</b> (shadow mode) for 7-day evaluation'],
    ['act', 'Notifying correlation engine of rule set change…'],
    ['ok', 'Engine will pick up 3 new rules on next run'],
];

const STAGE_NAMES = ['Mine', 'Synthesize', 'Review', 'Deploy'];

// ==================================================================
// Main component
// ==================================================================
export default function RuleDiscoveryView({ onBack }) {
    const [stage, setStage] = useState(1);
    const [isLive, setIsLive] = useState(false);
    const timersRef = useRef([]);

    // Clear pending timers on unmount + stage change
    useEffect(() => {
        return () => {
            timersRef.current.forEach(clearTimeout);
            timersRef.current = [];
        };
    }, []);

    const schedule = (fn, delay) => {
        const t = setTimeout(fn, delay);
        timersRef.current.push(t);
        return t;
    };
    const clearTimers = () => {
        timersRef.current.forEach(clearTimeout);
        timersRef.current = [];
    };

    const goToStage = (n) => {
        clearTimers();
        setStage(Math.max(1, Math.min(4, n)));
    };

    // Keyboard nav
    useEffect(() => {
        const onKey = (e) => {
            if (e.key === 'ArrowRight' && stage < 4) goToStage(stage + 1);
            if (e.key === 'ArrowLeft' && stage > 1) goToStage(stage - 1);
        };
        document.addEventListener('keydown', onKey);
        return () => document.removeEventListener('keydown', onKey);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [stage]);

    return (
        <>
            <ScopedStyles />
            <div className="view rd-root">
                <button className="back-btn" onClick={onBack}>&larr; Go back</button>

                <header className="rd-header">
                    <div>
                        <div className="eyebrow">ARE Platform · AI-Driven Rule Discovery</div>
                        <h1>How AI discovers correlation rules from your CMDB</h1>
                        <div className="rd-sub">
                            Instead of humans authoring correlation rules by hand, the system mines your{' '}
                            <b>CMDB</b>, <b>CI-to-tool mappings</b>, and <b>historical alert patterns</b>,
                            then uses <b>OpenAI</b> to synthesize candidate rules. A human reviewer approves,
                            tunes, or rejects each one before it goes live in the correlation engine.
                        </div>
                    </div>
                    
                    <div className="rd-toggle-wrap">
                        <span className="rd-toggle-label">Demo</span>
                        <label className="rd-toggle">
                            <input 
                                type="checkbox" 
                                checked={isLive} 
                                onChange={(e) => { clearTimers(); setIsLive(e.target.checked); }} 
                            />
                            <span className="rd-toggle-slider"></span>
                        </label>
                        <span className="rd-toggle-label">Live</span>
                    </div>
                </header>

                {/* Stage strip */}
                <div className="stage-strip">
                    {STAGE_NAMES.map((name, i) => {
                        const n = i + 1;
                        const cls = 'stage-pill '
                            + (stage === n ? 'active' : '')
                            + (stage > n ? ' done' : '');
                        return (
                            <div key={name} className={cls} onClick={() => goToStage(n)}>
                                <div className="stage-num"><span className="stage-num-txt">{n}</span></div>
                                <div className="stage-title">{name}</div>
                                <div className="stage-sub">{stageSubtitle(n)}</div>
                            </div>
                        );
                    })}
                </div>

                {/* Prev / Next nav */}
                <div className="nav-bar">
                    <button className="nav ghost" onClick={() => goToStage(stage - 1)} disabled={stage === 1}>
                        &larr; Prev
                    </button>
                    <div className="nav-info">
                        Stage <b>{stage}</b> of 4 · <span>{STAGE_NAMES[stage - 1]}</span>
                    </div>
                    <button className="nav primary" onClick={() => goToStage(stage + 1)} disabled={stage === 4}>
                        {stage < 4 ? (
                            <>Next &rarr; <span className="step-indicator">{STAGE_NAMES[stage]}</span></>
                        ) : (
                            'End of walkthrough'
                        )}
                    </button>
                </div>

                {/* Canvas */}
                <div className="canvas">
                    {stage === 1 && <Stage2 schedule={schedule} key={`s2-${isLive}`} isLive={isLive} />}
                    {stage === 2 && <Stage3 schedule={schedule} key={`s3-${isLive}`} isLive={isLive} />}
                    {stage === 3 && <Stage4 schedule={schedule} key={`s4-${isLive}`} isLive={isLive} />}
                    {stage === 4 && <Stage5 schedule={schedule} key={`s5-${isLive}`} isLive={isLive} />}
                </div>

                <footer className="rd-footer">
                    Canada Life · ARE Observability Platform · AI Rule Discovery flow
                </footer>
            </div>
        </>
    );
}

function stageSubtitle(n) {
    return {
        1: 'Mine historical alerts for recurring events',
        2: 'GPT proposes candidate rules',
        3: 'Human approves, tunes or rejects',
        4: 'Approved rules go live in the engine',
    }[n];
}

// ==================================================================
// Stage 1 - CMDB Discovery
// ==================================================================
function Stage1({ schedule, isLive }) {
    const [cis, setCis] = useState([]);
    const [stats, setStats] = useState({ total: 142, tools: 6, cov: 89 });
    const [error, setError] = useState(null);

    useEffect(() => {
        let active = true;
        setCis([]);
        
        if (isLive) {
            observabilityService.getCiCoverage().then(data => {
                if (active) {
                    setCis(data.map(c => ({
                        name: c.component_name || c.name,
                        tools: (c.tools || []).map(t => [t.tool_id || 'default', t.tool_name || t.tool_id])
                    })));
                    if (data.length > 0) {
                        const totalCis = data[0].total_cis || 100;
                        const multiCis = data[0].multi_tool_cis || 0;
                        const cov = totalCis > 0 ? Math.round((multiCis / totalCis) * 100) : 0;
                        const uniqueTools = new Set();
                        data.forEach(c => {
                            if (c.tools) c.tools.forEach(t => uniqueTools.add(t.tool_id));
                        });
                        setStats({ total: totalCis, tools: uniqueTools.size, cov });
                    }
                }
            }).catch(err => {
                if (active) setError(err.message);
            });
        } else {
            CI_DATA.forEach((ci, i) => {
                schedule(() => {
                    if (active) setCis(prev => [...prev, ci]);
                }, i * 150);
            });
            setStats({ total: 142, tools: 6, cov: 89 });
        }
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    return (
        <div className="stage active">
            <h2 className="stage-h">Stage 1 — Discover CIs across your monitoring landscape</h2>
            <p className="stage-desc">
                The system reads your <b>CMDB</b> (or ServiceNow, Device42, etc.) and pulls every
                configuration item along with which monitoring tools cover it. This "who-watches-what"
                map is the foundation for everything else — you can't correlate signals across tools
                until you know which tool signals what.
            </p>

            {error && <div className="rd-error">Error loading CIs: {error}</div>}

            <div className="cmdb-grid">
                <div className="cmdb-panel">
                    <h4>CMDB · CIs with multi-tool coverage</h4>
                    <div>
                        {cis.map((ci, i) => (
                            <div key={i} className="ci-row">
                                <div className="ci-name">{ci.name}</div>
                                <div className="ci-tools">
                                    {ci.tools.map(([cls, nm], j) => (
                                        <span key={`${cls}-${j}`} className={'tool-badge ' + cls}>{nm}</span>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="cmdb-stats">
                        <div className="cmdb-stat"><div className="n">{stats.total}</div><div className="l">total CIs</div></div>
                        <div className="cmdb-stat"><div className="n">{stats.tools}</div><div className="l">tools connected</div></div>
                        <div className="cmdb-stat"><div className="n">{stats.cov}%</div><div className="l">coverage</div></div>
                    </div>
                </div>

                <div className="cmdb-panel">
                    <h4>Discovered signal graph</h4>
                    <svg viewBox="0 0 400 300" style={{ width: '100%', height: 'auto', background: '#fff', borderRadius: 6 }}>
                        <defs>
                            <marker id="rd-arr1" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
                                <path d="M0,0 L10,5 L0,10 z" fill="#c8102e" />
                            </marker>
                        </defs>
                        <ellipse cx="200" cy="150" rx="70" ry="34" fill="#fdecee" stroke="#c8102e" strokeWidth="2" />
                        <text x="200" y="147" textAnchor="middle" fontFamily="Space Grotesk" fontSize="12" fontWeight="700" fill="#2a1418">Policy Admin DB</text>
                        <text x="200" y="163" textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#7a5a5f">Oracle RAC 19c</text>

                        <circle cx="60" cy="60" r="24" fill="#c8102e" />
                        <text x="60" y="63" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Oracle EM</text>
                        <line x1="82" y1="72" x2="140" y2="125" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />

                        <circle cx="340" cy="60" r="24" fill="#0f7a4d" />
                        <text x="340" y="63" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">AppD DB</text>
                        <line x1="320" y1="72" x2="262" y2="128" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />

                        <circle cx="60" cy="240" r="24" fill="#b45309" />
                        <text x="60" y="243" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Splunk</text>
                        <line x1="82" y1="230" x2="140" y2="175" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />

                        <circle cx="340" cy="240" r="24" fill="#1e40af" />
                        <text x="340" y="243" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Dynatrace</text>
                        <line x1="320" y1="230" x2="262" y2="175" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />

                        <text x="200" y="290" textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="10" fill="#7a5a5f">
                            4 tools monitor this single CI — perfect correlation candidate
                        </text>
                    </svg>
                </div>
            </div>

            <div className="architecture-note">
                <b>Data sources:</b> ServiceNow CMDB · Device42 · custom YAML · JSON exports.
                Read via connectors under <code>app/connectors/*_connector.py</code>.
                <br /><b>Storage:</b> reference tables <code>components</code> (CIs) and{' '}
                <code>monitoring_tools</code> — extended with a new junction table{' '}
                <code>ci_tool_coverage</code> recording which tool watches which CI and via which signal names.
            </div>
        </div>
    );
}

// ==================================================================
// Stage 2 - Pattern Mining
// ==================================================================
function Stage2({ schedule, isLive }) {
    const [lines, setLines] = useState([]);
    const [patterns, setPatterns] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const streamRef = useRef(null);

    useEffect(() => {
        let active = true;
        setLines([]);
        setPatterns([]);
        if (!isLive) {
            STREAM_LINES.forEach((l, i) => {
                schedule(() => {
                    if (!active) return;
                    setLines(prev => [...prev, l]);
                    if (streamRef.current) streamRef.current.scrollTop = streamRef.current.scrollHeight;
                }, i * 250);
            });
            PATTERNS_DEMO.forEach((p, i) => {
                schedule(() => {
                    if (active) setPatterns(prev => [...prev, p]);
                }, 1200 + i * 500);
            });
        }
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    const runMiner = async () => {
        try {
            setLoading(true);
            setError(null);
            await observabilityService.minePatterns(30, 180);
            const data = await observabilityService.listPatterns('new');
            setPatterns(data.map(p => ({
                id: p.pattern_id,
                title: `${p.pattern_id} · ${p.name}`,
                meta: `<b>${p.tool_count} tools</b>, <b>${p.ci_count} CIs</b>, avg Δt <b>${p.avg_time_delta_s}s</b>, recurred <b>${p.support_count}×</b>`
            })));
        } catch(err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="stage active">
            <h2 className="stage-h">Stage 1 — Mine Historical Alerts for Recurring Events</h2>
            <p className="stage-desc">
                The engine ingests historical alerts and identifies events that repeatedly occur within specific time windows, surfacing recurring anomalies for further analysis.
            </p>

            <div style={{ background: 'var(--panel-bg)', padding: '16px', borderRadius: '8px', border: '1px solid var(--border)', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={{ fontWeight: 'bold' }}>Time Range:</span>
                <select style={{ padding: '8px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--bg)', color: 'var(--text-bright)' }}>
                    <option>Last 30 Days</option>
                    <option selected>Specific Time: 15-06-2025 (10am - 12pm)</option>
                    <option>Last 90 Days</option>
                </select>
                <span style={{ color: 'var(--text-dim)', fontSize: '13px' }}>
                    Filtering by Caller: ITSI Event Management, Channel: Monitoring
                </span>
            </div>

            {error && <div className="rd-error">Error mining patterns: {error}</div>}
            
            {isLive && (
                <div style={{marginBottom: '16px'}}>
                    <button className="rd-live-btn" onClick={runMiner} disabled={loading}>
                        {loading ? 'Mining patterns...' : 'Run Pattern Miner'}
                    </button>
                    {loading && <span className="rd-loading"></span>}
                </div>
            )}

            <div className="mining-layout" style={{ gridTemplateColumns: isLive ? '1fr' : '1fr 1fr' }}>
                {!isLive && (
                    <div className="alert-stream" ref={streamRef}>
                        <div className="hdr">RAW ALERT STREAM · LAST 90 DAYS</div>
                        {lines.map((l, i) => (
                            <div key={i} className={'alert-line' + (l.crit ? ' crit' : '')}>
                                <span className="ts">{l.ts}</span>{' '}
                                <span className="tool">[{l.tool}]</span>{' '}
                                <span className="sig">{l.sig}</span>
                            </div>
                        ))}
                    </div>
                )}

                <div className="patterns-out">
                    <h4>Discovered Recurring Events</h4>
                    {patterns.length === 0 && isLive && !loading && <div style={{fontSize:'12px', color:'#7a5a5f'}}>No events mined yet. Click 'Run Pattern Miner'.</div>}
                    {patterns.map((p, i) => (
                        <div key={i} className="pattern-card">
                            <div className="pattern-title">{p.title}</div>
                            <div className="pattern-meta" dangerouslySetInnerHTML={{ __html: p.meta }} />
                        </div>
                    ))}
                </div>
            </div>

            <div className="architecture-note">
                <b>Algorithm:</b> temporal clustering (DBSCAN on time deltas ≤ 300s) + topology
                constraint (all alerts must lie on a connected sub-graph in the CMDB) +
                minimum support (pattern must recur ≥ 3 times to be considered). Output is a
                set of <code>PatternCandidate</code> objects passed to Stage 3.
            </div>
        </div>
    );
}

// ==================================================================
// Stage 3 - AI Synthesis
// ==================================================================
function Stage3({ schedule, isLive }) {
    const [logLines, setLogLines] = useState([]);
    const [patterns, setPatterns] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [proposal, setProposal] = useState(null);
    const logRef = useRef(null);

    useEffect(() => {
        let active = true;
        if (!isLive) {
            setLogLines([]);
            GPT_LOG_LINES.forEach((line, i) => {
                schedule(() => {
                    if (!active) return;
                    setLogLines(prev => [...prev, line]);
                    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
                }, i * 280);
            });
        } else {
            observabilityService.listPatterns('new')
                .then(data => {
                    if (active) setPatterns(data);
                })
                .catch(err => {
                    if (active) setError(err.message);
                });
        }
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    const synthesizePattern = async (patternId) => {
        try {
            setLoading(true);
            setError(null);
            setProposal(null);
            const data = await observabilityService.synthesizePattern(patternId);
            setProposal(data);
        } catch(err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="stage active">
            <h2 className="stage-h">Stage 2 — OpenAI synthesizes correlation rules</h2>
            <p className="stage-desc">
                For each pattern, we send the CMDB context plus the co-firing evidence to <b>OpenAI GPT-4</b>{' '}
                with a strict system prompt. The model returns a structured rule proposal —
                trigger condition, combine logic, expected inputs, plain-English explanation, and a
                confidence estimate.
            </p>

            {error && <div className="rd-error">Error: {error}</div>}

            {isLive ? (
                <div className="rd-pattern-list">
                    <h4>Available Patterns for Synthesis</h4>
                    {patterns.length === 0 && <div style={{fontSize:'12px', color:'#7a5a5f'}}>No patterns available. Go back to Stage 2 and mine patterns.</div>}
                    <div style={{display:'flex', gap:'20px'}}>
                        <div style={{flex: 1}}>
                            {patterns.map(p => (
                                <div key={p.pattern_id} className="pattern-card" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                                    <div>
                                        <div className="pattern-title">{p.pattern_id} · {p.name}</div>
                                        <div className="pattern-meta"><b>{p.tool_count} tools</b>, <b>{p.ci_count} CIs</b></div>
                                    </div>
                                    <button className="rd-live-btn" onClick={() => synthesizePattern(p.pattern_id)} disabled={loading}>
                                        Synthesize Rule
                                    </button>
                                </div>
                            ))}
                            {loading && <div className="rd-loading" style={{marginTop:'10px'}}></div>}
                        </div>
                        
                        {proposal && (
                            <div className="synth-box output" style={{flex: 1}}>
                                <h5>Structured rule proposal</h5>
                                <div className="synth-content">
                                    <code>name:</code> {proposal.name}<br />
                                    <code>trigger_when:</code> {proposal.trigger_when}<br />
                                    <code>combine_logic:</code> {proposal.combine_logic}<br />
                                    <code>confidence:</code> {proposal.confidence_score}<br />
                                    <code>expected_precision:</code> {proposal.expected_precision}<br />
                                    <code>expected_reduction:</code> {proposal.expected_alert_reduction}<br />
                                    <code>generated_by:</code> {proposal.generated_by}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            ) : (
                <div className="synth-flow">
                    <div className="synth-box input">
                        <h5>Input to GPT</h5>
                        <div className="synth-content">
                            <b>Pattern seed:</b><br />
                            <code>PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED</code><br/>
                            <code>PAGER79 309B TRANSACTION GS20CUS1 HAS ABENDED</code>
                            <br /><br />
                            <b>Context:</b><br />
                            <code>ITSI Event Management</code> (Caller)<br />
                            <code>Monitoring</code> (Channel)
                            <br /><br />
                            <b>Co-firings observed:</b><br />
                            150 times in 90d, avg Δt = 65m
                        </div>
                    </div>

                    <div className="synth-arrow">→</div>

                    <div className="synth-box gpt">
                        <h5>GPT-4 reasoning</h5>
                        <div className="gpt-log" ref={logRef}>
                            {logLines.map(([cls, txt], i) => (
                                <div key={i} className={cls}>{txt}</div>
                            ))}
                        </div>
                    </div>

                    <div className="synth-arrow">→</div>

                    <div className="synth-box output">
                        <h5>Structured rule proposal</h5>
                        <div className="synth-content">
                            <code>rule_id: RULE-AI-101</code><br />
                            <code>trigger_when:</code> ITSI · PAGER79 309B TRANSACTION &lt;JOBNAME&gt; HAS ABENDED<br />
                            <code>combine_logic:</code> AND within 65m AND matching &lt;JOBNAME&gt;<br />
                            <code>confidence:</code> 0.94<br />
                            <code>expected_precision:</code> 95%<br />
                            <code>expected_reduction:</code> 4 alerts → 1 incident
                        </div>
                    </div>
                </div>
            )}

            <div className="architecture-note">
                <b>Prompt design:</b> function-calling with a JSON schema; the model MUST return valid{' '}
                <code>CorrelationRule</code> object or the request retries with feedback. Guardrails: no
                free-form rule names, confidence must be numeric, chain must reference existing tier IDs.
            </div>
        </div>
    );
}

// ==================================================================
// Stage 4 - Human Review
// ==================================================================
function Stage4({ schedule, isLive }) {
    const [rules, setRules] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const loadProposals = async (active = true) => {
        try {
            setLoading(true);
            const data = await observabilityService.listProposals();
            if (active) {
                setRules(data.map(p => ({
                    id: p.proposal_id,
                    conf: p.confidence_score,
                    name: p.name,
                    plain: p.plain_english || p.combine_logic,
                    status: p.status,
                    m: [
                        [p.expected_precision ? (p.expected_precision*100).toFixed(0)+'%' : 'N/A', 'precision'],
                        [p.combine_logic ? 'Logic' : 'N/A', 'combine']
                    ],
                    raw: p
                })));
            }
        } catch(err) {
            if (active) setError(err.message);
        } finally {
            if (active) setLoading(false);
        }
    };

    useEffect(() => {
        let active = true;
        setRules([]);
        if (!isLive) {
            REVIEW_RULES_DEMO.forEach((r, i) => {
                schedule(() => {
                    if (active) setRules(prev => [...prev, r]);
                }, i * 400);
            });
        } else {
            loadProposals(active);
        }
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    const handleAction = async (id, action) => {
        try {
            setLoading(true);
            setError(null);
            if (action === 'approve') await observabilityService.approveProposal(id, '');
            else if (action === 'reject') await observabilityService.rejectProposal(id, '');
            await loadProposals(true);
        } catch(err) {
            setError(err.message);
            setLoading(false);
        }
    };

    return (
        <div className="stage active">
            <h2 className="stage-h">Stage 3 — Human review, tune, or reject</h2>
            <p className="stage-desc">
                Every AI-generated rule lands in the <b>Rule Review</b> queue. An SRE inspects the
                plain-English summary, the involved CIs, historical support, expected precision,
                and either <b>Approves</b> (deploys as-is), <b>Tunes</b> (edits then approves), or{' '}
                <b>Rejects</b> (with a reason that trains future prompts).
            </p>

            {error && <div className="rd-error">Error: {error}</div>}
            {loading && isLive && <div className="rd-loading" style={{marginBottom:'10px'}}></div>}

            <div className="review-list">
                {rules.length === 0 && isLive && !loading && <div style={{fontSize:'12px', color:'#7a5a5f'}}>No proposals found. Go back to Stage 3 to synthesize rules.</div>}
                {rules.map((r, i) => (
                    <div key={i} className="rule-proposal" style={{ opacity: isLive && r.status !== 'pending' ? 0.7 : 1 }}>
                        <div className="rp-hdr">
                            <div>
                                <div className="rp-id">
                                    {r.id} · <span className="rp-conf">{Math.round(r.conf * 100)}% confidence</span>
                                    {isLive && r.status && (
                                        <span className={`rd-status-badge rd-status-${r.status.toLowerCase()}`} style={{marginLeft:'10px'}}>
                                            {r.status}
                                        </span>
                                    )}
                                </div>
                                <div className="rp-name">{r.name}</div>
                            </div>
                        </div>
                        <div className="rp-plain">{r.plain}</div>
                        <div className="rp-meta">
                            {r.m.map(([v, l], j) => (
                                <div key={j} className="rp-meta-cell">
                                    <b>{v}</b><span>{l}</span>
                                </div>
                            ))}
                        </div>
                        <div className="rp-actions">
                            <button 
                                className="rp-btn approve" 
                                onClick={() => isLive ? handleAction(r.id, 'approve') : null}
                                disabled={isLive && r.status !== 'pending'}
                            >
                                ✓ Approve
                            </button>
                            <button 
                                className="rp-btn tune"
                                disabled={isLive && r.status !== 'pending'}
                            >
                                ✎ Tune
                            </button>
                            <button 
                                className="rp-btn reject" 
                                onClick={() => isLive ? handleAction(r.id, 'reject') : null}
                                disabled={isLive && r.status !== 'pending'}
                            >
                                ✗ Reject
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            <div className="architecture-note">
                <b>Governance:</b> approvals require 2 reviewers for confidence &lt; 0.80. All actions
                are logged in <code>rule_review_events</code> with reviewer_id, decision, comment.
                Rejected patterns feed back into the prompt via few-shot examples so the model learns
                what your team considers noise.
            </div>
        </div>
    );
}

// ==================================================================
// Stage 5 - Deploy
// ==================================================================
function Stage5({ schedule, isLive }) {
    const [logLines, setLogLines] = useState([]);
    const [pending, setPending] = useState(0);
    const [liveCount, setLiveCount] = useState(0);
    const [approvedProposals, setApprovedProposals] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const fetchCountsAndProposals = async (active = true) => {
        try {
            const approved = await observabilityService.listProposals('approved');
            const deployed = await observabilityService.listProposals('deployed');
            if (active) {
                setPending(approved.length);
                setLiveCount(deployed.length);
                setApprovedProposals(approved);
            }
        } catch(err) {
            if (active) setError(err.message);
        }
    };

    useEffect(() => {
        let active = true;
        if (!isLive) {
            setLogLines([]);
            setPending(6);
            setLiveCount(14);
            DEPLOY_LOG_LINES.forEach((entry, i) => {
                schedule(() => {
                    if (active) setLogLines(prev => [...prev, entry]);
                }, i * 450);
            });
            schedule(() => {
                if (active) {
                    setPending(0);
                    setLiveCount(17);
                }
            }, DEPLOY_LOG_LINES.length * 450 + 200);
        } else {
            setLogLines([]);
            fetchCountsAndProposals(active);
        }
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLive]);

    const handleDeploy = async (id, name) => {
        try {
            setLoading(true);
            setError(null);
            setLogLines(prev => [...prev, ['act', `Deploying rule <b>${name}</b>...`]]);
            await observabilityService.deployProposal(id);
            setLogLines(prev => [...prev, ['ok', `Rule <b>${name}</b> deployed successfully.`]]);
            await fetchCountsAndProposals(true);
        } catch(err) {
            setError(err.message);
            setLogLines(prev => [...prev, ['act', `Deployment failed: ${err.message}`]]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="stage active">
            <h2 className="stage-h">Stage 4 — Deploy approved rules into the live engine</h2>
            <p className="stage-desc">
                Approved rules are written into the existing <b>correlation_rules</b> table (plus{' '}
                <code>rule_combine_inputs</code> and <code>rule_explanations</code>) — the same
                tables your correlation engine already reads. No engine code change needed. The next
                correlation run evaluates them automatically.
            </p>

            {error && <div className="rd-error">Error: {error}</div>}

            <div className="deploy-diagram">
                <div className="deploy-box pending">
                    <div className="deploy-num">{pending}</div>
                    <div className="deploy-lbl">Pending review</div>
                </div>
                <div className="deploy-arrow">→</div>
                <div className="deploy-box active-b">
                    <div className="deploy-num">{liveCount}</div>
                    <div className="deploy-lbl">Live rules</div>
                </div>
            </div>

            {isLive && approvedProposals.length > 0 && (
                <div style={{marginBottom: '20px'}}>
                    <h4 style={{fontFamily:'Space Grotesk', fontSize:'14px', margin:'0 0 10px 0'}}>Approved Rules Ready for Deployment</h4>
                    {approvedProposals.map(p => (
                        <div key={p.proposal_id} style={{display:'flex', justifyContent:'space-between', alignItems:'center', background:'#fff', padding:'10px', border:'1px solid #e6d5d5', borderRadius:'6px', marginBottom:'8px'}}>
                            <div>
                                <div style={{fontFamily:'Space Grotesk', fontWeight:'700', fontSize:'13px', color:'#2a1418'}}>{p.name}</div>
                                <div style={{fontSize:'11px', color:'#7a5a5f', marginTop:'2px'}}>{p.proposal_id}</div>
                            </div>
                            <button className="rd-live-btn" onClick={() => handleDeploy(p.proposal_id, p.name)} disabled={loading}>
                                Deploy
                            </button>
                        </div>
                    ))}
                </div>
            )}

            <div className="deploy-panel">
                <div className="deploy-log-title">Deployment log</div>
                <div>
                    {logLines.length === 0 && <div style={{fontSize:'11px', color:'#7a5a5f'}}>No deployment activity yet.</div>}
                    {logLines.map(([cls, html], i) => (
                        <div key={i} className={'deploy-log-line ' + cls}
                            dangerouslySetInnerHTML={{ __html: html }} />
                    ))}
                </div>
            </div>

            <div className="architecture-note">
                <b>Rollback:</b> soft-delete via <code>rules.active=false</code> — reversible in one click.
                <br /><b>A/B testing:</b> new rules run in <b>shadow mode</b> for 7 days by default —
                they log what they <em>would</em> have grouped without actually suppressing alerts, so
                you can measure precision on real traffic before promoting.
            </div>
        </div>
    );
}

// ==================================================================
// Scoped styles - injected once, all rules prefixed with .rd-root
// ==================================================================
function ScopedStyles() {
    return (
        <style>{`
      .rd-root { font-family: 'IBM Plex Mono', monospace; }
      .rd-root .rd-header {
        border-bottom: 3px solid #c8102e; padding-bottom: 16px; margin-bottom: 24px;
        display: flex; justify-content: space-between; align-items: flex-end;
        flex-wrap: wrap; gap: 16px;
      }
      .rd-root .rd-sub {
        color: #7a5a5f; font-size: 13px; margin-top: 8px; max-width: 800px; line-height: 1.55;
      }
      .rd-root h1 {
        font-family: 'Space Grotesk', sans-serif; font-size: 28px; font-weight: 600;
        margin: 6px 0 4px 0; letter-spacing: -.01em; color: #2a1418; line-height: 1.15;
      }

      /* TOGGLE CSS */
      .rd-root .rd-toggle-wrap {
        display: flex; align-items: center; gap: 10px; background: #fdf5f5;
        padding: 8px 12px; border-radius: 20px; border: 1px solid #e6d5d5;
      }
      .rd-root .rd-toggle-label {
        font-family: 'Space Grotesk', sans-serif; font-size: 12px; font-weight: 700;
        color: #2a1418; text-transform: uppercase; letter-spacing: .05em;
      }
      .rd-root .rd-toggle {
        position: relative; display: inline-block; width: 44px; height: 24px;
      }
      .rd-root .rd-toggle input { opacity: 0; width: 0; height: 0; }
      .rd-root .rd-toggle-slider {
        position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
        background-color: #d9bcbc; transition: .4s; border-radius: 24px;
      }
      .rd-root .rd-toggle-slider:before {
        position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px;
        background-color: white; transition: .4s; border-radius: 50%;
      }
      .rd-root .rd-toggle input:checked + .rd-toggle-slider { background-color: #c8102e; }
      .rd-root .rd-toggle input:checked + .rd-toggle-slider:before { transform: translateX(20px); }

      /* NEW LIVE UI CLASSES */
      .rd-root .rd-live-btn {
        background: #c8102e; color: #fff; border: none; padding: 8px 16px; border-radius: 16px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 11px;
        text-transform: uppercase; letter-spacing: .05em; cursor: pointer; transition: background .2s;
      }
      .rd-root .rd-live-btn:hover:not(:disabled) { background: #9c0b23; }
      .rd-root .rd-live-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      
      .rd-root .rd-loading {
        display: inline-block; width: 16px; height: 16px; margin-left: 10px; vertical-align: middle;
        border: 2px solid #e6d5d5; border-radius: 50%; border-top-color: #c8102e;
        animation: rd-spin 1s ease-in-out infinite;
      }
      @keyframes rd-spin { to { transform: rotate(360deg); } }

      .rd-root .rd-error {
        background: #fef2f2; border: 1px solid #f87171; color: #991b1b;
        padding: 10px; border-radius: 6px; margin-bottom: 16px; font-size: 12px;
      }

      .rd-root .rd-status-badge {
        display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 10px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; text-transform: uppercase;
      }
      .rd-root .rd-status-pending { background: #fef9e7; color: #d97706; border: 1px solid #fde68a; }
      .rd-root .rd-status-approved { background: #eaf9f0; color: #0f7a4d; border: 1px solid #a7f3d0; }
      .rd-root .rd-status-rejected { background: #fdecee; color: #c8102e; border: 1px solid #fecdd3; }
      .rd-root .rd-status-deployed { background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; }

      .rd-root .stage-strip {
        display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 16px;
        padding: 12px; background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px;
      }
      .rd-root .stage-pill {
        background: #fff; border: 1px solid #e6d5d5; border-radius: 6px; padding: 12px 10px;
        text-align: center; transition: all .3s; position: relative; opacity: .5; cursor: pointer;
      }
      .rd-root .stage-pill:hover { opacity: .8; }
      .rd-root .stage-pill.active {
        border-color: #c8102e; background: #fdecee; opacity: 1;
        box-shadow: 0 4px 14px rgba(200,16,46,.12);
      }
      .rd-root .stage-pill.done { border-color: #0f7a4d; background: #eaf9f0; opacity: 1; }
      .rd-root .stage-num {
        display: inline-block; width: 24px; height: 24px; border-radius: 50%;
        background: #c8102e; color: #fff; font-family: 'Space Grotesk', sans-serif;
        font-weight: 700; font-size: 11px; line-height: 24px; margin-bottom: 6px;
      }
      .rd-root .stage-pill.done .stage-num { background: #0f7a4d; }
      .rd-root .stage-pill.done .stage-num::after { content: '\\2713'; }
      .rd-root .stage-pill.done .stage-num-txt { display: none; }
      .rd-root .stage-title {
        font-family: 'Space Grotesk', sans-serif; font-size: 11px; font-weight: 700;
        letter-spacing: .05em; text-transform: uppercase; color: #2a1418;
      }
      .rd-root .stage-sub {
        font-size: 9.5px; color: #7a5a5f; margin-top: 3px; line-height: 1.3;
      }
      .rd-root .nav-bar {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 16px; padding: 8px 4px; gap: 12px; flex-wrap: wrap;
      }
      .rd-root .nav-info {
        font-family: 'Space Grotesk', sans-serif; font-size: 11px; color: #7a5a5f;
        text-transform: uppercase; letter-spacing: .06em; font-weight: 700;
      }
      .rd-root .nav-info b { color: #9c0b23; font-size: 13px; }
      .rd-root button.nav {
        padding: 10px 20px; border-radius: 22px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 12px;
        letter-spacing: .05em; text-transform: uppercase; cursor: pointer;
        display: inline-flex; align-items: center; gap: 8px;
        transition: background .15s, transform .1s;
      }
      .rd-root button.nav.primary { background: #c8102e; color: #fff; border: none; }
      .rd-root button.nav.primary:hover:not(:disabled) { background: #9c0b23; }
      .rd-root button.nav.ghost { background: #fff; color: #c8102e; border: 1px solid #c8102e; }
      .rd-root button.nav.ghost:hover:not(:disabled) { background: #fdecee; }
      .rd-root button.nav:disabled { opacity: .35; cursor: not-allowed; }
      .rd-root button.nav:active:not(:disabled) { transform: scale(.97); }
      .rd-root button.nav .step-indicator {
        background: rgba(255,255,255,.25); padding: 2px 8px; border-radius: 10px;
        font-size: 10px; margin-left: 4px;
      }
      .rd-root .canvas {
        background: #fff; border: 1px solid #e6d5d5; border-radius: 10px;
        padding: 24px; min-height: 560px; position: relative; overflow: hidden;
      }
      .rd-root .stage { display: block; animation: rd-fadeIn .4s ease; }
      @keyframes rd-fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
      .rd-root h2.stage-h {
        font-family: 'Space Grotesk', sans-serif; font-size: 20px; font-weight: 600;
        margin: 0 0 6px 0; color: #9c0b23;
      }
      .rd-root .stage-desc {
        color: #7a5a5f; font-size: 13px; line-height: 1.55; max-width: 760px; margin-bottom: 20px;
      }

      /* Stage 1: CMDB */
      .rd-root .cmdb-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
      .rd-root .cmdb-panel {
        border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px; background: #fdf5f5;
      }
      .rd-root .cmdb-panel h4 {
        margin: 0 0 12px 0; font-family: 'Space Grotesk', sans-serif; font-size: 12px;
        letter-spacing: .08em; text-transform: uppercase; color: #c8102e;
      }
      .rd-root .ci-row {
        display: grid; grid-template-columns: 1fr 2fr; gap: 8px; align-items: center;
        padding: 8px 10px; margin-bottom: 6px; background: #fff; border-radius: 5px;
        border: 1px solid #e6d5d5; font-size: 11.5px;
        animation: rd-slideIn .3s ease;
      }
      @keyframes rd-slideIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
      .rd-root .ci-name { font-family: 'Space Grotesk', sans-serif; font-weight: 700; color: #2a1418; }
      .rd-root .ci-tools { display: flex; gap: 4px; flex-wrap: wrap; }
      .rd-root .tool-badge {
        font-size: 9px; padding: 2px 6px; border-radius: 9px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; color: #fff;
      }
      .rd-root .tool-badge.appd   { background: #0f7a4d; }
      .rd-root .tool-badge.splunk { background: #b45309; }
      .rd-root .tool-badge.oem    { background: #c8102e; }
      .rd-root .tool-badge.dyn    { background: #1e40af; }
      .rd-root .tool-badge.hawk   { background: #7c3aed; }
      .rd-root .tool-badge.fnet   { background: #0e7490; }
      .rd-root .tool-badge.default { background: #64748b; }
      .rd-root .cmdb-stats {
        display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 14px;
      }
      .rd-root .cmdb-stat {
        background: #fff; border: 1px solid #e6d5d5; border-radius: 5px; padding: 8px;
        text-align: center;
      }
      .rd-root .cmdb-stat .n {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700;
        font-size: 20px; color: #9c0b23;
      }
      .rd-root .cmdb-stat .l {
        font-size: 9px; color: #7a5a5f; text-transform: uppercase;
        letter-spacing: .06em; font-weight: 700; margin-top: 2px;
      }

      /* Stage 2: Pattern Mining */
      .rd-root .mining-layout { display: grid; gap: 20px; }
      .rd-root .alert-stream {
        background: #0f172a; color: #e2e8f0; border-radius: 8px; padding: 14px;
        height: 360px; overflow: hidden;
        font-family: 'IBM Plex Mono', monospace; font-size: 10.5px; line-height: 1.6;
      }
      .rd-root .alert-stream .hdr {
        color: #64748b; margin-bottom: 8px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700;
        text-transform: uppercase; font-size: 10px; letter-spacing: .08em;
      }
      .rd-root .alert-line { padding: 2px 0; animation: rd-fadeIn .25s ease; }
      .rd-root .alert-line .ts   { color: #94a3b8; }
      .rd-root .alert-line .tool { color: #38bdf8; }
      .rd-root .alert-line .sig  { color: #f97316; }
      .rd-root .alert-line.crit .sig { color: #f43f5e; font-weight: 700; }
      .rd-root .patterns-out {
        background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px;
        padding: 14px; height: 360px; overflow-y: auto;
      }
      .rd-root .patterns-out h4 {
        margin: 0 0 12px 0; font-family: 'Space Grotesk', sans-serif; font-size: 12px;
        letter-spacing: .08em; text-transform: uppercase; color: #c8102e;
      }
      .rd-root .pattern-card {
        background: #fff; border: 1px solid #e6d5d5; border-left: 3px solid #c8102e;
        border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;
        animation: rd-slideIn .35s ease;
      }
      .rd-root .pattern-title {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700;
        font-size: 11.5px; color: #2a1418;
      }
      .rd-root .pattern-meta {
        font-size: 10px; color: #7a5a5f; margin-top: 4px; line-height: 1.5;
      }
      .rd-root .pattern-meta b { color: #9c0b23; }

      /* Stage 3: AI Synthesis */
      .rd-root .synth-flow {
        display: grid; grid-template-columns: 1fr 40px 1fr 40px 1fr;
        gap: 0; align-items: stretch;
      }
      .rd-root .synth-box {
        border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px; background: #fff;
      }
      .rd-root .synth-box.input  { border-left: 4px solid #d97706; background: #fef9e7; }
      .rd-root .synth-box.gpt    { border-left: 4px solid #7c3aed; background: #f4edff; }
      .rd-root .synth-box.output { border-left: 4px solid #c8102e; background: #fdecee; }
      .rd-root .synth-arrow {
        display: flex; align-items: center; justify-content: center;
        font-size: 20px; color: #c8102e;
      }
      .rd-root .synth-box h5 {
        font-family: 'Space Grotesk', sans-serif; font-size: 11px;
        letter-spacing: .08em; text-transform: uppercase; color: #7a5a5f;
        margin: 0 0 8px 0; font-weight: 700;
      }
      .rd-root .synth-content { font-size: 11px; line-height: 1.55; color: #2a1418; }
      .rd-root .synth-content code {
        background: rgba(0,0,0,.05); padding: 1px 4px; border-radius: 2px;
        font-size: 10px; color: #9c0b23;
      }
      .rd-root .gpt-log {
        background: #1e1e2e; color: #f0f6fc; border-radius: 5px; padding: 10px;
        font-family: 'IBM Plex Mono', monospace; font-size: 10px; line-height: 1.55;
        height: 180px; overflow-y: auto; margin-top: 8px;
      }
      .rd-root .gpt-log .prompt { color: #94a3b8; }
      .rd-root .gpt-log .comp   { color: #a5f3fc; }
      .rd-root .gpt-log .out    { color: #86efac; }

      /* Stage 4: Human Review */
      .rd-root .review-list { max-width: 900px; }
      .rd-root .rule-proposal {
        background: #fff; border: 1px solid #e6d5d5; border-left: 4px solid #d97706;
        border-radius: 8px; padding: 16px 20px; margin-bottom: 14px;
        animation: rd-slideIn .35s ease;
      }
      .rd-root .rp-hdr {
        display: flex; justify-content: space-between; align-items: flex-start;
        gap: 12px; flex-wrap: wrap;
      }
      .rd-root .rp-id { font-family: 'IBM Plex Mono', monospace; font-size: 10.5px; color: #7a5a5f; }
      .rd-root .rp-name {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 14px;
        color: #2a1418; margin: 4px 0 6px 0;
      }
      .rd-root .rp-conf {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 13px; color: #9c0b23;
      }
      .rd-root .rp-plain {
        font-size: 12px; line-height: 1.55; color: #2a1418;
        background: #fdecee; border-left: 2px solid #c8102e;
        padding: 8px 10px; border-radius: 4px; margin: 8px 0;
      }
      .rd-root .rp-meta {
        display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;
        margin: 10px 0; font-size: 10.5px;
      }
      .rd-root .rp-meta-cell {
        text-align: center; padding: 6px; background: #fdf5f5;
        border: 1px solid #e6d5d5; border-radius: 4px;
      }
      .rd-root .rp-meta-cell b {
        display: block; font-family: 'Space Grotesk', sans-serif; color: #2a1418; font-size: 13px;
      }
      .rd-root .rp-meta-cell span {
        color: #7a5a5f; font-size: 9.5px; text-transform: uppercase;
        letter-spacing: .05em; font-weight: 700;
      }
      .rd-root .rp-actions { display: flex; gap: 8px; margin-top: 10px; }
      .rd-root .rp-btn {
        padding: 6px 14px; border-radius: 16px;
        font-family: 'Space Grotesk', sans-serif; font-weight: 700;
        font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase;
        cursor: pointer; border: none;
      }
      .rd-root .rp-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      .rd-root .rp-btn.approve { background: #0f7a4d; color: #fff; }
      .rd-root .rp-btn.tune    { background: #fff; color: #2a1418; border: 1px solid #d9bcbc; }
      .rd-root .rp-btn.reject  { background: #fff; color: #c8102e; border: 1px solid #c8102e; }

      /* Stage 5: Deployment */
      .rd-root .deploy-diagram {
        display: grid; grid-template-columns: 1fr 60px 1fr;
        gap: 0; align-items: center; margin-bottom: 20px;
      }
      .rd-root .deploy-box {
        background: #fff; border: 1px solid #e6d5d5; border-radius: 8px;
        padding: 20px; text-align: center;
      }
      .rd-root .deploy-box.pending  { border-left: 4px solid #d97706; background: #fef9e7; }
      .rd-root .deploy-box.active-b { border-left: 4px solid #0f7a4d; background: #eaf9f0; }
      .rd-root .deploy-num {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700;
        font-size: 36px; color: #9c0b23;
      }
      .rd-root .deploy-lbl {
        font-family: 'Space Grotesk', sans-serif; font-size: 11px;
        letter-spacing: .08em; text-transform: uppercase; color: #7a5a5f;
        font-weight: 700; margin-top: 4px;
      }
      .rd-root .deploy-arrow { text-align: center; color: #c8102e; font-size: 28px; }
      .rd-root .deploy-panel {
        background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px;
      }
      .rd-root .deploy-log-title {
        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 12px;
        color: #c8102e; letter-spacing: .08em; text-transform: uppercase; margin-bottom: 10px;
      }
      .rd-root .deploy-log-line {
        font-family: 'IBM Plex Mono', monospace; font-size: 11px; color: #7a5a5f;
        padding: 4px 0; border-top: 1px dashed #e6d5d5;
        animation: rd-fadeIn .3s ease;
      }
      .rd-root .deploy-log-line:first-child { border-top: none; }
      .rd-root .deploy-log-line.ok::before  { content: '\\2713 '; color: #0f7a4d; font-weight: 700; }
      .rd-root .deploy-log-line.act::before { content: '\\2192 '; color: #c8102e; font-weight: 700; }
      .rd-root .deploy-log-line b { color: #2a1418; }

      .rd-root .architecture-note {
        background: #fdf5f5; border: 1px solid #e6d5d5; border-left: 4px solid #c8102e;
        border-radius: 6px; padding: 12px 16px; margin-top: 20px; font-size: 11.5px;
        line-height: 1.55; color: #7a5a5f;
      }
      .rd-root .architecture-note b { color: #2a1418; }
      .rd-root .rd-footer {
        margin-top: 24px; padding-top: 16px; border-top: 1px solid #e6d5d5;
        font-size: 10.5px; color: #b8a0a3; text-align: center;
      }

      @media (max-width: 900px) {
        .rd-root .cmdb-grid,
        .rd-root .mining-layout { grid-template-columns: 1fr; }
        .rd-root .synth-flow { grid-template-columns: 1fr; }
        .rd-root .synth-arrow { transform: rotate(90deg); padding: 8px 0; }
      }
    `}</style>
    );
}