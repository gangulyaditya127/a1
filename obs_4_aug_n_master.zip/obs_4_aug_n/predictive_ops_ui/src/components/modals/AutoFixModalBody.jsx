import { useEffect, useState } from 'react';

const AGENT_STEPS = [
    { target: 'PaymentDB', action: 'Restart PaymentDB connection pool + kill blocked sessions.', metric: 'TX latency 4000ms ➔ 240ms' },
    { target: 'MessageQueue', action: 'Purge poison messages & scale consumer group 3 ➔ 8 pods.', metric: 'queue.depth 52k ➔ 1.2k' },
    { target: 'MainframeGW', action: 'Failover GW-MF01 ➔ GW-MF02 (standby).', metric: 'GW timeouts cleared' },
    { target: 'OrderService', action: 'Rolling restart of OrderService replicas (3/3).', metric: 'P95 2800ms ➔ 380ms' }
];

const LOG_STREAM = [
    "[heal] Self-Healing Agent engaged - runbook cascade-recovery.v3 selected.",
    "[heal] Executing on PaymentDB: Restart PaymentDB connection pool + kill blocked sessions",
    "[heal] Executing on MessageQueue: Purge poison messages & scale consumer group 3 -> 8 pods",
    "[heal] Executing on MainframeGW: Failover GW-MF01 -> GW-MF02 (standby)",
    "[heal] Executing on OrderService: Rolling restart of OrderService replicas (3/3)",
    "[heal] Post-heal probes: Oracle EM - AppD - Splunk - HP BSM -> all green.",
    "[heal] Incident INC0048291 auto-resolved. No human intervention required."
];

export default function AutoFixModalBody({ onComplete }) {
    const [logs, setLogs] = useState([]);
    const [activeStepIdx, setActiveStepIdx] = useState(-1);
    const [isFixing, setIsFixing] = useState(true);

    useEffect(() => {
        let isMounted = true;

        LOG_STREAM.forEach((log, index) => {
            setTimeout(() => {
                if (!isMounted) return;
                setLogs(prev => [...prev, log]);

                // Sync the visual cards with the log stream progress
                if (index >= 1 && index <= 4) setActiveStepIdx(index - 1);
                if (index === 5) setActiveStepIdx(4); // Mark all as done

                // Finish sequence
                if (index === LOG_STREAM.length - 1) {
                    setIsFixing(false);
                    if (onComplete) onComplete();
                }
            }, index * 900); // 900ms delay per output line
        });

        return () => { isMounted = false; };
    }, [onComplete]);

    return (
        <div>
            <div className="rb-tag" style={{ marginBottom: '16px' }}>runbook: cascade-recovery.v3</div>

            <div className="agent-steps-grid">
                {AGENT_STEPS.map((step, i) => (
                    <div key={i} className={`agent-step ${activeStepIdx === i ? 'active' : activeStepIdx > i ? 'done' : ''}`}>
                        <div className="agent-step-target">{step.target}</div>
                        <div className="agent-step-action">{step.action}</div>
                        <div className="agent-step-metric">{step.metric}</div>
                    </div>
                ))}
            </div>

            <h4 className="agent-term-title">Agentic Reasoning Stream</h4>
            <div className="agent-term">
                {logs.map((log, i) => {
                    const isHeal = log.startsWith('[heal]');
                    const text = log.replace('[heal] ', '');
                    return (
                        <div key={i}>
                            {isHeal && <span className="heal-tag">[heal]</span>} {text}
                        </div>
                    );
                })}
                {isFixing && <span className="blink">_</span>}
            </div>
        </div>
    );
}