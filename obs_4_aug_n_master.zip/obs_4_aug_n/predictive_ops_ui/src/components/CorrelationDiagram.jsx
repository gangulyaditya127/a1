export default function CorrelationDiagram({ corrData, tiers }) {
  const map = {};
  corrData.nodes.forEach(n => { map[n.id] = n; });

  const buildEdge = ([a, b], crit) => {
    const A = map[a], B = map[b];
    const dx = B.x - A.x, dy = B.y - A.y;
    const len = Math.sqrt(dx * dx + dy * dy);
    const ux = dx / len, uy = dy / len;
    const padA = Math.max(A.w / 2, A.h / 2) * 0.85;
    const padB = Math.max(B.w / 2, B.h / 2) * 0.85;
    return `M ${A.x + ux * padA} ${A.y + uy * padA} L ${B.x - ux * padB} ${B.y - uy * padB}`;
  };

  return (
    <div className="corr-panel">
      <div className="corr-title">
        <span>Correlation across application tiers</span>
        <span style={{fontFamily:'var(--mono)',fontSize:11,color:'var(--text-dim)',fontWeight:400}}>Red edges = correlated fault chain · ★ = root cause</span>
      </div>
      <div className="lane-headers">
        {corrData.laneMeta.map((l, i) => (
          <div key={i} className={'lane-header ' + l.level}>
            {l.name}
            <div className="cnt">{tiers[i]?.alertCount || 0} alerts</div>
          </div>
        ))}
      </div>
      <div className="lane-arrows">
        <div className="ar">→</div><div className="ar">→</div><div className="ar">→</div><div className="ar">→</div><div className="ar" />
      </div>
      <svg viewBox="0 0 1250 400" className="corr-svg">
        <g>
          {corrData.edges.map((e, i) => (
            <path key={'e'+i} d={buildEdge(e, false)} className="cedge" />
          ))}
          {corrData.critEdges.map((e, i) => (
            <path key={'ce'+i} d={buildEdge(e, true)} className="cedge crit" />
          ))}
        </g>
        <g>
          {corrData.nodes.map(n => (
            <g key={n.id}>
              <rect
                x={n.x - n.w / 2} y={n.y - n.h / 2}
                width={n.w} height={n.h}
                className={'cnode-rect ' + n.level + (n.rc ? ' rc-node' : '')}
              />
              <text x={n.x} y={n.y - 4} className="cnode-label">{n.label}</text>
              <text x={n.x} y={n.y + 11} className="cnode-sub">{n.sub}</text>
              {n.rc && (
                <text x={n.x} y={n.y - n.h / 2 - 8} className="rc-flag" textAnchor="middle">★ ROOT CAUSE</text>
              )}
            </g>
          ))}
        </g>
      </svg>
    </div>
  );
}
