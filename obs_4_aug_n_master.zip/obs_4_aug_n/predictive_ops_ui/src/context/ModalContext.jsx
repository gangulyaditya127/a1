import { createContext, useContext, useState, useCallback, useEffect } from 'react';

const ModalContext = createContext(null);

export function ModalProvider({ children }) {
  const [modal, setModal] = useState(null); // {title, id, body}
  const openModal = useCallback(({ title, id, body }) => setModal({ title, id, body }), []);
  const closeModal = useCallback(() => setModal(null), []);

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') closeModal(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [closeModal]);

  return (
    <ModalContext.Provider value={{ openModal, closeModal }}>
      {children}
      {modal && (
        <div className="modal-back" onClick={closeModal}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <div>
                <div className="mtitle">{modal.title}</div>
                <div className="mid">{modal.id}</div>
              </div>
              <button className="mclose" onClick={closeModal}>×</button>
            </div>
            <div className="modal-body">{modal.body}</div>
          </div>
        </div>
      )}
    </ModalContext.Provider>
  );
}
export function useModal() { return useContext(ModalContext); }
