# ARE Platform Skeleton

Linux/Mac: ./run.sh
Windows: run.bat

API Endpoints:
- GET /
- GET /api/v1/health
