from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.event_corr.db import get_db
from datetime import datetime, date
from app.event_corr.models import ApplicationMetrics,EventLog
from pydantic import BaseModel

# ... your existing code ...
router = APIRouter()
@router.get("/applications", response_model=List[str])
def get_distinct_applications(db: Session = Depends(get_db)):
    """
    Returns a list of distinct application names from the application_metrices table.
    """
    # Fetch distinct application names
    distinct_apps = db.query(ApplicationMetrics.application).distinct().all()
    
    # SQLAlchemy returns a list of tuples, e.g., [('Policy Administration System',), ...]
    # We extract the first element of each tuple to return a clean list of strings
    return [app[0] for app in distinct_apps if app[0]]

import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from app.event_corr.db import get_db
from app.event_corr.models import ApplicationMetrics

# ============================================================
# 1. Fetch Journeys for an Application
# ============================================================
@router.get("/applications/{application}/journeys", response_model=List[str])
def get_journeys_by_application(
    application: str,
    db: Session = Depends(get_db)
):
    """
    Given an application name, returns a list of distinct journeys.
    """
    distinct_journeys = db.query(ApplicationMetrics.journey).filter(
        ApplicationMetrics.application == application
    ).distinct().all()
    
    return [j[0] for j in distinct_journeys if j[0]]

# ============================================================
# 2. Fetch Steps and Actions for an Application & Journey
# ============================================================
@router.get("/applications/{application}/journeys/{journey}/steps", response_model=List[Dict[str, List[str]]])
def get_steps_and_actions(
    application: str,
    journey: str,
    db: Session = Depends(get_db)
):
    """
    Given an application and journey, returns a list of dictionaries mapped as:
    [ { "step_name": ["action_1", "action_2"] } ]
    """
    records = db.query(ApplicationMetrics.step, ApplicationMetrics.action).filter(
        ApplicationMetrics.application == application,
        ApplicationMetrics.journey == journey
    ).all()
    
    # Group actions by step
    step_mapping = {}
    for step, action in records:
        if step not in step_mapping:
            step_mapping[step] = set()
        step_mapping[step].add(action)
        
    # Convert to the requested list of dicts format
    return [{step: list(actions)} for step, actions in step_mapping.items()]

# ============================================================
# 3. Fetch Topology Hierarchy
# ============================================================
@router.get("/topology")
def get_topology_hierarchy(
    application: str = Query(...),
    journey: str = Query(...),
    step: str = Query(...),
    action: str = Query(...),
    db: Session = Depends(get_db)
):
    """
    Given the full breadcrumb path, returns the topology dictionary:
    { "Tier_Name": [ { "Layer_Name": { "log_sources": [...], "source_tag": "..." } } ] }
    """
    records = db.query(ApplicationMetrics).filter(
        ApplicationMetrics.application == application,
        ApplicationMetrics.journey == journey,
        ApplicationMetrics.step == step,
        ApplicationMetrics.action == action
    ).all()
    
    topology = {}
    
    for row in records:
        tier = row.technical_tier
        layer = row.layer
        
        # Parse log_sources from string back to a list if stored as text
        try:
            parsed_sources = json.loads(row.log_sources) if isinstance(row.log_sources, str) else row.log_sources
        except Exception:
            parsed_sources = []

        if tier not in topology:
            topology[tier] = []
            
        topology[tier].append({
            layer: {
                "log_sources": parsed_sources,
                "source_tag": row.source_tag
            }
        })
        
    return topology

class EventFilterRequest(BaseModel):
    # organization: str
    application: str
    journey: str
    step: str
    action: str

# --- 2. Define the Output Model (JSON Response) ---
class RecentEventResponse(BaseModel):
    tier: str
    eventname: str
    event_timestamp: str
    message: str
    severity: str
    layer: str
    source:str

# --- 3. Create the POST API ---
@router.post("/recent_event", response_model=List[RecentEventResponse])
def get_recent_events(
    payload: EventFilterRequest,
    db: Session = Depends(get_db)
):
    """
    Accepts a JSON payload and fetches raw events for a specific action within the last 2 minutes.
    """
    # 1. Parse the timestamp from the JSON payload and calculate the 2-minute window
    # try:
    #     clean_timestamp = payload.current_timestamp.replace("Z", "+00:00")
    #     end_dt = datetime.fromisoformat(clean_timestamp).replace(tzinfo=None)
    # except ValueError:
    #     end_dt = datetime.now()

    # start_dt = end_dt - timedelta(minutes=2)

    # 2. Build the base hierarchy query using the JSON payload & Direct DateTime Filtering
    query = db.query(EventLog).filter(
        # PolicyEventLog.organization == payload.organization,
        EventLog.application == payload.application,
        EventLog.journey == payload.journey,
        EventLog.step == payload.step,
        EventLog.action == payload.action,
        # PolicyEventLog.event_timestamp >= start_dt, # <-- CHANGED: Direct DateTime comparison
        # PolicyEventLog.event_timestamp <= end_dt
    )

    # 3. Fetch and sort chronologically
    events = query.order_by(EventLog.event_timestamp.asc()).all()

    # 4. Format the output
    formatted_events = []
    for event in events:
        formatted_events.append(
            RecentEventResponse(
                tier=event.tier,
                eventname=event.eventname,
                event_timestamp=event.event_timestamp.strftime("%H:%M:%S"), # Returns exactly "14:05:00" format
                message=event.message,
                severity=event.severity,
                layer=event.layer,
                source=event.source,
            )
        )

    return formatted_events

from typing import Optional

class EventFilterRequest(BaseModel):
    application: str
    journey: str
    step: str
    action: str

class RCADetails(BaseModel):
    alert_name: str
    layer: str
    timestamp: str
    rca_summary: str
    confidence: int

class NodeAlert(BaseModel):
    eventname: str
    severity: str
    timestamp: str
    source: str

class NodeDetail(BaseModel):
    id: str  # Matches the layer name
    tier: str
    status: str
    alert_count: int
    alerts: List[NodeAlert]

class EdgeDetail(BaseModel):
    source: str
    target: str
    is_fault_path: bool

class IncidentGraphResponse(BaseModel):
    root_cause: Optional[RCADetails]
    nodes: List[NodeDetail]
    edges: List[EdgeDetail]



from datetime import datetime
from typing import Dict, Any, List
import openai

# 1. Initialize your custom OpenAI client
client = openai.OpenAI(
    api_key="sk-Lve5YG_C0MzROtFtphZQyw",
    base_url="http://10.73.74.36:20119/v1"
)

# 2. Rule-Based Scoring Engine
def calculate_rule_based_rca(alerts: List[Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Applies deterministic scoring and priority rules from YAML config.
    """
    if not alerts:
        return {"root_cause": None, "score": 0}

    priority_list = config.get("root_cause_priority", [])
    splunk_patterns = config.get("splunk_override", {}).get("root_patterns", [])
    
    scored_alerts = []
    
    for alert in alerts:
        score = 50 # Base score
        event_name = getattr(alert, "eventname", "")
        source = getattr(alert, "source", "").lower()
        tier = getattr(alert, "tier", "").lower()
        
        # Rule 1: Splunk Overrides (Highest Boost)
        if "splunk" in source and any(p.lower() in event_name.lower() for p in splunk_patterns):
            score += 40
            
        # Rule 2: Priority List Matching
        if any(p.lower() in event_name.lower() for p in priority_list):
            score += 25
            
        # Rule 3: Tier Depth Weighting (Infrastructure/Data > Presentation)
        if tier in ["data", "infrastructure"]:
            score += 15
        elif tier == "integration":
            score += 10
            
        # Rule 4: Critical Severity
        if getattr(alert, "severity", "").lower() == "critical":
            score += 10

        # Cap max score at 99%
        final_score = min(score, 99)
        scored_alerts.append((final_score, alert))

    # Sort descending by calculated score
    scored_alerts.sort(key=lambda x: x[0], reverse=True)
    best_score, root_alert = scored_alerts[0]

    return {
        "root_cause_alert": root_alert,
        "confidence_score": best_score,
        "all_scored": scored_alerts
    }


# 3. LLM Natural Language Summary Generator
def generate_llm_rca_summary(root_alert: Any, all_alerts: List[Any], confidence: int) -> str:
    """
    Sends the rule-engine results to gpt-4o-mini to draft a technical RCA summary.
    """
    # Format raw alerts into text for the LLM prompt
    alert_summary_text = "\n".join([
        f"- [{a.event_timestamp}] Tier: {a.tier} | Layer: {getattr(a, 'layer', 'N/A')} | "
        f"Source: {a.source} | Event: {a.eventname} | Message: {a.message}"
        for a in all_alerts
    ])

    prompt = f"""
You are an expert AIOps Site Reliability Engineer. 
Our deterministic rule engine has identified the primary Root Cause with {confidence}% confidence.

Root Cause Event:
- Event Name: {root_alert.eventname}
- Tier / Layer: {root_alert.tier} / {getattr(root_alert, 'layer', 'N/A')}
- Source: {root_alert.source}
- Details: {root_alert.message}

All Correlated Cascade Alerts (Chronological):
{alert_summary_text}

Task:
Provide a clear, concise 2-3 sentence executive Root Cause Analysis (RCA) summary explaining:
1. What failed first at the backend/infrastructure layer.
2. How the failure cascaded up to the user interface/APIs.
3. Keep the tone professional and directly usable in an incident management ticket.
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        # Fallback if the LLM service is unreachable
        return f"Automated RCA: Primary failure detected on {root_alert.tier} tier ({root_alert.eventname}) causing downstream cascade."

import openai

# 1. Initialize custom OpenAI Client
llm_client = openai.OpenAI(
    api_key="sk-Lve5YG_C0MzROtFtphZQyw",
    base_url="http://10.73.74.36:20119/v1"
)

# 2. Define Rule-Based Config (Mapped from your YAML)
RCA_CONFIG = {
    "priority_list": [
        "SQLTimeoutException", "Backend_Call_Response_Time_High", 
        "JVM_GC_Time_High", "JVM_Heap_Memory_Critical", 
        "Thread_Pool_Queue_Critical", "Node_CPU_Utilization_Critical",
        "Business_Transaction_Response_Time_High", "Business_Transaction_Error_Rate_High"
    ],
    "splunk_patterns": [
        "Slow_Query_Detected", "NullPointerException", 
        "Retry_Without_Backoff", "Backend_Exception"
    ]
}

@router.post("/event/graph", response_model=IncidentGraphResponse)
def event_dependency_graph(
    payload: EventFilterRequest,
    db: Session = Depends(get_db)
):
    """
    Dynamically generates the Graph Topology (Nodes & Edges) and Root Cause 
    based on the raw EventLogs, utilizing a Hybrid Rule+LLM Engine.
    """
    
    # 1. Fetch static topology nodes for this exact hierarchy
    topology_nodes = db.query(ApplicationMetrics).filter(
        ApplicationMetrics.application == payload.application,
        ApplicationMetrics.journey == payload.journey,
        ApplicationMetrics.step == payload.step,
        ApplicationMetrics.action == payload.action
    ).all()

    # 2. Fetch all raw events for this hierarchy sorted chronologically
    alerts = db.query(EventLog).filter(
        EventLog.application == payload.application,
        EventLog.journey == payload.journey,
        EventLog.step == payload.step,
        EventLog.action == payload.action
    ).order_by(EventLog.event_timestamp.asc()).all()

    # Helper for formatting timestamps consistently
    def format_ts(ts):
        if hasattr(ts, "strftime"):
            return ts.strftime("%H:%M:%S")
        return str(ts)

    # 3. Group active alerts by layer
    alerts_by_layer: Dict[str, List[EventLog]] = {}
    for alert in alerts:
        layer = getattr(alert, "layer", "Unknown")
        if layer not in alerts_by_layer:
            alerts_by_layer[layer] = []
        alerts_by_layer[layer].append(alert)

    # 4. Build Nodes payload
    graph_nodes = []
    alerted_layers = set()

    for node in topology_nodes:
        layer_alerts = alerts_by_layer.get(node.layer, [])
        alert_count = len(layer_alerts)
        
        status = "HEALTHY"
        if alert_count > 0:
            alerted_layers.add(node.layer)
            severities = [a.severity.lower() for a in layer_alerts if a.severity]
            if "critical" in severities:
                status = "CRITICAL"
            elif "high" in severities or "medium" in severities:
                status = "DEGRADED"

        tier_value = getattr(node, "technical_tier", None) or getattr(node, "tecnical_tier", "Unknown")

        graph_nodes.append(
            NodeDetail(
                id=node.layer,
                tier=tier_value,
                status=status,
                alert_count=alert_count,
                alerts=[
                    NodeAlert(
                        eventname=a.eventname,
                        severity=a.severity,
                        timestamp=format_ts(a.event_timestamp),
                        source=a.source
                    ) for a in layer_alerts
                ]
            )
        )

    # 5. Define standard Edges based on UI Architecture
    standard_edges = [
        {"source": "Digital Experience Monitor", "target": "Application Server"},
        {"source": "Digital Experience Monitor", "target": "Business Rules Engine"},
        {"source": "Load Balancer", "target": "Application Server"},
        {"source": "Application Server", "target": "Enterprise Service Bus"},
        {"source": "Business Rules Engine", "target": "Enterprise Service Bus"},
        {"source": "Enterprise Service Bus", "target": "Primary Database"},
        {"source": "Enterprise Service Bus", "target": "Document Management"},
        {"source": "Enterprise Service Bus", "target": "Cache Layer"},
        {"source": "Primary Database", "target": "Compute / Virtualization"},
        {"source": "Document Management", "target": "Storage"},
        {"source": "Cache Layer", "target": "Network"}
    ]

    # 6. Build Edges payload & mark correlated fault paths
    graph_edges = []
    for edge in standard_edges:
        is_fault = (edge["source"] in alerted_layers) and (edge["target"] in alerted_layers)
        graph_edges.append(
            EdgeDetail(
                source=edge["source"],
                target=edge["target"],
                is_fault_path=is_fault
            )
        )

    # 7. Hybrid Root Cause Deduction (Rule Engine + LLM)
    rca_details = None
    if alerts:
        scored_alerts = []
        
        # A. Apply Deterministic Scoring Rules
        for alert in alerts:
            score = 50 # Base Score
            event_name = getattr(alert, "eventname", "")
            source = getattr(alert, "source", "").lower()
            tier = getattr(alert, "tier", "").lower()
            severity = getattr(alert, "severity", "").lower()

            # Rule 1: Splunk Overrides (Highest Precedence)
            if "splunk" in source and any(p.lower() in event_name.lower() for p in RCA_CONFIG["splunk_patterns"]):
                score += 40
            
            # Rule 2: High Priority Health Rules
            if any(p.lower() in event_name.lower() for p in RCA_CONFIG["priority_list"]):
                score += 25
            
            # Rule 3: Tier Depth Weighting
            if tier in ["data", "infrastructure"]:
                score += 15
            elif tier == "integration":
                score += 10
                
            # Rule 4: Critical Severity
            if severity == "critical":
                score += 10

            final_score = min(score, 99) # Cap at 99%
            
            # Handle timestamps for tie-breaking
            ts = alert.event_timestamp
            if not isinstance(ts, datetime) and hasattr(ts, "strftime"):
                ts = datetime.combine(date.today(), ts)
                
            scored_alerts.append((final_score, ts, alert))

        # Sort Descending by Score, then Ascending by Time
        scored_alerts.sort(key=lambda x: (-x[0], x[1]))
        
        best_score, _, root_cause_alert = scored_alerts[0]
        rca_layer = getattr(root_cause_alert, "layer", "Backend Layer")

        # B. Ask LLM to generate Narrative Summary based on Rules output
        alert_summary_text = "\n".join([
            f"- Tier: {a.tier} | Layer: {getattr(a, 'layer', 'N/A')} | Source: {a.source} | Event: {a.eventname}"
            for a in alerts
        ])

        prompt = f"""
        You are an expert AIOps Site Reliability Engineer. 
        Our deterministic rule engine has identified the primary Root Cause with {best_score}% confidence.

        Root Cause Event:
        - Event Name: {root_cause_alert.eventname}
        - Tier / Layer: {getattr(root_cause_alert, 'tier', 'Unknown')} / {rca_layer}
        - Source: {root_cause_alert.source}
        - Details: {getattr(root_cause_alert, 'message', 'N/A')}

        All Correlated Cascade Alerts (Chronological):
        {alert_summary_text}

        Task:
        Provide a clear, concise 2-3 sentence executive Root Cause Analysis (RCA) summary explaining:
        1. What failed first at the backend/infrastructure layer.
        2. How the failure cascaded up to the user interface/APIs.
        3. Keep the tone professional and directly usable in an incident management ticket.
        """

        try:
            llm_response = llm_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2
            )
            rca_narrative = llm_response.choices[0].message.content.strip()
        except Exception as e:
            # Fallback narrative if the LLM endpoint fails or times out
            rca_narrative = f"Automated RCA: {rca_layer} degradation detected due to {root_cause_alert.eventname}. Upstream cascade impact triggered."

        # C. Construct final RCA Object
        rca_details = RCADetails(
            alert_name=root_cause_alert.eventname,
            layer=rca_layer,
            timestamp=format_ts(root_cause_alert.event_timestamp),
            rca_summary=rca_narrative,
            confidence=best_score
        )

    return IncidentGraphResponse(
        root_cause=rca_details,
        nodes=graph_nodes,
        edges=graph_edges
    )

# Shared log detail model
class AlertDetail(BaseModel):
    eventname: str
    severity: str
    timestamp: str
    message: str
    layer: str

# Models for Requirement 1 (Kanban View: Tier -> Source)
class SourceSummary(BaseModel):
    source_name: str
    alert_count: int
    status: str

# Models for Requirement 2 (Graph Side Panel: Tier -> Layer -> Source)
class LayerSource(BaseModel):
    source_name: str
    alert_count: int
    status: str
    alerts: List[AlertDetail]

class LayerDetail(BaseModel):
    layer_name: str
    source_tag: str
    status: str
    alert_count: int
    sources: List[LayerSource]

# Main Merged Response
class TierColumnData(BaseModel):
    tier_name: str
    tier_status: str
    total_alerts: int
    
    # Requirement 1: Tier -> Source -> Logs (For the Kanban Board)
    event_summary: List[SourceSummary]
    raw_alerts: Dict[str, List[AlertDetail]] 
    
    # Requirement 2: Tier -> Layer -> Source -> Logs (For the Graph Side Panel)
    layers: List[LayerDetail]


@router.post("/tier_board", response_model=List[TierColumnData])
def get_merged_tier_board(
    payload: EventFilterRequest,
    db: Session = Depends(get_db)
):
    """
    Merges static topology and active alerts.
    Provides data grouped by Tier->Source (Req 1) AND Tier->Layer->Source (Req 2).
    """
    # 1. Fetch Topology & Events
    topology_nodes = db.query(ApplicationMetrics).filter(
        ApplicationMetrics.application == payload.application,
        ApplicationMetrics.journey == payload.journey,
        ApplicationMetrics.step == payload.step,
        ApplicationMetrics.action == payload.action
    ).all()

    events = db.query(EventLog).filter(
        EventLog.application == payload.application,
        EventLog.journey == payload.journey,
        EventLog.step == payload.step,
        EventLog.action == payload.action
    ).order_by(EventLog.event_timestamp.asc()).all()

    def format_ts(ts):
        if hasattr(ts, "strftime"): return ts.strftime("%H:%M:%S")
        return str(ts)

    def get_status_from_alerts(alerts_list):
        if not alerts_list: return "HEALTHY"
        sevs = [a.severity.lower() for a in alerts_list if a.severity]
        if "critical" in sevs: return "CRITICAL"
        if "high" in sevs or "medium" in sevs: return "DEGRADED"
        return "HEALTHY"

    # 2. Build the Topology Skeleton
    tier_map = {}
    
    for node in topology_nodes:
        tier = getattr(node, "technical_tier", None) or getattr(node, "tecnical_tier", "Unknown")
        layer = node.layer
        source_tag = node.source_tag or ""
        
        try:
            sources = json.loads(node.log_sources) if isinstance(node.log_sources, str) else node.log_sources
        except:
            sources = []

        if tier not in tier_map:
            tier_map[tier] = {
                "tier_alerts_by_source": {}, # For Req 1
                "layers": {}                 # For Req 2
            }
            
        tier_map[tier]["layers"][layer] = {
            "source_tag": source_tag,
            "layer_alerts_by_source": {src: [] for src in sources} # Initialize empty logs for every known source
        }
        
        for src in sources:
            if src not in tier_map[tier]["tier_alerts_by_source"]:
                tier_map[tier]["tier_alerts_by_source"][src] = []

    # 3. Slot Events into the Skeleton
    for event in events:
        tier = event.tier
        layer = event.layer
        src = event.source
        
        alert_detail = AlertDetail(
            eventname=event.eventname,
            severity=event.severity,
            timestamp=format_ts(event.event_timestamp),
            message=event.message,
            layer=event.layer
        )

        # Failsafes for dynamic events not in topology
        if tier not in tier_map:
            tier_map[tier] = {"tier_alerts_by_source": {}, "layers": {}}
        if layer not in tier_map[tier]["layers"]:
            tier_map[tier]["layers"][layer] = {"source_tag": "Dynamic", "layer_alerts_by_source": {}}
        if src not in tier_map[tier]["tier_alerts_by_source"]:
            tier_map[tier]["tier_alerts_by_source"][src] = []
        if src not in tier_map[tier]["layers"][layer]["layer_alerts_by_source"]:
            tier_map[tier]["layers"][layer]["layer_alerts_by_source"][src] = []

        # Add to Tier-Level Grouping (Req 1)
        tier_map[tier]["tier_alerts_by_source"][src].append(alert_detail)
        
        # Add to Layer-Level Grouping (Req 2)
        tier_map[tier]["layers"][layer]["layer_alerts_by_source"][src].append(alert_detail)

    # 4. Format the Final Response
    response = []
    standard_order = {"Presentation": 1, "Application": 2, "Integration": 3, "Data": 4, "Infrastructure": 5, "PRESENTATION": 1, "APPLICATION": 2, "INTEGRATION": 3, "DATA": 4, "INFRASTRUCTURE": 5}
    sorted_tiers = sorted(tier_map.keys(), key=lambda t: standard_order.get(t, 99))

    for tier in sorted_tiers:
        tier_data = tier_map[tier]
        
        # Prepare Req 1 Data (Tier -> Source)
        all_tier_alerts = [a for alerts in tier_data["tier_alerts_by_source"].values() for a in alerts]
        event_summary = []
        for src, alerts in tier_data["tier_alerts_by_source"].items():
            event_summary.append(
                SourceSummary(source_name=src, alert_count=len(alerts), status=get_status_from_alerts(alerts))
            )
        
        # Filter raw alerts to only include sources that actually have errors
        raw_alerts = {src: alerts for src, alerts in tier_data["tier_alerts_by_source"].items() if alerts}

        # Prepare Req 2 Data (Tier -> Layer -> Source)
        formatted_layers = []
        for layer_name, layer_data in tier_data["layers"].items():
            all_layer_alerts = [a for alerts in layer_data["layer_alerts_by_source"].values() for a in alerts]
            
            layer_sources = []
            for src, alerts in layer_data["layer_alerts_by_source"].items():
                layer_sources.append(
                    LayerSource(
                        source_name=src,
                        alert_count=len(alerts),
                        status=get_status_from_alerts(alerts),
                        alerts=alerts # Includes empty [] if no errors, which is great for UI healthy state
                    )
                )
            
            formatted_layers.append(
                LayerDetail(
                    layer_name=layer_name,
                    source_tag=layer_data["source_tag"],
                    status=get_status_from_alerts(all_layer_alerts),
                    alert_count=len(all_layer_alerts),
                    sources=layer_sources
                )
            )

        response.append(
            TierColumnData(
                tier_name=tier,
                tier_status=get_status_from_alerts(all_tier_alerts),
                total_alerts=len(all_tier_alerts),
                event_summary=event_summary,
                raw_alerts=raw_alerts,
                layers=formatted_layers # <--- Requirement 2 is fully accessible here
            )
        )

    return response