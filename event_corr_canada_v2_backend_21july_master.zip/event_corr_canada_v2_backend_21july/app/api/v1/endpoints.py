from fastapi import APIRouter, Query, Depends, Response, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
from typing import List
from pydantic import BaseModel
import json
import os
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from app.event_corr.db import get_db
from app.event_corr.models import TimelineBreakdownResponse, PolicyEventLog, Correlation
from app.event_corr.engine import build_db_timeline_breakdown, run_db_correlation

router = APIRouter()

@router.post("/engine/run")
def trigger_correlation(db: Session = Depends(get_db)):
    """Triggers the background task to bucket events into 2-minute windows and save to DB."""
    return run_db_correlation(db)


# ============================================================
# CONFIGURATION
# ============================================================

JSON_FILE = Path(
    os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "synthetic_observability_logs-2.json",
    )
)

SOURCE_START_SECONDS = 14 * 60 * 60
WINDOW_SECONDS = 120
TOTAL_WINDOWS = 5

# ============================================================
# BACKGROUND PROCESS CONTROL
# ============================================================

replay_thread = None
stop_event = threading.Event()
state_lock = threading.Lock()

replay_state = {
    "status": "stopped",
    "current_source_window": None,
    "completed_windows": 0,
    "inserted_records": 0,
    "last_corelation_id": None,
    "last_target_window_start": None,
    "next_insertion_at": None,
    "started_at": None,
    "stopped_at": None,
    "last_error": None,
}

def update_state(**values):
    with state_lock:
        replay_state.update(values)

def get_state():
    with state_lock:
        return dict(replay_state)

def parse_timestamp(timestamp_value):
    return datetime.strptime(timestamp_value, "%H:%M:%S").time()

def time_to_seconds(time_value):
    return time_value.hour * 3600 + time_value.minute * 60 + time_value.second

def get_source_window_index(timestamp_value):
    event_time = parse_timestamp(timestamp_value)
    event_seconds = time_to_seconds(event_time)
    relative_seconds = event_seconds - SOURCE_START_SECONDS

    if not 0 <= relative_seconds < 600:
        raise ValueError(f"Timestamp {timestamp_value} is outside 14:00:00 to 14:09:59")
    return relative_seconds // WINDOW_SECONDS

def get_event_offset(timestamp_value, source_window_index):
    event_time = parse_timestamp(timestamp_value)
    event_seconds = time_to_seconds(event_time)
    source_window_start = SOURCE_START_SECONDS + source_window_index * WINDOW_SECONDS
    offset_seconds = event_seconds - source_window_start

    if not 0 <= offset_seconds < WINDOW_SECONDS:
        raise ValueError(f"Timestamp {timestamp_value} does not belong to window {source_window_index + 1}")
    return offset_seconds

def load_json_windows():
    if not JSON_FILE.exists():
        raise FileNotFoundError(f"JSON file not found: {JSON_FILE}")

    with JSON_FILE.open("r", encoding="utf-8") as file:
        events = json.load(file)

    if not isinstance(events, list):
        raise ValueError("JSON file must contain an array")

    windows = {index: [] for index in range(TOTAL_WINDOWS)}

    for item_index, item in enumerate(events):
        if not isinstance(item, dict):
            raise ValueError(f"JSON item {item_index} must be an object")
        if "timestamp" not in item:
            raise ValueError(f"JSON item {item_index} has no timestamp")
        if "event" not in item:
            raise ValueError(f"JSON item {item_index} has no event object")

        source_window_index = get_source_window_index(item["timestamp"])
        windows[source_window_index].append(item)

    for window_index in range(TOTAL_WINDOWS):
        source_events = windows[window_index]
        if not source_events:
            raise ValueError(f"No events found in source window {window_index + 1}")
        source_events.sort(key=lambda item: item["timestamp"])

    return windows


def insert_source_window(source_events, source_window_index, target_window_start):
    corelation_id = f"CORR-REPLAY-W{source_window_index + 1}-{uuid.uuid4()}"
    records = []

    for item in source_events:
        event_data = item["event"]
        offset_seconds = get_event_offset(
            timestamp_value=item["timestamp"],
            source_window_index=source_window_index,
        )
        mapped_datetime = target_window_start + timedelta(seconds=offset_seconds)

        record = PolicyEventLog(
            organization=item["organization"],
            application=item["application"],
            journey=item["journey"],
            step=item["step"],
            action=item["action"],
            tier=item["tier"],
            event_timestamp=mapped_datetime, # <-- CHANGED: Now saves the full DateTime object
            eventname=event_data["eventname"],
            message=event_data["message"],
            severity=event_data["severity"],
            source=event_data["source"],
        )
        records.append(record)

    session = get_db()
    try:
        session.add_all(records)
        session.commit()
        return {
            "inserted_count": len(records),
            "corelation_id": corelation_id,
            "target_window_start": target_window_start.isoformat(),
            "target_window_end": (target_window_start + timedelta(seconds=WINDOW_SECONDS)).isoformat(),
        }
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def replay_worker():
    try:
        json_windows = load_json_windows()
        source_window_index = 0
        target_window_start = datetime.now().replace(microsecond=0)

        update_state(
            status="running",
            current_source_window=1,
            completed_windows=0,
            inserted_records=0,
            completed_cycles=0,
            last_corelation_id=None,
            last_target_window_start=None,
            next_insertion_at=target_window_start.isoformat(),
            started_at=datetime.now().isoformat(),
            stopped_at=None,
            last_error=None,
        )

        while not stop_event.is_set():
            source_events = json_windows[source_window_index]

            update_state(
                status="running",
                current_source_window=source_window_index + 1,
                next_insertion_at=target_window_start.isoformat(),
            )

            result = insert_source_window(
                source_events=source_events,
                source_window_index=source_window_index,
                target_window_start=target_window_start,
            )

            current_state = get_state()
            completed_windows = current_state["completed_windows"] + 1

            update_values = {
                "completed_windows": completed_windows,
                "inserted_records": current_state["inserted_records"] + result["inserted_count"],
                "last_corelation_id": result["corelation_id"],
                "last_target_window_start": result["target_window_start"],
            }

            print(f"Inserted source window {source_window_index + 1}")
            print(f"Inserted records: {result['inserted_count']}")
            print(f"Corelation ID: {result['corelation_id']}")
            print(f"Mapped target window: {result['target_window_start']} to {result['target_window_end']}")
            
            # --- TRIGGER CORRELATION ENGINE & AI RCA ---
            print("Triggering Correlation Engine & AI RCA Generation...")
            engine_session = get_db()
            try:
                correlation_result = run_db_correlation(engine_session)
                print(f"Engine Output: {correlation_result.get('status', 'Unknown')}")
            except Exception as e:
                print(f"Correlation Engine Error: {e}")
            finally:
                engine_session.close()
            # ------------------------------------------

            source_window_index += 1

            if source_window_index >= TOTAL_WINDOWS:
                source_window_index = 0
                update_values["completed_cycles"] = current_state.get("completed_cycles", 0) + 1
                print("Completed one full cycle. Restarting from source window 1.")

            update_state(**update_values)
            target_window_start += timedelta(seconds=WINDOW_SECONDS)

            update_state(
                current_source_window=source_window_index + 1,
                next_insertion_at=target_window_start.isoformat(),
            )

            print(f"Waiting two minutes before inserting source window {source_window_index + 1}")

            stop_requested = stop_event.wait(timeout=WINDOW_SECONDS)
            if stop_requested:
                break

        update_state(
            status="stopped",
            current_source_window=None,
            next_insertion_at=None,
            stopped_at=datetime.now().isoformat(),
        )
        print("Continuous alert injection stopped.")

    except Exception as error:
        update_state(
            status="failed",
            current_source_window=None,
            next_insertion_at=None,
            last_error=str(error),
            stopped_at=datetime.now().isoformat(),
        )
        print(f"Continuous alert injection failed: {error}")


@router.post("/start")
def start_alert_injection(response: Response):
    global replay_thread

    with state_lock:
        if replay_thread is not None and replay_thread.is_alive():
            response.status_code = status.HTTP_200_OK
            return {
                "status": "already_running",
                "message": "Alert injection is already running",
                "replay": dict(replay_state),
            }

        if not JSON_FILE.exists():
            response.status_code = status.HTTP_404_NOT_FOUND
            return {
                "status": "error",
                "error": f"JSON file not found: {JSON_FILE}",
            }

        stop_event.clear()
        replay_thread = threading.Thread(
            target=replay_worker,
            name="alert-injection-worker",
            daemon=True,
        )
        replay_thread.start()

    response.status_code = status.HTTP_202_ACCEPTED
    return {
        "status": "started",
        "message": "Sequential alert injection started",
        "json_file": JSON_FILE.name,
        "total_windows": TOTAL_WINDOWS,
        "interval_seconds": WINDOW_SECONDS,
    }


@router.post("/stop")
def stop_alert_injection(response: Response):
    global replay_thread

    if replay_thread is None or not replay_thread.is_alive():
        response.status_code = status.HTTP_200_OK
        return {
            "status": "not_running",
            "message": "Alert injection is not currently running",
            "replay": get_state(),
        }

    stop_event.set()
    replay_thread.join(timeout=5)

    if replay_thread.is_alive():
        response.status_code = status.HTTP_202_ACCEPTED
        return {
            "status": "stop_requested",
            "message": "Stop requested. The current database transaction is still finishing.",
            "replay": get_state(),
        }

    update_state(
        status="stopped",
        current_source_window=None,
        next_insertion_at=None,
        stopped_at=datetime.now().isoformat(),
    )

    response.status_code = status.HTTP_200_OK
    return {
        "status": "stopped",
        "message": "Alert injection stopped successfully",
        "replay": get_state(),
    }


@router.get("/status")
def alert_injection_status():
    thread_running = replay_thread is not None and replay_thread.is_alive()
    return {
        "thread_running": thread_running,
        "json_file": str(JSON_FILE),
        "replay": get_state(),
    }


# ============================================================
# FETCH RECENT EVENTS API
# ============================================================

# --- 1. Define the Input Model (JSON Request) ---
class EventFilterRequest(BaseModel):
    current_timestamp: str
    organization: str
    application: str
    journey: str
    step: str
    action: str

# --- 2. Define the Output Model (JSON Response) ---
class RecentEventResponse(BaseModel):
    tier: str
    eventname: str
    event_timestamp: str
    message: str
    severity: str

# --- 3. Create the POST API ---
@router.post("/events/recent", response_model=List[RecentEventResponse])
def get_recent_events_by_hierarchy(
    payload: EventFilterRequest,
    db: Session = Depends(get_db)
):
    """
    Accepts a JSON payload and fetches raw events for a specific action within the last 2 minutes.
    """
    # 1. Parse the timestamp from the JSON payload and calculate the 2-minute window
    try:
        clean_timestamp = payload.current_timestamp.replace("Z", "+00:00")
        end_dt = datetime.fromisoformat(clean_timestamp).replace(tzinfo=None)
    except ValueError:
        end_dt = datetime.now()

    start_dt = end_dt - timedelta(minutes=2)

    # 2. Build the base hierarchy query using the JSON payload & Direct DateTime Filtering
    query = db.query(PolicyEventLog).filter(
        PolicyEventLog.organization == payload.organization,
        PolicyEventLog.application == payload.application,
        PolicyEventLog.journey == payload.journey,
        PolicyEventLog.step == payload.step,
        PolicyEventLog.action == payload.action,
        PolicyEventLog.event_timestamp >= start_dt, # <-- CHANGED: Direct DateTime comparison
        PolicyEventLog.event_timestamp <= end_dt
    )

    # 3. Fetch and sort chronologically
    events = query.order_by(PolicyEventLog.event_timestamp.asc()).all()

    # 4. Format the output
    formatted_events = []
    for event in events:
        formatted_events.append(
            RecentEventResponse(
                tier=event.tier,
                eventname=event.eventname,
                event_timestamp=event.event_timestamp.strftime("%H:%M:%S"), # Returns exactly "14:05:00" format
                message=event.message,
                severity=event.severity
            )
        )

    return formatted_events

# --- 1. Define the Incident Response Model ---
class RecentIncidentResponse(BaseModel):
    correlation_id: str
    rca: str
    severity: str
    affected_apps: List[str]
    alerts: int
    correlated_at: datetime
    root_cause_tier: str
    root_cause_name: str
    rca_score: int
    root_cause_confidence: int
    organization: str
    journey: str
    cascade_chain: List[str]

# --- 2. Create the POST Endpoint ---
@router.post("/corelations/recent", response_model=List[RecentIncidentResponse])
def get_recent_corelations(
    payload: EventFilterRequest,
    db: Session = Depends(get_db)
):
    """
    Accepts the hierarchy JSON payload and fetches all correlation records 
    associated with events from the last 5 minutes.
    """
    # 1. Parse the timestamp and calculate the 5-minute window
    try:
        clean_timestamp = payload.current_timestamp.replace("Z", "+00:00")
        end_dt = datetime.fromisoformat(clean_timestamp).replace(tzinfo=None)
    except ValueError:
        end_dt = datetime.now()

    start_dt = end_dt - timedelta(minutes=10)

    # 2. Query distinct correlation_ids for events matching the hierarchy in the last 5 minutes
    distinct_corr_ids = db.query(PolicyEventLog.corelation_id).filter(
        PolicyEventLog.organization == payload.organization,
        PolicyEventLog.application == payload.application,
        PolicyEventLog.journey == payload.journey,
        PolicyEventLog.step == payload.step,
        PolicyEventLog.action == payload.action,
        PolicyEventLog.event_timestamp >= start_dt,
        PolicyEventLog.event_timestamp <= end_dt,
        PolicyEventLog.corelation_id.isnot(None)  # Only get logs that are correlated
    ).distinct().all()

    # Extract correlation IDs into a flat list
    corr_ids = [c_id[0] for c_id in distinct_corr_ids if c_id[0]]

    if not corr_ids:
        return []

    # 3. Fetch the correlation records from the 'correlations' table matching those IDs
    correlations = db.query(Correlation).filter(
        Correlation.correlation_id.in_(corr_ids)
    ).order_by(Correlation.correlated_at.desc()).all()

    # 4. Format and return as a list of dictionaries/objects
    return [
        RecentIncidentResponse(
            correlation_id=corr.correlation_id,
            rca=corr.rca,
            severity=corr.severity,
            affected_apps=corr.affected_apps or [],
            alerts=corr.alerts,
            correlated_at=corr.correlated_at,
            root_cause_tier=corr.root_cause_tier or "",
            root_cause_name=corr.root_cause_name or "",
            rca_score=corr.rca_score or 0,
            root_cause_confidence=corr.root_cause_confidence or 0,
            organization=corr.organization or "",
            journey=corr.journey or "",
            cascade_chain=corr.cascade_chain or []
        )
        for corr in correlations
    ]