from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, Boolean, ForeignKey,Time, JSON,Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import declarative_base

Base = declarative_base()

# --- SQLALCHEMY DATABASE MODELS ---
class Correlation(Base):
    __tablename__ = 'correlations'

    correlation_id = Column(String(50), primary_key=True)
    rca = Column(Text, nullable=False)
    severity = Column(String(20), nullable=False)
    affected_apps = Column(ARRAY(String), nullable=False)
    alerts = Column(Integer, default=0)
    correlated_at = Column(DateTime, default=datetime.utcnow)
    
    root_cause_event_id = Column(Integer) 
    root_cause_tier = Column(String(100))
    root_cause_name = Column(String(255))
    rca_score = Column(Integer, default=0)
    root_cause_confidence = Column(Integer, default=95)
    
    organization = Column(String(255))
    journey = Column(String(255))
    cascade_chain = Column(JSONB)
    
    

class PolicyEventLog(Base):
    __tablename__ = 'policy_event_logs'

    id = Column(Integer, primary_key=True)
    organization = Column(String(150))
    application = Column(String(150))
    journey = Column(String(150))
    step = Column(String(150))
    action = Column(String(150))
    tier = Column(String(100))       # Preserved from your old Event model
    source = Column(String(150))     # Preserved from your old Event model
    event_timestamp = Column(DateTime)
    eventname = Column(String(150))
    message = Column(String)
    severity = Column(String(20))
    
    corelation_id = Column(String(50), ForeignKey('correlations.correlation_id'))
    
class ApplicationMetrics(Base):
    __tablename__ = 'application_metrics'

    id = Column(Integer, primary_key=True, autoincrement=True)
    application = Column(String(150))
    journey = Column(String(150))
    step = Column(String(150))
    action = Column(String(150))
    technical_tier = Column(String(100))
    layer = Column(String(150))
    log_sources = Column(String) # Stored as stringified JSON or JSONB
    source_tag = Column(String(150))

# --- DASHBOARD & TIMELINE UI MODELS (Preserved) ---
class BlastRadius(BaseModel):
    users: int
    transactions: int
    apps: int

class Evidence(BaseModel):
    source: str
    type: str
    detail: str
    weight: int

class CorrelationIncident(BaseModel):
    id: str
    title: str
    severity: str
    affectedApps: List[str]
    alertCount: int
    correlatedAt: datetime
    rootCause: str
    rootCauseConfidence: int
    blastRadius: BlastRadius
    evidence: List[Evidence]
    dependencyPath: List[str]
    recommendations: List[str]
    narrative: str

class ConnectorAlert(BaseModel):
    id: str
    timestamp: datetime
    severity: str
    message: str
    metric: Optional[str] = None
    value: Optional[str] = None

class Connector(BaseModel):
    id: str
    name: str
    status: str
    alerts: List[ConnectorAlert]

class LayerMetrics(BaseModel):
    latency: Optional[str] = None
    errorRate: Optional[str] = None
    throughput: Optional[str] = None
    cpu: Optional[str] = None
    memory: Optional[str] = None

class TechLayer(BaseModel):
    id: str
    name: str
    icon: str
    technology: str
    status: str
    metrics: Optional[LayerMetrics] = None
    connectors: List[Connector]

class TechTier(BaseModel):
    id: str
    name: str
    icon: str
    status: str
    layers: List[TechLayer]

class TimelineSummary(BaseModel):
    totalAlerts: int
    rootCauseHint: str

class TimelineBreakdownResponse(BaseModel):
    action: str
    summary: TimelineSummary
    tiers: List[TechTier]

class EventLog(Base):
    __tablename__ = 'event_logs'
    id = Column(Integer, primary_key=True)
    organization = Column(String(150))
    application = Column(String(150))
    journey = Column(String(150))
    step = Column(String(150))
    action = Column(String(150))
    tier = Column(String(100))
    layer = Column(String(150))       
    source = Column(String(150))
    event_timestamp = Column(DateTime) 
    eventname = Column(String(150))
    message = Column(String)
    severity = Column(String(20))
    corelation_id = Column(String(50), ForeignKey('correlations.correlation_id'))