import uuid
import openai
from typing import List, Dict
from datetime import time, datetime, date
from sqlalchemy.orm import Session
from app.event_corr.models import (
    PolicyEventLog, Correlation, TimelineBreakdownResponse, TechTier, TechLayer, 
    Connector, ConnectorAlert, LayerMetrics, TimelineSummary, CorrelationIncident,
    Evidence
)

# --- AI CLIENT SETUP ---
client = openai.OpenAI(
    api_key="sk-Lve5YG_C0MzROtFtphZQyw",
    base_url="http://10.73.74.36:20119/v1"
)

def generate_ai_rca(root_cause: PolicyEventLog, batch: List[PolicyEventLog], best_score: int) -> str:
    """Sends the alert cluster to the LLM to generate a concise Root Cause Analysis."""
    
    # Prepare the logs for the AI to read with clear tier formatting
    alert_summaries = [f"[{log.event_timestamp}] Tier: {log.tier} | Event: {log.eventname} | Msg: {log.message}" for log in batch]
    alerts_text = "\n".join(alert_summaries)
    
    prompt = f"""
    You are an expert Site Reliability Engineer analyzing a cascading failure.
    Based on our internal scoring algorithm, the root cause alert is '{root_cause.eventname}' in the '{root_cause.tier}' tier, which received the highest risk score of {best_score}.
    
    Here is the full sequence of alerts:
    {alerts_text}
    
    Write a professional Root Cause Analysis (RCA) summary in 2 to 3 sentences. 
    You MUST follow this exact structure:
    1. First, explicitly state which alert is the root cause and mention that it was identified based on its high risk score.
    2. Next, explain sequentially how this specific alert caused the subsequent alerts in the other affected tiers.
    
    Do not use pleasantries or markdown formatting. Just output the text.
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=150,
            temperature=0.2 # Lowered temperature to force strict adherence to the format
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"AI RCA Generation failed: {e}")
        return f"Root cause identified as {root_cause.eventname} in the {root_cause.tier} tier based on risk score. This event cascaded to affect downstream tiers."

TIER_ICONS = {
    "Presentation": "monitor",
    "Application": "cpu",
    "Integration": "cable",
    "Data": "database",
    "Infrastructure": "hard-drive"
}

def time_to_seconds(t: time) -> float:
    """Converts a datetime.time object to total seconds since midnight."""
    return t.hour * 3600 + t.minute * 60 + t.second + t.microsecond / 1e6

def get_status_from_alerts(alerts: List[ConnectorAlert]) -> str:
    if any(a.severity.lower() == "critical" for a in alerts):
        return "critical"
    if any(a.severity.lower() in ["warning", "high", "medium"] for a in alerts):
        return "degraded"
    return "healthy"

def calculate_alert_score(event: PolicyEventLog) -> int:
    score = 0
    tier_weights = {"Infrastructure": 51, "Data": 50, "Integration": 40, "Application": 30, "Security": 20, "Presentation": 10}
    severity_weights = {"critical": 25, "high": 15, "medium": 10, "warning": 5, "low": 0}
    signature_weights = {
        "SQLTimeoutException": 42, "Backend_Call_Response_Time_High": 40, "JVM_Heap_Memory_Critical": 30,
        "Thread_Pool_Queue_Critical": 20, "Node_CPU_Utilization_Critical": 15,
        "Business_Transaction_Error_Rate_High": 10, "Business_Transaction_Response_Time_High": 5
    }
    
    score += tier_weights.get(event.tier, 0)
    score += severity_weights.get(event.severity.lower(), 0)
    score += signature_weights.get(event.eventname, 0)
    return score

# --- 1. BACKGROUND ENGINE LOGIC (Writes to DB) ---

def run_db_correlation(db: Session):
    """Buckets events into 2-minute windows, scores them, and saves to DB."""
    uncorrelated = db.query(PolicyEventLog).filter(
        PolicyEventLog.corelation_id == None
    ).order_by(PolicyEventLog.event_timestamp.asc()).all()

    if not uncorrelated:
        return {"status": "No new events to process"}

    clusters = []
    current_batch = []
    base_time = None

    for log in uncorrelated:
        if not base_time:
            base_time = log.event_timestamp
            current_batch.append(log)
        else:
            delta_seconds = time_to_seconds(log.event_timestamp) - time_to_seconds(base_time)
            delta_minutes = delta_seconds / 60.0

            if 0 <= delta_minutes <= 2.0:
                current_batch.append(log)
            else:
                if len(current_batch) >= 2:
                    clusters.append(current_batch)
                base_time = log.event_timestamp
                current_batch = [log]
                
    if len(current_batch) >= 2:
        clusters.append(current_batch)

    for batch in clusters:
        best_score = -1
        root_cause = batch[0]
        
        for log in batch:
            score = calculate_alert_score(log)
            if hasattr(log, 'rca_score'):
                log.rca_score = score
            if score > best_score:
                best_score = score
                root_cause = log

        if hasattr(root_cause, 'is_root_cause'):
            root_cause.is_root_cause = True
       # --- ROBUST DYNAMIC CONFIDENCE CALCULATION ---
        if len(batch) == 1:
            confidence = 80  
        else:
            top_score = getattr(root_cause, 'rca_score', calculate_alert_score(root_cause))
            
            # Find the highest score of an alert that is DIFFERENT from our chosen root cause
            competitor_scores = [
                calculate_alert_score(log) for log in batch 
                if log.eventname != root_cause.eventname or log.tier != root_cause.tier
            ]
            
            if not competitor_scores:
                # All 16 alerts are the exact same error just spamming the logs
                confidence = 95
            else:
                # Calculate the gap between our root cause and the best DIFFERENT alert
                top_competitor = max(competitor_scores)
                gap = top_score - top_competitor
                
                # Base 65% + gap, maxing out at 99%
                confidence = min(99, 65 + gap)


        corr_id = f"COR-{uuid.uuid4().hex[:6].upper()}"
        
        # --- STRICT LOGICAL HIERARCHY FOR CASCADE ---
        # Define the exact bottom-up failure path
        ideal_hierarchy = ["Infrastructure", "Data", "Integration", "Application", "Presentation"]
        
        # Get unique tiers present in the log batch
        unique_tiers = set([log.tier for log in batch])
        
        # Build the cascade array by forcing the unique tiers into the ideal order
        cascade = [tier for tier in ideal_hierarchy if tier in unique_tiers]
        
        correlated_dt = datetime.now()
        
        # --- GENERATE AI RCA HERE ---
        ai_generated_rca = generate_ai_rca(root_cause, batch,best_score)

        db.add(Correlation(
            correlation_id=corr_id,
            rca=ai_generated_rca, # <--- Inserted into DB here
            severity=root_cause.severity,
            affected_apps=[root_cause.application],
            alerts=len(batch),
            correlated_at=correlated_dt,
            root_cause_event_id=root_cause.id,
            root_cause_tier=root_cause.tier,
            root_cause_name=root_cause.eventname,
            rca_score=best_score,
            root_cause_confidence=confidence,
            organization=root_cause.organization,
            journey=root_cause.journey,
            cascade_chain=cascade,
        ))
        
        for log in batch:
            log.corelation_id = corr_id

    db.commit()
    return {"status": f"Successfully correlated {len(clusters)} clusters with AI-generated RCAs."}

# --- 2. PRESENTATION FORMATTERS (For UI Models) ---

def format_incident_for_ui(correlation: Correlation, logs: List[PolicyEventLog]) -> CorrelationIncident:
    evidence_list = [
        Evidence(
            source=log.source or "System", 
            type=log.eventname, 
            detail=f"{log.tier}: {log.message}", 
            weight=95 if log.id == correlation.root_cause_event_id else 45
        )
        for log in logs[:4]
    ]
    
    return CorrelationIncident(
        id=correlation.correlation_id,
        title=correlation.rca,
        severity=correlation.severity,
        affectedApps=correlation.affected_apps,
        alertCount=correlation.alerts,
        correlatedAt=correlation.correlated_at,
        rootCause=f"{correlation.root_cause_tier} Tier: {correlation.root_cause_name}", # <--- Fixed root_cause_node issue here
        rootCauseConfidence=correlation.root_cause_confidence,
        evidence=evidence_list,
        dependencyPath=correlation.cascade_chain or [],
        recommendations=[f"Investigate {correlation.root_cause_tier} tier for {correlation.root_cause_name} spikes."],
        narrative=correlation.rca # Reusing the AI summary for the narrative body
    )

def build_db_timeline_breakdown(events: List[PolicyEventLog], target_journey: str) -> TimelineBreakdownResponse:
    if not events:
        return TimelineBreakdownResponse(action="Unknown", summary=TimelineSummary(totalAlerts=0, rootCauseHint="No cascading pattern detected."), tiers=[])
        
    current_action = events[0].action if events[0].action else "Unknown Action"
    root_event = next((e for e in events if getattr(e, 'is_root_cause', False)), events[0])
    
    path_nodes = []
    seen_nodes = set()
    for e in sorted(events, key=lambda x: time_to_seconds(x.event_timestamp)):
        node_name = f"{e.tier}-Node"
        if node_name not in seen_nodes:
            path_nodes.append(f"{node_name} ({e.tier})")
            seen_nodes.add(node_name)
            
    root_node = f"{root_event.tier}-Node"
    root_score = getattr(root_event, 'rca_score', 0)
    root_cause_hint = f"🚨 Root Cause: {root_event.eventname} on {root_node} ({root_event.tier}) [Score: {root_score}] : Cascaded Upwards: " + " ➔ ".join(path_nodes)

    structure: Dict[str, Dict[str, Dict[str, List[PolicyEventLog]]]] = {t: {} for t in TIER_ICONS.keys()}
    for ev in events:
        node_name = f"{ev.tier}-Node"
        structure.setdefault(ev.tier, {}).setdefault(node_name, {}).setdefault(ev.source or "System", []).append(ev)

    tier_list = []
    for tier_name, nodes in structure.items():
        layer_list = []
        for node_name, sources in nodes.items():
            connector_list = []
            for source_name, source_events in sources.items():
                alerts = []
                for e in source_events:
                    alerts.append(ConnectorAlert(
                        id=str(e.id), 
                        timestamp=datetime.combine(date.today(), e.event_timestamp), 
                        severity=e.severity, 
                        message=e.message,
                        metric=e.eventname,
                        value="N/A"
                    ))
                    
                connector_list.append(Connector(id=f"conn-{tier_name}-{node_name}-{source_name}".replace(" ", "-"), name=source_name, status=get_status_from_alerts(alerts), alerts=alerts))
            
            has_critical = any(c.status == "critical" for c in connector_list)
            
            layer_list.append(TechLayer(
                id=f"lay-{tier_name}-{node_name}".replace(" ", "-"),
                name=node_name,
                icon="database" if "Database" in node_name or "Oracle" in node_name else ("workflow" if "Engine" in node_name else "server"),
                technology="Oracle RAC DB" if "Oracle" in node_name or "Database" in node_name else "Enterprise Subsystem",
                status="critical" if has_critical else "healthy",
                metrics=LayerMetrics(
                    latency="5200ms" if has_critical else "120ms", 
                    errorRate="18%" if has_critical else "0%", 
                    throughput="45/s", 
                    cpu="94%" if has_critical else "12%", 
                    memory="87%" if has_critical else "42%"
                ),
                connectors=connector_list
            ))
            
        tier_list.append(TechTier(
            id=f"tier-{tier_name}",
            name=f"{tier_name} Tier",
            icon=TIER_ICONS.get(tier_name, "cpu"),
            status="critical" if any(l.status == "critical" for l in layer_list) else ("degraded" if any(l.status == "degraded" for l in layer_list) else "healthy"),
            layers=layer_list
        ))

    return TimelineBreakdownResponse(
        action=current_action,
        summary=TimelineSummary(
            totalAlerts=len(events), 
            rootCauseHint=root_cause_hint
        ),
        tiers=tier_list
    )