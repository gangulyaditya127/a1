from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from typing import List

# Import your existing health router (assuming it's in app/health.py based on your screenshot)
from app.api.v1.health import router as health_router

# Import the new event correlation router
# Based on your VS code screenshot, endpoints.py is in app/event_corr/
from app.api.v1.endpoints import router as event_corr_router
from app.api.v1.new_endpoint import router as new_router


app = FastAPI(title="ARE Platform")

# Add CORS middleware to allow the S5 Proactive Monitoring React frontend to fetch data
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this to your frontend's actual domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include your existing health router
app.include_router(health_router, prefix="/api/v1", tags=["Health"])
app.include_router(new_router, prefix="/api/v1", tags=["Observability"])

# Include the new event correlation engine router
app.include_router(event_corr_router, prefix="/api/v1", tags=["Event Correlation"])

@app.get("/")
def root():
    return {"application": "ARE Platform", "status": "running"}

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)