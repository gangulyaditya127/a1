import { type ReactNode } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Bell,
  Cloud,
  HelpCircle,
  User,
  ArrowLeft,
  LayoutDashboard,
  type LucideIcon,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

// ─── Public types ────────────────────────────────────────────────────

export interface NavItem {
  title: string;
  url: string;
  icon: LucideIcon;
  badge?: string;
}

interface ConsoleLayoutProps {
  role: "admin" | "superadmin";
  navItems: NavItem[];
  children: ReactNode;
}

// ─── Admin nav items (Dashboard only) ────────────────────────────────

const adminNavItems: NavItem[] = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard },
];

// ─── Inner sidebar (needs useSidebar context) ────────────────────────

const InnerSidebar = ({
  items,
  role,
}: {
  items: NavItem[];
  role: "admin" | "superadmin";
}) => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();

  const isActive = (url: string) =>
    pathname === url || pathname.startsWith(url + "/");

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        {/* Brand */}
        <div className="px-3 py-3 flex items-center gap-2 border-b border-sidebar-border">
          <div className="h-8 w-8 rounded bg-sidebar-primary/15 text-sidebar-primary flex items-center justify-center shrink-0">
            <Cloud className="h-4 w-4" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="text-xs font-semibold text-sidebar-foreground truncate">
                DIS Console
              </p>
              <p className="text-[10px] text-sidebar-foreground/60 truncate">
                {role === "superadmin" ? "Super Admin" : "DIS Admin"}
              </p>
            </div>
          )}
        </div>

        {/* Navigation */}
        <SidebarGroup>
          <SidebarGroupLabel>
            {role === "superadmin" ? "Governance" : "Operations"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <NavLink
                      to={item.url}
                      className="flex items-center gap-2"
                    >
                      <item.icon className="h-4 w-4" />
                      {!collapsed && (
                        <span className="flex-1 flex items-center justify-between">
                          <span>{item.title}</span>
                          {item.badge && (
                            <Badge
                              variant="secondary"
                              className="h-4 px-1.5 text-[10px]"
                            >
                              {item.badge}
                            </Badge>
                          )}
                        </span>
                      )}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>


      </SidebarContent>
    </Sidebar>
  );
};

// ─── ConsoleLayout (generic) ─────────────────────────────────────────

export const ConsoleLayout = ({
  role,
  navItems,
  children,
}: ConsoleLayoutProps) => {
  const { user } = useAuth();

  const roleColor =
    role === "superadmin"
      ? "bg-amber-500/15 text-amber-600 border-amber-500/30"
      : "bg-teal-500/15 text-teal-600 border-teal-500/30";

  const roleLabel = role === "superadmin" ? "Super Admin" : "Admin";

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <InnerSidebar items={navItems} role={role} />

        <div className="flex-1 flex flex-col min-w-0">
          {/* Top header bar */}
          <header className="h-14 border-b bg-card flex items-center px-4 justify-between sticky top-0 z-10">
            <div className="flex items-center gap-3">
              <SidebarTrigger />
              <div>
                <h1 className="text-sm font-semibold text-foreground leading-tight">
                  DIS Cloud Onboarding
                </h1>
                <p className="text-[10px] text-muted-foreground">
                  {role === "superadmin"
                    ? "Super Admin Console"
                    : "DIS Admin Console"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Badge variant="outline" className={roleColor}>
                {roleLabel}
              </Badge>
              <Button variant="ghost" size="icon">
                <HelpCircle className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-4 w-4" />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500" />
              </Button>
              <Button variant="ghost" size="sm" className="gap-2">
                <User className="h-4 w-4" />
                <span className="text-xs">
                  {user?.name ?? roleLabel} — {roleLabel}
                </span>
              </Button>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 p-6 overflow-auto">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
};

// ─── AdminLayout (backwards-compatible wrapper) ──────────────────────

export const AdminLayout = ({ children }: { children: ReactNode }) => (
  <ConsoleLayout role="admin" navItems={adminNavItems}>
    {children}
  </ConsoleLayout>
);
