import { useState, useEffect, useRef } from "react";
import { type ArchitectureOverview } from "@/types/onboarding";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Upload,
  Cpu,
  ShieldAlert,
  ShieldCheck,
  FileImage,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Info,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  uploadArchitectureDiagram,
  validateArchitecture,
  getArchitectureValidation,
  type ApiValidationViolation,
} from "@/lib/api";

interface Props {
  data: ArchitectureOverview;
  onboardingId: string;
  onChange: (data: ArchitectureOverview) => void;
}

const SEVERITY_CONFIG: Record<string, { color: string; bg: string; border: string; icon: typeof AlertTriangle }> = {
  CRITICAL: { color: "text-red-700", bg: "bg-red-50", border: "border-red-200", icon: XCircle },
  HIGH: { color: "text-orange-700", bg: "bg-orange-50", border: "border-orange-200", icon: AlertTriangle },
  MEDIUM: { color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200", icon: Info },
  LOW: { color: "text-blue-700", bg: "bg-blue-50", border: "border-blue-200", icon: Info },
};

// ── Severity badge helper ──────────────────────────────────────────
const SeverityBadge = ({ severity }: { severity: string }) => {
  const upper = severity.toUpperCase();
  const variant = upper === "CRITICAL" ? "destructive" : "secondary";
  return <Badge variant={variant} className="text-xs font-mono">{upper}</Badge>;
};
const BASE_URL = `${import.meta.env.VITE_API_BASE_URL}`;

// ── Verdict banner helper ──────────────────────────────────────────
const VerdictBanner = ({
  verdict,
  validatedAt,
  violationsCount
}: {
  verdict: string;
  validatedAt: string | null;
  violationsCount: number;
}) => {
  if (verdict === "not_a_diagram") {
    return (
      <div className="flex items-center gap-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
        <XCircle className="h-6 w-6 text-purple-600 shrink-0" />
        <div>
          <p className="font-semibold text-purple-800">Not a Cloud Architecture Diagram</p>
          <p className="text-sm text-purple-700">
            The uploaded image was not recognized as a valid cloud architecture diagram.
            Please upload an actual architecture diagram and try again.
            {validatedAt && <> Checked at {new Date(validatedAt).toLocaleString()}</>}
          </p>
        </div>
      </div>
    );
  }

  if (verdict === "valid") {
    return (
      <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
        <ShieldCheck className="h-6 w-6 text-green-600 shrink-0" />
        <div>
          <p className="font-semibold text-green-800">Architecture Validated — No Violations</p>
          <p className="text-sm text-green-700">
            Your cloud architecture diagram passes all configured security and compliance rules.
            {validatedAt && <> Validated at {new Date(validatedAt).toLocaleString()}</>}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
      <ShieldAlert className="h-6 w-6 text-red-600 shrink-0" />
      <div>
        <p className="font-semibold text-red-800">
          Architecture Invalid — {violationsCount} Violation{violationsCount !== 1 && "s"} Found
        </p>
        <p className="text-sm text-red-700">
          Review the findings below and update your architecture accordingly.
          {validatedAt && <> Validated at {new Date(validatedAt).toLocaleString()}</>}
        </p>
      </div>
    </div>
  );
};


export const StepArchitectureOverview = ({ data, onboardingId, onChange }: Props) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [violations, setViolations] = useState<ApiValidationViolation[]>([]);
  const [verdict, setVerdict] = useState<string | null>(null);
  const [validatedAt, setValidatedAt] = useState<string | null>(null);
  const [imageKey, setImageKey] = useState(Date.now()); // cache-busting for image preview
  const [userContext, setUserContext] = useState<string>(data.userContext || "");

  // ── Load existing validation from DB on mount ──────────────────────
  useEffect(() => {
    if (!onboardingId) { setIsLoading(false); return; }
    getArchitectureValidation(onboardingId)
      .then((res) => {
        const loadedContext = res.user_context ?? data.userContext ?? "";
        setUserContext(loadedContext);
        onChange({
          ...data,
          uploadedDiagram: res.image_filename,
          userContext: loadedContext,
          securityViolations: res.violations.map((v) => v.finding),
          analysisComplete: !!res.verdict,
        });
        setViolations(res.violations);
        setVerdict(res.verdict);
        setValidatedAt(res.validated_at);
        setImageKey(Date.now());
      })
      .catch(() => {
        // 404 is expected for new onboardings
      })
      .finally(() => setIsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboardingId]);

  const handleContextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setUserContext(val);
    onChange({
      ...data,
      userContext: val,
    });
  };

  // ── Upload handler ─────────────────────────────────────────────────
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onboardingId) return;

    setIsUploading(true);
    try {
      const res = await uploadArchitectureDiagram(onboardingId, file, userContext);
      onChange({
        ...data,
        uploadedDiagram: res.image_filename,
        userContext: res.user_context ?? userContext,
        analysisComplete: false,
        securityViolations: [],
        revisedDiagram: null,
      });
      setViolations([]);
      setVerdict(null);
      setValidatedAt(null);
      setImageKey(Date.now());
      toast({ title: "Diagram Uploaded", description: `${res.image_filename} uploaded successfully.` });
    } catch {
      toast({ title: "Upload Failed", description: "Could not upload the diagram.", variant: "destructive" });
    } finally {
      setIsUploading(false);
      // Reset input so re-uploading the same file triggers onChange
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // ── Validate handler ───────────────────────────────────────────────
  const handleValidate = async () => {
    if (!onboardingId) return;
    setIsValidating(true);
    try {
      const res = await validateArchitecture(onboardingId, userContext);
      setVerdict(res.verdict);
      setViolations(res.violations);
      setValidatedAt(res.validated_at);
      onChange({
        ...data,
        userContext: res.user_context ?? userContext,
        analysisComplete: true,
        securityViolations: res.violations.map((v) => v.finding),
      });

      let descriptionMessage = `Found ${res.violations.length} violation(s).`;
      if (res.verdict === "not_a_diagram") {
        descriptionMessage = "The image is not a valid cloud architecture diagram.";
      } else if (res.verdict === "valid") {
        descriptionMessage = "Architecture passed all rule checks!";
      }

      toast({
        title: "Validation Complete",
        description: descriptionMessage,
      });
    } catch {
      toast({ title: "Validation Failed", description: "Could not validate the architecture.", variant: "destructive" });
    } finally {
      setIsValidating(false);
    }
  };

  const renderValidateButtonContent = () => {
    if (isValidating) {
      return (
        <>
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          Validating...
        </>
      );
    }
    if (verdict) {
      return "Re-validate";
    }
    return "Validate Architecture";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
        <span className="text-muted-foreground">Loading architecture data...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/svg+xml,image/webp,application/pdf"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Upload or Generate */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upload card */}
        <button
          type="button"
          className="w-full border-2 border-dashed rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          onClick={() => !isUploading && fileInputRef.current?.click()}
        >
          {isUploading ? (
            <Loader2 className="h-10 w-10 mx-auto text-primary mb-3 animate-spin" />
          ) : (
            <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3 group-hover:text-primary transition-colors" />
          )}
          <p className="font-medium">
            {data.uploadedDiagram ? "Re-upload Architecture Diagram" : "Upload Architecture Diagram"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Click to upload (.png, .jpg, .svg, .pdf)
          </p>
          {data.uploadedDiagram && (
            <Badge className="mt-3" variant="secondary">
              <CheckCircle2 className="h-3 w-3 mr-1" /> {data.uploadedDiagram}
            </Badge>
          )}
        </button>

        {/* Generate from Bucket card — DISABLED / Coming Soon */}
        <div className="border-2 border-dashed rounded-lg p-8 text-center opacity-50 cursor-not-allowed relative">
          <div className="absolute top-2 right-2">
            <Badge variant="outline" className="text-xs">Coming Soon</Badge>
          </div>
          <Cpu className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
          <p className="font-medium">Generate from Resource Bucket</p>
          <p className="text-sm text-muted-foreground mt-1">
            Auto-generate architecture from your configured resources
          </p>
        </div>
      </div>

      {/* Architecture Context (Optional) */}
      <div className="space-y-2 border rounded-lg p-5 bg-card shadow-sm">
        <div className="flex items-center justify-between">
          <Label htmlFor="arch-context" className="text-sm font-semibold text-foreground flex items-center gap-1.5">
            <FileImage className="h-4 w-4 text-primary" /> Architecture context (optional)
          </Label>
          <span className="text-xs text-muted-foreground">Sent to AI verification & DIS Admin</span>
        </div>
        <Textarea
          id="arch-context"
          placeholder="Provide any additional context or architecture notes for AI verification and admin review (e.g. key design decisions, multi-region setup, hybrid cloud connectivity, security boundaries, etc.)."
          value={userContext}
          onChange={handleContextChange}
          rows={3}
          className="resize-y"
        />
        <p className="text-xs text-muted-foreground">
          This statement will be evaluated by the LLM along with the architecture diagram to verify compliance, and will also be visible to the admin.
        </p>
      </div>

      {/* Image Preview */}
      {data.uploadedDiagram && (
        <div className="border rounded-lg p-4 bg-muted/20">
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <FileImage className="h-4 w-4" /> Uploaded Diagram
          </h4>
          <div className="rounded-lg overflow-hidden border bg-white">
            <img
              key={imageKey}
              src={`${BASE_URL}/api/architecture-validation/${onboardingId}/image?t=${imageKey}`}
              alt={data.uploadedDiagram}
              className="w-full h-auto max-h-[500px] object-contain"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">{data.uploadedDiagram}</p>
        </div>
      )}

      {/* Validate button — appears after upload */}
      {data.uploadedDiagram && (
        <div className="flex items-center justify-between border rounded-lg p-4 bg-muted/30">
          <div className="flex items-center gap-3">
            <FileImage className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium">Diagram ready for validation</p>
              <p className="text-xs text-muted-foreground">{data.uploadedDiagram}</p>
            </div>
          </div>
          <Button
            onClick={handleValidate}
            disabled={isValidating}
            className="gradient-primary text-primary-foreground"
          >
            {renderValidateButtonContent()}
          </Button>
        </div>
      )}

      {/* Verdict & Violations */}
      {verdict && (
        <div className="space-y-4">
          <VerdictBanner 
            verdict={verdict} 
            validatedAt={validatedAt} 
            violationsCount={violations.length} 
          />

          {/* Violations list */}
          {violations.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                Violations
              </h4>
              {violations.map((v, idx) => {
                const sev = v.severity?.toUpperCase() || "HIGH";
                const cfg = SEVERITY_CONFIG[sev] || SEVERITY_CONFIG.HIGH;
                const IconComp = cfg.icon;
                return (
                  <div
                    key={`${v.finding}-${idx}`}
                    className={`flex items-start gap-3 p-4 rounded-lg border ${cfg.bg} ${cfg.border}`}
                  >
                    <IconComp className={`h-5 w-5 ${cfg.color} mt-0.5 shrink-0`} />
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <SeverityBadge severity={sev} />
                        <Badge variant="outline" className="text-xs">{v.category}</Badge>
                      </div>
                      <p className="text-sm font-medium">{v.finding}</p>
                      <p className="text-xs text-muted-foreground">Rule: {v.rule_text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};