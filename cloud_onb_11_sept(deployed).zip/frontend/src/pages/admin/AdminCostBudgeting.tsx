import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft, DollarSign, Plus, Trash2, Save, ChevronRight, Loader2, Calculator,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { toast } from "@/hooks/use-toast";
import { fetchAdminOnboarding, upsertCost, type AdminOnboarding, type ResourceCostItem } from "@/lib/adminApi";

const AdminCostBudgeting = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [data, setData] = useState<AdminOnboarding | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [resourceCosts, setResourceCosts] = useState<ResourceCostItem[]>([]);
  const [infraSupportCost, setInfraSupportCost] = useState(0);
  const [currency, setCurrency] = useState('INR');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!id) return;
    fetchAdminOnboarding(id)
      .then((d) => {
        setData(d);
        if (d.cost_estimation) {
          setResourceCosts(
            (d.cost_estimation.resource_costs || []).map((r, idx) => ({
              id: r.id || `cost-${idx}-${Date.now()}`,
              ...r,
            }))
          );
          setInfraSupportCost(d.cost_estimation.infra_support_cost);
          setCurrency(d.cost_estimation.currency);
          setNotes(d.cost_estimation.notes);
        } else if (d.cloud_resource_bucket?.resources) {
          setResourceCosts(
            d.cloud_resource_bucket.resources.map((r, idx) => ({
              id: `bucket-${idx}-${Date.now()}`,
              resource_name: r.service,
              unit_cost: 0,
              quantity: r.count,
              monthly_cost: 0,
            }))
          );
        }
      })
      .catch(() => toast({ title: "Error", description: "Failed to load onboarding.", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, [id]);

  const updateResourceCost = (index: number, field: keyof ResourceCostItem, value: string | number) => {
    setResourceCosts((prev) => {
      const updated = [...prev];
      const item = { ...updated[index], [field]: value };
      if (field === 'unit_cost' || field === 'quantity') {
        item.monthly_cost = (Number(item.unit_cost) || 0) * (Number(item.quantity) || 0);
      }
      updated[index] = item;
      return updated;
    });
  };

  const addCustomRow = () => {
    setResourceCosts((prev) => [
      ...prev,
      {
        id: `cost-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        resource_name: '',
        unit_cost: 0,
        quantity: 1,
        monthly_cost: 0,
      },
    ]);
  };

  const removeRow = (index: number) => {
    setResourceCosts((prev) => prev.filter((_, i) => i !== index));
  };

  const resourceSubtotal = resourceCosts.reduce((sum, r) => sum + (r.monthly_cost || 0), 0);
  const totalMonthly = resourceSubtotal + infraSupportCost;
  const totalAnnual = totalMonthly * 12;

  const handleSave = async () => {
    if (!id) return;
    setSaving(true);
    try {
      await upsertCost(id, {
        resource_costs: resourceCosts,
        infra_support_cost: infraSupportCost,
        total_monthly_cost: totalMonthly,
        total_annual_cost: totalAnnual,
        currency,
        notes,
      });
      toast({ title: "Cost Saved", description: "Cost estimation has been saved." });
    } catch {
      toast({ title: "Error", description: "Failed to save cost estimation.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-5xl">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">{data?.name ?? 'Onboarding'}</h1>
            <p className="text-sm text-muted-foreground">Cost Budgeting & Estimation</p>
          </div>
          <Badge className="bg-blue-100 text-blue-700 border-blue-200">
            <DollarSign className="h-3 w-3 mr-1" /> Cost Estimation
          </Badge>
        </div>

        {/* Resource-Level Costs */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Calculator className="h-4 w-4 text-amber-600" /> Resource-Level Costs
              </CardTitle>
              <Button size="sm" variant="outline" onClick={addCustomRow}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Add Row
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">Resource Name</TableHead>
                  <TableHead className="w-[140px]">Unit Cost ({currency})</TableHead>
                  <TableHead className="w-[100px] text-center">Quantity</TableHead>
                  <TableHead className="w-[150px] text-right">Monthly Cost ({currency})</TableHead>
                  <TableHead className="w-[50px]" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {resourceCosts.map((row, i) => (
                  <TableRow key={row.id || `cost-row-${i}`}>
                    <TableCell>
                      <Input
                        value={row.resource_name}
                        onChange={(e) => updateResourceCost(i, 'resource_name', e.target.value)}
                        placeholder="Resource name"
                        className="text-sm"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={row.unit_cost || ''}
                        onChange={(e) => updateResourceCost(i, 'unit_cost', Number(e.target.value))}
                        placeholder="0"
                        className="text-sm"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={row.quantity || ''}
                        onChange={(e) => updateResourceCost(i, 'quantity', Number(e.target.value))}
                        placeholder="1"
                        className="text-sm text-center"
                      />
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {(row.monthly_cost || 0).toLocaleString('en-IN')}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => removeRow(i)}>
                        <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {resourceCosts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-6">
                      No resources. Add rows manually or they will auto-populate from the resource bucket.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            <div className="flex justify-end pt-3 border-t mt-3">
              <div className="text-sm">
                Resource Subtotal: <span className="font-bold text-foreground ml-2">{currency} {resourceSubtotal.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Infrastructure Support */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-amber-600" /> Infrastructure Support Cost
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-w-xs space-y-2">
              <Label htmlFor="infra-support-cost" className="text-sm">
                Monthly Infra Support Cost ({currency})
              </Label>
              <Input
                id="infra-support-cost"
                type="number"
                value={infraSupportCost || ''}
                onChange={(e) => setInfraSupportCost(Number(e.target.value))}
                placeholder="0"
              />
            </div>
          </CardContent>
        </Card>

        {/* Totals */}
        <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border-amber-200">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="currency-select" className="text-xs text-muted-foreground font-medium mb-1 block">
                  Currency
                </Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger id="currency-select" className="w-32 bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INR">INR (₹)</SelectItem>
                    <SelectItem value="USD">USD ($)</SelectItem>
                    <SelectItem value="EUR">EUR (€)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground font-medium mb-1">Total Monthly Cost</p>
                <p className="text-3xl font-bold text-amber-700">{currency} {totalMonthly.toLocaleString('en-IN')}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground font-medium mb-1">Total Annual Cost</p>
                <p className="text-3xl font-bold text-orange-700">{currency} {totalAnnual.toLocaleString('en-IN')}</p>
              </div>
            </div>
            <Separator className="my-4 bg-amber-200" />
            <div className="space-y-2">
              <Label htmlFor="cost-notes" className="text-sm">Notes</Label>
              <Textarea
                id="cost-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Additional notes about the cost estimation…"
                rows={2}
                className="bg-white"
              />
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={() => navigate(`/admin/review/${id}`)}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Review
          </Button>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
              Save Cost Estimation
            </Button>
            <Button
              onClick={() => { handleSave().then(() => navigate(`/admin/recommendations/${id}`)); }}
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white"
            >
              Proceed to Approval Checklist <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminCostBudgeting;