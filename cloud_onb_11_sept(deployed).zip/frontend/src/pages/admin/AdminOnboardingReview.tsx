import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  CheckCircle2, XCircle, AlertTriangle, Loader2, ArrowLeft, Send,
  FileText, Settings2, Cloud, Image, MessageSquare, DollarSign,
  Lightbulb, Plus, Trash2, Sparkles, Copy, Edit, Check, Eye,
  BookOpen, ShieldCheck, Server, Layers, Download, ChevronsUpDown, ChevronDown, ChevronRight, ClipboardList,
  UploadCloud, RotateCcw, FileImage,
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { InteractionTimeline, type InteractionEvent } from "@/components/InteractionTimeline";
import { toast } from "@/hooks/use-toast";
import {
  fetchAdminOnboarding,
  submitFeedback,
  approveOnboarding,
  sendBackOnboarding,
  upsertCost,
  seedCostFromBucket,
  getCost,
  generateRecommendations,
  getRecommendations,
  updateRecommendation,
  sendToUser,
  fetchInteractionEvents,
  getAdminApprovalScreenshots,
  approveApprovalScreenshot,
  sendBackApprovalScreenshot,
  adminUpdateCloudBucket,
  generateCbId,
  getCbId,
  type CbIdInfo,
  type AdminOnboarding,
  type ValidationFeedback,
  type ResourceCostItem,
  type RecommendationItem,
  type InteractionEventItem,
  type AdminApprovalScreenshotItem,
  type AdminBucketEditItem,
} from "@/lib/adminApi";

const SECTIONS = ['account_details', 'requirements', 'cloud_resources', 'architecture'] as const;
type Section = typeof SECTIONS[number];

const sectionLabels: Record<Section, string> = {
  account_details: 'Account Details',
  requirements: 'Requirements',
  cloud_resources: 'Cloud Resources',
  architecture: 'Architecture',
};

// ─── Extracted Sub-Components to Reduce Cognitive Complexity ───

const formatAdminStatus = (status: string | undefined) => {
  if (!status) return '—';
  if (status === 'approval_checklist_sent') return 'approval checklist sent';
  if (status === 'approvals_under_review') return 'approvals in review';
  if (status === 'approvals_sent_back') return 'approvals sent back';
  if (status === 'approvals_approved') return 'approvals verified';
  if (status === 'cb_id_created') return 'cb id created';
  if (status === 'recommendations_pending') return 'approval checklist pending';
  return status.replace(/_/g, ' ');
};
const BASE_URL = `${import.meta.env.VITE_API_BASE_URL}`;

const AdminActionPanel = ({
  isReadOnly, adminStatus, isUnassigned, allApproved, approving, handleApproveAll,
  rejectedCount, sendBackComment, setSendBackComment, sendingBack, handleSendBack
}: any) => {
  if (isUnassigned) {
    return (
      <Card className="border-2 border-amber-300 bg-amber-50">
        <CardContent className="p-5 text-sm text-amber-800 text-center flex items-center justify-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
          <span>This onboarding is pending assignment. A SuperAdmin must assign a DIS Admin to this project before review can begin.</span>
        </CardContent>
      </Card>
    );
  }

  if (isReadOnly) {
    return (
      <Card className="border-2 bg-muted/50">
        <CardContent className="p-5 text-sm text-muted-foreground text-center">
          You are viewing this onboarding in read-only mode.
        </CardContent>
      </Card>
    );
  }

  if (adminStatus !== 'assigned' && adminStatus !== 'under_review') {
    return (
      <Card className="border-2 bg-muted/50">
        <CardContent className="p-5 text-sm text-muted-foreground space-y-4">
          <div className="text-center">
            {/* This onboarding is currently in <strong>{adminStatus?.replace(/_/g, ' ')}</strong> status.
            {adminStatus === 'sent_back' && ' Waiting for user to resubmit.'} */}
            This onboarding is currently in <strong>{formatAdminStatus(adminStatus)}</strong> status.
          </div>
        </CardContent>
      </Card>
    );
  }

  if (allApproved) {
    return (
      <Card className="border-2">
        <CardContent className="p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="h-5 w-5" />
              <span className="font-medium">All sections approved ✓</span>
            </div>
            <Button onClick={handleApproveAll} disabled={approving} className="gradient-primary text-white">
              {approving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
              Approve & Proceed to Cost Budgeting
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (rejectedCount > 0) {
    return (
      <Card className="border-2">
        <CardContent className="p-5">
          <div className="space-y-3">
            <p className="text-sm text-amber-600 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              {rejectedCount} section{rejectedCount > 1 ? 's' : ''} flagged for changes. Send back with consolidated feedback.
            </p>
            <Textarea
              placeholder="Add overall comments for the user…"
              value={sendBackComment}
              onChange={(e) => setSendBackComment(e.target.value)}
              rows={2}
            />
            <Button variant="destructive" onClick={handleSendBack} disabled={sendingBack}>
              {sendingBack ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
              Send Back to User
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2">
      <CardContent className="p-5">
        <p className="text-sm text-muted-foreground flex items-center gap-2">
          <MessageSquare className="h-4 w-4" />
          Review each section and approve or request changes. All 4 sections must be approved.
        </p>
      </CardContent>
    </Card>
  );
};

const EditRecommendationDialog = ({
  editingRec,
  setEditingRec,
  setRecs,
  onboardingId,
}: {
  editingRec: RecommendationItem | null;
  setEditingRec: (r: RecommendationItem | null) => void;
  setRecs: React.Dispatch<React.SetStateAction<RecommendationItem[]>>;
  onboardingId: string;
}) => {
  const [saving, setSaving] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editSummary, setEditSummary] = useState('');

  useEffect(() => {
    if (editingRec) {
      setEditTitle(editingRec.title || '');
      setEditSummary(editingRec.summary || '');
    }
  }, [editingRec]);

  if (!editingRec) return null;

  const handleSave = async () => {
    if (!onboardingId || !editingRec?.id) return;
    const trimmedTitle = editTitle.trim();
    const trimmedSummary = editSummary.trim();
    if (!trimmedTitle) {
      toast({ title: "Validation Error", description: "Title cannot be empty.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const updated = await updateRecommendation(onboardingId, editingRec.id, {
        title: trimmedTitle,
        summary: trimmedSummary,
      });
      setRecs((prev: RecommendationItem[]) =>
        prev.map((r) =>
          r.id === editingRec.id
            ? { ...r, ...updated, title: trimmedTitle, summary: trimmedSummary, status: 'edited' }
            : r
        )
      );
      setEditingRec(null);
      toast({ title: "Updated", description: "Approval checklist item saved successfully." });
    } catch (err: any) {
      toast({
        title: "Error",
        description: err?.message || "Failed to update approval checklist item.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!editingRec} onOpenChange={(open) => { if (!saving) setEditingRec(null); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit Approval Checklist Item</DialogTitle>
          <DialogDescription>
            Modify the approval title and description before sending to the user.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <label htmlFor="edit-rec-title" className="text-sm font-medium">Title</label>
            <Input
              id="edit-rec-title"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              placeholder="e.g. Approval – ISM Approval"
              disabled={saving}
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="edit-rec-summary" className="text-sm font-medium">Summary / Description</label>
            <Textarea
              id="edit-rec-summary"
              value={editSummary}
              onChange={(e) => setEditSummary(e.target.value)}
              placeholder="Description of the approval..."
              rows={4}
              disabled={saving}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setEditingRec(null)} disabled={saving}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || !editTitle.trim()}
            className="gradient-primary text-white"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const DetailsTabContent = ({ acct, req, renderValidationStatus, renderSectionActions }: any) => (
  <div className="space-y-4">
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="h-4 w-4 text-primary" /> Account Details
          </CardTitle>
          <div className="flex items-center gap-2">
            {renderValidationStatus('account_details')}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {acct ? (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
              {[
                { label: 'Project Name', value: acct.project_name },
                { label: 'ISU', value: acct.isu },
                { label: 'Account Name', value: acct.account_name },
                { label: 'Owner', value: acct.owner },
                { label: 'Employee ID', value: acct.emp_id },
                { label: 'Business Unit', value: acct.business_unit },
              ].map((f) => (
                <div key={f.label} className="rounded border p-2">
                  <p className="text-xs text-muted-foreground">{f.label}</p>
                  <p className="font-medium">{f.value || '—'}</p>
                </div>
              ))}
            </div>
            {acct.description && (
              <div className="rounded border p-3 text-sm">
                <p className="text-xs text-muted-foreground mb-1">Description</p>
                <p>{acct.description}</p>
              </div>
            )}
            <Separator />
            {renderSectionActions('account_details')}
          </>
        ) : (
          <p className="text-sm text-muted-foreground">No account details submitted yet.</p>
        )}
      </CardContent>
    </Card>

    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-primary" /> Requirements
          </CardTitle>
          <div className="flex items-center gap-2">
            {renderValidationStatus('requirements')}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {req ? (
          <>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="rounded border p-2">
                <p className="text-xs text-muted-foreground">Solution Type</p>
                <Badge variant="secondary">{req.solution_type?.replace(/-/g, ' ') || '—'}</Badge>
              </div>
              <div className="rounded border p-2">
                <p className="text-xs text-muted-foreground">Cloud Provider</p>
                <Badge variant="outline" className="gap-1"><Cloud className="h-3 w-3" /> {req.cloud_provider || '—'}</Badge>
              </div>
              <div className="rounded border p-2">
                <p className="text-xs text-muted-foreground">Region</p>
                <p className="font-medium">{req.region || '—'}</p>
              </div>
              <div className="rounded border p-2">
                <p className="text-xs text-muted-foreground">Environments</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {(req.deployment_environments ?? []).map((env: string) => (
                    <Badge key={env} className="bg-blue-500/10 text-blue-600 border-blue-500/20 text-[10px]">{env}</Badge>
                  ))}
                </div>
              </div>
            </div>
            <Separator />
            {renderSectionActions('requirements')}
          </>
        ) : (
          <p className="text-sm text-muted-foreground">No requirements submitted yet.</p>
        )}
      </CardContent>
    </Card>
  </div>
);

const ResourceTabContent = ({
  bucket, renderValidationStatus, renderSectionActions,
  isReadOnly, onboardingId, onSaved,
}: {
  bucket: AdminOnboarding['cloud_resource_bucket'];
  renderValidationStatus: (section: any) => React.ReactNode;
  renderSectionActions: (section: any) => React.ReactNode;
  isReadOnly: boolean;
  onboardingId: string;
  onSaved: () => void;
}) => {
  const [editMode, setEditMode] = useState(false);
  const [editRows, setEditRows] = useState<AdminBucketEditItem[]>([]);
  const [editProvider, setEditProvider] = useState('');
  const [saving, setSaving] = useState(false);

  const startEdit = () => {
    setEditProvider(bucket?.provider || '');
    setEditRows(
      bucket?.resources.map((r) => ({
        service: r.service,
        count: r.count,
        configDetails: r.configDetails,
      })) ?? []
    );
    setEditMode(true);
  };

  const cancelEdit = () => setEditMode(false);

  const updateRow = (i: number, field: keyof AdminBucketEditItem, value: string | number) => {
    setEditRows((prev) => {
      const updated = [...prev];
      updated[i] = { ...updated[i], [field]: value };
      return updated;
    });
  };

  const addRow = () =>
    setEditRows((prev) => [...prev, { service: '', count: 1, configDetails: '' }]);

  const removeRow = (i: number) =>
    setEditRows((prev) => prev.filter((_, idx) => idx !== i));

  const handleSave = async () => {
    setSaving(true);
    try {
      await adminUpdateCloudBucket(onboardingId, {
        provider: editProvider,
        resources: editRows,
      });
      toast({ title: 'Resources Saved', description: 'Cloud resources updated and now visible to the user.' });
      setEditMode(false);
      onSaved();
    } catch {
      toast({ title: 'Error', description: 'Failed to save cloud resources.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Cloud Resource Buckets</h3>
        <div className="flex items-center gap-2">
          {renderValidationStatus('cloud_resources')}
          {/* {!isReadOnly && !editMode && (
            <Button size="sm" variant="outline" onClick={startEdit}>
              <Edit className="h-3.5 w-3.5 mr-1" /> Edit Resources
            </Button>
          )} */}
          {!isReadOnly && editMode && (
            <Button size="sm" variant="ghost" onClick={cancelEdit} disabled={saving}>
              Cancel
            </Button>
          )}
        </div>
      </div>

      {!editMode ? (
        /* ── Read-only view ── */
        bucket && bucket.resources.length > 0 ? (
          <div className="rounded-md border">
            <div className="px-3 py-2 bg-muted/40 text-xs font-semibold uppercase">
              {bucket.provider} — {bucket.resources.length} resource(s)
            </div>
            <Table>
              <TableHeader><TableRow>
                <TableHead>Service</TableHead><TableHead>Count</TableHead><TableHead>Config</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {bucket.resources.map((r: any, i: number) => (
                  <TableRow key={`${r.service}-${i}`}>
                    <TableCell className="font-medium">{r.service}</TableCell>
                    <TableCell>{r.count}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.configDetails}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No resources submitted yet by the user.</p>
        )
      ) : (
        /* ── Edit mode ── */
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground font-medium">Provider:</span>
            <Input
              value={editProvider}
              onChange={(e) => setEditProvider(e.target.value)}
              className="h-7 w-32 text-xs"
              placeholder="e.g. AWS"
            />
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Service</TableHead>
                <TableHead className="w-20">Count</TableHead>
                <TableHead>Config Details</TableHead>
                <TableHead className="w-10" />
              </TableRow></TableHeader>
              <TableBody>
                {editRows.map((row, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Input
                        value={row.service}
                        onChange={(e) => updateRow(i, 'service', e.target.value)}
                        className="h-8 text-xs"
                        placeholder="Service name"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min={1}
                        value={row.count}
                        onChange={(e) => updateRow(i, 'count', Number(e.target.value) || 1)}
                        className="h-8 text-xs text-center"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        value={row.configDetails}
                        onChange={(e) => updateRow(i, 'configDetails', e.target.value)}
                        className="h-8 text-xs"
                        placeholder="Config details"
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeRow(i)}
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {editRows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground text-sm py-4">
                      No resources. Click "+ Add Row" to add one.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-between pt-1">
            <Button size="sm" variant="outline" onClick={addRow}>
              <Plus className="h-3.5 w-3.5 mr-1" /> Add Row
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              disabled={saving}
              className="gradient-primary text-white"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <Check className="h-3.5 w-3.5 mr-1" />}
              Save Changes
            </Button>
          </div>
        </div>
      )}

      {renderSectionActions('cloud_resources')}
    </CardContent></Card>
  );
};


const ArchTabContent = ({ arch, id, renderValidationStatus, renderSectionActions }: any) => (
  <Card><CardContent className="p-5 space-y-4">
    <div className="flex items-center justify-between">
      <h3 className="font-semibold">Architecture Overview</h3>
      {renderValidationStatus('architecture')}
    </div>
    {arch ? (
      <div className="space-y-4">
        {arch.image_filename && (
          <div className="border rounded-lg overflow-hidden bg-muted/30 relative group">
            <a
              href={`${BASE_URL}/api/architecture-validation/${id}/image`}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="absolute top-2 right-2 p-2 bg-background/80 hover:bg-background rounded-md shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
              title="Download diagram"
            >
              <Download className="h-4 w-4" />
            </a>
            <img
              src={`${BASE_URL}/api/architecture-validation/${id}/image`}
              alt="Architecture diagram"
              className="max-w-full max-h-96 mx-auto p-4"
            />
          </div>
        )}
        {arch.user_context && (
          <div className="rounded-lg border bg-muted/30 p-4 space-y-1.5">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5 text-primary" /> Architecture Context (User Statement)
            </p>
            <p className="text-sm text-foreground whitespace-pre-wrap">{arch.user_context}</p>
          </div>
        )}
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="rounded border p-3">
            <p className="text-xs text-muted-foreground">Verdict</p>
            {arch.verdict ? (
              <Badge className={arch.verdict === 'PASS' ? 'bg-green-500/10 text-green-600' : 'bg-red-500/10 text-red-600'}>
                {arch.verdict}
              </Badge>
            ) : <Badge variant="secondary">Not validated</Badge>}
          </div>
          <div className="rounded border p-3">
            <p className="text-xs text-muted-foreground">Security Violations</p>
            <p className="font-medium">{arch.violations.length}</p>
          </div>
        </div>
        {arch.violations.length > 0 && (
          <ul className="text-xs space-y-1 list-disc pl-5">
            {arch.violations.map((v: any, i: number) => (
              <li key={`${v.finding}-${i}`} className="text-red-600">
                <span className="font-medium">{v.finding}</span> · {v.category} · {v.severity}
              </li>
            ))}
          </ul>
        )}
      </div>
    ) : (
      <p className="text-sm text-muted-foreground">Architecture validation has not been completed.</p>
    )}
    {renderSectionActions('architecture')}
  </CardContent></Card>
);

const CostBudgetingTabContent = ({
  allApproved, bothValidationsApproved, costReady, data, isReadOnly,
  handleLoadFromBucket, addCostRow, handleSaveCost, savingCost, resourceCosts,
  currency, updateResourceCost, removeCostRow, infraSupportCost, setInfraSupportCost,
  setCurrency, totalMonthly, costNotes, setCostNotes
}: any) => {
  const readOnly = isReadOnly ?? data?.is_read_only;

  if (!allApproved && !bothValidationsApproved && !costReady) {
    return (
      <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
        Cost budgeting unlocks after all sections are approved.
      </CardContent></Card>
    );
  }

  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Cost Budgeting</h3>
        <div className="flex gap-2">
          {!readOnly && resourceCosts.length === 0 && (
            <Button size="sm" variant="outline" onClick={handleLoadFromBucket}>
              Load from resources
            </Button>
          )}
          {!readOnly && (
            <Button size="sm" variant="outline" onClick={addCostRow}>
              <Plus className="h-3.5 w-3.5 mr-1" /> Add Row
            </Button>
          )}
          {!readOnly && (
            <Button
              size="sm"
              onClick={handleSaveCost}
              disabled={savingCost || resourceCosts.length === 0}
              className="gradient-primary text-white"
            >
              {savingCost ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <Send className="h-3.5 w-3.5 mr-1" />}
              Publish to User
            </Button>
          )}
        </div>
      </div>

      {costReady && (
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
          Cost published
        </Badge>
      )}

      <Table>
        <TableHeader><TableRow>
          <TableHead>Resource</TableHead>
          <TableHead className="w-32">Unit Cost ({currency})</TableHead>
          <TableHead className="w-20">Qty</TableHead>
          <TableHead className="w-32 text-right">Monthly ({currency})</TableHead>
          <TableHead className="w-10" />
        </TableRow></TableHeader>
        <TableBody>
          {resourceCosts.map((row: any, i: number) => (
            <TableRow key={row.id || `cost-row-${i}`}>
              <TableCell>
                <Input value={row.resource_name} onChange={(e) => updateResourceCost(i, 'resource_name', e.target.value)} className="h-8 text-xs" readOnly={!!readOnly} />
              </TableCell>
              <TableCell>
                <Input type="number" value={row.unit_cost || ''} onChange={(e) => updateResourceCost(i, 'unit_cost', Number(e.target.value))} className="h-8" readOnly={!!readOnly} />
              </TableCell>
              <TableCell>
                <Input type="number" value={row.quantity || ''} onChange={(e) => updateResourceCost(i, 'quantity', Number(e.target.value))} className="h-8" readOnly={!!readOnly} />
              </TableCell>
              <TableCell className="text-right font-mono text-xs">
                {(row.monthly_cost || 0).toLocaleString('en-IN')}
              </TableCell>
              <TableCell>
                {!readOnly && (
                  <Button variant="ghost" size="sm" onClick={() => removeCostRow(i)}>
                    <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
          {resourceCosts.length === 0 && (
            <TableRow>
              <TableCell colSpan={5} className="text-center text-muted-foreground text-sm py-6">
                No cost lines yet. Click "Load from resources" to seed from user's bucket.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
        <div className="rounded border p-3">
          <p className="text-xs text-muted-foreground">Infra Support ({currency})</p>
          <Input
            type="number"
            value={infraSupportCost || ''}
            onChange={(e) => setInfraSupportCost(Number(e.target.value))}
            className="mt-1"
          />
        </div>
        <div className="rounded border p-3">
          <p className="text-xs text-muted-foreground">Currency</p>
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="INR">INR (₹)</SelectItem>
              <SelectItem value="USD">USD ($)</SelectItem>
              <SelectItem value="EUR">EUR (€)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="rounded border p-3 bg-primary/5">
          <p className="text-xs text-muted-foreground">Total monthly</p>
          <p className="text-lg font-bold font-mono text-primary mt-1">
            {currency} {totalMonthly.toLocaleString('en-IN')}
          </p>
        </div>
      </div>

      <div>
        <p className="text-xs text-muted-foreground mb-1">Notes</p>
        <Textarea value={costNotes} onChange={(e) => setCostNotes(e.target.value)} placeholder="Additional notes…" rows={2} />
      </div>
    </CardContent></Card>
  );
};

const RecommendationsTabContent = ({
  costReady, data, recs, generating, handleGenerate, sendDialogOpen, setSendDialogOpen,
  handleSendToUser, sending, gpsRecs, rfcRecs, approvalRecs, setEditingRec, copyToClipboard,
  isReadOnly,
}: any) => {
  if (!costReady) {
    return (
      <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
        Approval Checklist unlocks after Cost Budgeting is published.
      </CardContent></Card>
    );
  }

  const isSentToUser = [
    'approval_checklist_sent',
    'approvals_under_review',
    'approvals_sent_back',
    'approvals_approved',
    'cb_id_created',
    'completed',
  ].includes(data?.admin_status ?? '');

  const canEdit = !isReadOnly && !isSentToUser;

  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">Approval Checklist</h3>
          <p className="text-xs text-muted-foreground">
            {isSentToUser
              ? 'Checklist has been sent to the user and is now read-only.'
              : 'Review and edit approval checklist items before sending to the user.'}
          </p>
        </div>
        <div className="flex gap-2">
          {!isReadOnly && recs.length === 0 && !generating && (
            <Button size="sm" onClick={handleGenerate} className="gradient-primary text-white">
              <Sparkles className="h-3.5 w-3.5 mr-1" /> Fetch Approvals
            </Button>
          )}
          {!isReadOnly && recs.length > 0 && (
            <Dialog open={sendDialogOpen} onOpenChange={setSendDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gradient-primary text-white">
                  <Send className="h-3.5 w-3.5 mr-1" />
                  {data.admin_status === 'approval_checklist_sent' ? 'Re-send' : 'Send to User'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Send Approval Checklist to User</DialogTitle>
                  <DialogDescription>This will make Approval Checklist and cost visible to the user.</DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setSendDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleSendToUser} disabled={sending} className="gradient-primary text-white">
                    {sending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                    Confirm & Send
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {isSentToUser && (
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
          Approval Checklist sent to user
        </Badge>
      )}

      {generating && (
        <div className="text-center py-8 space-y-3">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
          <p className="text-sm font-medium">Generating Approval Checklist...</p>
          <p className="text-xs text-muted-foreground">This may take 10-30 seconds.</p>
        </div>
      )}

      {recs.length === 0 && !generating && (
        <div className="rounded-lg border border-dashed bg-muted/40 p-8 text-center space-y-3">
          <Sparkles className="h-8 w-8 mx-auto text-muted-foreground" />
          <p className="text-sm font-medium">No Approval Checklist yet</p>
          <p className="text-xs text-muted-foreground">Click Fetch Approvals to create Approval Checklist.</p>
        </div>
      )}

      {recs.length > 0 && !generating && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5" /> Approval Checklist ({approvalRecs.length})
          </h4>
          {approvalRecs.map((rec: any) => {
            const role =
              rec.parameters?.find((p: any) => p.label === 'Approver Role' || p.label === 'approver_role')?.value ??
              'Approver';
            return (
              <div key={rec.id} className="rounded border p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="h-8 w-8 rounded-full bg-purple-500/10 text-purple-600 flex items-center justify-center shrink-0">
                    <ShieldCheck className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{rec.title}</p>
                      {rec.status === 'edited' && (
                        <Badge variant="secondary" className="text-[10px] py-0 px-1.5 text-muted-foreground font-normal">
                          Edited
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{rec.summary}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant="outline" className="text-[10px]">
                    {role}
                  </Badge>
                  {canEdit && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 px-2.5 text-xs gap-1"
                      onClick={() => setEditingRec({ ...rec })}
                    >
                      <Edit className="h-3.5 w-3.5" />
                      Edit
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </CardContent></Card>
  );
};

// ─── Approve Approvals Tab ───

const ApproveApprovalsTabContent = ({
  isReady, screenshots, approvalRecs, isReadOnly, approvingScreenshot,
  sendBackScreenshotComment, setSendBackScreenshotComment, sendingBackScreenshot,
  handleApproveScreenshot, handleSendBackScreenshot, onboardingId,
}: {
  isReady: boolean;
  screenshots: AdminApprovalScreenshotItem[];
  approvalRecs: RecommendationItem[];
  isReadOnly: boolean;
  approvingScreenshot: string | null;
  sendBackScreenshotComment: Record<string, string>;
  setSendBackScreenshotComment: (v: Record<string, string>) => void;
  sendingBackScreenshot: string | null;
  handleApproveScreenshot: (recId: string) => void;
  handleSendBackScreenshot: (recId: string) => void;
  onboardingId: string;
}) => {
  if (!isReady) {
    return (
      <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
        Approve Approvals unlocks after the Approval Checklist has been sent to the user.
      </CardContent></Card>
    );
  }

  const screenshotMap = new Map(screenshots.map((s) => [s.rec_id, s]));
  const approvedCount = screenshots.filter((s) => s.admin_status === "approved").length;

  return (
    <Card>
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Approve Approvals</h3>
          <Badge
            className={
              approvedCount === approvalRecs.length && approvalRecs.length > 0
                ? "bg-green-500/10 text-green-600 border-green-500/20"
                : "bg-muted text-muted-foreground"
            }
          >
            {approvedCount} / {approvalRecs.length} Approved
          </Badge>
        </div>

        {approvalRecs.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">
            No approval checklist items found. Generate the approval checklist first.
          </p>
        )}

        <div className="space-y-4">
          {approvalRecs.map((rec) => {
            const recScreenshots = screenshots.filter((s) => s.rec_id === rec.id);
            const hasScreenshots = recScreenshots.length > 0;
            const isApproved = hasScreenshots && recScreenshots.every((s) => s.admin_status === "approved");
            const isUploaded = hasScreenshots && !isApproved && recScreenshots.some((s) => s.admin_status === "uploaded");
            const isSentBack = hasScreenshots && !isApproved && !isUploaded && recScreenshots.some((s) => s.admin_status === "sent_back");
            const latestComment = recScreenshots.find((s) => s.admin_comment)?.admin_comment;
            const isApproving = approvingScreenshot === rec.id;
            const isSendingBack = sendingBackScreenshot === rec.id;

            return (
              <div key={rec.id} className={`rounded-lg border p-4 space-y-3
                ${isApproved ? "border-green-500/30 bg-green-500/5" : ""}
                ${isSentBack ? "border-amber-500/30 bg-amber-500/5" : ""}
              `}>
                {/* Title row */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold">{rec.title}</p>
                    <p className="text-xs text-muted-foreground">{rec.summary}</p>
                  </div>
                  {isApproved && (
                    <Badge className="bg-green-500/10 text-green-600 border-green-500/20 gap-1 shrink-0">
                      <CheckCircle2 className="h-3 w-3" /> Approved
                    </Badge>
                  )}
                  {isSentBack && (
                    <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 gap-1 shrink-0">
                      <RotateCcw className="h-3 w-3" /> Sent Back
                    </Badge>
                  )}
                  {isUploaded && (
                    <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20 gap-1 shrink-0">
                      <FileImage className="h-3 w-3" /> Uploaded ({recScreenshots.length} proof{recScreenshots.length > 1 ? "s" : ""})
                    </Badge>
                  )}
                  {!hasScreenshots && (
                    <Badge className="bg-muted text-muted-foreground gap-1 shrink-0">
                      <UploadCloud className="h-3 w-3" /> Not Uploaded
                    </Badge>
                  )}
                </div>

                {/* Screenshots info */}
                {hasScreenshots ? (
                  <div className="space-y-3">
                    <p className="text-xs font-medium text-slate-600">
                      {recScreenshots.length} attachment{recScreenshots.length > 1 ? "s" : ""} uploaded:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {recScreenshots.map((item) => (
                        <div key={item.id} className="border rounded-lg p-3 bg-slate-50/60 space-y-2">
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <FileImage className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                            <span className="font-medium text-foreground truncate">{item.filename}</span>
                            <span className="ml-auto shrink-0">{item.uploaded_at ? new Date(item.uploaded_at).toLocaleDateString() : "—"}</span>
                          </div>

                          {/* Image preview */}
                          {item.content_type?.startsWith("image/") && (
                            <div className="relative group max-w-md rounded-lg border bg-white p-2 overflow-hidden">
                              <img
                                src={`${BASE_URL}/api/approval-screenshots/${onboardingId}/image/${item.id}`}
                                alt={item.filename}
                                className="max-h-48 object-contain rounded mx-auto"
                              />
                              <a
                                href={`${BASE_URL}/api/approval-screenshots/${onboardingId}/image/${item.id}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="absolute top-2 right-2 px-2 py-1 bg-white/95 hover:bg-white rounded shadow-sm opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-xs text-slate-800"
                                title="Open full image in new tab"
                              >
                                <Eye className="h-3.5 w-3.5" /> Full View
                              </a>
                            </div>
                          )}

                          {/* Download link */}
                          <a
                            href={`${BASE_URL}/api/approval-screenshots/${onboardingId}/image/${item.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-primary hover:underline flex items-center gap-1 w-fit"
                          >
                            <Download className="h-3 w-3" /> Download ({item.filename})
                          </a>
                        </div>
                      ))}
                    </div>

                    {/* Admin previous comment */}
                    {latestComment && (
                      <div className="text-xs bg-amber-50 border border-amber-200 rounded px-3 py-2 text-amber-800">
                        <strong>Previous note:</strong> {latestComment}
                      </div>
                    )}

                    {/* Actions — only if not yet approved and not read-only */}
                    {!isReadOnly && !isApproved && (
                      <div className="space-y-2 pt-2 border-t">
                        <Textarea
                          placeholder="Comment for user (required for Send Back)…"
                          value={sendBackScreenshotComment[rec.id] ?? ""}
                          onChange={(e) =>
                            setSendBackScreenshotComment({ ...sendBackScreenshotComment, [rec.id]: e.target.value })
                          }
                          rows={2}
                          className="text-sm"
                        />
                        <div className="flex gap-2 justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSendBackScreenshot(rec.id)}
                            disabled={isSendingBack || isApproving}
                          >
                            {isSendingBack
                              ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                              : <AlertTriangle className="h-3.5 w-3.5 mr-1" />}
                            Send Back
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleApproveScreenshot(rec.id)}
                            disabled={isApproving || isSendingBack}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            {isApproving
                              ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                              : <CheckCircle2 className="h-3.5 w-3.5 mr-1" />}
                            Approve
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground italic">
                    User has not uploaded a screenshot yet.
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

// ─── CB ID Tab ───
const CbIdTabContent = ({
  isReady,
  data,
  cbIdData,
  generatingCbId,
  handleGenerateCbId,
  isReadOnly,
}: {
  isReady: boolean;
  data: AdminOnboarding;
  cbIdData: CbIdInfo | null;
  generatingCbId: boolean;
  handleGenerateCbId: () => void;
  isReadOnly?: boolean;
}) => {
  const [copied, setCopied] = useState(false);

  const copyCbId = (idStr: string) => {
    navigator.clipboard.writeText(idStr);
    setCopied(true);
    toast({ title: "Copied", description: "CB ID copied to clipboard." });
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isReady && !cbIdData) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-sm text-muted-foreground">
          CB ID generation unlocks after all approvals in the "Approve Approvals" section are verified.
        </CardContent>
      </Card>
    );
  }

  const appName = data.account_details?.project_name || data.name || "Untitled Application";
  const solutionType = data.requirement_assessment?.solution_type || "";
  const isGenAi = ["generative-ai", "genai", "generative ai"].includes(solutionType.toLowerCase());

  if (cbIdData?.cb_id) {
    return (
      <Card className="border-2 border-emerald-500/20 bg-emerald-500/5">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base font-semibold text-emerald-900">
                CB ID Generated
              </CardTitle>
            </div>
            {/* <Badge className="bg-emerald-100 text-emerald-800 border-emerald-300">
              Active
            </Badge> */}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg border bg-white p-5 shadow-sm space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-muted/30 rounded-lg border">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Application Name
                </p>
                <p className="text-base font-semibold text-foreground mt-1">
                  {cbIdData.application_name || appName}
                </p>
              </div>
              <div className="p-3 bg-primary/5 rounded-lg border border-primary/20 flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-primary uppercase tracking-wider">
                    CB ID
                  </p>
                  <p className="text-xl font-mono font-bold text-primary mt-1">
                    {cbIdData.cb_id}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyCbId(cbIdData.cb_id)}
                  className="gap-1.5"
                >
                  {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                  {copied ? "Copied" : "Copy"}
                </Button>
              </div>
            </div>

            <div className="p-4 bg-muted/40 rounded-lg text-sm space-y-1">
              <p className="font-medium text-foreground">
                Application: <span className="text-primary font-semibold">{cbIdData.application_name || appName}</span> · CB ID: <span className="font-mono text-primary font-semibold">{cbIdData.cb_id}</span>
              </p>
              <p className="text-xs text-muted-foreground">
                This CB ID has been provisioned. The user will now see their CB ID to proceed with RFC creation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          CB ID Generation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="rounded-lg border p-5 bg-muted/30 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
            <div className="p-3 bg-background rounded border">
              <p className="text-xs text-muted-foreground">Application Name</p>
              <p className="font-semibold text-foreground mt-0.5">{appName}</p>
            </div>
            <div className="p-3 bg-background rounded border">
              <p className="text-xs text-muted-foreground">Solution Type</p>
              <p className="font-medium text-foreground mt-0.5 flex items-center gap-1.5">
                <Badge variant="secondary">
                  {solutionType.replace(/-/g, " ") || "Non-Generative AI"}
                </Badge>
              </p>
            </div>
            <div className="p-3 bg-background rounded border">
              <p className="text-xs text-muted-foreground">Target ID Format</p>
              <p className="font-mono text-xs font-semibold text-primary mt-1">
                {isGenAi ? "CBAI001" : "CB001"}
              </p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            Clicking <strong>Generate CB ID</strong> will generate a unique {isGenAi ? "Generative AI (e.g. CBAI001)" : "standard (e.g. CB001)"} CB ID and save it in the <code className="font-mono text-xs">cbid</code> repository. Only one CB ID can be created per onboarding.
          </p>
        </div>

        {!isReadOnly && (
          <div className="flex justify-start">
            <Button
              onClick={handleGenerateCbId}
              disabled={generatingCbId}
              className="gradient-primary text-white gap-2"
              size="lg"
            >
              {generatingCbId ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
              Generate CB ID
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};


// ─── Main Component ───

const AdminOnboardingReview = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // ── General state ──
  const [data, setData] = useState<AdminOnboarding | null>(null);
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<InteractionEvent[]>([]);

  // ── Review state ──
  const [feedbackComment, setFeedbackComment] = useState<Record<Section, string>>({
    account_details: '', requirements: '', cloud_resources: '', architecture: '',
  });
  const [submitting, setSubmitting] = useState<string | null>(null);
  const [sendBackComment, setSendBackComment] = useState('');
  const [sendingBack, setSendingBack] = useState(false);
  const [approving, setApproving] = useState(false);

  // ── Cost state ──
  const [resourceCosts, setResourceCosts] = useState<ResourceCostItem[]>([]);
  const [infraSupportCost, setInfraSupportCost] = useState(0);
  const [currency, setCurrency] = useState('INR');
  const [costNotes, setCostNotes] = useState('');
  const [savingCost, setSavingCost] = useState(false);

  // ── Recommendations state ──
  const [recs, setRecs] = useState<RecommendationItem[]>([]);
  const [generating, setGenerating] = useState(false);
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [editingRec, setEditingRec] = useState<RecommendationItem | null>(null);
  const [activityOpen, setActivityOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("details");

  // ── Approval Screenshots state ──
  const [screenshots, setScreenshots] = useState<AdminApprovalScreenshotItem[]>([]);
  const [approvingScreenshot, setApprovingScreenshot] = useState<string | null>(null);
  const [sendingBackScreenshot, setSendingBackScreenshot] = useState<string | null>(null);
  const [sendBackScreenshotComment, setSendBackScreenshotComment] = useState<Record<string, string>>({});

  // ── CB ID state ──
  const [cbIdData, setCbIdData] = useState<CbIdInfo | null>(null);
  const [generatingCbId, setGeneratingCbId] = useState(false);

  // ── Data loading ──
  const loadData = () => {
    if (!id) return;
    setLoading(true);
    Promise.all([
      fetchAdminOnboarding(id),
      getRecommendations(id).catch(() => []),
      fetchInteractionEvents(id).catch(() => []),
      getAdminApprovalScreenshots(id).catch(() => []),
      getCbId(id).catch(() => null),
    ])
      .then(([onb, r, evts, ss, cb]) => {
        setData(onb);
        setCbIdData(cb || onb.cb_id_record || null);
        setRecs(r.length > 0 ? r : onb.recommendations ?? []);
        setScreenshots(ss as AdminApprovalScreenshotItem[]);
        setEvents((evts as InteractionEventItem[]).map((e) => ({
          id: e.id,
          ts: e.ts,
          actor: e.actor,
          actorName: e.actor_name,
          kind: e.kind as InteractionEvent['kind'],
          title: e.title,
          body: e.body ?? undefined,
          scope: e.scope ?? undefined,
        })));
        if (onb.cost_estimation) {
          setResourceCosts(
            (onb.cost_estimation.resource_costs || []).map((r: any, idx: number) => ({
              id: r.id || `cost-loaded-${idx}-${Date.now()}`,
              ...r,
            }))
          );
          setInfraSupportCost(onb.cost_estimation.infra_support_cost);
          setCurrency(onb.cost_estimation.currency);
          setCostNotes(onb.cost_estimation.notes);
        } else if (onb.cloud_resource_bucket?.resources && onb.cloud_resource_bucket.resources.length > 0) {
          setResourceCosts(
            onb.cloud_resource_bucket.resources.map((r: any, idx: number) => ({
              id: `bucket-${idx}-${Date.now()}`,
              resource_name: r.service,
              unit_cost: 0,
              quantity: r.count,
              monthly_cost: 0,
            }))
          );
        }
      })
      .catch(() => toast({ title: "Error", description: "Failed to load onboarding.", variant: "destructive" }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, [id]);

  // ── Review helpers ──
  const feedbacks = data?.validation_feedbacks ?? [];
  const getFeedback = (section: Section): ValidationFeedback | undefined => feedbacks.find((f) => f.section === section);

  const approvedCount = SECTIONS.filter((s) => getFeedback(s)?.status === 'approved').length;
  const rejectedCount = SECTIONS.filter((s) => getFeedback(s)?.status === 'rejected').length;
  const allApproved = approvedCount === 4;
  const isUnassigned = data ? (data.admin_status === 'pending_assignment' || (!data.admin_assignment && !data.assigned_admin_id)) : false;
  // This admin cannot edit this onboarding if it is not assigned to them or if it is unassigned:
  const isReadOnlyAdmin = data ? (data.is_read_only || isUnassigned) : false;
  // Section-level approval/rejection (Steps 1-4) is locked once past the initial review stage:
  const isSectionReviewLocked = isReadOnlyAdmin || (data?.admin_status !== 'assigned' && data?.admin_status !== 'under_review');
  const bothValidationsApproved = getFeedback('cloud_resources')?.status === 'approved' && getFeedback('architecture')?.status === 'approved';
  const costReady = ['cost_done', 'approval_checklist_sent', 'approvals_under_review', 'approvals_sent_back', 'approvals_approved', 'cb_id_created', 'completed'].includes(data?.admin_status ?? '');

  // ── Review actions ──
  const handleSectionApprove = async (section: Section) => {
    if (!id || isSectionReviewLocked) return;
    setSubmitting(section);
    try {
      await submitFeedback(id, { section, status: 'approved' });
      toast({ title: "Section Approved", description: `${sectionLabels[section]} has been approved.` });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to submit feedback.", variant: "destructive" });
    } finally {
      setSubmitting(null);
    }
  };

  const handleSectionReject = async (section: Section) => {
    if (!id || isSectionReviewLocked) return;
    const comment = feedbackComment[section];
    if (!comment.trim()) {
      toast({ title: "Comment Required", description: "Please provide a reason for requesting changes.", variant: "destructive" });
      return;
    }
    setSubmitting(section);
    try {
      await submitFeedback(id, { section, status: 'rejected', comment });
      toast({ title: "Changes Requested", description: `Feedback sent for ${sectionLabels[section]}.` });
      setFeedbackComment((prev) => ({ ...prev, [section]: '' }));
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to submit feedback.", variant: "destructive" });
    } finally {
      setSubmitting(null);
    }
  };

  const handleApproveAll = async () => {
    if (!id || isSectionReviewLocked) return;
    setApproving(true);
    try {
      await approveOnboarding(id);
      toast({ title: "Onboarding Approved!", description: "Proceeding to cost budgeting." });
      setActiveTab("cost");
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to approve.", variant: "destructive" });
    } finally {
      setApproving(false);
    }
  };

  const handleSendBack = async () => {
    if (!id || isSectionReviewLocked) return;
    if (!sendBackComment.trim()) {
      toast({ title: "Comment Required", description: "Provide feedback for the user.", variant: "destructive" });
      return;
    }
    setSendingBack(true);
    try {
      await sendBackOnboarding(id, { comment: sendBackComment });
      toast({ title: "Sent Back", description: "Onboarding sent back to the user." });
      navigate('/admin');
    } catch {
      toast({ title: "Error", description: "Failed to send back.", variant: "destructive" });
    } finally {
      setSendingBack(false);
    }
  };

  // ── Cost actions ──
  const updateResourceCost = (index: number, field: keyof ResourceCostItem, value: string | number) => {
    setResourceCosts((prev) => {
      const updated = [...prev];
      const item = { ...updated[index], [field]: value };
      if (field === 'unit_cost' || field === 'quantity') {
        item.monthly_cost = (Number(item.unit_cost) || 0) * (Number(item.quantity) || 0);
      }
      updated[index] = item;
      return updated;
    });
  };

  const addCostRow = () => {
    setResourceCosts((prev) => [
      ...prev,
      {
        id: `cost-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        resource_name: '',
        unit_cost: 0,
        quantity: 1,
        monthly_cost: 0,
      },
    ]);
  };

  const removeCostRow = (index: number) => {
    setResourceCosts((prev) => prev.filter((_, i) => i !== index));
  };

  const handleLoadFromBucket = async () => {
    if (!id) return;
    try {
      const items = await seedCostFromBucket(id);
      setResourceCosts(
        items.map((it: any, idx: number) => ({
          id: it.id || `bucket-${idx}-${Date.now()}`,
          ...it,
        }))
      );
      toast({ title: "Loaded", description: `${items.length} resource(s) loaded from bucket.` });
    } catch {
      if (data?.cloud_resource_bucket?.resources) {
        setResourceCosts(
          data.cloud_resource_bucket.resources.map((r, idx) => ({
            id: `bucket-${idx}-${Date.now()}`,
            resource_name: r.service,
            unit_cost: 0,
            quantity: r.count,
            monthly_cost: 0,
          }))
        );
        toast({ title: "Loaded from cache", description: "Resources loaded from local data." });
      }
    }
  };

  const resourceSubtotal = resourceCosts.reduce((sum, r) => sum + (r.monthly_cost || 0), 0);
  const totalMonthly = resourceSubtotal + infraSupportCost;
  const totalAnnual = totalMonthly * 12;

  const handleSaveCost = async () => {
    if (!id || isReadOnlyAdmin) return;
    setSavingCost(true);
    try {
      await upsertCost(id, {
        resource_costs: resourceCosts,
        infra_support_cost: infraSupportCost,
        total_monthly_cost: totalMonthly,
        total_annual_cost: totalAnnual,
        currency,
        notes: costNotes,
      });
      toast({ title: "Cost Saved", description: "Cost estimation published to user." });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to save cost.", variant: "destructive" });
    } finally {
      setSavingCost(false);
    }
  };

  // ── Recommendations actions ──
  const handleGenerate = async () => {
    if (!id || isReadOnlyAdmin) return;
    setGenerating(true);
    try {
      const generated = await generateRecommendations(id);
      setRecs(generated);
      toast({ title: "Generated", description: `${generated.length} approval checklist items created.` });
    } catch {
      toast({ title: "Error", description: "Failed to generate.", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const handleSendToUser = async () => {
    if (!id || isReadOnlyAdmin) return;
    setSending(true);
    try {
      await sendToUser(id);
      toast({ title: "Sent to User", description: "Approval checklist visible to the user." });
      setSendDialogOpen(false);
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to send.", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "Copied to clipboard." });
  };

  // ── Approval Screenshot handlers ──
  const handleApproveScreenshot = async (recId: string) => {
    if (!id) return;
    setApprovingScreenshot(recId);
    try {
      await approveApprovalScreenshot(id, recId);
      toast({ title: "Approved", description: "Approval screenshot verified." });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to approve screenshot.", variant: "destructive" });
    } finally {
      setApprovingScreenshot(null);
    }
  };

  const handleSendBackScreenshot = async (recId: string) => {
    if (!id) return;
    const comment = sendBackScreenshotComment[recId] ?? "";
    if (!comment.trim()) {
      toast({ title: "Comment Required", description: "Please provide a reason for sending back.", variant: "destructive" });
      return;
    }
    setSendingBackScreenshot(recId);
    try {
      await sendBackApprovalScreenshot(id, recId, comment);
      toast({ title: "Sent Back", description: "User will be notified to re-upload." });
      setSendBackScreenshotComment((prev) => ({ ...prev, [recId]: "" }));
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to send back screenshot.", variant: "destructive" });
    } finally {
      setSendingBackScreenshot(null);
    }
  };

  // ── CB ID handler ──
  const handleGenerateCbId = async () => {
    if (!id) return;
    setGeneratingCbId(true);
    try {
      const res = await generateCbId(id);
      setCbIdData(res);
      toast({
        title: "CB ID Generated",
        description: `CB ID ${res.cb_id} generated for ${res.application_name}.`,
      });
      loadData();
    } catch {
      toast({
        title: "Error",
        description: "Failed to generate CB ID.",
        variant: "destructive",
      });
    } finally {
      setGeneratingCbId(false);
    }
  };

  const gpsRecs = recs.filter((r) => r.category === 'gps');
  const rfcRecs = recs.filter((r) => r.category === 'rfc');
  const approvalRecs = recs.filter((r) => r.category === 'approval');

  // ── Validation status rendering ──
  const renderValidationStatus = (section: Section) => {
    const fb = getFeedback(section);
    if (!fb) return null;
    if (fb.status === 'approved') {
      return (
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20 gap-1">
          <CheckCircle2 className="h-3 w-3" /> Approved
        </Badge>
      );
    }
    return (
      <div className="space-y-1">
        <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 gap-1">
          <AlertTriangle className="h-3 w-3" /> Changes Requested
        </Badge>
        {fb.comment && <p className="text-xs text-muted-foreground italic pl-1">"{fb.comment}"</p>}
      </div>
    );
  };

  const renderSectionActions = (section: Section) => {
    const fb = getFeedback(section);
    if (fb || isSectionReviewLocked) return null;
    const isSubmitting = submitting === section;
    return (
      <div className="space-y-3 pt-4 border-t">
        <Textarea
          placeholder="Comment for user (required for Send Back)…"
          value={feedbackComment[section]}
          onChange={(e) => setFeedbackComment((prev) => ({ ...prev, [section]: e.target.value }))}
          rows={2}
          className="text-sm"
        />
        <div className="flex gap-2 justify-end">
          <Button
            size="sm"
            variant="outline"
            onClick={() => handleSectionReject(section)}
            disabled={isSubmitting}
          >
            {isSubmitting ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <AlertTriangle className="h-3.5 w-3.5 mr-1" />}
            Send Back
          </Button>
          <Button
            size="sm"
            onClick={() => handleSectionApprove(section)}
            disabled={isSubmitting}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            {isSubmitting ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1" />}
            Approve
          </Button>
        </div>
      </div>
    );
  };

  // ── Loading / not found ──
  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  if (!data) {
    return (
      <AdminLayout>
        <Card><CardContent className="p-10 text-center space-y-3">
          <p className="text-sm text-muted-foreground">
            Onboarding <span className="font-mono">{id}</span> not found.
          </p>
          <Link to="/admin"><Button variant="outline" size="sm"><ArrowLeft className="h-3 w-3 mr-1" /> Back to dashboard</Button></Link>
        </CardContent></Card>
      </AdminLayout>
    );
  }

  const acct = data.account_details;
  const req = data.requirement_assessment;
  const bucket = data.cloud_resource_bucket;
  const arch = data.architecture_validation;

  const statusTone = (status: string) => {
    if (['approved', 'cost_done', 'approval_checklist_sent', 'approvals_approved', 'cb_id_created', 'completed'].includes(status)) return 'bg-green-500/10 text-green-600 border-green-500/20';
    if (['sent_back', 'approvals_sent_back'].includes(status)) return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    if (status === 'cost_pending') return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    if (status === 'approvals_under_review') return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
  };

  return (
    <AdminLayout>
      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6 max-w-[1500px]">
        {/* ── Main content ── */}
        <div className="space-y-4 min-w-0">
          {/* Back link */}
          <Link to="/admin" className="text-xs text-muted-foreground inline-flex items-center gap-1 hover:text-foreground">
            <ArrowLeft className="h-3 w-3" /> Back to dashboard
          </Link>

          {/* Pending assignment banner */}
          {isUnassigned && (
            <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-amber-50 border border-amber-300 text-amber-800 text-sm">
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
              <span>
                <strong>Pending Admin Assignment.</strong> A SuperAdmin must assign a DIS Admin to this project before review can begin.
              </span>
            </div>
          )}

          {/* Read-only banner for non-assigned admins */}
          {!isUnassigned && data.is_read_only && (
            <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-sm">
              <Eye className="h-4 w-4 shrink-0" />
              <span>
                <strong>Read-only view.</strong> This onboarding is assigned to another admin. You can view progress but cannot take actions.
              </span>
            </div>
          )}

          {/* Header card */}
          <Card>
            <CardHeader className="flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle className="text-xl">{data.name}</CardTitle>
                <p className="text-xs text-muted-foreground mt-1 font-mono">{data.id}</p>
                <p className="text-xs text-muted-foreground">
                  Requestor: {data.user_name || acct?.owner || '—'}
                  {data.user_email && <span className="ml-1">({data.user_email})</span>}
                  {data.user_emp_id && <span className="ml-1">· EmpID: {data.user_emp_id}</span>}
                  {acct?.business_unit && <span className="ml-1">· BU: {acct.business_unit}</span>}
                </p>
              </div>
              {/* <Badge className={statusTone(data.admin_status)}>
                {data.admin_status?.replace(/_/g, ' ')}
              </Badge> */}
              <Badge className={statusTone(data.admin_status)}>
                {formatAdminStatus(data.admin_status)}
              </Badge>
            </CardHeader>
          </Card>

          {/* ── 5-Tab Review ── */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="flex-wrap h-auto gap-1">
              <TabsTrigger value="details" className="gap-1.5">
                <ClipboardList className="h-3.5 w-3.5" /> Application Details
                {getFeedback('account_details')?.status === 'approved' && getFeedback('requirements')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="resource" className="gap-1.5">
                <Server className="h-3.5 w-3.5" /> Resource Validation
                {getFeedback('cloud_resources')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="arch" className="gap-1.5">
                <Layers className="h-3.5 w-3.5" /> Architecture
                {getFeedback('architecture')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="cost" className="gap-1.5">
                <DollarSign className="h-3.5 w-3.5" /> Cost Budgeting
                {costReady && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="recs" className="gap-1.5">
                <Lightbulb className="h-3.5 w-3.5" /> Approval Checklist
                {['approval_checklist_sent', 'approvals_under_review', 'approvals_sent_back', 'approvals_approved', 'cb_id_created', 'completed'].includes(data.admin_status) && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="approve-approvals" className="gap-1.5">
                <UploadCloud className="h-3.5 w-3.5" /> Approve Approvals
                {(['approvals_approved', 'cb_id_created'].includes(data.admin_status) || (screenshots.length > 0 && screenshots.every((s) => s.admin_status === 'approved'))) && (
                  <CheckCircle2 className="h-3 w-3 text-green-600" />
                )}
              </TabsTrigger>
              <TabsTrigger value="cb-id" className="gap-1.5">
                <Sparkles className="h-3.5 w-3.5" /> CB ID
                {cbIdData?.cb_id && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details">
              <DetailsTabContent
                acct={acct}
                req={req}
                renderValidationStatus={renderValidationStatus}
                renderSectionActions={renderSectionActions}
              />
            </TabsContent>

            <TabsContent value="resource">
              <ResourceTabContent
                bucket={bucket}
                renderValidationStatus={renderValidationStatus}
                renderSectionActions={renderSectionActions}
                isReadOnly={isSectionReviewLocked}
                onboardingId={id || ''}
                onSaved={loadData}
              />
            </TabsContent>

            <TabsContent value="arch">
              <ArchTabContent
                arch={arch}
                id={id}
                renderValidationStatus={renderValidationStatus}
                renderSectionActions={renderSectionActions}
              />
            </TabsContent>

            <TabsContent value="cost">
              <CostBudgetingTabContent
                allApproved={allApproved}
                bothValidationsApproved={bothValidationsApproved}
                costReady={costReady}
                data={data}
                isReadOnly={isReadOnlyAdmin}
                resourceCosts={resourceCosts}
                handleLoadFromBucket={handleLoadFromBucket}
                addCostRow={addCostRow}
                handleSaveCost={handleSaveCost}
                savingCost={savingCost}
                updateResourceCost={updateResourceCost}
                removeCostRow={removeCostRow}
                currency={currency}
                infraSupportCost={infraSupportCost}
                setInfraSupportCost={setInfraSupportCost}
                setCurrency={setCurrency}
                totalMonthly={totalMonthly}
                costNotes={costNotes}
                setCostNotes={setCostNotes}
              />
            </TabsContent>

            <TabsContent value="recs">
              <RecommendationsTabContent
                costReady={costReady}
                data={data}
                recs={recs}
                generating={generating}
                handleGenerate={handleGenerate}
                sendDialogOpen={sendDialogOpen}
                setSendDialogOpen={setSendDialogOpen}
                handleSendToUser={handleSendToUser}
                sending={sending}
                gpsRecs={gpsRecs}
                rfcRecs={rfcRecs}
                approvalRecs={approvalRecs}
                setEditingRec={setEditingRec}
                copyToClipboard={copyToClipboard}
                isReadOnly={isReadOnlyAdmin}
              />
            </TabsContent>

            <TabsContent value="approve-approvals">
              <ApproveApprovalsTabContent
                isReady={['approval_checklist_sent', 'approvals_under_review', 'approvals_sent_back', 'approvals_approved', 'cb_id_created', 'completed'].includes(data.admin_status)}
                screenshots={screenshots}
                approvalRecs={approvalRecs}
                isReadOnly={isReadOnlyAdmin}
                approvingScreenshot={approvingScreenshot}
                sendBackScreenshotComment={sendBackScreenshotComment}
                setSendBackScreenshotComment={setSendBackScreenshotComment}
                sendingBackScreenshot={sendingBackScreenshot}
                handleApproveScreenshot={handleApproveScreenshot}
                handleSendBackScreenshot={handleSendBackScreenshot}
                onboardingId={id || data.id}
              />
            </TabsContent>

            <TabsContent value="cb-id">
              <CbIdTabContent
                isReady={['approvals_approved', 'cb_id_created', 'completed'].includes(data.admin_status) || (screenshots.length > 0 && screenshots.every((s) => s.admin_status === 'approved'))}
                data={data}
                cbIdData={cbIdData}
                generatingCbId={generatingCbId}
                handleGenerateCbId={handleGenerateCbId}
                isReadOnly={isReadOnlyAdmin}
              />
            </TabsContent>
          </Tabs>

          {/* ── Bottom Action Bar ── */}
          <AdminActionPanel
            isReadOnly={isReadOnlyAdmin}
            isUnassigned={isUnassigned}
            adminStatus={data.admin_status}
            allApproved={allApproved}
            approving={approving}
            handleApproveAll={handleApproveAll}
            rejectedCount={rejectedCount}
            sendBackComment={sendBackComment}
            setSendBackComment={setSendBackComment}
            sendingBack={sendingBack}
            handleSendBack={handleSendBack}
          />
        </div>

        {/* ── Right Rail: Activity Timeline (collapsible) ── */}
        <aside className="xl:sticky xl:top-6 self-start">
          <Collapsible open={activityOpen} onOpenChange={setActivityOpen}>
            <Card>
              <CollapsibleTrigger asChild>
                <button className="w-full flex items-center justify-between p-4 hover:bg-muted/40 transition-colors rounded-t-lg">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold text-sm">User ↔ Admin Activity</span>
                    <Badge variant="secondary" className="text-[10px] h-5">{events.length}</Badge>
                  </div>
                  {activityOpen
                    ? <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    : <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  }
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="p-4 pt-0 max-h-[calc(100vh-12rem)] overflow-auto">
                  <InteractionTimeline
                    events={events}
                    title=""
                    emptyHint="No interactions yet. Submissions, comments, decisions and publishes appear here."
                    compact
                  />
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        </aside>
      </div>

      <EditRecommendationDialog
        editingRec={editingRec}
        setEditingRec={setEditingRec}
        setRecs={setRecs}
        onboardingId={id || data.id}
      />
    </AdminLayout>
  );
};

export default AdminOnboardingReview;