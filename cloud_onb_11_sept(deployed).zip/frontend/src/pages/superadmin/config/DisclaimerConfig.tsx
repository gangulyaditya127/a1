import { useState, useEffect } from "react";
import {
  Loader2,
  Plus,
  Pencil,
  Trash2,
  ArrowLeft,
  GripVertical,
} from "lucide-react";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import {
  fetchDisclaimerClauses,
  createDisclaimerClause,
  updateDisclaimerClause,
  deleteDisclaimerClause,
  type DisclaimerClause,
} from "@/lib/adminApi";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useNavigate } from "react-router-dom";

const DisclaimerConfig = () => {
  const [clauses, setClauses] = useState<DisclaimerClause[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentClause, setCurrentClause] = useState<Partial<DisclaimerClause> | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const loadClauses = () => {
    setLoading(true);
    fetchDisclaimerClauses()
      .then(setClauses)
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to load disclaimer clauses.",
          variant: "destructive",
        });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadClauses();
  }, []);

  const handleSave = async () => {
    if (!currentClause?.title || !currentClause?.text) {
      toast({ title: "Validation Error", description: "Title and text are required.", variant: "destructive" });
      return;
    }

    try {
      const payload = {
        title: currentClause.title,
        text: currentClause.text,
        sort_order: currentClause.sort_order || 0,
      };

      if (currentClause.id) {
        await updateDisclaimerClause(currentClause.id, payload);
        toast({ title: "Success", description: "Clause updated successfully." });
      } else {
        await createDisclaimerClause(payload);
        toast({ title: "Success", description: "Clause created successfully." });
      }
      setIsDialogOpen(false);
      loadClauses();
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "An unexpected error occurred";
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this clause?")) {
      try {
        await deleteDisclaimerClause(id);
        toast({ title: "Success", description: "Clause deleted successfully." });
        loadClauses();
      } catch (e: unknown) {
        const errorMessage = e instanceof Error ? e.message : "An unexpected error occurred";
        toast({ title: "Error", description: errorMessage, variant: "destructive" });
      }
    }
  };

  const openDialog = (clause?: DisclaimerClause) => {
    setCurrentClause(clause || { sort_order: clauses.length * 10 });
    setIsDialogOpen(true);
  };

  let mainContent;
  if (loading) {
    mainContent = (
      <div className="flex justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  } else {
    mainContent = (
      <Card className="shadow-sm">
        <CardHeader className="border-b bg-muted/20">
          <CardTitle>Clauses ({clauses.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {clauses.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No clauses found. Click "Add Clause" to create one.
            </div>
          ) : (
            <div className="divide-y">
              {clauses.map((c) => (
                <div key={c.id} className="flex items-start justify-between p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex gap-3 items-start">
                    <div className="mt-1 cursor-grab text-muted-foreground/50">
                      <GripVertical className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-foreground">{c.title}</span>
                        <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">Order: {c.sort_order}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{c.text}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <Button variant="ghost" size="icon" onClick={() => openDialog(c)}>
                      <Pencil className="h-4 w-4 text-blue-500" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(c.id)}>
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <SuperAdminLayout
      title="Disclaimer Clauses"
      subtitle="Configure disclaimer text and clauses users must acknowledge."
    >
      <div className="mb-6 flex items-center justify-between">
        <Button variant="ghost" onClick={() => navigate("/superadmin/config")} className="pl-0 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <Button onClick={() => openDialog()} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="mr-2 h-4 w-4" />
          Add Clause
        </Button>
      </div>

      {mainContent}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{currentClause?.id ? "Edit Clause" : "Add Clause"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="disclaimer-title">Title</Label>
              <Input
                id="disclaimer-title"
                value={currentClause?.title || ""}
                onChange={(e) => setCurrentClause({ ...currentClause, title: e.target.value })}
                placeholder="e.g. Data Residency"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="disclaimer-text">Text / Description</Label>
              <Textarea
                id="disclaimer-text"
                value={currentClause?.text || ""}
                onChange={(e) => setCurrentClause({ ...currentClause, text: e.target.value })}
                rows={4}
                placeholder="The clause text..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="disclaimer-sort-order">Sort Order</Label>
              <Input
                id="disclaimer-sort-order"
                type="number"
                value={currentClause?.sort_order || 0}
                onChange={(e) => setCurrentClause({ ...currentClause, sort_order: Number.parseInt(e.target.value, 10) || 0 })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default DisclaimerConfig;