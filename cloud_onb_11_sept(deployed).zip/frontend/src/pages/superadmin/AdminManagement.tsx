import { useEffect, useState } from "react";
import {
  Loader2,
  UserCog,
  Plus,
  Pencil,
  UserX,
  UserCheck,
  Mail,
  Hash,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import { toast } from "@/hooks/use-toast";
import {
  fetchAdmins,
  createAdmin,
  updateAdmin,
  deleteAdmin,
  type AdminUser,
} from "@/lib/adminApi";

const AdminManagement = () => {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    name: "",
    email: "",
    emp_id: "",
  });
  const [creating, setCreating] = useState(false);

  // Edit dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    email: "",
    emp_id: "",
  });
  const [updating, setUpdating] = useState(false);

  const loadAdmins = () => {
    setLoading(true);
    fetchAdmins()
      .then(setAdmins)
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadAdmins();
  }, []);

  const handleCreate = async () => {
    if (!createForm.name || !createForm.email || !createForm.emp_id) return;
    setCreating(true);
    try {
      await createAdmin(createForm);
      toast({
        title: "Admin Registered",
        description: `Successfully registered ${createForm.name} as an admin.`,
      });
      setCreateOpen(false);
      setCreateForm({ name: "", email: "", emp_id: "" });
      loadAdmins();
    } catch {
      toast({
        title: "Error",
        description: "Failed to register admin. Please try again.",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const openEdit = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setEditForm({ name: admin.name, email: admin.email, emp_id: admin.emp_id });
    setEditOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingAdmin) return;
    setUpdating(true);
    try {
      await updateAdmin(editingAdmin.id, editForm);
      toast({
        title: "Admin Updated",
        description: `Successfully updated ${editForm.name}.`,
      });
      setEditOpen(false);
      setEditingAdmin(null);
      loadAdmins();
    } catch {
      toast({
        title: "Error",
        description: "Failed to update admin. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUpdating(false);
    }
  };

  const handleToggleActive = async (admin: AdminUser) => {
    try {
      if (admin.is_active) {
        await deleteAdmin(admin.id);
        toast({
          title: "Admin Deactivated",
          description: `${admin.name} has been deactivated.`,
        });
      } else {
        await updateAdmin(admin.id, { is_active: true } as Partial<AdminUser>);
        toast({
          title: "Admin Activated",
          description: `${admin.name} has been activated.`,
        });
      }
      loadAdmins();
    } catch {
      toast({
        title: "Error",
        description: "Failed to update admin status.",
        variant: "destructive",
      });
    }
  };

  return (
    <SuperAdminLayout
      title="Admin Management"
      subtitle="Register, edit, and manage platform administrators"
    >
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Header with Add button */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              {admins.length} admin{admins.length !== 1 ? "s" : ""} registered
            </p>
            <Button
              onClick={() => setCreateOpen(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Register New Admin
            </Button>
          </div>

          {/* Table */}
          {admins.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <UserCog className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground font-medium">
                  No admins registered
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Click "Register New Admin" to add the first administrator.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-card overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="font-semibold">Name</TableHead>
                    <TableHead className="font-semibold">Email</TableHead>
                    <TableHead className="font-semibold">
                      Employee ID
                    </TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold">Workload</TableHead>
                    <TableHead className="font-semibold text-right">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {admins.map((admin) => (
                    <TableRow
                      key={admin.id}
                      className="hover:bg-muted/30 transition-colors"
                    >
                      <TableCell className="font-medium">
                        {admin.name}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <Mail className="h-3.5 w-3.5" />
                          {admin.email}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <Hash className="h-3.5 w-3.5" />
                          {admin.emp_id}
                        </span>
                      </TableCell>
                      <TableCell>
                        {admin.is_active ? (
                          <Badge className="bg-green-50 text-green-700 border-green-200 text-[10px]">
                            Active
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-500 border-gray-200 text-[10px]">
                            Inactive
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-sm font-medium text-foreground">
                          {admin.workload}
                        </span>
                        <span className="text-xs text-muted-foreground ml-1">
                          assigned
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEdit(admin)}
                            className="text-purple-700 hover:bg-purple-50"
                          >
                            <Pencil className="h-3.5 w-3.5 mr-1" />
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleToggleActive(admin)}
                            className={
                              admin.is_active
                                ? "text-red-600 hover:bg-red-50"
                                : "text-green-600 hover:bg-green-50"
                            }
                          >
                            {admin.is_active ? (
                              <>
                                <UserX className="h-3.5 w-3.5 mr-1" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <UserCheck className="h-3.5 w-3.5 mr-1" />
                                Activate
                              </>
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </div>
      )}

      {/* Create Admin Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Register New Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="create-name" className="text-sm font-medium text-foreground">
                Name
              </label>
              <Input
                id="create-name"
                placeholder="Full name"
                value={createForm.name}
                onChange={(e) =>
                  setCreateForm({ ...createForm, name: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="create-email" className="text-sm font-medium text-foreground">
                Email
              </label>
              <Input
                id="create-email"
                type="email"
                placeholder="admin@company.com"
                value={createForm.email}
                onChange={(e) =>
                  setCreateForm({ ...createForm, email: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="create-emp-id" className="text-sm font-medium text-foreground">
                Employee ID
              </label>
              <Input
                id="create-emp-id"
                placeholder="EMP-12345"
                value={createForm.emp_id}
                onChange={(e) =>
                  setCreateForm({ ...createForm, emp_id: e.target.value })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCreateOpen(false)}
              disabled={creating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              disabled={
                !createForm.name ||
                !createForm.email ||
                !createForm.emp_id ||
                creating
              }
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {creating && (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              )}
              Register Admin
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Admin Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="edit-name" className="text-sm font-medium text-foreground">
                Name
              </label>
              <Input
                id="edit-name"
                placeholder="Full name"
                value={editForm.name}
                onChange={(e) =>
                  setEditForm({ ...editForm, name: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="edit-email" className="text-sm font-medium text-foreground">
                Email
              </label>
              <Input
                id="edit-email"
                type="email"
                placeholder="admin@company.com"
                value={editForm.email}
                onChange={(e) =>
                  setEditForm({ ...editForm, email: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="edit-emp-id" className="text-sm font-medium text-foreground">
                Employee ID
              </label>
              <Input
                id="edit-emp-id"
                placeholder="EMP-12345"
                value={editForm.emp_id}
                onChange={(e) =>
                  setEditForm({ ...editForm, emp_id: e.target.value })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEditOpen(false)}
              disabled={updating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={
                !editForm.name ||
                !editForm.email ||
                !editForm.emp_id ||
                updating
              }
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {updating && (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              )}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default AdminManagement;