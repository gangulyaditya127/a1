import { useEffect, useState } from "react";
import {
  Loader2,
  Users,
  Filter,
  UserPlus,
  RefreshCw,
  Cloud,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import { toast } from "@/hooks/use-toast";
import {
  fetchAllOnboardings,
  fetchAdmins,
  assignAdmin,
  reassignAdmin,
  type AdminOnboarding,
  type AdminUser,
} from "@/lib/adminApi";

const statusBadgeStyle: Record<string, string> = {
  pending_assignment: "bg-gray-100 text-gray-600 border-gray-200",
  assigned: "bg-yellow-50 text-yellow-700 border-yellow-200",
  under_review: "bg-yellow-50 text-yellow-700 border-yellow-200",
  approved: "bg-green-50 text-green-700 border-green-200",
  sent_back: "bg-red-50 text-red-700 border-red-200",
  cost_pending: "bg-blue-50 text-blue-700 border-blue-200",
  recommendations_pending: "bg-purple-50 text-purple-700 border-purple-200",
  recommendations_sent: "bg-emerald-50 text-emerald-700 border-emerald-200",
  approval_checklist_sent: "bg-emerald-50 text-emerald-700 border-emerald-200",
  approvals_under_review: "bg-blue-50 text-blue-700 border-blue-200",
  approvals_sent_back: "bg-red-50 text-red-700 border-red-200",
  approvals_approved: "bg-emerald-50 text-emerald-700 border-emerald-200",
  cb_id_created: "bg-emerald-50 text-emerald-700 border-emerald-200",
  completed: "bg-green-50 text-green-700 border-green-200",
};

const filterTabs = [
  { label: "All", value: "" },
  { label: "Unassigned", value: "unassigned" },
  { label: "Assigned", value: "assigned" },
];

const OnboardingAssignment = () => {
  const [onboardings, setOnboardings] = useState<AdminOnboarding[]>([]);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState("");

  // Dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedOnboarding, setSelectedOnboarding] =
    useState<AdminOnboarding | null>(null);
  const [selectedAdminId, setSelectedAdminId] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const loadData = () => {
    setLoading(true);
    Promise.all([fetchAllOnboardings(), fetchAdmins()])
      .then(([onb, adm]) => {
        setOnboardings(onb);
        setAdmins(adm);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredOnboardings = activeFilter
    ? onboardings.filter((o) => {
        // @ts-ignore - handling backend payload differences
        const isAssigned = !!(o.assigned_admin_id || o.admin_assignment?.admin_id);
        if (activeFilter === "unassigned") return !isAssigned;
        if (activeFilter === "assigned") return isAssigned;
        return true;
      })
    : onboardings;

  const openAssignDialog = (onboarding: AdminOnboarding) => {
    setSelectedOnboarding(onboarding);
    
    // Support both direct fields (if added later) or nested admin_assignment
    // @ts-ignore - admin_assignment might not be fully typed in AdminOnboarding
    const assignedId = onboarding.assigned_admin_id || onboarding.admin_assignment?.admin_id || "";
    setSelectedAdminId(assignedId);
    setDialogOpen(true);
  };

  const handleAssign = async () => {
    if (!selectedOnboarding || !selectedAdminId) return;
    setSubmitting(true);
    try {
      // @ts-ignore
      const isReassign = !!(selectedOnboarding.assigned_admin_id || selectedOnboarding.admin_assignment?.admin_id);
      if (isReassign) {
        await reassignAdmin(selectedOnboarding.id, {
          admin_id: selectedAdminId,
        });
      } else {
        await assignAdmin(selectedOnboarding.id, {
          admin_id: selectedAdminId,
        });
      }
      toast({
        title: isReassign ? "Admin Reassigned" : "Admin Assigned",
        description: `Successfully ${isReassign ? "reassigned" : "assigned"} admin to "${selectedOnboarding.name}".`,
      });
      setDialogOpen(false);
      setSelectedOnboarding(null);
      setSelectedAdminId("");
      loadData();
    } catch {
      toast({
        title: "Error",
        description: "Failed to assign admin. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <SuperAdminLayout
      title="Onboarding Assignment"
      subtitle="Assign and manage admin assignments for onboarding requests"
    >
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Filter Tabs */}
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="h-4 w-4 text-muted-foreground" />
            {filterTabs.map((tab) => (
              <Button
                key={tab.value}
                variant={activeFilter === tab.value ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(tab.value)}
                className={
                  activeFilter === tab.value
                    ? "bg-purple-600 hover:bg-purple-700 text-white"
                    : ""
                }
              >
                {tab.label}
              </Button>
            ))}
            <div className="ml-auto">
              <Button variant="ghost" size="sm" onClick={loadData}>
                <RefreshCw className="h-3.5 w-3.5 mr-1" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Count */}
          <div>
            <p className="text-sm text-muted-foreground">
              {filteredOnboardings.length} onboarding
              {filteredOnboardings.length !== 1 ? "s" : ""}
              {activeFilter ? ` (${activeFilter})` : ""}
            </p>
          </div>

          {/* Table */}
          {filteredOnboardings.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground font-medium">
                  No onboardings found
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {activeFilter
                    ? "Try a different filter."
                    : "No onboarding requests yet."}
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-card overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="font-semibold">
                      Onboarding Name
                    </TableHead>
                    <TableHead className="font-semibold">Requestor</TableHead>
                    <TableHead className="font-semibold">
                      Cloud Provider
                    </TableHead>
                    <TableHead className="font-semibold">
                      Admin Status
                    </TableHead>
                    <TableHead className="font-semibold">
                      Assigned Admin
                    </TableHead>
                    <TableHead className="font-semibold">Date</TableHead>
                    <TableHead className="font-semibold text-right">
                      Action
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOnboardings.map((onboarding) => (
                    <TableRow
                      key={onboarding.id}
                      className="hover:bg-muted/30 transition-colors"
                    >
                      <TableCell className="font-medium">
                        {onboarding.name}
                      </TableCell>
                      <TableCell className="text-sm">
                        {onboarding.account_details?.owner ?? (
                          <span className="text-muted-foreground">N/A</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {onboarding.requirement_assessment?.cloud_provider ? (
                          <Badge
                            variant="outline"
                            className="text-[10px] gap-1"
                          >
                            <Cloud className="h-3 w-3" />
                            {
                              onboarding.requirement_assessment.cloud_provider
                            }
                          </Badge>
                        ) : (
                          <span className="text-sm text-muted-foreground">
                            —
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={`text-[10px] ${
                            statusBadgeStyle[onboarding.admin_status] ??
                            "bg-muted text-muted-foreground"
                          }`}
                        >
                          {onboarding.admin_status?.replace(/_/g, " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {(() => {
                          // @ts-ignore
                          const adminName = onboarding.assigned_admin_name || (onboarding.admin_assignment?.admin_id && admins.find(a => a.id === onboarding.admin_assignment.admin_id)?.name);
                          return adminName ? (
                            <span className="text-sm">
                              {adminName}
                            </span>
                          ) : (
                            <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200 text-[10px]">
                              Unassigned
                            </Badge>
                          );
                        })()}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(onboarding.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openAssignDialog(onboarding)}
                          className="text-purple-700 border-purple-200 hover:bg-purple-50"
                        >
                          {/* @ts-ignore */}
                          {onboarding.assigned_admin_id || onboarding.admin_assignment?.admin_id ? (
                            <>
                              <RefreshCw className="h-3.5 w-3.5 mr-1" />
                              Reassign
                            </>
                          ) : (
                            <>
                              <UserPlus className="h-3.5 w-3.5 mr-1" />
                              Assign
                            </>
                          )}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </div>
      )}

      {/* Assign / Reassign Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedOnboarding?.assigned_admin_id
                ? "Reassign Admin"
                : "Assign Admin"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <p className="text-sm font-medium text-foreground mb-1">
                Onboarding
              </p>
              <p className="text-sm text-muted-foreground">
                {selectedOnboarding?.name}
              </p>
            </div>
            <div className="space-y-2">
              <label htmlFor="select-admin-trigger" className="text-sm font-medium text-foreground">
                Select Admin
              </label>
              <Select
                value={selectedAdminId}
                onValueChange={setSelectedAdminId}
              >
                <SelectTrigger id="select-admin-trigger">
                  <SelectValue placeholder="Choose an admin..." />
                </SelectTrigger>
                <SelectContent>
                  {admins
                    .filter((a) => a.is_active)
                    .map((admin) => (
                      <SelectItem key={admin.id} value={admin.id}>
                        {admin.name}{" "}
                        <span className="text-muted-foreground">
                          · {admin.email}
                        </span>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAssign}
              disabled={!selectedAdminId || submitting}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {submitting && (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              )}
              {selectedOnboarding?.assigned_admin_id ? "Reassign" : "Assign"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default OnboardingAssignment;