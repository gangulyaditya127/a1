import { useEffect, useState } from "react";
import {
  Loader2,
  HelpCircle,
  FileText,
  ShieldCheck,
  Gavel,
  ArrowRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import { fetchConfigSummary } from "@/lib/adminApi";
import { useNavigate } from "react-router-dom";

interface ConfigSummary {
  eligibility_questions: number;
  disclaimer_clauses: number;
  architecture_rules: number;
  approval_rules: number;
}

const ConfigManagement = () => {
  const [summary, setSummary] = useState<ConfigSummary | null>(null);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchConfigSummary()
      .then(setSummary)
      .catch(() => {
        setSummary({
          eligibility_questions: 8,
          disclaimer_clauses: 5,
          architecture_rules: 12,
          approval_rules: 4,
        });
      })
      .finally(() => setLoading(false));
  }, []);

  const configCards = summary
    ? [
        {
          title: "Eligibility Questions",
          description:
            "Manage the questions shown during the eligibility assessment step.",
          count: summary.eligibility_questions,
          icon: HelpCircle,
          gradient: "from-purple-500 to-violet-600",
          countLabel: "questions",
          path: "/superadmin/config/eligibility",
        },
        {
          title: "Disclaimer Clauses",
          description:
            "Configure disclaimer text and clauses users must acknowledge.",
          count: summary.disclaimer_clauses,
          icon: FileText,
          gradient: "from-blue-500 to-indigo-600",
          countLabel: "clauses",
          path: "/superadmin/config/disclaimers",
        },
        {
          title: "Architecture Rules",
          description:
            "Define validation rules applied during architecture review.",
          count: summary.architecture_rules,
          icon: ShieldCheck,
          gradient: "from-emerald-500 to-green-600",
          countLabel: "rules",
          path: "/superadmin/config/architecture-rules",
        },
        {
          title: "Approval Rules",
          description:
            "Set up approval workflows, required roles, and mandatory checks.",
          count: summary.approval_rules,
          icon: Gavel,
          gradient: "from-amber-500 to-orange-600",
          countLabel: "rules",
          path: "/superadmin/config/approval-rules",
        },
      ]
    : [];

  return (
    <SuperAdminLayout
      title="Configuration"
      subtitle="Manage platform settings, rules, and templates"
    >
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
        </div>
      ) : (
        <div className="space-y-8">
          {/* Config Category Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {configCards.map((card) => (
              <Card
                key={card.title}
                className="shadow-card hover:shadow-card-hover transition-shadow overflow-hidden"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-10 w-10 rounded-lg bg-gradient-to-br ${card.gradient} flex items-center justify-center shadow-sm`}
                      >
                        <card.icon className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-base">
                          {card.title}
                        </CardTitle>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {card.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-foreground">
                        {card.count}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {card.countLabel}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-purple-700 border-purple-200 hover:bg-purple-50"
                      onClick={() => {
                        if (card.path) {
                          navigate(card.path);
                        } else {
                          import("@/hooks/use-toast").then(({ toast }) => {
                            toast({
                              title: "Coming Soon",
                              description: "Configuration editor will be available in a future update.",
                            });
                          });
                        }
                      }}
                    >
                      Manage
                      <ArrowRight className="h-3.5 w-3.5 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

        </div>
      )}
    </SuperAdminLayout>
  );
};

export default ConfigManagement;
