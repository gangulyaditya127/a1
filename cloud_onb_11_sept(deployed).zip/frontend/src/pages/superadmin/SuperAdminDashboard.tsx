import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Clock,
  AlertCircle,
  CheckCircle2,
  Users,
  Loader2,
  Settings,
  Inbox,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ConsoleLayout,
  type NavItem,
} from "@/components/admin/AdminLayout";
import {
  fetchSuperAdminDashboard,
  fetchAllOnboardings,
  fetchAdmins,
  assignAdmin,
  reassignAdmin,
  type SuperAdminDashboardData,
  type AdminOnboarding,
  type AdminUser,
} from "@/lib/adminApi";
import { useAuth } from "@/contexts/AuthContext";

// ─── SuperAdmin nav items ────────────────────────────────────────────

const superAdminNavItems: NavItem[] = [
  { title: "Dashboard", url: "/superadmin", icon: LayoutDashboard },
  {
    title: "Onboarding Assignment",
    url: "/superadmin/onboardings",
    icon: Inbox,
  },
  { title: "Admin Management", url: "/superadmin/admins", icon: Users },
  { title: "Configuration", url: "/superadmin/config", icon: Settings },
];

// ─── Status badge colours ────────────────────────────────────────────

const statusBadgeStyle: Record<string, string> = {
  pending_assignment: "bg-gray-500/10 text-gray-600 border-gray-500/20",
  assigned: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  under_review: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  approved: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  sent_back: "bg-red-500/10 text-red-600 border-red-500/20",
  cost_pending: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  recommendations_pending:
    "bg-purple-500/10 text-purple-600 border-purple-500/20",
  recommendations_sent:
    "bg-teal-500/10 text-teal-600 border-teal-500/20",
  approval_checklist_sent:
    "bg-teal-500/10 text-teal-600 border-teal-500/20",
  approvals_under_review:
    "bg-blue-500/10 text-blue-600 border-blue-500/20",
  approvals_sent_back:
    "bg-red-500/10 text-red-600 border-red-500/20",
  approvals_approved:
    "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  cb_id_created:
    "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  completed: "bg-green-500/10 text-green-600 border-green-500/20",
};

// ─── KPI Card ────────────────────────────────────────────────────────

const Kpi = ({
  label,
  value,
  icon: Icon,
  tone = "bg-primary/10 text-primary",
}: {
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tone?: string;
}) => (
  <Card>
    <CardContent className="p-4 flex items-center gap-3">
      <div
        className={`h-10 w-10 rounded-md flex items-center justify-center ${tone}`}
      >
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-lg font-semibold text-foreground">{value}</p>
      </div>
    </CardContent>
  </Card>
);

// ─── Main component ──────────────────────────────────────────────────

const SuperAdminDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [data, setData] = useState<SuperAdminDashboardData | null>(null);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Assignment dialog
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedOnboarding, setSelectedOnboarding] = useState<AdminOnboarding | null>(null);
  const [selectedAdminId, setSelectedAdminId] = useState<string>("");
  const [assigning, setAssigning] = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetchSuperAdminDashboard(),
      fetchAllOnboardings(),
      fetchAdmins(),
    ])
      .then(([dashData, _onboardings, adminList]) => {
        setData(dashData);
        setAdmins(adminList);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // ─── Assignment handler ──────────────────────────────────────────

  const openAssignDialog = (onboarding: AdminOnboarding) => {
    setSelectedOnboarding(onboarding);
    setSelectedAdminId(onboarding.assigned_admin_id ?? "");
    setAssignDialogOpen(true);
  };

  const handleAssign = async () => {
    if (!selectedOnboarding || !selectedAdminId) return;
    setAssigning(true);
    try {
      const fn = selectedOnboarding.assigned_admin_id
        ? reassignAdmin
        : assignAdmin;
      await fn(selectedOnboarding.id, { admin_id: selectedAdminId });
      // Refresh data
      const [dashData, _onboardings, adminList] = await Promise.all([
        fetchSuperAdminDashboard(),
        fetchAllOnboardings(),
        fetchAdmins(),
      ]);
      setData(dashData);
      setAdmins(adminList);
      setAssignDialogOpen(false);
    } catch {
      // error handling is handled by the api layer
    } finally {
      setAssigning(false);
    }
  };

  // ─── Derived data ────────────────────────────────────────────────

  const recentOnboardings = (data?.recent_onboardings ?? []).slice(0, 6);

  // Build admin workload from fetched admins
  const adminWorkloads = admins
    .filter((a) => a.is_active)
    .map((a) => ({
      id: a.id,
      name: a.name,
      workload: a.workload,
      capacity: 10, // default capacity
    }));

  // Resolve nested ternary for Assign Button text
  let assignBtnText = "Assign";
  if (assigning) {
    assignBtnText = "Assigning...";
  } else if (selectedOnboarding?.assigned_admin_id) {
    assignBtnText = "Reassign";
  }

  return (
    <ConsoleLayout role="superadmin" navItems={superAdminNavItems}>
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
        </div>
      ) : (
        <div className="space-y-6 max-w-[1500px]">
          {/* Welcome */}
          <div>
            <h2 className="text-2xl font-semibold text-foreground">
              Super Admin Overview
            </h2>
            <p className="text-sm text-muted-foreground">
              Hi {user?.name?.split(" ")[0] ?? "Super Admin"} —
              system-wide view of onboarding orchestration, admin
              workload, and SLA health.
            </p>
          </div>

          {/* KPI row — 4 cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Kpi
              label="Total Onboardings"
              value={data?.total_onboardings ?? 0}
              icon={LayoutDashboard}
            />
            <Kpi
              label="Unassigned"
              value={data?.unassigned ?? 0}
              icon={AlertCircle}
              tone="bg-amber-500/10 text-amber-600"
            />
            <Kpi
              label="In Progress"
              value={data?.in_progress ?? 0}
              icon={Clock}
              tone="bg-blue-500/10 text-blue-600"
            />
            <Kpi
              label="Completed"
              value={data?.completed ?? 0}
              icon={CheckCircle2}
              tone="bg-emerald-500/10 text-emerald-600"
            />
          </div>

          {/* Two-column grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left: Admin Workload */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4" /> Admin Workload
                  </h3>
                  <Badge variant="outline">
                    {adminWorkloads.length} active
                  </Badge>
                </div>
                <div className="space-y-3">
                  {adminWorkloads.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">
                      No active admins
                    </p>
                  ) : (
                    adminWorkloads.map((a) => {
                      const pct = Math.min(
                        Math.round((a.workload / a.capacity) * 100),
                        100
                      );

                      // Resolve nested ternary for Progress Bar class
                      let progressClass = "";
                      if (pct >= 100) {
                        progressClass = "[&>div]:bg-destructive";
                      } else if (pct >= 80) {
                        progressClass = "[&>div]:bg-amber-500";
                      }

                      return (
                        <div key={a.id} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="font-medium text-foreground">
                              {a.name}
                            </span>
                            <span className="font-mono">
                              {/* {a.workload}/{a.capacity} */}
                              {a.workload}
                            </span>
                          </div>
                          <Progress
                            value={pct}
                            className={progressClass}
                          />
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Right: Recent Onboardings */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" /> Recent
                  Onboardings
                </h3>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Project</TableHead>
                        <TableHead>Cloud</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentOnboardings.map((o) => (
                        <TableRow 
                          key={o.id} 
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => openAssignDialog(o)}
                        >
                          <TableCell className="font-mono text-xs max-w-[100px] truncate">
                            {o.id}
                          </TableCell>
                          <TableCell className="text-sm">
                            {o.account_details?.project_name ?? o.name}
                          </TableCell>
                          <TableCell>
                            {o.requirement_assessment?.cloud_provider ? (
                              <Badge variant="outline">
                                {o.requirement_assessment.cloud_provider}
                              </Badge>
                            ) : (
                              <span className="text-xs text-muted-foreground">
                                —
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={`text-[10px] ${
                                statusBadgeStyle[o.admin_status] ??
                                "bg-muted text-muted-foreground"
                              }`}
                            >
                              {o.admin_status?.replace(/_/g, " ")}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                      {recentOnboardings.length === 0 && (
                        <TableRow>
                          <TableCell
                            colSpan={4}
                            className="text-center text-sm text-muted-foreground py-6"
                          >
                            No recent onboardings
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick actions */}
          <div className="flex items-center gap-3">
            <Button
              onClick={() => navigate("/superadmin/onboardings")}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              View All Onboardings
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/superadmin/admins")}
              className="border-amber-200 text-amber-700 hover:bg-amber-50"
            >
              <Users className="h-4 w-4 mr-2" />
              Manage Admins
            </Button>
          </div>
        </div>
      )}

      {/* ─── Assignment Dialog ─────────────────────────────────────── */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedOnboarding?.assigned_admin_id
                ? "Reassign Admin"
                : "Assign Admin"}
            </DialogTitle>
            <DialogDescription>
              Select an admin to{" "}
              {selectedOnboarding?.assigned_admin_id
                ? "reassign"
                : "assign"}{" "}
              for onboarding "{selectedOnboarding?.name}".
            </DialogDescription>
          </DialogHeader>

          <Select value={selectedAdminId} onValueChange={setSelectedAdminId}>
            <SelectTrigger>
              <SelectValue placeholder="Select an admin" />
            </SelectTrigger>
            <SelectContent>
              {admins
                .filter((a) => a.is_active)
                .map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name} (workload: {a.workload})
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAssignDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAssign}
              disabled={!selectedAdminId || assigning}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {assignBtnText}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ConsoleLayout>
  );
};

export default SuperAdminDashboard;