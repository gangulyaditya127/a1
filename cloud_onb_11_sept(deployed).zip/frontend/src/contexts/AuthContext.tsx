import { createContext, useContext, useEffect, useState, useMemo, useCallback, type ReactNode } from 'react';
import { getCurrentUser, loginUser, listUsers, type AuthUser } from '@/lib/adminApi';
import { ChevronDown, User, X } from 'lucide-react';

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  login: (emailOrEmpId: string) => Promise<void>;
  logout: () => void;
  switchRole: (role: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};

// ─── Role Switcher (dev mode) ────────────────────────────────────────

const RoleSwitcher = ({ currentUser, onSwitch }: { currentUser: AuthUser | null; onSwitch: (user: AuthUser) => void }) => {
  const [open, setOpen] = useState(false);
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);

  const toggleOpen = () => {
    if (!open && users.length === 0) {
      setLoadingUsers(true);
      listUsers()
        .then(setUsers)
        .catch(() => {})
        .finally(() => setLoadingUsers(false));
    }
    setOpen(!open);
  };

  const roleColor: Record<string, string> = {
    user: 'bg-blue-500',
    admin: 'bg-amber-500',
    superadmin: 'bg-purple-500',
  };

  let userListContent;
  if (loadingUsers) {
    userListContent = <div className="p-4 text-center text-sm text-muted-foreground">Loading users…</div>;
  } else if (users.length === 0) {
    userListContent = <div className="p-4 text-center text-sm text-muted-foreground">No users found</div>;
  } else {
    userListContent = users.map((u) => (
      <button
        key={u.id}
        onClick={() => { onSwitch(u); setOpen(false); }}
        className={`w-full text-left px-4 py-2.5 hover:bg-muted/60 transition-colors flex items-center gap-3 ${currentUser?.id === u.id ? 'bg-muted/40' : ''}`}
      >
        <div className={`h-7 w-7 rounded-full ${roleColor[u.role] ?? 'bg-gray-400'} flex items-center justify-center`}>
          <User className="h-3.5 w-3.5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{u.name}</p>
          <p className="text-[10px] text-muted-foreground">{u.email}</p>
        </div>
        <span className={`text-[10px] px-1.5 py-0.5 rounded-full text-white font-medium ${roleColor[u.role] ?? 'bg-gray-400'}`}>
          {u.role}
        </span>
      </button>
    ));
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {open && (
        <div className="mb-2 w-72 rounded-lg border bg-card shadow-xl overflow-hidden animate-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/50">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Dev — Switch User</span>
            <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="max-h-64 overflow-auto">
            {userListContent}
          </div>
        </div>
      )}
      <button
        onClick={toggleOpen}
        className="flex items-center gap-2 rounded-full bg-foreground/90 text-background px-3 py-2 shadow-lg hover:bg-foreground transition-colors text-xs font-medium"
      >
        <div className={`h-5 w-5 rounded-full ${roleColor[currentUser?.role ?? ''] ?? 'bg-gray-400'} flex items-center justify-center`}>
          <User className="h-3 w-3 text-white" />
        </div>
        <span>{currentUser?.name ?? 'Not logged in'}</span>
        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-semibold text-white ${roleColor[currentUser?.role ?? ''] ?? 'bg-gray-400'}`}>
          {currentUser?.role ?? '—'}
        </span>
        <ChevronDown className={`h-3 w-3 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
    </div>
  );
};

// ─── Provider ────────────────────────────────────────────────────────

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  const autoLogin = useCallback(() => {
    listUsers()
      .then((allUsers) => {
        // Prefer superadmin, then admin, then first user
        const sa = allUsers.find((u) => u.role === 'superadmin');
        const admin = allUsers.find((u) => u.role === 'admin');
        const pick = sa ?? admin ?? allUsers[0];
        if (pick) {
          localStorage.setItem('auth_user_id', pick.id);
          setUser(pick);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // Hydrate from localStorage on mount, or auto-login as superadmin
  useEffect(() => {
    const savedId = localStorage.getItem('auth_user_id');
    if (savedId) {
      getCurrentUser()
        .then((u) => setUser(u))
        .catch(() => {
          localStorage.removeItem('auth_user_id');
          // Fallback: auto-login
          autoLogin();
        })
        .finally(() => setLoading(false));
    } else {
      // No saved user — auto-login as superadmin for dev convenience
      autoLogin();
    }
  }, [autoLogin]);

  const login = useCallback(async (emailOrEmpId: string) => {
    const isEmail = emailOrEmpId.includes('@');
    const payload = isEmail ? { email: emailOrEmpId } : { emp_id: emailOrEmpId };
    const u = await loginUser(payload);
    localStorage.setItem('auth_user_id', u.id);
    setUser(u);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('auth_user_id');
    setUser(null);
  }, []);

  const switchRole = useCallback((_role: string) => {
    // No-op for now; use RoleSwitcher's onSwitch instead
  }, []);

  const handleDevSwitch = useCallback((u: AuthUser) => {
    localStorage.setItem('auth_user_id', u.id);
    setUser(u);
  }, []);

  const contextValue = useMemo(
    () => ({ user, loading, login, logout, switchRole }),
    [user, loading, login, logout, switchRole]
  );

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
      <RoleSwitcher currentUser={user} onSwitch={handleDevSwitch} />
    </AuthContext.Provider>
  );
};