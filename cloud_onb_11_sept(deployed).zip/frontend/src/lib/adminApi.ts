const BASE_URL = `${import.meta.env.VITE_API_BASE_URL}/api`;

// ─── Auth Helpers ────────────────────────────────────────────────────

function getAuthHeaders(): Record<string, string> {
  const userId = localStorage.getItem('auth_user_id');
  return userId ? { 'X-User-Id': userId } : {};
}

async function authRequest<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders(), ...options?.headers },
    ...options,
  });
  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`API Error ${res.status}: ${errorBody}`);
  }
  return res.json();
}

// ─── Types ───────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  emp_id: string;
  role: 'user' | 'admin' | 'superadmin';
}

export interface ValidationFeedback {
  section: string;
  status: string;
  comment: string;
  created_at: string;
}

export interface ResourceCostItem {
  id?: string;
  resource_name: string;
  unit_cost: number;
  quantity: number;
  monthly_cost: number;
}

export interface CostEstimation {
  resource_costs: ResourceCostItem[];
  infra_support_cost: number;
  total_monthly_cost: number;
  total_annual_cost: number;
  currency: string;
  notes: string;
}

export interface CostPayload {
  resource_costs: ResourceCostItem[];
  infra_support_cost: number;
  total_monthly_cost: number;
  total_annual_cost: number;
  currency: string;
  notes: string;
}

export interface RecommendationItem {
  id: string;
  category: string;
  title: string;
  summary: string;
  parameters: Array<{ label: string; value: string }>;
  copy_text: string;
  status: string;
}

export interface AdminOnboarding {
  id: string;
  name: string;
  status: string;
  current_step: number;
  admin_status: string;
  user_id: string | null;
  user_name: string | null;
  user_email: string | null;
  user_emp_id: string | null;
  admin_comments?: Array<{
    admin_id: string;
    admin_name: string;
    comment: string;
    timestamp: string;
    section_comments?: Array<{ section: string; section_label: string; comment: string }>;
  }>;
  assigned_admin_id: string | null;
  assigned_admin_name: string | null;
  admin_assignment?: {
    id: string;
    admin_id: string;
    admin_name: string | null;
    assigned_by: string;
    assigned_at: string;
    status: string;
  } | null;
  created_at: string;
  updated_at: string;
  account_details: {
    project_name: string;
    isu: string;
    account_name: string;
    owner: string;
    emp_id: string;
    description: string;
    business_unit: string;
  } | null;
  requirement_assessment: {
    solution_type: string;
    deployment_environments: string[];
    cloud_provider: string;
    region: string;
  } | null;
  cloud_resource_bucket: {
    provider: string;
    resources: Array<{ service: string; count: number; configDetails: string }>;
  } | null;
  architecture_validation: {
    image_filename: string | null;
    user_context?: string | null;
    verdict: string | null;
    violations: Array<{ category: string; rule_text: string; severity: string; finding: string }>;
    validated_at: string | null;
  } | null;
  validation_feedbacks: ValidationFeedback[];
  cost_estimation: CostEstimation | null;
  recommendations: RecommendationItem[];
  remaining_state: Record<string, unknown> | null;
  cb_id_record?: CbIdInfo | null;
  is_read_only?: boolean;
}

export interface AdminDashboardData {
  total_assigned: number;
  pending_review: number;
  approved: number;
  sent_back: number;
  cost_pending: number;
  recommendations_pending: number;
  onboardings: AdminOnboarding[];
}

export interface SuperAdminDashboardData {
  total_onboardings: number;
  unassigned: number;
  in_progress: number;
  completed: number;
  active_admins: number;
  recent_onboardings: AdminOnboarding[];
}

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  emp_id: string;
  role: string;
  is_active: boolean;
  workload: number;
}

export interface ApprovalRule {
  id: string;
  name: string;
  description: string;
  approver_role: string;
  is_mandatory: boolean;
  applies_to: string;
  sort_order: number;
}

export interface EligibilityQuestion {
  id: string;
  section: string;
  title: string;
  note?: string;
  question_type: string;
  options: string[];
  correct_answer: any;
  fail_message: string;
  sort_order: number;
}

export interface DisclaimerClause {
  id: string;
  title: string;
  text: string;
  sort_order: number;
}

export interface ArchitectureRule {
  id: string;
  cloud_provider: string;
  category: string;
  rule_text: string;
  severity: string;
}

// ─── Auth API ────────────────────────────────────────────────────────

export const loginUser = (data: { email?: string; emp_id?: string }) =>
  authRequest<AuthUser>('/auth/login', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const getCurrentUser = () =>
  authRequest<AuthUser>('/auth/me');

export const listUsers = () =>
  authRequest<AuthUser[]>('/auth/users');

// ─── Admin Dashboard ─────────────────────────────────────────────────

export const fetchAdminDashboard = (status?: string) => {
  const params = status ? `?status=${encodeURIComponent(status)}` : '';
  return authRequest<AdminDashboardData>(`/admin/dashboard${params}`);
};

export const fetchAdminOnboarding = (id: string) =>
  authRequest<AdminOnboarding>(`/admin/onboardings/${id}`);

export interface OtherOnboardingsResponse {
  total_count: number;
  onboardings: AdminOnboarding[];
}

export const fetchOtherOnboardings = (offset = 0, limit = 10, search?: string) => {
  const params = new URLSearchParams({ offset: String(offset), limit: String(limit) });
  if (search) params.set('search', search);
  return authRequest<OtherOnboardingsResponse>(`/admin/other-onboardings?${params}`);
};

// ─── Validation Feedback ─────────────────────────────────────────────

export const submitFeedback = (
  onboardingId: string,
  data: { section: string; status: string; comment?: string },
) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/feedback`, {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const approveOnboarding = (onboardingId: string) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/approve`, {
    method: 'POST',
  });

export const sendBackOnboarding = (onboardingId: string, data: { comment: string }) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/send-back`, {
    method: 'POST',
    body: JSON.stringify(data),
  });

// ─── Admin: Cloud Resource Bucket Edit ───────────────────────────────────────

export interface AdminBucketEditItem {
  service: string;
  count: number;
  configDetails: string;
}

export interface AdminBucketEditRequest {
  provider: string;
  resources: AdminBucketEditItem[];
}

export interface AdminBucketEditResponse {
  id: string;
  onboarding_id: string;
  provider: string;
  resources: AdminBucketEditItem[];
}

export const adminUpdateCloudBucket = (
  onboardingId: string,
  data: AdminBucketEditRequest,
) =>
  authRequest<AdminBucketEditResponse>(
    `/admin/onboardings/${onboardingId}/cloud-resources/bucket`,
    {
      method: 'PUT',
      body: JSON.stringify(data),
    },
  );

// ─── Cost ────────────────────────────────────────────────────────────

export const upsertCost = (onboardingId: string, data: CostPayload) =>
  authRequest<CostEstimation>(`/admin/onboardings/${onboardingId}/cost`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const getCost = (onboardingId: string) =>
  authRequest<CostEstimation>(`/admin/onboardings/${onboardingId}/cost`);

export const seedCostFromBucket = (onboardingId: string) =>
  authRequest<ResourceCostItem[]>(`/admin/onboardings/${onboardingId}/cost/seed-from-bucket`);

// ─── Interaction Events ──────────────────────────────────────────────

export interface InteractionEventItem {
  id: string;
  onboarding_id: string;
  ts: string;
  actor: 'user' | 'admin' | 'superadmin' | 'system';
  actor_name: string;
  kind: string;
  title: string;
  body?: string | null;
  scope?: string | null;
}

export const fetchInteractionEvents = (onboardingId: string) =>
  authRequest<InteractionEventItem[]>(`/admin/onboardings/${onboardingId}/events`);

// ─── Recommendations ─────────────────────────────────────────────────

export const generateRecommendations = (onboardingId: string) =>
  authRequest<RecommendationItem[]>(`/admin/onboardings/${onboardingId}/recommendations/generate`, {
    method: 'POST',
  });

export const getRecommendations = (onboardingId: string) =>
  authRequest<RecommendationItem[]>(`/admin/onboardings/${onboardingId}/recommendations`);

export const updateRecommendation = (
  onboardingId: string,
  recId: string,
  data: Partial<RecommendationItem>,
) =>
  authRequest<RecommendationItem>(`/admin/onboardings/${onboardingId}/recommendations/${recId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const sendToUser = (onboardingId: string) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/send-to-user`, {
    method: 'POST',
  });

// ─── SuperAdmin ──────────────────────────────────────────────────────

export const fetchSuperAdminDashboard = () =>
  authRequest<SuperAdminDashboardData>('/superadmin/dashboard');

export const fetchAllOnboardings = (params?: { status?: string; admin_status?: string }) => {
  const searchParams = new URLSearchParams();
  if (params?.status) searchParams.set('status', params.status);
  if (params?.admin_status) searchParams.set('admin_status', params.admin_status);
  const qs = searchParams.toString();
  const queryString = qs ? '?' + qs : '';
  return authRequest<AdminOnboarding[]>(`/superadmin/onboardings${queryString}`);
};

export const assignAdmin = (onboardingId: string, data: { admin_id: string }) =>
  authRequest<{ ok: boolean }>(`/superadmin/onboardings/${onboardingId}/assign`, {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const reassignAdmin = (onboardingId: string, data: { admin_id: string }) =>
  authRequest<{ ok: boolean }>(`/superadmin/onboardings/${onboardingId}/reassign`, {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const fetchAdmins = () =>
  authRequest<AdminUser[]>('/superadmin/admins');

export const createAdmin = (data: { name: string; email: string; emp_id: string }) =>
  authRequest<AdminUser>('/superadmin/admins', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const updateAdmin = (id: string, data: Partial<AdminUser>) =>
  authRequest<AdminUser>(`/superadmin/admins/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteAdmin = (id: string) =>
  authRequest<{ ok: boolean }>(`/superadmin/admins/${id}`, { method: 'DELETE' });

// ─── Config ──────────────────────────────────────────────────────────

export const fetchConfigSummary = () =>
  authRequest<{
    eligibility_questions: number;
    disclaimer_clauses: number;
    architecture_rules: number;
    approval_rules: number;
  }>('/superadmin/config/summary');

export const fetchApprovalRules = () =>
  authRequest<ApprovalRule[]>('/superadmin/config/approval-rules');

export const createApprovalRule = (data: Partial<ApprovalRule>) =>
  authRequest<ApprovalRule>('/superadmin/config/approval-rules', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const updateApprovalRule = (id: string, data: Partial<ApprovalRule>) =>
  authRequest<ApprovalRule>(`/superadmin/config/approval-rules/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteApprovalRule = (id: string) =>
  authRequest<{ ok: boolean }>(`/superadmin/config/approval-rules/${id}`, { method: 'DELETE' });

// Eligibility
export const fetchEligibilityQuestions = () =>
  authRequest<EligibilityQuestion[]>('/admin/eligibility');

export const createEligibilityQuestion = (data: Partial<EligibilityQuestion>) =>
  authRequest<EligibilityQuestion>('/admin/eligibility', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const updateEligibilityQuestion = (id: string, data: Partial<EligibilityQuestion>) =>
  authRequest<EligibilityQuestion>(`/admin/eligibility/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteEligibilityQuestion = (id: string) =>
  authRequest<{ ok: boolean }>(`/admin/eligibility/${id}`, { method: 'DELETE' });

// Disclaimer
export const fetchDisclaimerClauses = () =>
  authRequest<DisclaimerClause[]>('/admin/disclaimer');

export const createDisclaimerClause = (data: Partial<DisclaimerClause>) =>
  authRequest<DisclaimerClause>('/admin/disclaimer', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const updateDisclaimerClause = (id: string, data: Partial<DisclaimerClause>) =>
  authRequest<DisclaimerClause>(`/admin/disclaimer/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteDisclaimerClause = (id: string) =>
  authRequest<{ ok: boolean }>(`/admin/disclaimer/${id}`, { method: 'DELETE' });

// Architecture Rules
export const fetchArchitectureRules = () =>
  authRequest<ArchitectureRule[]>('/admin/architecture-rules');

export const fetchArchitectureRulesByProvider = (provider: string) =>
  authRequest<ArchitectureRule[]>(`/admin/architecture-rules/provider/${provider}`);

export const createArchitectureRule = (data: Partial<ArchitectureRule>) =>
  authRequest<ArchitectureRule>('/admin/architecture-rules', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const updateArchitectureRule = (id: string, data: Partial<ArchitectureRule>) =>
  authRequest<ArchitectureRule>(`/admin/architecture-rules/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteArchitectureRule = (id: string) =>
  authRequest<{ ok: boolean }>(`/admin/architecture-rules/${id}`, { method: 'DELETE' });

// ─── Admin: Approval Screenshots ─────────────────────────────────────────────

export interface AdminApprovalScreenshotItem {
  id: string;
  rec_id: string;
  rec_title: string;
  filename: string;
  content_type: string;
  admin_status: 'uploaded' | 'approved' | 'sent_back';
  admin_comment: string | null;
  uploaded_at: string | null;
  reviewed_at: string | null;
}

export const getAdminApprovalScreenshots = (onboardingId: string) =>
  authRequest<AdminApprovalScreenshotItem[]>(`/admin/onboardings/${onboardingId}/approval-screenshots`);

export const approveApprovalScreenshot = (onboardingId: string, recId: string) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/approval-screenshots/${recId}/approve`, {
    method: 'POST',
  });

export const sendBackApprovalScreenshot = (onboardingId: string, recId: string, comment: string) =>
  authRequest<{ ok: boolean }>(`/admin/onboardings/${onboardingId}/approval-screenshots/${recId}/send-back`, {
    method: 'POST',
    body: JSON.stringify({ comment }),
  });

// ─── CB ID Management ──────────────────────────────────────────────────────────

export interface CbIdInfo {
  id: string;
  onboarding_id: string;
  cb_id: string;
  application_name: string;
  created_at: string;
  admin_email?: string;
  solution_type?: string;
}

export const generateCbId = (onboardingId: string) =>
  authRequest<CbIdInfo>(`/admin/onboardings/${onboardingId}/cbid/generate`, {
    method: 'POST',
  });

export const getCbId = (onboardingId: string) =>
  authRequest<CbIdInfo>(`/admin/onboardings/${onboardingId}/cbid`);