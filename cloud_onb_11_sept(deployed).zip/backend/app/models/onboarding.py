"""SQLAlchemy models for onboarding, eligibility, and disclaimer."""

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import JSON, ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.account_details import AccountDetails
    from app.models.cloud_resources import CloudResourceBucket
    from app.models.requirements import RequirementAssessment
    from app.models.architecture_validation import ArchitectureValidation
    from app.models.admin_assignment import AdminAssignment
    from app.models.validation_feedback import ValidationFeedback
    from app.models.cost_estimation import CostEstimation
    from app.models.recommendation import Recommendation
    from app.models.interaction_event import InteractionEvent
    from app.models.user import User
    from app.models.cbid import CbId

CASCADE_ALL_DELETE_ORPHAN = "all, delete-orphan"


class Onboarding(Base):
    """Represents a single onboarding workflow instance."""

    __tablename__ = "onboardings"

    id: Mapped[str] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(default="Untitled Onboarding")
    status: Mapped[str] = mapped_column(default="Draft")
    current_step: Mapped[int] = mapped_column(default=1)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
    )
    remaining_state: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    # Owner — the user who created this onboarding
    user_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True,
    )

    # Admin workflow columns
    admin_status: Mapped[str] = mapped_column(default="pending_assignment")
    admin_comments: Mapped[Optional[list]] = mapped_column(JSON, nullable=True, default=list)
    user_comments: Mapped[Optional[list]] = mapped_column(JSON, nullable=True, default=list)

    # Relationships
    user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[user_id], lazy="joined")
    
    account_details: Mapped[Optional["AccountDetails"]] = relationship(
        "AccountDetails",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    requirement_assessment: Mapped[Optional["RequirementAssessment"]] = relationship(
        "RequirementAssessment",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    cloud_resource_bucket: Mapped[Optional["CloudResourceBucket"]] = relationship(
        "CloudResourceBucket",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    architecture_validation: Mapped[Optional["ArchitectureValidation"]] = relationship(
        "ArchitectureValidation",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    admin_assignment: Mapped[Optional["AdminAssignment"]] = relationship(
        "AdminAssignment",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
        primaryjoin="and_(Onboarding.id==AdminAssignment.onboarding_id, AdminAssignment.status=='active')",
    )
    validation_feedbacks: Mapped[list["ValidationFeedback"]] = relationship(
        "ValidationFeedback",
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    cost_estimation: Mapped[Optional["CostEstimation"]] = relationship(
        "CostEstimation",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    recommendations: Mapped[list["Recommendation"]] = relationship(
        "Recommendation",
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )
    interaction_events: Mapped[list["InteractionEvent"]] = relationship(
        "InteractionEvent",
        back_populates="onboarding",
        cascade=CASCADE_ALL_DELETE_ORPHAN,
        order_by="InteractionEvent.ts",
    )
    cb_id_record: Mapped[Optional["CbId"]] = relationship(
        "CbId",
        back_populates="onboarding",
        uselist=False,
        cascade=CASCADE_ALL_DELETE_ORPHAN,
    )


class EligibilityQuestion(Base):
    """A single eligibility-check question shown before onboarding begins."""

    __tablename__ = "eligibility_questions"

    id: Mapped[str] = mapped_column(primary_key=True)
    section: Mapped[str] = mapped_column()
    title: Mapped[str] = mapped_column(Text)
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    question_type: Mapped[str] = mapped_column()  # "single" or "multi"
    options: Mapped[list] = mapped_column(JSON)
    correct_answer: Mapped[list | str] = mapped_column(JSON)
    fail_message: Mapped[str] = mapped_column(Text)
    sort_order: Mapped[int] = mapped_column()


class DisclaimerClause(Base):
    """A disclaimer clause the user must acknowledge."""

    __tablename__ = "disclaimer_clauses"

    id: Mapped[str] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column()
    text: Mapped[str] = mapped_column(Text)
    sort_order: Mapped[int] = mapped_column()