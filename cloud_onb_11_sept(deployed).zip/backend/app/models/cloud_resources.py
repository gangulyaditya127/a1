"""SQLAlchemy model for the cloud resource bucket."""

from typing import TYPE_CHECKING

from sqlalchemy import JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.onboarding import Onboarding


class CloudResourceBucket(Base):
    """Approved cloud resource bucket for an onboarding, scoped to a single provider."""

    __tablename__ = "cloud_resource_buckets"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
        unique=True,
    )
    provider: Mapped[str] = mapped_column(default="")
    # JSON array: [{"service": str, "count": int, "configDetails": str}]
    resources: Mapped[list] = mapped_column(JSON, default=list)

    # Back-reference to parent onboarding
    onboarding: Mapped["Onboarding"] = relationship(
        "Onboarding",
        back_populates="cloud_resource_bucket",
    )
