"""SQLAlchemy model for admin validation feedback."""

from datetime import datetime
from typing import Optional

from sqlalchemy import ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ValidationFeedback(Base):
    """Per-section validation feedback from an admin on an onboarding."""

    __tablename__ = "validation_feedbacks"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
    )
    admin_id: Mapped[str] = mapped_column(
        ForeignKey("users.id"),
    )
    section: Mapped[str] = mapped_column()  # 'account_details', 'requirements', 'cloud_resources', 'architecture'
    status: Mapped[str] = mapped_column()  # 'approved', 'rejected', 'comment'
    comment: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
