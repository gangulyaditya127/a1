"""SQLAlchemy model for architecture diagram validations."""

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import JSON, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.onboarding import Onboarding


class ArchitectureValidation(Base):
    """Stores an uploaded architecture diagram and its validation results."""

    __tablename__ = "architecture_validations"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
        unique=True,
    )
    image_data: Mapped[str] = mapped_column(Text)             # base64-encoded image
    image_filename: Mapped[str] = mapped_column()              # original filename
    image_content_type: Mapped[str] = mapped_column()          # MIME type
    user_context: Mapped[Optional[str]] = mapped_column(Text, nullable=True) # user-provided architecture context
    verdict: Mapped[Optional[str]] = mapped_column(nullable=True)   # "valid" / "invalid"
    violations: Mapped[list] = mapped_column(JSON, default=list)
    validated_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)

    # Back-reference to parent onboarding
    onboarding: Mapped["Onboarding"] = relationship(
        "Onboarding",
        back_populates="architecture_validation",
    )
