"""Service layer for SuperAdmin operations."""

import uuid

from sqlalchemy import func as sa_func
from sqlalchemy.orm import Session, joinedload

from app.models.admin_assignment import AdminAssignment
from app.models.onboarding import Onboarding
from app.models.user import User
from app.admin.superadmin.schemas import (
    AdminCreate,
    AdminUpdate,
    AdminWithWorkload,
    DashboardStats,
)


# ── Dashboard ────────────────────────────────────────────────────────────────

def get_dashboard(db: Session) -> DashboardStats:
    """Return aggregate stats and admin workloads."""
    total = db.query(Onboarding).count()

    status_counts: dict[str, int] = {}
    rows = (
        db.query(Onboarding.admin_status, sa_func.count(Onboarding.id))
        .group_by(Onboarding.admin_status)
        .all()
    )
    for status, count in rows:
        status_counts[status] = count

    # Admin workloads
    admins = db.query(User).filter(User.role == "admin", User.is_active == True).all()
    admin_workloads: list[AdminWithWorkload] = []
    for admin in admins:
        active_count = (
            db.query(AdminAssignment)
            .filter(
                AdminAssignment.admin_id == admin.id,
                AdminAssignment.status == "active",
            )
            .count()
        )
        admin_workloads.append(
            AdminWithWorkload(
                id=admin.id,
                email=admin.email,
                name=admin.name,
                emp_id=admin.emp_id,
                is_active=admin.is_active,
                active_assignments=active_count,
            )
        )

    return DashboardStats(
        total_onboardings=total,
        unassigned=status_counts.get("pending_assignment", 0),
        assigned=status_counts.get("assigned", 0),
        under_review=status_counts.get("under_review", 0),
        approved=status_counts.get("approved", 0),
        cost_pending=status_counts.get("cost_pending", 0),
        cost_done=status_counts.get("cost_done", 0),
        sent_back=status_counts.get("sent_back", 0),
        approval_checklist_sent=status_counts.get("approval_checklist_sent", 0),
        admins=admin_workloads,
    )


# ── Onboarding listing ──────────────────────────────────────────────────────

def list_onboardings(
    db: Session,
    unassigned: bool | None = None,
    assigned: bool | None = None,
    admin_status: str | None = None,
    search: str | None = None,
) -> list[Onboarding]:
    """List all onboardings with optional filters."""
    query = (
        db.query(Onboarding)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.user),
        )
    )

    if unassigned:
        query = query.filter(Onboarding.admin_status == "pending_assignment")
    if assigned:
        query = query.filter(Onboarding.admin_status != "pending_assignment")
    if admin_status:
        query = query.filter(Onboarding.admin_status == admin_status)
    if search:
        query = query.filter(Onboarding.name.ilike(f"%{search}%"))

    return query.order_by(Onboarding.created_at.desc()).all()


# ── Assignment ───────────────────────────────────────────────────────────────

def assign_admin(
    db: Session, onboarding_id: str, admin_id: str, assigned_by: str,
) -> AdminAssignment:
    """Assign an admin to an onboarding."""
    # Deactivate any previous active assignments
    db.query(AdminAssignment).filter(
        AdminAssignment.onboarding_id == onboarding_id,
        AdminAssignment.status == "active",
    ).update({"status": "reassigned"})

    assignment = AdminAssignment(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        admin_id=admin_id,
        assigned_by=assigned_by,
        status="active",
    )
    db.add(assignment)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        ob.admin_status = "assigned"

    db.commit()
    db.refresh(assignment)
    return assignment


def reassign_admin(
    db: Session, onboarding_id: str, new_admin_id: str, assigned_by: str,
) -> AdminAssignment:
    """Reassign an onboarding to a different admin."""
    # Mark old assignment as reassigned
    old = (
        db.query(AdminAssignment)
        .filter(
            AdminAssignment.onboarding_id == onboarding_id,
            AdminAssignment.status == "active",
        )
        .first()
    )
    if old:
        old.status = "reassigned"

    # Create new assignment
    assignment = AdminAssignment(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        admin_id=new_admin_id,
        assigned_by=assigned_by,
        status="active",
    )
    db.add(assignment)

    db.commit()
    db.refresh(assignment)
    return assignment


# ── Admin CRUD ───────────────────────────────────────────────────────────────

def list_admins(db: Session) -> list[User]:
    """List all admin users."""
    admins = db.query(User).filter(User.role == "admin").all()
    for admin in admins:
        admin.workload = (
            db.query(AdminAssignment)
            .filter(
                AdminAssignment.admin_id == admin.id,
                AdminAssignment.status == "active",
            )
            .count()
        )
    return admins


def create_admin(db: Session, data: AdminCreate) -> User:
    """Register a new admin user."""
    admin = User(
        id=str(uuid.uuid4()),
        name=data.name,
        email=data.email,
        emp_id=data.emp_id,
        role="admin",
    )
    db.add(admin)
    db.commit()
    db.refresh(admin)
    return admin


def update_admin(db: Session, admin_id: str, data: AdminUpdate) -> User | None:
    """Update an admin user."""
    admin = db.query(User).filter(User.id == admin_id, User.role == "admin").first()
    if admin is None:
        return None

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(admin, field, value)

    db.commit()
    db.refresh(admin)
    return admin


def deactivate_admin(db: Session, admin_id: str) -> bool:
    """Deactivate an admin (soft delete)."""
    admin = db.query(User).filter(User.id == admin_id, User.role == "admin").first()
    if admin is None:
        return False

    admin.is_active = False
    db.commit()
    return True
