"""Pydantic schemas for SuperAdmin endpoints."""

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


# ── Admin management ─────────────────────────────────────────────────────────

class AdminCreate(BaseModel):
    """Register a new admin user."""

    name: str
    email: str
    emp_id: str


class AdminUpdate(BaseModel):
    """Update an admin user — all fields optional."""

    name: Optional[str] = None
    email: Optional[str] = None
    is_active: Optional[bool] = None


class AdminResponse(BaseModel):
    """Admin user response."""

    id: str
    email: str
    name: str
    emp_id: str
    role: str
    is_active: bool
    created_at: datetime
    workload: int = 0

    model_config = ConfigDict(from_attributes=True)


class AdminWithWorkload(BaseModel):
    """Admin user with assigned workload count."""

    id: str
    email: str
    name: str
    emp_id: str
    is_active: bool
    active_assignments: int = 0

    model_config = ConfigDict(from_attributes=True)


# ── Assignment ───────────────────────────────────────────────────────────────

class AssignRequest(BaseModel):
    """Assign or reassign an admin to an onboarding."""

    admin_id: str


class AssignmentResponse(BaseModel):
    """Assignment result."""

    id: str
    onboarding_id: str
    admin_id: str
    assigned_by: str
    assigned_at: datetime
    status: str

    model_config = ConfigDict(from_attributes=True)


# ── Dashboard ────────────────────────────────────────────────────────────────

class DashboardStats(BaseModel):
    """SuperAdmin dashboard statistics."""

    total_onboardings: int
    unassigned: int
    assigned: int
    under_review: int
    approved: int
    cost_pending: int
    cost_done: int
    sent_back: int
    approval_checklist_sent: int
    admins: list[AdminWithWorkload]


# ── Onboarding listing ──────────────────────────────────────────────────────

class AdminAssignmentInfo(BaseModel):
    id: str
    admin_id: str
    assigned_by: str
    assigned_at: datetime
    status: str

    model_config = ConfigDict(from_attributes=True)


class AccountDetailsInfo(BaseModel):
    project_name: str
    isu: str
    owner: str
    business_unit: str

    model_config = ConfigDict(from_attributes=True)


class RequirementAssessmentInfo(BaseModel):
    cloud_provider: str
    region: str
    solution_type: str
    deployment_environments: list[str]

    model_config = ConfigDict(from_attributes=True)


class OnboardingListItem(BaseModel):
    """Onboarding in superadmin listing."""

    id: str
    name: str
    status: str
    current_step: int
    admin_status: str
    created_at: datetime
    updated_at: datetime
    account_details: Optional[AccountDetailsInfo] = None
    requirement_assessment: Optional[RequirementAssessmentInfo] = None
    admin_assignment: Optional[AdminAssignmentInfo] = None

    model_config = ConfigDict(from_attributes=True)
