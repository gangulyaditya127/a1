"""Admin API for architecture validation rule management."""
