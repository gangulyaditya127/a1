"""Pydantic schemas for architecture-rule admin endpoints."""

from typing import Optional

from pydantic import BaseModel, ConfigDict


class ArchitectureRuleCreate(BaseModel):
    cloud_provider: str
    category: str
    rule_text: str
    severity: str = "CRITICAL"


class ArchitectureRuleUpdate(BaseModel):
    cloud_provider: Optional[str] = None
    category: Optional[str] = None
    rule_text: Optional[str] = None
    severity: Optional[str] = None


class ArchitectureRuleResponse(BaseModel):
    id: str
    cloud_provider: str
    category: str
    rule_text: str
    severity: str

    model_config = ConfigDict(from_attributes=True)
