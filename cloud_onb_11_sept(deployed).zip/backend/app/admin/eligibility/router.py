"""Admin API router for eligibility question management."""

from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.admin.eligibility import service
from app.admin.eligibility.schemas import (
    EligibilityQuestionCreate,
    EligibilityQuestionResponse,
    EligibilityQuestionUpdate,
)

QUESTION_NOT_FOUND_MSG = "Question not found"
NOT_FOUND_RESPONSE = {404: {"description": QUESTION_NOT_FOUND_MSG}}

router = APIRouter()


@router.get("/")
def list_questions(db: Annotated[Session, Depends(get_db)]) -> list[EligibilityQuestionResponse]:
    """List all eligibility questions (ordered by sort_order)."""
    return service.get_all(db)


@router.post("/", status_code=201)
def create_question(
    data: EligibilityQuestionCreate,
    db: Annotated[Session, Depends(get_db)],
) -> EligibilityQuestionResponse:
    """Create a single eligibility question."""
    return service.create(db, data)


@router.post(
    "/bulk",
    status_code=201,
)
def bulk_create_questions(
    items: list[EligibilityQuestionCreate],
    db: Annotated[Session, Depends(get_db)],
) -> list[EligibilityQuestionResponse]:
    """Create multiple eligibility questions in one request."""
    return service.bulk_create(db, items)


@router.get("/{question_id}", responses=NOT_FOUND_RESPONSE)
def get_question(
    question_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> EligibilityQuestionResponse:
    """Get a single eligibility question by ID."""
    question = service.get_by_id(db, question_id)
    if question is None:
        raise HTTPException(status_code=404, detail=QUESTION_NOT_FOUND_MSG)
    return question


@router.put("/{question_id}", responses=NOT_FOUND_RESPONSE)
def update_question(
    question_id: str,
    data: EligibilityQuestionUpdate,
    db: Annotated[Session, Depends(get_db)],
) -> EligibilityQuestionResponse:
    """Update an eligibility question."""
    question = service.update(db, question_id, data)
    if question is None:
        raise HTTPException(status_code=404, detail=QUESTION_NOT_FOUND_MSG)
    return question


@router.delete("/{question_id}", status_code=204, responses=NOT_FOUND_RESPONSE)
def delete_question(
    question_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> None:
    """Delete an eligibility question."""
    deleted = service.delete(db, question_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=QUESTION_NOT_FOUND_MSG)


@router.delete("/", status_code=204)
def delete_all_questions(db: Annotated[Session, Depends(get_db)]) -> None:
    """Delete all eligibility questions."""
    service.delete_all(db)