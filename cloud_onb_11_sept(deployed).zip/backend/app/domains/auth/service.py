"""Service layer for user authentication and lookup."""

from sqlalchemy.orm import Session

from app.models.user import User


def get_user_by_id(db: Session, user_id: str) -> User | None:
    """Return a user by primary key."""
    return db.query(User).filter(User.id == user_id).first()


def get_user_by_email(db: Session, email: str) -> User | None:
    """Return a user by email address."""
    return db.query(User).filter(User.email == email).first()


def get_user_by_emp_id(db: Session, emp_id: str) -> User | None:
    """Return a user by employee ID."""
    return db.query(User).filter(User.emp_id == emp_id).first()


def get_all_users(db: Session) -> list[User]:
    """Return all users."""
    return db.query(User).all()
