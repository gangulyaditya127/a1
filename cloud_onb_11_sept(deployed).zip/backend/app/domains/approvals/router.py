"""Router for user-facing approval screenshot uploads."""

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Response
from sqlalchemy.orm import Session
import base64

from app.core.database import get_db
from app.domains.auth.dependencies import get_optional_user
from app.models.user import User
from app.domains.approvals import service

router = APIRouter()

ALLOWED_TYPES = {
    "image/png", "image/jpg", "image/jpeg", "application/pdf",
    "image/gif", "image/webp",
}
MAX_SIZE = 10 * 1024 * 1024  # 10 MB


@router.post("/{onboarding_id}/submit")
def submit_screenshots(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[Optional[User], Depends(get_optional_user)] = None,
) -> dict:
    """Explicitly submit all uploaded approval screenshots for DIS Admin review."""
    user_name = user.name if user else None
    result = service.submit_approval_screenshots(db, onboarding_id, user_name)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "Could not submit for review"))
    return result


@router.post("/{onboarding_id}/{rec_id}")
async def upload_screenshot(
    onboarding_id: str,
    rec_id: str,
    file: Annotated[UploadFile, File(...)],
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[Optional[User], Depends(get_optional_user)] = None,
) -> dict:
    """Upload a screenshot as proof for a specific approval checklist item."""
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {file.content_type}. Allowed: PNG, JPG, JPEG, PDF.",
        )

    content = await file.read()
    if len(content) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large. Maximum is 10 MB.")

    from io import BytesIO
    file.file = BytesIO(content)

    user_name = user.name if user else None
    screenshot = await service.upload_screenshot(db, onboarding_id, rec_id, file, user_name)

    return {
        "id": screenshot.id,
        "onboarding_id": screenshot.onboarding_id,
        "rec_id": screenshot.rec_id,
        "filename": screenshot.filename,
        "content_type": screenshot.content_type,
        "admin_status": screenshot.admin_status,
        "uploaded_at": screenshot.uploaded_at.isoformat() if screenshot.uploaded_at else None,
    }


@router.get("/{onboarding_id}/image/{screenshot_id}")
def get_screenshot_image(
    onboarding_id: str,
    screenshot_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> Response:
    """Serve the raw image bytes for a screenshot by its UUID."""
    screenshot = service.get_screenshot_by_id(db, screenshot_id, onboarding_id)
    if screenshot is None:
        raise HTTPException(status_code=404, detail="Screenshot not found")

    img_bytes = base64.b64decode(screenshot.image_data)
    return Response(
        content=img_bytes,
        media_type=screenshot.content_type,
        headers={"Content-Disposition": f'inline; filename="{screenshot.filename}"'},
    )


@router.get("/{onboarding_id}/{rec_id}/image")
def get_screenshot_image_by_rec_id(
    onboarding_id: str,
    rec_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> Response:
    """Serve the raw image bytes for a screenshot by rec_id."""
    screenshot = service.get_screenshot(db, onboarding_id, rec_id)
    if screenshot is None:
        raise HTTPException(status_code=404, detail="Screenshot not found")

    img_bytes = base64.b64decode(screenshot.image_data)
    return Response(
        content=img_bytes,
        media_type=screenshot.content_type,
        headers={"Content-Disposition": f'inline; filename="{screenshot.filename}"'},
    )


@router.delete("/{onboarding_id}/{screenshot_id}")
def delete_screenshot(
    onboarding_id: str,
    screenshot_id: str,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[Optional[User], Depends(get_optional_user)] = None,
) -> dict:
    """Delete a specific uploaded screenshot by its UUID."""
    deleted = service.delete_screenshot(db, screenshot_id, onboarding_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Screenshot not found")
    return {"ok": True}


@router.get("/{onboarding_id}")
def list_screenshots(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """Return grouped metadata for all uploaded approval screenshots for an onboarding."""
    return service.list_screenshots(db, onboarding_id)
