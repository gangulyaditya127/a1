"""Cloud resources domain — LLM chat and resource bucket persistence."""
