"""Pydantic schemas for the cloud resources domain."""

from typing import Optional

from pydantic import BaseModel, ConfigDict


# ── Chat schemas ─────────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    """A single turn in the conversation."""

    role: str  # "user" or "model"
    text: str


class ChatRequest(BaseModel):
    """Request payload for the chat endpoint."""

    provider: str = "AWS"
    message: str
    history: list[ChatMessage] = []


class ProposedResource(BaseModel):
    """A single cloud resource proposed by the LLM."""

    service: str
    count: int
    configDetails: str


class ChatResponse(BaseModel):
    """Response from the chat endpoint."""

    reply: str
    proposed_resources: list[ProposedResource] = []


# ── Bucket persistence schemas ────────────────────────────────────────────────

class ResourceItem(BaseModel):
    """A single approved resource entry in the bucket."""

    service: str
    count: int
    configDetails: str


class BucketUpsert(BaseModel):
    """Payload to create or update the resource bucket for an onboarding."""

    provider: str
    resources: list[ResourceItem]


class BucketResponse(BaseModel):
    """Response schema for a cloud resource bucket."""

    id: str
    onboarding_id: str
    provider: str
    resources: list[ResourceItem]

    model_config = ConfigDict(from_attributes=True)
