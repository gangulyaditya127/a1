"""Service layer for the cloud resources domain."""

import json
import re
import uuid

from sqlalchemy.orm import Session

from app.core import llm as llm_client
from app.core.logger import get_logger
from app.models.cloud_resources import CloudResourceBucket
from app.domains.cloud_resources.schemas import (
    BucketUpsert,
    ChatRequest,
    ChatResponse,
    ProposedResource,
)

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# LLM helpers
# ---------------------------------------------------------------------------

def _get_system_prompt(provider: str) -> str:
    """Return the system prompt for the cloud architect agent."""
    return f"""
You are an expert Cloud Solution Architect specializing in {provider}.
Your goal is to help the user design their cloud infrastructure and provision the right resources.

Follow these rules strictly:
1. Have a natural, conversational interaction. Ask 1-2 clarifying questions at a time.
2. Do not overwhelm the user with too many questions at once.
3. Once you have gathered enough requirements, propose a final cloud resource configuration.
4. IMPORTANT: When proposing the configuration, you MUST include a JSON array containing the resources.
   Wrap the JSON exactly in a ```json block.

Schema for the JSON array:
[
  {{
    "service": "Name of the {provider} cloud service (free text, no catalog)",
    "count": number,
    "configDetails": "Specific configuration details (e.g. t3.medium, Multi-AZ, 3 nodes)"
  }}
]

Always provide a friendly natural language explanation alongside the JSON block.
Do not restrict yourself to a predefined catalog — name any real {provider} service that fits the requirement.
"""


def _extract_json_resources(
    text: str,
) -> tuple[str, list[dict]]:
    """Extract the JSON resource array from LLM output.

    Returns:
        (clean_text, resources) where clean_text has the ```json block removed.
    """
    json_regex = r"```json\s*(.*?)\s*```"
    matches = re.findall(json_regex, text, re.DOTALL)

    resources: list[dict] = []
    clean_text = text

    if matches:
        try:
            resources = json.loads(matches[-1])
            clean_text = re.sub(json_regex, "", text, flags=re.DOTALL).strip()
        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON block from LLM response.")

    return clean_text, resources


# ---------------------------------------------------------------------------
# Chat service
# ---------------------------------------------------------------------------

def chat(request: ChatRequest) -> ChatResponse:
    """Run one conversational turn through the LLM and parse the response."""
    system_prompt = _get_system_prompt(request.provider)

    # Convert Pydantic ChatMessage objects to plain dicts for llm_client
    history = [{"role": msg.role, "text": msg.text} for msg in request.history]

    raw_text = llm_client.invoke(system_prompt, history, request.message)

    clean_text, raw_resources = _extract_json_resources(raw_text)

    proposed = [
        ProposedResource(
            service=r.get("service", ""),
            count=int(r.get("count", 1)),
            configDetails=r.get("configDetails", ""),
        )
        for r in raw_resources
        if isinstance(r, dict)
    ]

    return ChatResponse(reply=clean_text, proposed_resources=proposed)


# ---------------------------------------------------------------------------
# Bucket persistence
# ---------------------------------------------------------------------------

def get_bucket(
    db: Session,
    onboarding_id: str,
) -> CloudResourceBucket | None:
    """Return the cloud resource bucket for an onboarding, or None."""
    return (
        db.query(CloudResourceBucket)
        .filter(CloudResourceBucket.onboarding_id == onboarding_id)
        .first()
    )


def upsert_bucket(
    db: Session,
    onboarding_id: str,
    data: BucketUpsert,
) -> CloudResourceBucket:
    """Create or update the resource bucket for an onboarding."""
    bucket = get_bucket(db, onboarding_id)

    resources_json = [
        {"service": r.service, "count": r.count, "configDetails": r.configDetails}
        for r in data.resources
    ]

    if bucket is None:
        bucket = CloudResourceBucket(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            provider=data.provider,
            resources=resources_json,
        )
        db.add(bucket)
    else:
        bucket.provider = data.provider
        bucket.resources = resources_json

    db.commit()
    db.refresh(bucket)
    return bucket
