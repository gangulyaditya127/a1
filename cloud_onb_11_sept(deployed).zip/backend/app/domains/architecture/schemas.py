"""Pydantic schemas for architecture diagram validation endpoints."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class ValidationViolation(BaseModel):
    category: str
    rule_text: str
    severity: str
    finding: str


class UploadResponse(BaseModel):
    id: str
    onboarding_id: str
    image_filename: str
    user_context: Optional[str] = None
    message: str


class ValidateRequest(BaseModel):
    user_context: Optional[str] = None


class ValidationResponse(BaseModel):
    id: str
    onboarding_id: str
    image_filename: str
    user_context: Optional[str] = None
    verdict: Optional[str] = None
    violations: list[ValidationViolation] = []
    validated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)
