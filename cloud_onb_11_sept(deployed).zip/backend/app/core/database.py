"""Database engine, session factory, and base model."""

from typing import Generator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import settings

# Optimized Engine Configuration
engine = create_engine(
    settings.DATABASE_URL,
    echo=False,                     # Disable SQL logging
    pool_size=20,                   # Persistent connections
    max_overflow=30,                # Extra connections during spikes
    pool_timeout=30,
    pool_recycle=3600,
    pool_pre_ping=True,             # Avoid stale connections
)

# Optimized Session Factory
SessionLocal: sessionmaker[Session] = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,         # Prevent unnecessary refresh queries
)


class Base(DeclarativeBase):
    """SQLAlchemy declarative base for all models."""
    pass


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create database tables."""
    import app.models  # noqa: F401

    Base.metadata.create_all(bind=engine)

    try:
        with engine.begin() as conn:
            # conn.execute(
            #     text(
            #         """
            #         ALTER TABLE architecture_validations
            #         ADD COLUMN IF NOT EXISTS user_context TEXT;
            #         """
            #     )
            # )
            pass
    except Exception:
        pass