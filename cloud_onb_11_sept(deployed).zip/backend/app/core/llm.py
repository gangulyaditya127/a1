"""LLM utility for the CloudOps API.

Proxy configuration is explicitly set in main.py during startup.
"""

import logging
from typing import Any
from langchain_tcs_bfsi_genai import APIClient, Auth, TCSLLMs

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Gemini LLM invocation
# ---------------------------------------------------------------------------

def gemini_invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Call Gemini LLM and return the raw response text.

    Args:
        system_prompt: The system-level instruction for the model.
        history: List of previous turns as [{"role": "user"|"model", "text": "..."}].
        message: The latest user message.

    Returns:
        Raw LLM response text (may contain markdown, JSON blocks, etc.).
    """
    try:
        import google.generativeai as genai
    except ImportError as exc:
        raise RuntimeError(
            "google-generativeai is not installed. Run: pip install google-generativeai"
        ) from exc

    if not settings.GEMINI_API_KEY:
        raise ValueError(
            "GEMINI_API_KEY is not set. Add it to backend/.env or the environment."
        )

    genai.configure(api_key=settings.GEMINI_API_KEY)

    model = genai.GenerativeModel(
        model_name=settings.LLM_MODEL,
        system_instruction=system_prompt,
    )

    # Convert our history format to Gemini format
    formatted_history = [
        {"role": msg["role"], "parts": [msg["text"]]}
        for msg in history
    ]

    chat = model.start_chat(history=formatted_history)
    response = chat.send_message(message)
    return response.text


# ---------------------------------------------------------------------------
# Gemini multimodal (image + text) invocation
# ---------------------------------------------------------------------------

# def invoke_with_image(
#     system_prompt: str,
#     image_base64: str,
#     image_mime: str,
#     message: str,
# ) -> str:
#     """Call Gemini with an image for multimodal analysis.

#     Args:
#         system_prompt: System-level instruction for the model.
#         image_base64: Base64-encoded image data.
#         image_mime: MIME type of the image (e.g. "image/png").
#         message: The user's text message/prompt.

#     Returns:
#         Raw LLM response text.
#     """
#     import base64

#     try:
#         import google.generativeai as genai
#     except ImportError as exc:
#         raise RuntimeError(
#             "google-generativeai is not installed. Run: pip install google-generativeai"
#         ) from exc

#     if not settings.GEMINI_API_KEY:
#         raise ValueError(
#             "GEMINI_API_KEY is not set. Add it to backend/.env or the environment."
#         )

#     genai.configure(api_key=settings.GEMINI_API_KEY)

#     model = genai.GenerativeModel(
#         model_name=settings.LLM_MODEL,
#         system_instruction=system_prompt,
#     )

#     # Build multimodal content: image + text
#     image_bytes = base64.b64decode(image_base64)

#     logger.debug(
#         "invoke_with_image — model=%s image_size=%d mime=%s",
#         settings.LLM_MODEL, len(image_bytes), image_mime,
#     )

#     response = model.generate_content([
#         {
#             "mime_type": image_mime,
#             "data": image_bytes,
#         },
#         message,
#     ])
#     return response.text

import base64
import io
import logging
import time

from PIL import Image, ImageOps

logger = logging.getLogger(__name__)


def compress_base64_image(
    image_base64: str,
    max_width: int = 1280,
    max_height: int = 1280,
    quality: int = 75,
    max_output_bytes: int = 500_000,
) -> tuple[str, str]:
    """
    Decode, resize, and compress a Base64 image.

    Returns:
        tuple[str, str]:
            compressed Base64 string,
            resulting MIME type
    """

    # Handle data URLs such as:
    # data:image/png;base64,iVBORw0KGgo...
    if "," in image_base64 and image_base64.strip().startswith("data:"):
        image_base64 = image_base64.split(",", 1)[1]

    image_base64 = "".join(image_base64.split())

    try:
        image_bytes = base64.b64decode(
            image_base64,
            validate=True,
        )
    except Exception as exc:
        raise ValueError("Invalid Base64 image data") from exc

    original_size = len(image_bytes)

    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            image = ImageOps.exif_transpose(image)

            # Preserve transparency by placing the image on a white background.
            if image.mode in ("RGBA", "LA") or (
                image.mode == "P" and "transparency" in image.info
            ):
                rgba_image = image.convert("RGBA")
                background = Image.new(
                    "RGB",
                    rgba_image.size,
                    (255, 255, 255),
                )
                background.paste(
                    rgba_image,
                    mask=rgba_image.getchannel("A"),
                )
                image = background
            else:
                image = image.convert("RGB")

            # Resize only when required.
            image.thumbnail(
                (max_width, max_height),
                Image.Resampling.LANCZOS,
            )

            # Reduce JPEG quality until the output is within the limit.
            current_quality = quality
            compressed_bytes = b""

            while current_quality >= 40:
                buffer = io.BytesIO()

                image.save(
                    buffer,
                    format="JPEG",
                    quality=current_quality,
                    optimize=True,
                    progressive=True,
                )

                compressed_bytes = buffer.getvalue()

                if len(compressed_bytes) <= max_output_bytes:
                    break

                current_quality -= 5

    except Exception as exc:
        raise ValueError("Unable to process the supplied image") from exc

    compressed_base64 = base64.b64encode(
        compressed_bytes
    ).decode("utf-8")

    logger.info(
        (
            "Image compressed: original=%d bytes, "
            "compressed=%d bytes, base64=%d chars, "
            "quality=%d"
        ),
        original_size,
        len(compressed_bytes),
        len(compressed_base64),
        current_quality,
    )

    return compressed_base64, "image/jpeg"
# ---------------------------------------------------------------------------
# BFSI LLM invocation
# # ---------------------------------------------------------------------------
# def invoke_with_image(
#     system_prompt: str,
#     image_base64: str,
#     image_mime: str,
#     message: str,
# ) -> str:

#     try:
#         client = APIClient()

#         auth = Auth(client)
#         auth.login(
#             settings.LLM_USERNAME,
#             settings.LLM_PASSWORD,
#         )

#         llm = TCSLLMs(
#             client=client,
#             model_name=settings.LLM_MODEL
#         )
#         # print("**************")
#         # print(type(llm))
#         # print("*******************")
#         # print(dir(llm))
#         prompt = f"""
#     {system_prompt}

#     User Message:
#     {message}

#     Image MIME Type:
#     {image_mime}

#     Image Base64:
#     {image_base64}

#     Analyze the image and answer the user query.
#     """

#         response = llm.invoke(prompt)
#         logger.info("LLM call for image analysis completed")
#         return response
#     except Exception as e:
#         print(str(e))
#         raise

def invoke_with_image(
    system_prompt: str,
    image_base64: str,
    image_mime: str,
    message: str,
) -> str:
    try:
        compressed_base64, compressed_mime = compress_base64_image(
            image_base64=image_base64,
            max_width=1280,
            max_height=1280,
            quality=75,
            max_output_bytes=500_000,
        )

        client = APIClient()

        auth = Auth(client)
        auth.login(
            settings.LLM_USERNAME,
            settings.LLM_PASSWORD,
        )

        llm = TCSLLMs(
            client=client,
            model_name=settings.LLM_MODEL,
        )

        prompt = f"""
{system_prompt}

User message:
{message}

Image MIME type:
{compressed_mime}

Image Base64:
{compressed_base64}

Analyze the supplied image and answer the user query.
""".strip()

        logger.info(
            "Calling image analysis: original_mime=%s, "
            "compressed_mime=%s, prompt_chars=%d",
            image_mime,
            compressed_mime,
            len(prompt),
        )

        start_time = time.perf_counter()

        response = llm.invoke(
            prompt,
            max_tokens=1500,
            temperature=0.1,
        )

        elapsed_time = time.perf_counter() - start_time

        logger.info(
            "LLM image-analysis call completed in %.2f seconds",
            elapsed_time,
        )

        if isinstance(response, str):
            return response

        if hasattr(response, "content"):
            return str(response.content)

        if isinstance(response, dict):
            return str(
                response.get("content")
                or response.get("text")
                or response.get("response")
                or response
            )

        return str(response)

    except Exception:
        logger.exception("LLM image-analysis call failed")
        raise
def bfsi_invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Call TCS BFSI GenAI LLM and return the raw response text."""
    

    # In a real app, you'd add LLM_USERNAME and LLM_PASSWORD to settings.
    # We fallback to hardcoded for this reference if not found.
    username = getattr(settings, "LLM_USERNAME", "152459")
    password = getattr(settings, "LLM_PASSWORD", "Surajit@152459")
    model_name = getattr(settings, "LLM_MODEL", "gpt-4o-mini")

    client = APIClient()
    auth = Auth(client)
    auth.login(username, password)

    llm = TCSLLMs(
        client=client,
        model_name=model_name
    )

    history_text = ""
    if history:
        turns = [
            f"{'User' if msg.get('role', '').lower() == 'user' else 'Assistant'}: {msg.get('text', '')}"
            for msg in history
        ]
        history_text = f"\nConversation history:\n{chr(10).join(turns)}\n"

    prompt = f"""{system_prompt}

{history_text}

Latest user message:
User: {message}

Assistant:
"""

    llm_response = llm.invoke(prompt)
    logger.info("BFSI llm call completed")
    if isinstance(llm_response, str):
        return llm_response
    if hasattr(llm_response, "content"):
        return llm_response.content
    if isinstance(llm_response, dict):
        return (
            llm_response.get("content") or 
            llm_response.get("text") or 
            llm_response.get("response") or 
            str(llm_response)
        )

    return str(llm_response)


# ---------------------------------------------------------------------------
# Public dispatch — call this from service code
# ---------------------------------------------------------------------------

def invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Invoke the configured LLM provider.

    Currently uses Gemini as per the user's request. 
    To switch providers in the future, just call bfsi_invoke instead.
    """
    logger.debug("LLM invoke — model=%s history_turns=%d", settings.LLM_MODEL, len(history))
    # return gemini_invoke(system_prompt, history, message)
    return bfsi_invoke(system_prompt, history, message)