import json
import uuid
from datetime import datetime

from sqlalchemy.orm import Session
from models import get_session,PolicyEventLog


JSON_FILE = "canara_observability_events_10min.json"


def insert_events_from_json():
    # Read JSON array
    with open(JSON_FILE, "r", encoding="utf-8") as file:
        events = json.load(file)

    if not isinstance(events, list):
        raise ValueError("JSON file must contain an array of objects")

    # One correlation ID for this complete file/import
    corelation_id = f"CORR-{uuid.uuid4()}"
    try:
        session=get_session()
        for item in events:
            event_data = item["event"]

            record = PolicyEventLog(
                # corelation_id=corelation_id,
                organization=item["organization"],
                application=item["application"],
                journey=item["journey"],
                step=item["step"],
                action=item["action"],
                tier=item["tier"],
                event_timestamp=datetime.strptime(
                    item["timestamp"],
                    "%H:%M:%S",
                ).time(),
                eventname=event_data["eventname"],
                message=event_data["message"],
                severity=event_data["severity"],
                source=event_data["source"]
            )

            session.add(record)

        session.commit()

        

    except Exception as error:
        session.rollback()
        print(f"Insert failed: {error}")
        raise


if __name__ == "__main__":
    insert_events_from_json()