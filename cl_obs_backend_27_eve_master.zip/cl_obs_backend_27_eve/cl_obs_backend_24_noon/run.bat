@echo off
@REM python -m app.scripts.seed_data
@REM python -m app.scripts.seed_ai_discovery
@REM python -m app.scripts.seed_historical_alerts 
@REM python -m app.scripts.seed_group_benefits
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
