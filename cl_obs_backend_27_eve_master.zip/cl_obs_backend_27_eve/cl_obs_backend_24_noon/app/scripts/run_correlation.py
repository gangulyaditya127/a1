"""CLI runner for the correlation engine with human-readable trace.

Usage:
    python -m app.scripts.run_correlation                          # dry run
    python -m app.scripts.run_correlation --write                  # persist
    python -m app.scripts.run_correlation --write --incident-id X  # custom id
"""
import argparse, json
from app.core.database import SessionLocal
from app.services.correlation_engine import CorrelationEngine


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--write", action="store_true", help="Persist derived incident to DB")
    p.add_argument("--incident-id", default="INC-AUTO-001")
    p.add_argument("--json", action="store_true", help="Emit JSON")
    args = p.parse_args()

    db = SessionLocal()
    try:
        engine = CorrelationEngine(db)
        run = engine.run(incident_id=args.incident_id, write_to_db=args.write)

        if args.json:
            print(json.dumps(run.to_dict(), indent=2))
            return

        print(f"Correlation run at {run.started_at}")
        print(f"  Alerts scanned : {run.alerts_scanned}")
        print(f"  Rules evaluated: {run.rules_evaluated}")
        print(f"  Written to DB  : {run.written_to_db}")
        if run.incident_id:
            print(f"  Incident ID    : {run.incident_id}")
        print("=" * 80)
        for i, m in enumerate(run.matches, 1):
            status = "OK" if m.is_valid() else "SKIP"
            print()
            print(f"[{i}] {status}  {m.rule.rule_id}  -  {m.rule.name}")
            print(f"     confidence = {m.runtime_confidence:.3f} "
                  f"(base {float(m.rule.confidence_score):.2f} x match {m.match_ratio:.2f})")
            if m.anchor:
                print(f"     anchor     = {m.anchor.alert_ref} ({m.anchor.name}) @ {m.anchor.first_seen_today}")
            print(f"     window     = {m.time_window_seconds}s ({'ok' if m.time_window_ok else 'fail'})")
            if m.required_chain:
                print(f"     chain      = {' -> '.join(m.required_chain)} "
                      f"({'ok' if m.topology_chain_ok else 'fail'})")
            print(f"     alerts     = {m.alert_refs}")
            print("     trace:")
            for line in m.trace:
                print(f"        {line}")
    finally:
        db.close()


if __name__ == "__main__":
    main()
