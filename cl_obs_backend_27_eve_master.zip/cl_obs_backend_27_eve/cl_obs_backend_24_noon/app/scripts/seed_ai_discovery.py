"""Seed AI Rule Discovery reference data."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from sqlalchemy import delete
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine
from app.models import Base
from app.models.ai_discovery import (
    CiToolCoverage, DiscoveredPattern, AiRuleProposal, RuleReviewEvent,
)

NOW = datetime.now(timezone.utc)

COVERAGE = [
    ("ora", "oracle_em",     "RACNodeInstanceFailover / ActiveSessionsSpike",  "Native DB monitoring"),
    ("ora", "appd_db",       "SQLResponseTimeSpike",                            "DB APM"),
    ("ora", "splunk",        "DBConnectionExhaustion",                          "Log-based"),
    ("ora", "dynatrace",     "SessionCountAnomaly",                             "APM auto-instrumentation"),
    ("claims", "appd",       "ThreadPoolExhaustion / RuleExecutionTimeout / HighResponseTimeDeviation", "APM"),
    ("claims", "splunk",     "JVMOldGenSaturation / ErrorLogSurge",             "Log-based"),
    ("claims", "dynatrace",  "BackendCallResponseTimeHigh",                     "RUM + APM"),
    ("esb", "tibco_hawk",    "ProcessEngineStuckThread / HighQueueDepth",       "Native TIBCO"),
    ("esb", "appd",          "ESBHealthDegraded",                                "APM view"),
    ("esb", "splunk",        "ESBTransactionLatency",                            "Log-based"),
    ("rating-eng", "appd",   "JVMHeapExhaustion / ThreadPoolExhaustion / GCPauseTimeHigh / HighResponseTimeDeviation", "APM"),
    ("rating-eng", "splunk", "ErrorLogSurge",                                    "Log-based"),
    ("fnet", "filenet_admin","DocRepositoryTimeout",                             "Admin console"),
    ("fnet", "splunk",       "ObjectStoreErrorRate",                             "Log-based"),
    ("esxi", "solarwinds",   "CPUReadyTimeHigh",                                 "SNMP"),
    ("esxi", "vmware_vc",    "VMMemoryBalloonActive",                            "vCenter API"),
    ("dyna", "dynatrace",    "BackendCallResponseTimeHigh / UserActionFailureRate", "Real user monitoring"),
    ("gw", "splunk",         "GatewayTimeoutSpike",                              "Access logs"),
]

PATTERNS = [
    dict(pattern_id="PAT-041", name="DB failover cascade",
        support_count=4, avg_time_delta_s=17, tool_count=3, ci_count=3,
        signals=[
            {"tool_id":"oracle_em","tool_name":"Oracle EM","signal":"RACNodeInstanceFailover"},
            {"tool_id":"appd","tool_name":"AppDynamics","signal":"ThreadPoolExhaustion"},
            {"tool_id":"tibco_hawk","tool_name":"TIBCO Hawk","signal":"ProcessEngineStuckThread"},
            {"tool_id":"splunk","tool_name":"Splunk","signal":"DBConnectionExhaustion"},
        ],
        cis=["ora","claims","esb"], tiers=["data","integration","application"], status="new"),
    dict(pattern_id="PAT-057", name="Memory leak deployment cascade",
        support_count=7, avg_time_delta_s=34, tool_count=4, ci_count=4,
        signals=[
            {"tool_id":"appd","tool_name":"AppDynamics","signal":"JVMHeapExhaustion"},
            {"tool_id":"appd","tool_name":"AppDynamics","signal":"GCPauseTimeHigh"},
            {"tool_id":"splunk","tool_name":"Splunk","signal":"KafkaConsumerLag"},
            {"tool_id":"tibco_hawk","tool_name":"TIBCO Hawk","signal":"HighQueueDepth"},
        ],
        cis=["rating-eng","kafka","esb","grpdb"], tiers=["application","integration","data"], status="new"),
    dict(pattern_id="PAT-072", name="ESB queue backlog with node health degradation",
        support_count=11, avg_time_delta_s=13, tool_count=2, ci_count=2,
        signals=[
            {"tool_id":"tibco_hawk","tool_name":"TIBCO Hawk","signal":"HighQueueDepth"},
            {"tool_id":"appd","tool_name":"AppDynamics","signal":"ESBHealthDegraded"},
        ],
        cis=["esb"], tiers=["integration"], status="new"),
]


def _cleanup(db: Session):
    db.execute(delete(RuleReviewEvent))
    db.execute(delete(AiRuleProposal))
    db.execute(delete(DiscoveredPattern))
    db.execute(delete(CiToolCoverage))
    db.commit()


def seed():
    print("Ensuring schema exists...")
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        print("Cleaning prior AI-Discovery rows...")
        _cleanup(db)

        from app.models.reference import Component, MonitoringTool
        existing_components = {c.component_id for c in db.query(Component).all()}
        existing_tools      = {t.tool_id for t in db.query(MonitoringTool).all()}

        added = skipped = 0
        for comp_id, tool_id, signal, notes in COVERAGE:
            if comp_id not in existing_components or tool_id not in existing_tools:
                skipped += 1
                continue
            db.add(CiToolCoverage(component_id=comp_id, tool_id=tool_id,
                                  signal_pattern=signal, notes=notes))
            added += 1
        print(f"Seeded {added} CI-tool coverage rows ({skipped} skipped - missing refs).")

        for p in PATTERNS:
            db.add(DiscoveredPattern(
                pattern_id=p["pattern_id"], name=p["name"],
                support_count=p["support_count"], avg_time_delta_s=p["avg_time_delta_s"],
                tool_count=p["tool_count"], ci_count=p["ci_count"],
                signals_json=json.dumps(p["signals"]),
                cis_json=json.dumps(p["cis"]), tiers_json=json.dumps(p["tiers"]),
                discovered_at=NOW, status=p["status"],
            ))
        print(f"Seeded {len(PATTERNS)} discovered patterns.")
        db.commit()
        print("[OK] AI Rule Discovery seeding complete.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
