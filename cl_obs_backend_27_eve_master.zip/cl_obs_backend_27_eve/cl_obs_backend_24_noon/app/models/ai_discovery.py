"""AI Rule Discovery - 4 new tables."""
from __future__ import annotations
from datetime import datetime
from sqlalchemy import (
    String, Integer, Text, Numeric, DateTime, ForeignKey, Boolean,
    CheckConstraint, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base


class CiToolCoverage(Base):
    __tablename__ = "ci_tool_coverage"
    id:             Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    component_id:   Mapped[str] = mapped_column(String(30), ForeignKey("components.component_id"), nullable=False, index=True)
    tool_id:        Mapped[str] = mapped_column(String(30), ForeignKey("monitoring_tools.tool_id"), nullable=False, index=True)
    signal_pattern: Mapped[str] = mapped_column(String(200), nullable=False)
    notes:          Mapped[str] = mapped_column(Text, nullable=True)
    __table_args__ = (UniqueConstraint("component_id","tool_id","signal_pattern",name="uq_ci_tool_signal"),)


class DiscoveredPattern(Base):
    __tablename__ = "discovered_patterns"
    pattern_id:       Mapped[str]      = mapped_column(String(20), primary_key=True)
    name:             Mapped[str]      = mapped_column(String(200), nullable=False)
    support_count:    Mapped[int]      = mapped_column(Integer, nullable=False)
    avg_time_delta_s: Mapped[int]      = mapped_column(Integer, nullable=False)
    tool_count:       Mapped[int]      = mapped_column(Integer, nullable=False)
    ci_count:         Mapped[int]      = mapped_column(Integer, nullable=False)
    signals_json:     Mapped[str]      = mapped_column(Text, nullable=False)
    cis_json:         Mapped[str]      = mapped_column(Text, nullable=False)
    tiers_json:       Mapped[str]      = mapped_column(Text, nullable=False)
    discovered_at:    Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status:           Mapped[str]      = mapped_column(String(20), nullable=False, default="new")
    __table_args__ = (CheckConstraint("status in ('new','used','ignored')", name="discovered_pattern_status_valid"),)


class AiRuleProposal(Base):
    __tablename__ = "ai_rule_proposals"
    proposal_id:              Mapped[str]      = mapped_column(String(30), primary_key=True)
    source_pattern_id:        Mapped[str]      = mapped_column(String(20), ForeignKey("discovered_patterns.pattern_id"), nullable=False)
    name:                     Mapped[str]      = mapped_column(String(200), nullable=False)
    plain_english:            Mapped[str]      = mapped_column(Text, nullable=False)
    trigger_when:             Mapped[str]      = mapped_column(String(200), nullable=False)
    trigger_target:           Mapped[str]      = mapped_column(String(200), nullable=False)
    combine_logic:            Mapped[str]      = mapped_column(Text, nullable=False)
    output_summary:           Mapped[str]      = mapped_column(Text, nullable=False)
    combine_inputs_json:      Mapped[str]      = mapped_column(Text, nullable=False)
    explanation_json:         Mapped[str]      = mapped_column(Text, nullable=False)
    confidence_score:         Mapped[float]    = mapped_column(Numeric(3, 2), nullable=False)
    expected_precision:       Mapped[float]    = mapped_column(Numeric(3, 2), nullable=False)
    expected_alert_reduction: Mapped[int]      = mapped_column(Integer, nullable=False)
    generated_by:             Mapped[str]      = mapped_column(String(30), nullable=False, default="openai")
    llm_model:                Mapped[str]      = mapped_column(String(60), nullable=True)
    created_at:               Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status:                   Mapped[str]      = mapped_column(String(20), nullable=False, default="pending")
    deployed_rule_id:         Mapped[str]      = mapped_column(String(30), ForeignKey("correlation_rules.rule_id"), nullable=True)
    __table_args__ = (
        CheckConstraint("status in ('pending','approved','tuned','rejected','deployed')", name="proposal_status_valid"),
        CheckConstraint("confidence_score >= 0 and confidence_score <= 1", name="proposal_confidence_range"),
        CheckConstraint("expected_precision >= 0 and expected_precision <= 1", name="proposal_precision_range"),
    )


class RuleReviewEvent(Base):
    __tablename__ = "rule_review_events"
    event_id:    Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    proposal_id: Mapped[str]      = mapped_column(String(30), ForeignKey("ai_rule_proposals.proposal_id", ondelete="CASCADE"), nullable=False, index=True)
    reviewer_id: Mapped[str]      = mapped_column(String(60), nullable=False)
    decision:    Mapped[str]      = mapped_column(String(20), nullable=False)
    comment:     Mapped[str]      = mapped_column(Text, nullable=True)
    tuned_json:  Mapped[str]      = mapped_column(Text, nullable=True)
    created_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    __table_args__ = (CheckConstraint("decision in ('approve','tune','reject','deploy')", name="review_decision_valid"),)
