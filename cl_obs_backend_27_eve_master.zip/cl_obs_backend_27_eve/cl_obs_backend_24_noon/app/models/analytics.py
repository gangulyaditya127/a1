"""Rolling analytics aggregates (recomputed periodically)."""
from datetime import datetime
from sqlalchemy import String, Integer, DateTime, ForeignKey, CheckConstraint, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class TierHistoricalStat(Base):
    __tablename__ = "tier_historical_stats"
    id:                    Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    tier_id:               Mapped[str]      = mapped_column(String(10),
                                                            ForeignKey("tiers.tier_id"),
                                                            nullable=False, index=True)
    alerts_today:          Mapped[int]      = mapped_column(Integer, nullable=False)
    alerts_last_7d:        Mapped[int]      = mapped_column(Integer, nullable=False)
    alerts_last_30d:       Mapped[int]      = mapped_column(Integer, nullable=False)
    median_mttr_minutes:   Mapped[int]      = mapped_column(Integer, nullable=False)
    computed_at:           Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)


class TierTopCause(Base):
    __tablename__ = "tier_top_causes"
    id:          Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    tier_id:     Mapped[str]      = mapped_column(String(10),
                                                  ForeignKey("tiers.tier_id"),
                                                  nullable=False)
    rank:        Mapped[int]      = mapped_column(Integer, nullable=False)
    cause_name:  Mapped[str]      = mapped_column(String(160), nullable=False)
    percentage:  Mapped[int]      = mapped_column(Integer, nullable=False)
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    __table_args__ = (
        CheckConstraint("rank between 1 and 10", name="rank_range"),
        CheckConstraint("percentage between 0 and 100", name="pct_range"),
        UniqueConstraint("tier_id", "rank", "computed_at", name="uq_tier_rank_computed"),
    )
