"""Correlation rule definitions."""
from sqlalchemy import String, Integer, Text, Numeric, ForeignKey, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class CorrelationRule(Base):
    __tablename__ = "correlation_rules"
    rule_id:          Mapped[str]   = mapped_column(String(30), primary_key=True)
    name:             Mapped[str]   = mapped_column(String(200), nullable=False)
    confidence_score: Mapped[float] = mapped_column(Numeric(3, 2), nullable=False)
    plain_english:    Mapped[str]   = mapped_column(Text, nullable=False)
    trigger_when:     Mapped[str]   = mapped_column(String(200), nullable=False)
    trigger_target:   Mapped[str]   = mapped_column(String(200), nullable=False)
    combine_logic:    Mapped[str]   = mapped_column(Text, nullable=False)
    output_summary:   Mapped[str]   = mapped_column(Text, nullable=False)
    __table_args__ = (
        CheckConstraint("confidence_score >= 0 and confidence_score <= 1", name="confidence_range"),
    )


class RuleCombineInput(Base):
    __tablename__ = "rule_combine_inputs"
    id:             Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    rule_id:        Mapped[str] = mapped_column(String(30),
                                                ForeignKey("correlation_rules.rule_id", ondelete="CASCADE"),
                                                nullable=False)
    tool_id:        Mapped[str] = mapped_column(String(30),
                                                ForeignKey("monitoring_tools.tool_id"),
                                                nullable=False)
    signal_pattern: Mapped[str] = mapped_column(String(200), nullable=False)
    display_order:  Mapped[int] = mapped_column(Integer, nullable=False)


class RuleExplanation(Base):
    __tablename__ = "rule_explanations"
    id:              Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    rule_id:         Mapped[str] = mapped_column(String(30),
                                                 ForeignKey("correlation_rules.rule_id", ondelete="CASCADE"),
                                                 nullable=False)
    paragraph_order: Mapped[int] = mapped_column(Integer, nullable=False)
    text:            Mapped[str] = mapped_column(Text, nullable=False)
    __table_args__ = (
        UniqueConstraint("rule_id", "paragraph_order", name="uq_rule_paragraph"),
    )
