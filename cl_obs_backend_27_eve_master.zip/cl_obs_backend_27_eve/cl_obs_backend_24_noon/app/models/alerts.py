"""Alert events + per-alert key/value metric grid."""
from datetime import datetime, time
from sqlalchemy import String, Integer, Text, DateTime, Time, ForeignKey, CheckConstraint, UniqueConstraint, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Alert(Base):
    __tablename__ = "alerts"
    alert_ref:              Mapped[str]      = mapped_column(String(30), primary_key=True)
    name:                   Mapped[str]      = mapped_column(String(120), nullable=False)
    description:            Mapped[str]      = mapped_column(Text, nullable=False)
    severity:               Mapped[str]      = mapped_column(String(10), nullable=False)
    tier_id:                Mapped[str]      = mapped_column(String(10),
                                                             ForeignKey("tiers.tier_id"),
                                                             nullable=False, index=True)
    tool_id:                Mapped[str]      = mapped_column(String(30),
                                                             ForeignKey("monitoring_tools.tool_id"),
                                                             nullable=False)
    component_id:           Mapped[str]      = mapped_column(String(30),
                                                             ForeignKey("components.component_id"),
                                                             nullable=False)
    component_display_name: Mapped[str]      = mapped_column(String(120), nullable=False)
    detected_at:            Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    first_seen_today:       Mapped[time]     = mapped_column(Time, nullable=False)
    occurrences_7d:         Mapped[int]      = mapped_column(Integer, nullable=False, default=0)
    occurrences_30d:        Mapped[int]      = mapped_column(Integer, nullable=False, default=0)
    is_correlated:          Mapped[bool]     = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (
        CheckConstraint("severity in ('crit','high','medium','low')", name="severity_valid"),
        CheckConstraint("occurrences_30d >= occurrences_7d", name="occurrences_monotonic"),
    )


class AlertMetric(Base):
    __tablename__ = "alert_metrics"
    id:            Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    alert_ref:     Mapped[str] = mapped_column(String(30),
                                               ForeignKey("alerts.alert_ref", ondelete="CASCADE"),
                                               nullable=False)
    metric_key:    Mapped[str] = mapped_column(String(80),  nullable=False)
    metric_value:  Mapped[str] = mapped_column(String(200), nullable=False)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False)
    __table_args__ = (
        UniqueConstraint("alert_ref", "metric_key", name="uq_alert_metric_key"),
    )
