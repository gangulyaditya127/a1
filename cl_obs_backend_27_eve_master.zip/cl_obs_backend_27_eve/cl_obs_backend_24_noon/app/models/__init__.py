"""Re-export all models for Base.metadata.create_all() discovery."""
from app.models.base import Base
from app.models.reference import (
    Tier, MonitoringTool, Component, ComponentDependency, Journey, SubJourney,
)
from app.models.rules import (
    CorrelationRule, RuleCombineInput, RuleExplanation,
)
from app.models.metrics import (
    JourneyMetric, SubJourneyMetric,
)
from app.models.alerts import (
    Alert, AlertMetric,
)
from app.models.incidents import (
    Incident, IncidentAlert, TierIncidentSummary, RuleFiring, RuleFiringAlert, IncidentSubJourney,
)
from app.models.analytics import (
    TierHistoricalStat, TierTopCause,
)

__all__ = [
    "Base",
    "Tier", "MonitoringTool", "Component", "ComponentDependency", "Journey", "SubJourney",
    "CorrelationRule", "RuleCombineInput", "RuleExplanation",
    "JourneyMetric", "SubJourneyMetric",
    "Alert", "AlertMetric",
    "Incident", "IncidentAlert", "TierIncidentSummary", "RuleFiring", "RuleFiringAlert", "IncidentSubJourney",
    "TierHistoricalStat", "TierTopCause",
]

# AI Rule Discovery models (installer)
from app.models.ai_discovery import (
    CiToolCoverage, DiscoveredPattern, AiRuleProposal, RuleReviewEvent,
)

# Sub-journey <-> component junction (installer)
from app.models.sub_journey_components import SubJourneyComponent
