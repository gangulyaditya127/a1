"""Schemas matching /public/data/journeys.json and subJourneys.json."""
from typing import Optional, List
from pydantic import BaseModel


class JourneyOut(BaseModel):
    id: str
    name: str
    users: int
    happy: int
    unhappy: int
    frustrated: int
    avail: float
    alerts: int


class SubJourneyStepOut(BaseModel):
    id: str
    name: str
    api: str
    hu: Optional[List[int]] = None
    avg: int
    p95: int
    err: float
    avail: float
    critical: bool


class SubJourneyOut(BaseModel):
    title: str
    steps: List[SubJourneyStepOut]
