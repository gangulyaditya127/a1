"""Correlation Engine.

Evaluates every rule in the DB against the alert set.
Parses `combine_logic` free text for time window + topology chain.
Writes derived incidents + rule firings to DB.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.services.llm_call import openai_invoke,gemini_invoke
from app.core.config import settings

from app.models.reference import Tier, MonitoringTool, Component, ComponentDependency
from app.models.alerts import Alert
from app.models.rules import CorrelationRule, RuleCombineInput
from app.models.incidents import (
    Incident, IncidentAlert, RuleFiring, RuleFiringAlert, IncidentSubJourney,
    IncidentTopologyState, IncidentCriticalEdge,
)
from app.models.sub_journey_components import SubJourneyComponent
import json

@dataclass
class SignalMatch:
    input_index: int
    input_tool_id: str
    input_signal: str
    alert: Alert
    def to_dict(self) -> dict:
        return {
            "input_index":   self.input_index,
            "input_tool_id": self.input_tool_id,
            "input_signal":  self.input_signal,
            "alert_ref":     self.alert.alert_ref,
            "alert_name":    self.alert.name,
            "alert_time":    self.alert.first_seen_today.strftime("%H:%M:%S"),
        }


@dataclass
class RuleMatch:
    rule: CorrelationRule
    anchor: Optional[Alert]
    signal_matches: list[SignalMatch]
    matched_input_indices: set[int]
    time_window_seconds: int
    required_chain: list[str]
    time_window_ok: bool
    topology_chain_ok: bool
    match_ratio: float
    runtime_confidence: float
    trace: list[str]

    @property
    def alert_refs(self) -> list[str]:
        seen = []
        for m in self.signal_matches:
            if m.alert.alert_ref not in seen:
                seen.append(m.alert.alert_ref)
        return seen

    def is_valid(self) -> bool:
        return (
            self.anchor is not None
            and self.time_window_ok
            and self.topology_chain_ok
            and len(self.matched_input_indices) > 0
        )

    def to_dict(self) -> dict:
        return {
            "rule_id":              self.rule.rule_id,
            "rule_name":            self.rule.name,
            "anchor_alert_ref":     self.anchor.alert_ref if self.anchor else None,
            "matched_input_count":  len(self.matched_input_indices),
            "match_ratio":          round(self.match_ratio, 3),
            "runtime_confidence":   round(self.runtime_confidence, 3),
            "time_window_seconds":  self.time_window_seconds,
            "time_window_ok":       self.time_window_ok,
            "required_chain":       self.required_chain,
            "topology_chain_ok":    self.topology_chain_ok,
            "alert_refs":           self.alert_refs,
            "signal_matches":       [m.to_dict() for m in self.signal_matches],
            "trace":                self.trace,
        }


@dataclass
class CorrelationRun:
    started_at:      datetime
    alerts_scanned:  int
    rules_evaluated: int
    matches:         list[RuleMatch] = field(default_factory=list)
    incident_id:     Optional[str]   = None
    written_to_db:   bool            = False

    def to_dict(self) -> dict:
        return {
            "started_at":       self.started_at.isoformat(),
            "alerts_scanned":   self.alerts_scanned,
            "rules_evaluated":  self.rules_evaluated,
            "match_count":      len(self.matches),
            "incident_id":      self.incident_id,
            "written_to_db":    self.written_to_db,
            "matches":          [m.to_dict() for m in self.matches],
        }


_TIER_NAME_TO_ID = {
    "presentation": "pres", "application":  "app",
    "integration":  "int",  "data":         "data",
    "infrastructure": "infra",
}
_ANCHOR_SEPARATORS = re.compile(r"\s*[.|]\s*")


class CorrelationEngine:
    def __init__(self, db: Session):
        self.db = db
        self._tools_by_id: dict[str, MonitoringTool] = {
            t.tool_id: t for t in db.execute(select(MonitoringTool)).scalars().all()
        }
        self._alerts: list[Alert] = []
        self._inputs_by_rule: dict[str, list[RuleCombineInput]] = {}
    
    def _generate_llm_incident_summary(self, top: RuleMatch) -> dict:
        """Uses OpenAI to generate a dynamic title, root cause, and description."""
    
    # 1. Update fallback to include root_cause
        fallback = {
            "title": f"Auto-correlated: {top.rule.name}",
            "root_cause": top.anchor.name if top.anchor else "Unknown Root Cause",
            "root_cause_desc": top.rule.output_summary
        }

        # if not getattr(settings, "OPENAI_ENABLED", False) or not getattr(settings, "OPENAI_API_KEY", ""):
        #     return fallback

        try:
            print("Inside try block")
            # import openai
            # import httpx 
            # direct_client = httpx.Client(trust_env=False)
            # print(settings.OPENAI_API_KEY)
            # client = openai.OpenAI(
            #     api_key=settings.OPENAI_API_KEY,
            #     base_url="http://10.73.74.36:20119/v1",
            #     http_client=direct_client
            # )
            print("------------------")

            # Added timestamp to the alerts context so the LLM can trace the chronological flow
            alerts_context = [
                {
                    "ref": sm.alert.alert_ref,
                    "name": sm.alert.name,
                    "component": sm.alert.component_display_name,
                    "severity": sm.alert.severity,
                    "description": sm.alert.description,
                    "monitoring_tool": self._tools_by_id[sm.alert.tool_id].name if sm.alert.tool_id in self._tools_by_id else sm.input_tool_id,
                    "timestamp": sm.alert.first_seen_today.strftime("%H:%M:%S") if sm.alert.first_seen_today else "Unknown"
                }
                for sm in top.signal_matches
            ]

            anchor_info = f"{top.anchor.name} on {top.anchor.component_display_name}" if top.anchor else "Unknown"
            print("-------alert context-----------")
            print(alerts_context)
            
            # 2. Update the prompt to include new rule details and explicit output instructions
            prompt = f"""You are an expert SRE. Synthesize a concise incident summary for an active incident using the provided correlation rule and the chronological alerts.

        Winning Rule: {top.rule.name}
        Rule Plain English: {top.rule.plain_english}
        Rule Trigger When: {top.rule.trigger_when}
        Rule Trigger Target: {top.rule.trigger_target}
        Rule Combine Logic: {top.rule.combine_logic}
        Rule Output Summary: {top.rule.output_summary}

        Anchor Root Cause Alert: {anchor_info}

        Matched Alerts Data (with chronological timestamps and monitoring tools):
        {json.dumps(alerts_context, indent=2)}

        Return ONLY a strict JSON object with no Markdown formatting:
        {{
            "title": "<A high-level executive title summarizing the degradation (max 90 chars)>",
            "root_cause": "<An explanatory phrase describing the exact root cause fault(do not just use a single alert name)>",
            "root_cause_desc": "<A 3-5 sentence technical summary detailing the chronological flow of the error cascading from the initial component to downstream components based on the alert timestamps. Explicitly mention which monitoring tools detected the key failures.>"
        }}
        """
            print("---------------llm call occurred-------------")
            # response = client.chat.completions.create(
            #     model=settings.OPENAI_MODEL,
            #     temperature=0.2,
            #     max_tokens=300, # Increased max_tokens slightly to accommodate the longer cascade description
            #     messages=[
            #         {"role": "system", "content": "You output strict JSON only."},
            #         {"role": "user", "content": prompt}
            #     ]
            # )

            # content = response.choices[0].message.content.strip()
            # if content.startswith("```"):
            #     content = content.split("\n", 1)[1].rsplit("```", 1)[0]
            # content=openai_invoke(prompt) 
            content=gemini_invoke(prompt)
            parsed = json.loads(content)
            
            # 3. Extract all three fields safely
            return {
                "title": parsed.get("title", fallback["title"]),
                "root_cause": parsed.get("root_cause", fallback["root_cause"]),
                "root_cause_desc": parsed.get("root_cause_desc", fallback["root_cause_desc"])
            }

        except Exception as ex:
            print(f"[CORRELATE] LLM summary generation failed, using fallback: {ex}")
            return fallback

    def evaluate_all_rules(self) -> list[RuleMatch]:
        window_minutes = settings.CORRELATION_WINDOW_MINUTES
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=window_minutes)
        self._alerts = self.db.execute(
            select(Alert)
            .where(Alert.is_correlated == False)    # noqa: E712
            .where(Alert.detected_at >= cutoff)
            .order_by(Alert.detected_at)
        ).scalars().all()
        print(f"[CORRELATE] Fetched {len(self._alerts)} uncorrelated alerts from last {window_minutes} min (cutoff={cutoff.isoformat()})")

        rules = self.db.execute(
            select(CorrelationRule).order_by(CorrelationRule.confidence_score.desc())
        ).scalars().all()

        all_inputs = self.db.execute(
            select(RuleCombineInput).order_by(
                RuleCombineInput.rule_id, RuleCombineInput.display_order
            )
        ).scalars().all()
        for ri in all_inputs:
            self._inputs_by_rule.setdefault(ri.rule_id, []).append(ri)

        results: list[RuleMatch] = []
        for rule in rules:
            r = self._evaluate_rule(rule)
            if r is not None:
                results.append(r)
        results.sort(key=lambda r: -r.runtime_confidence)
        return results

    def run(self, incident_id: str, write_to_db: bool = False) -> CorrelationRun:
        started = datetime.now(timezone.utc)
        matches = self.evaluate_all_rules()
        valid = [m for m in matches if m.is_valid()]

        # Resolve 'latest' → generate a fresh INC-{timestamp} ID
        resolved_id = incident_id
        is_new = False
        if incident_id.lower() == "latest":
            resolved_id = f"INC-{started.strftime('%Y%m%d%H%M%S')}"
            is_new = True
            print(f"[CORRELATE] incident_id='latest' → generated new ID: {resolved_id}")

        run = CorrelationRun(
            started_at=started,
            alerts_scanned=len(self._alerts),
            rules_evaluated=len(matches),
            matches=matches,
        )
        if write_to_db and valid:
            top = valid[0]
            self._write_incident(resolved_id, top, valid, skip_delete=is_new)
            run.incident_id = resolved_id
            run.written_to_db = True
        return run

    def _evaluate_rule(self, rule: CorrelationRule) -> Optional[RuleMatch]:
        trace: list[str] = []
        inputs = self._inputs_by_rule.get(rule.rule_id, [])
        total_inputs = len(inputs)

        time_window = self._parse_time_window(rule.combine_logic)
        trace.append(f"Parsed time window: {time_window}s from combine_logic")

        required_chain = self._parse_topology_chain(rule.combine_logic)
        if required_chain:
            trace.append(f"Parsed required topology chain: {' -> '.join(required_chain)}")

        anchors = self._find_anchors(rule)
        if not anchors:
            trace.append(f"No anchor alert matched trigger_when={rule.trigger_when!r}")
            return RuleMatch(
                rule=rule, anchor=None, signal_matches=[], matched_input_indices=set(),
                time_window_seconds=time_window, required_chain=required_chain,
                time_window_ok=False, topology_chain_ok=False,
                match_ratio=0.0, runtime_confidence=0.0, trace=trace,
            )
        anchor = anchors[0]
        trace.append(f"Anchor alert: {anchor.alert_ref} ({anchor.name}) at {anchor.first_seen_today}")

        anchor_ts = anchor.detected_at
        in_window = [
            a for a in self._alerts
            if abs((a.detected_at - anchor_ts).total_seconds()) <= time_window
        ]
        trace.append(f"{len(in_window)} alerts within +/- {time_window}s of anchor")

        signal_matches: list[SignalMatch] = []
        matched_input_indices: set[int] = set()
        for idx, ri in enumerate(inputs):
            matches_for_input = [
                a for a in in_window
                if self._matches_input(a, ri.tool_id, ri.signal_pattern)
            ]
            if matches_for_input:
                matched_input_indices.add(idx)
                for a in matches_for_input:
                    signal_matches.append(SignalMatch(
                        input_index=idx, input_tool_id=ri.tool_id,
                        input_signal=ri.signal_pattern, alert=a,
                    ))
                trace.append(
                    f"  [{ri.tool_id}] {ri.signal_pattern!r} matched "
                    f"{[m.alert.alert_ref for m in signal_matches if m.input_index == idx]}"
                )
            else:
                trace.append(f"  [{ri.tool_id}] {ri.signal_pattern!r} no match")

        time_window_ok = len(matched_input_indices) > 0
        topology_chain_ok = True
        if required_chain:
            tiers_seen = {sm.alert.tier_id for sm in signal_matches}
            missing = [t for t in required_chain if t not in tiers_seen]
            topology_chain_ok = not missing
            if missing:
                trace.append(f"Topology chain FAIL: missing tiers {missing} (seen {sorted(tiers_seen)})")
            else:
                trace.append(f"Topology chain OK: {sorted(tiers_seen)} covers {required_chain}")

        match_ratio = (len(matched_input_indices) / total_inputs) if total_inputs else 0.0
        base_conf = float(rule.confidence_score)
        runtime_confidence = base_conf * match_ratio
        if required_chain and not topology_chain_ok:
            runtime_confidence *= 0.5
        trace.append(
            f"Score: base={base_conf:.2f} * match_ratio={match_ratio:.2f} = {runtime_confidence:.3f}"
        )

        return RuleMatch(
            rule=rule, anchor=anchor, signal_matches=signal_matches,
            matched_input_indices=matched_input_indices,
            time_window_seconds=time_window, required_chain=required_chain,
            time_window_ok=time_window_ok, topology_chain_ok=topology_chain_ok,
            match_ratio=match_ratio, runtime_confidence=runtime_confidence,
            trace=trace,
        )

    def _parse_time_window(self, combine_logic: str) -> int:
        if not combine_logic:
            return 300
        m = re.search(r"within\s+(\d+)\s*s\b", combine_logic, re.IGNORECASE)
        return int(m.group(1)) if m else 300

    def _parse_topology_chain(self, combine_logic: str) -> list[str]:
        if not combine_logic:
            return []
        m = re.search(r"\((.+?(?:->|\u2192).+?)\)", combine_logic)
        if not m:
            return []
        chain = re.split(r"\s*(?:->|\u2192)\s*", m.group(1))
        out = []
        for name in chain:
            key = name.strip().lower()
            out.append(_TIER_NAME_TO_ID.get(key, key))
        return out

    def _find_anchors(self, rule: CorrelationRule) -> list[Alert]:
        trigger = rule.trigger_when or ""
        parts = re.split(r"\s+OR\s+", trigger)
        anchors: list[Alert] = []
        for part in parts:
            tokens = _ANCHOR_SEPARATORS.split(part.strip(), maxsplit=1)
            if len(tokens) < 2:
                continue
            tool_hint = tokens[0].strip().lower()
            sig_hint  = tokens[1].strip().lower()
            for a in self._alerts:
                tool = self._tools_by_id.get(a.tool_id)
                tool_name = tool.name.lower() if tool else ""
                if tool_hint and tool_hint not in tool_name:
                    continue
                if sig_hint and sig_hint not in a.name.lower():
                    continue
                anchors.append(a)
        return anchors

    def _matches_input(self, alert: Alert, tool_id: str, signal_pattern: str) -> bool:
        if alert.tool_id != tool_id:
            return False
        candidates = [s.strip().lower() for s in signal_pattern.split("/") if s.strip()]
        alert_name = alert.name.lower()
        return any(sig in alert_name for sig in candidates)

    def _assign_roles(self, top: RuleMatch, others: list[RuleMatch]) -> dict[str, str]:
        roles: dict[str, str] = {}
        if top.anchor:
            roles[top.anchor.alert_ref] = "root_cause"
        for sm in top.signal_matches:
            if sm.alert.alert_ref in roles:
                continue
            if sm.alert.tier_id == "pres":
                roles[sm.alert.alert_ref] = "symptom"
            elif top.anchor and sm.alert.tier_id == top.anchor.tier_id:
                roles[sm.alert.alert_ref] = "contributing"
            else:
                roles[sm.alert.alert_ref] = "downstream"
        for other in others:
            if other.rule.rule_id == top.rule.rule_id:
                continue
            if not other.is_valid():
                continue
            for sm in other.signal_matches:
                if sm.alert.alert_ref not in roles:
                    roles[sm.alert.alert_ref] = "contributing"
        return roles

    def _write_incident(self, incident_id: str, top: RuleMatch, all_valid: list[RuleMatch], skip_delete: bool = False) -> None:
        print(f"\n{'='*60}")
        print(f"[CORRELATE] Writing incident: {incident_id}")
        print(f"{'='*60}")

        if skip_delete:
            print(f"[CORRELATE] New generated ID — skipping delete.")
        else:
            existing = self.db.get(Incident, incident_id)
            if existing:
                print(f"[CORRELATE] Existing incident {incident_id} found — deleting (CASCADE)...")
                self.db.delete(existing)
                self.db.flush()
                print(f"[CORRELATE] Old incident deleted.")
            else:
                print(f"[CORRELATE] No existing incident — creating fresh.")

        root_component_id = top.anchor.component_id if top.anchor else None
        tools_contributing = len({sm.alert.tool_id for sm in top.signal_matches})

        print(f"[CORRELATE] Winning rule: {top.rule.rule_id} ({top.rule.name})")
        print(f"[CORRELATE] Root cause component: {root_component_id}")
        print(f"[CORRELATE] Alerts grouped: {len(top.alert_refs)}")
        print(f"[CORRELATE] Tools contributing: {tools_contributing}")
        print(f"[CORRELATE] Confidence: {round(top.runtime_confidence * 100, 2)}%")

        llm_summary = self._generate_llm_incident_summary(top)

#        Instantiate the Incident with all three dynamic fields
        incident = Incident(
            incident_id=incident_id,
            title=llm_summary["title"],
            root_cause=llm_summary["root_cause"],             # <--- Inserted here
            root_cause_desc=llm_summary["root_cause_desc"],
            root_cause_component_id=root_component_id,
            raw_alerts_grouped=len(top.alert_refs),
            tools_contributing=tools_contributing,
            correlation_confidence_pct=round(top.runtime_confidence * 100, 2),
            frustrated_user_count=0,
            detected_at=datetime.now(timezone.utc),
            status="open",
        )
        self.db.add(incident)
        self.db.flush()
        print(f"[CORRELATE] ✓ Incident {incident_id} inserted into DB.")

        roles = self._assign_roles(top, all_valid)
        print(f"\n[CORRELATE] Assigning roles to {len(roles)} alerts:")
        for alert_ref, role in roles.items():
            print(f"  → {alert_ref:12s} = {role}")
            self.db.add(IncidentAlert(
                incident_id=incident_id, alert_ref=alert_ref, role=role,
            ))
        print(f"[CORRELATE] ✓ {len(roles)} incident_alerts rows inserted.")

        print(f"\n[CORRELATE] Logging rule firings for {len(all_valid)} valid matches...")
        for match in all_valid:
            firing = RuleFiring(
                rule_id=match.rule.rule_id, incident_id=incident_id,
                fired_at=datetime.now(timezone.utc),
            )
            self.db.add(firing)
            self.db.flush()
            print(f"  → Rule {match.rule.rule_id} fired (firing_id={firing.firing_id}), evidence: {match.alert_refs}")
            for ref in match.alert_refs:
                self.db.add(RuleFiringAlert(firing_id=firing.firing_id, alert_ref=ref))

        # --- Progressive intersection: resolve affected sub-journeys ---
        print(f"\n[CORRELATE] Starting progressive intersection for sub-journey resolution...")
        affected_sjs = self._resolve_affected_sub_journeys(roles)
        if affected_sjs:
            print(f"[CORRELATE] ✓ Resolved {len(affected_sjs)} affected sub-journey(s): {affected_sjs}")
            for sj_id in affected_sjs:
                self.db.add(IncidentSubJourney(
                    incident_id=incident_id, sub_journey_id=sj_id,
                ))
            print(f"[CORRELATE] ✓ {len(affected_sjs)} incident_sub_journeys rows inserted.")
        else:
            print(f"[CORRELATE] ⚠ No sub-journeys resolved (components not mapped to any sub-journey).")

        # --- Topology snapshot: populate incident_topology_state + incident_critical_edges ---
        self._write_topology_snapshot(incident_id, roles, affected_sjs)

        self.db.commit()
        print(f"\n[CORRELATE] ✓ Transaction committed. Incident {incident_id} is live!")
        print(f"{'='*60}\n")

    # ---- Only root_cause + downstream participate in sub-journey resolution ----
    _SJ_ELIGIBLE_ROLES = {"root_cause", "downstream"}

    def _resolve_affected_sub_journeys(self, roles: dict[str, str]) -> list[str]:
        """Superset-check sub-journey resolution.

        1. From the anchor (root_cause) alert, find its component and look up
           all sub-journeys containing that component → candidate list.
        2. Collect all unique component_ids from root_cause + downstream alerts
           → required_components.
        3. For each candidate sub-journey, check if it contains ALL of the
           required_components.  Only those sub-journeys pass.
        """
        alert_map = {a.alert_ref: a for a in self._alerts}

        # Step 1: Find anchor alert (root_cause) and get candidate sub-journeys
        anchor_ref = None
        for ref, role in roles.items():
            if role == "root_cause":
                anchor_ref = ref
                break

        if anchor_ref is None or anchor_ref not in alert_map:
            print(f"  ⚠ No root_cause alert found — cannot resolve sub-journeys.")
            return []

        anchor_alert = alert_map[anchor_ref]
        print(f"  Step 1: Anchor alert {anchor_ref} → component={anchor_alert.component_id}")

        candidate_sj_rows = self.db.execute(
            select(SubJourneyComponent.sub_journey_id)
            .where(SubJourneyComponent.component_id == anchor_alert.component_id)
        ).scalars().all()
        candidate_sjs = set(candidate_sj_rows)

        if not candidate_sjs:
            print(f"  ⚠ Anchor component '{anchor_alert.component_id}' not mapped to any sub-journey.")
            return []

        print(f"  Step 1 result: {len(candidate_sjs)} candidate sub-journey(s): {sorted(candidate_sjs)}")

        # Step 2: Collect all components from root_cause + downstream alerts
        required_components = set()
        eligible_refs = [(ref, role) for ref, role in roles.items() if role in self._SJ_ELIGIBLE_ROLES]
        print(f"\n  Step 2: Collecting components from {len(eligible_refs)} eligible alerts (root_cause + downstream):")
        for ref, role in eligible_refs:
            alert = alert_map.get(ref)
            if alert:
                required_components.add(alert.component_id)
                print(f"    {ref:12s} [role={role}] → component={alert.component_id}")
        print(f"  Required components: {sorted(required_components)}")

        # Step 3: For each candidate sub-journey, check if it contains ALL required components
        print(f"\n  Step 3: Checking which candidate sub-journeys contain ALL required components:")
        matched_sjs = []
        for sj_id in sorted(candidate_sjs):
            sj_components = set(self.db.execute(
                select(SubJourneyComponent.component_id)
                .where(SubJourneyComponent.sub_journey_id == sj_id)
            ).scalars().all())

            missing = required_components - sj_components
            if not missing:
                print(f"    ✓ {sj_id} — contains ALL required components ({sorted(sj_components)})")
                matched_sjs.append(sj_id)
            else:
                print(f"    ✗ {sj_id} — missing components: {sorted(missing)}")

        return matched_sjs

    def _write_topology_snapshot(
        self, incident_id: str, roles: dict[str, str], affected_sjs: list[str],
    ) -> None:
        """Populate incident_topology_state and incident_critical_edges.

        1. Fetch all components from the affected sub-journeys.
        2. Map alert roles to component levels:
           - root_cause / downstream alert components → 'crit'
           - contributing alert components            → 'deg'
           - remaining sub-journey components         → 'ok'
        3. Set is_rc_at_time = True for the root_cause alert's component.
        4. For incident_critical_edges: find all existing dependency edges
           where BOTH endpoints are 'crit' level components.
        """
        if not affected_sjs:
            print(f"\n[TOPOLOGY] ⚠ No affected sub-journeys — skipping topology snapshot.")
            return

        alert_map = {a.alert_ref: a for a in self._alerts}

        print(f"\n[TOPOLOGY] Building topology snapshot for incident {incident_id}...")

        # Step 1: Collect all components from affected sub-journeys
        sj_component_ids: set[str] = set()
        for sj_id in affected_sjs:
            rows = self.db.execute(
                select(SubJourneyComponent.component_id)
                .where(SubJourneyComponent.sub_journey_id == sj_id)
            ).scalars().all()
            sj_component_ids.update(rows)
        print(f"[TOPOLOGY] Components from affected sub-journey(s): {sorted(sj_component_ids)}")

        # Step 2: Determine component levels from alert roles
        root_cause_components: set[str] = set()
        crit_components: set[str] = set()
        deg_components: set[str] = set()

        for ref, role in roles.items():
            alert = alert_map.get(ref)
            if alert is None:
                continue
            if role in ("root_cause", "downstream"):
                crit_components.add(alert.component_id)
                if role == "root_cause":
                    root_cause_components.add(alert.component_id)
            elif role == "contributing":
                deg_components.add(alert.component_id)

        # Don't let deg override crit
        deg_components -= crit_components

        print(f"[TOPOLOGY] Component levels:")
        print(f"  crit (root_cause + downstream): {sorted(crit_components)}")
        print(f"  deg  (contributing):             {sorted(deg_components)}")
        print(f"  ok   (remaining):                {sorted(sj_component_ids - crit_components - deg_components)}")
        print(f"  is_rc_at_time:                   {sorted(root_cause_components)}")

        # Step 3: Insert incident_topology_state rows
        inserted_count = 0
        for comp_id in sorted(sj_component_ids):
            if comp_id in crit_components:
                level = "crit"
            elif comp_id in deg_components:
                level = "deg"
            else:
                level = "ok"
            is_rc = comp_id in root_cause_components

            self.db.add(IncidentTopologyState(
                incident_id=incident_id,
                component_id=comp_id,
                level_at_time=level,
                is_rc_at_time=is_rc,
            ))
            inserted_count += 1
            flag = " ★ ROOT CAUSE" if is_rc else ""
            print(f"  → {comp_id:12s} = {level}{flag}")

        print(f"[TOPOLOGY] ✓ {inserted_count} incident_topology_state rows inserted.")

        # Step 4: Insert incident_critical_edges
        # Read levels from the incident_topology_state we just populated (source of truth)
        self.db.flush()  # ensure Step 3 rows are visible
        topo_rows = self.db.execute(
            select(IncidentTopologyState)
            .where(IncidentTopologyState.incident_id == incident_id)
        ).scalars().all()
        topo_level_map = {r.component_id: r.level_at_time for r in topo_rows}
        crit_from_topo = {cid for cid, lvl in topo_level_map.items() if lvl == "crit"}

        all_edges = self.db.execute(
            select(ComponentDependency)
        ).scalars().all()

        edge_count = 0
        print(f"\n[TOPOLOGY] Checking component_dependencies for critical edges (both endpoints crit in incident_topology_state):")
        for edge in all_edges:
            from_lvl = topo_level_map.get(edge.from_component)
            to_lvl = topo_level_map.get(edge.to_component)
            if from_lvl == "crit" and to_lvl == "crit":
                self.db.add(IncidentCriticalEdge(
                    incident_id=incident_id,
                    from_component=edge.from_component,
                    to_component=edge.to_component,
                ))
                edge_count += 1
                print(f"  → {edge.from_component} → {edge.to_component}  ✓ CRIT EDGE")
            elif from_lvl is not None and to_lvl is not None:
                print(f"  → {edge.from_component} ({from_lvl}) → {edge.to_component} ({to_lvl})  (normal)")

        print(f"[TOPOLOGY] ✓ {edge_count} incident_critical_edges rows inserted.")

