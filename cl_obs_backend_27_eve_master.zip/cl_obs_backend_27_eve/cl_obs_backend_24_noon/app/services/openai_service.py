"""OpenAI-backed dynamic tier-summary generation.

Regenerates the per-tier summary blurb from the LIVE alert set for a given incident.
Falls back to the stored TierIncidentSummary text when OPENAI_ENABLED=false or the
API call fails — so the UI never breaks because of an AI outage.
"""
import json
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.reference import Tier, MonitoringTool
from app.models.alerts import Alert
from app.models.incidents import IncidentAlert, TierIncidentSummary


class OpenAIService:

    @staticmethod
    def generate_tier_summary(db: Session, incident_id: str, tier_id: str) -> dict:
        tier = db.get(Tier, tier_id)
        if tier is None:
            raise ValueError(f"Unknown tier {tier_id}")

        fallback = db.execute(
            select(TierIncidentSummary).where(
                TierIncidentSummary.incident_id == incident_id,
                TierIncidentSummary.tier_id == tier_id,
            )
        ).scalar_one_or_none()
        fallback_text = fallback.summary_text if fallback else ""

        if not settings.OPENAI_ENABLED or not settings.OPENAI_API_KEY:
            return {
                "tier_id":      tier_id,
                "incident_id":  incident_id,
                "summary":      fallback_text,
                "generated_by": "db-fallback",
                "model":        None,
            }

        rows = db.execute(
            select(Alert, MonitoringTool)
            .join(IncidentAlert, IncidentAlert.alert_ref == Alert.alert_ref)
            .join(MonitoringTool, MonitoringTool.tool_id == Alert.tool_id)
            .where(IncidentAlert.incident_id == incident_id, Alert.tier_id == tier_id)
            .order_by(Alert.detected_at)
        ).all()

        alerts_ctx = [
            {
                "ref":       a.alert_ref,
                "name":      a.name,
                "severity":  a.severity,
                "tool":      t.name,
                "component": a.component_display_name,
                "time":      a.first_seen_today.strftime("%H:%M:%S"),
                "desc":      a.description,
            }
            for a, t in rows
        ]

        try:
            from openai import OpenAI
            client = OpenAI(api_key=settings.OPENAI_API_KEY,base_url="http://10.73.74.36:20119/v1")

            prompt = (
                f"You are an SRE writing a ONE-sentence status blurb for the "
                f"{tier.name} tier of an active incident. Rules:\n"
                f" - Max 22 words.\n"
                f" - No bullet points, no fluff, no adjectives without a number.\n"
                f" - Mention root-cause chain if evident.\n"
                f" - If this tier is the root cause, say so first.\n\n"
                f"Alerts on this tier for incident {incident_id}:\n"
                f"{json.dumps(alerts_ctx, indent=2)}"
            )

            resp = client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                temperature=0.2,
                max_tokens=120,
                messages=[
                    {"role": "system",
                     "content": "You write terse, factual observability summaries for SREs."},
                    {"role": "user", "content": prompt},
                ],
            )
            summary = resp.choices[0].message.content.strip().strip('"')
            print("--------------summary-----------------")
            print(summary)
            return {
                "tier_id":      tier_id,
                "incident_id":  incident_id,
                "summary":      summary,
                "generated_by": "openai",
                "model":        settings.OPENAI_MODEL,
            }
        except Exception as e:
            print("Exception occured--",str(e))
            return {
                "tier_id":      tier_id,
                "incident_id":  incident_id,
                "summary":      fallback_text,
                "generated_by": "db-fallback",
                "model":        None,
            }
