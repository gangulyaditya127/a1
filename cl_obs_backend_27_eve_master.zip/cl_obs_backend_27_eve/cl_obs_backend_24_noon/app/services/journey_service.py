"""Journey + sub-journey read logic.

Returns shapes byte-identical to /public/data/journeys.json and subJourneys.json.
Reads the LATEST snapshot per journey/sub-journey from time-series metric tables.
"""
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.reference import Journey, SubJourney
from app.models.metrics import JourneyMetric, SubJourneyMetric


class JourneyService:

    @staticmethod
    def list_journeys(db: Session) -> list[dict]:
        latest_ts = (
            select(
                JourneyMetric.journey_id,
                func.max(JourneyMetric.snapshot_at).label("max_ts")
            )
            .group_by(JourneyMetric.journey_id)
            .subquery()
        )
        stmt = (
            select(Journey, JourneyMetric)
            .join(latest_ts, latest_ts.c.journey_id == Journey.journey_id)
            .join(
                JourneyMetric,
                (JourneyMetric.journey_id == Journey.journey_id) &
                (JourneyMetric.snapshot_at == latest_ts.c.max_ts)
            )
            .order_by(Journey.display_order)
        )
        rows = db.execute(stmt).all()

        return [
            {
                "id":         j.journey_id,
                "name":       j.name,
                "users":      m.active_users,
                "happy":      m.happy_pct,
                "unhappy":    m.unhappy_pct,
                "frustrated": m.frustrated_pct,
                "avail":      float(m.availability_pct),
                "alerts":     m.open_alerts,
            }
            for j, m in rows
        ]

    @staticmethod

    def get_sub_journeys(db: Session, journey_id: str = None) -> dict[str, dict]:

        latest_ts = (

            select(

                SubJourneyMetric.sub_journey_id,

                func.max(SubJourneyMetric.snapshot_at).label("max_ts")

            )

            .group_by(SubJourneyMetric.sub_journey_id)

            .subquery()

        )

 

        stmt = (

            select(Journey, SubJourney, SubJourneyMetric)

            .join(SubJourney, SubJourney.journey_id == Journey.journey_id)

            .join(latest_ts, latest_ts.c.sub_journey_id == SubJourney.sub_journey_id)

            .join(

                SubJourneyMetric,

                (SubJourneyMetric.sub_journey_id == SubJourney.sub_journey_id) &

                (SubJourneyMetric.snapshot_at == latest_ts.c.max_ts)

            )

        )

 

        # Apply the filter if a journey_id is provided

        if journey_id:

            stmt = stmt.where(Journey.journey_id == journey_id)

 

        stmt = stmt.order_by(Journey.display_order, SubJourney.display_order)

        

        rows = db.execute(stmt).all()

        # ... (rest of the mapping logic remains unchanged)

        out: dict[str, dict] = {}
        for j, s, m in rows:
            bucket = out.setdefault(j.journey_id, {"title": j.name, "steps": []})
            hu = None
            if m.happy_pct is not None:
                hu = [m.happy_pct, m.unhappy_pct, m.frustrated_pct]
            bucket["steps"].append({
                "id":       s.sub_journey_id,
                "name":     s.name,
                "api":      s.api_label,
                "hu":       hu,
                "avg":      m.avg_response_ms,
                "p95":      m.p95_ms,
                "err":      float(m.error_rate_pct),
                "avail":    float(m.availability_pct),
                "critical": m.is_critical,
            })
        return out
