from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.rule_service import RuleService

router = APIRouter()

DEFAULT_INCIDENT = "INC0048291"


@router.get("/rules")
def list_rules(
    incident_id: str = Query(default=DEFAULT_INCIDENT, alias="incident"),
    db: Session = Depends(get_db),
):
    try:
        data = RuleService.list_rules_for_incident(db, incident_id)
        return {"success": True, "count": len(data), "data": data}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
