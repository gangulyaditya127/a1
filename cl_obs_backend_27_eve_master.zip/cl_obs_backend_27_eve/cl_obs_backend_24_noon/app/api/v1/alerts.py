from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.alert_service import AlertService

router = APIRouter()


@router.get("/alerts")
def list_alerts(db: Session = Depends(get_db)):
    try:
        data = AlertService.get_all_map(db)
        return {"success": True, "count": len(data), "data": data}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/alerts/{alert_ref}")
def get_alert(alert_ref: str, db: Session = Depends(get_db)):
    try:
        data = AlertService.get_by_ref(db, alert_ref)
        if data is None:
            raise HTTPException(status_code=404, detail=f"Alert {alert_ref} not found")
        return {"success": True, "data": data}
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
