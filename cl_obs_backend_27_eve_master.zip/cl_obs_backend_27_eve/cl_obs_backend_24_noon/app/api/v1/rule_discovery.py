"""AI Rule Discovery endpoints - REAL working version.

    GET  /rule-discovery/ci-coverage                       - flat CI list
    GET  /rule-discovery/journey-hierarchy                 - journey tree
    GET  /rule-discovery/sub-journeys/{id}/topology        - graph for one sub-journey
    GET  /rule-discovery/patterns[?status=new|used]
    POST /rule-discovery/patterns/mine                     - RUN THE MINER
    POST /rule-discovery/patterns/{pattern_id}/synthesize
    GET  /rule-discovery/proposals[?status=pending|approved|...]
    GET  /rule-discovery/proposals/{proposal_id}
    POST /rule-discovery/proposals/{proposal_id}/tune
    POST /rule-discovery/proposals/{proposal_id}/approve
    POST /rule-discovery/proposals/{proposal_id}/reject
    POST /rule-discovery/proposals/{proposal_id}/deploy
"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Body, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.cmdb_service import CmdbService
from app.services.pattern_mining_service import PatternMiningService
from app.services.rule_synthesizer_service import RuleSynthesizerService
from app.services.proposal_service import ProposalService

router = APIRouter(prefix="/rule-discovery", tags=["rule-discovery"])


@router.get("/ci-coverage")
def ci_coverage(db: Session = Depends(get_db)):
    try:
        return {"success": True, "data": CmdbService.list_ci_coverage(db)}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/journey-hierarchy")
def journey_hierarchy(db: Session = Depends(get_db)):
    try:
        return {"success": True, "data": CmdbService.list_journey_hierarchy(db)}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/sub-journeys/{sub_journey_id}/topology")
def sub_journey_topology(sub_journey_id: str, db: Session = Depends(get_db)):
    try:
        return {"success": True, "data": CmdbService.get_sub_journey_topology(db, sub_journey_id)}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/patterns")
def list_patterns(status: Optional[str] = None, db: Session = Depends(get_db)):
    try:
        data = PatternMiningService.list_patterns(db, status=status)
        return {"success": True, "count": len(data), "data": data}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/patterns/mine")
def mine_patterns(
    days: int = Query(30, ge=1, le=180),
    time_window_seconds: int = Query(180, ge=10, le=3600),
    db: Session = Depends(get_db),
):
    """Run the miner over alerts of the last `days` days."""
    try:
        result = PatternMiningService.mine(db, days=days, time_window_seconds=time_window_seconds)
        return {"success": True, "data": result}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/patterns/{pattern_id}/synthesize")
def synthesize(pattern_id: str, db: Session = Depends(get_db)):
    try:
        return {"success": True, "data": RuleSynthesizerService.synthesize_from_pattern(db, pattern_id)}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/proposals")
def list_proposals(status: Optional[str] = None, db: Session = Depends(get_db)):
    try:
        data = ProposalService.list_proposals(db, status=status)
        return {"success": True, "count": len(data), "data": data}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/proposals/{proposal_id}")
def get_proposal(proposal_id: str, db: Session = Depends(get_db)):
    try:
        data = ProposalService.get(db, proposal_id)
        if data is None:
            raise HTTPException(status_code=404, detail=f"Unknown proposal {proposal_id}")
        return {"success": True, "data": data}
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/proposals/{proposal_id}/tune")
def tune(proposal_id: str, payload: dict = Body(...), db: Session = Depends(get_db)):
    try:
        data = ProposalService.tune(
            db, proposal_id,
            fields=payload.get("fields", {}),
            reviewer_id=payload.get("reviewer_id", "sre-1"),
            comment=payload.get("comment"),
        )
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=400, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/proposals/{proposal_id}/approve")
def approve(proposal_id: str, payload: dict = Body(default={}), db: Session = Depends(get_db)):
    try:
        data = ProposalService.approve(
            db, proposal_id,
            reviewer_id=payload.get("reviewer_id", "sre-1"),
            comment=payload.get("comment"),
        )
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=400, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/proposals/{proposal_id}/reject")
def reject(proposal_id: str, payload: dict = Body(default={}), db: Session = Depends(get_db)):
    try:
        data = ProposalService.reject(
            db, proposal_id,
            reviewer_id=payload.get("reviewer_id", "sre-1"),
            comment=payload.get("comment"),
        )
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=400, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/proposals/{proposal_id}/deploy")
def deploy(proposal_id: str, payload: dict = Body(default={}), db: Session = Depends(get_db)):
    try:
        data = ProposalService.deploy(db, proposal_id, reviewer_id=payload.get("reviewer_id", "sre-1"))
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=400, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
