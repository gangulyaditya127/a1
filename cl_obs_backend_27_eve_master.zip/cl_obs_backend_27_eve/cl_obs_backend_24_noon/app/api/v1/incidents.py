# """GET /api/v1/incidents/{incident_id} — incident metadata for the exec card.

# Registered in app/main.py with:
#     from app.api.v1.incidents import router as incidents_router
#     app.include_router(incidents_router, prefix="/api/v1")
# """
# from fastapi import APIRouter, Depends, HTTPException
# from sqlalchemy.orm import Session

# from app.core.database import get_db
# from app.services.incident_service import IncidentService

# router = APIRouter()


# @router.get("/incidents/{incident_id}")
# def get_incident(incident_id: str, db: Session = Depends(get_db)):
#     """Return the incident row + resolved journey/sub-journey/component names + latest metrics."""
#     try:
#         data = IncidentService.get_by_id(db, incident_id)
#         if data is None:
#             raise HTTPException(status_code=404, detail=f"Incident {incident_id} not found")
#         return {"success": True, "data": data}
#     except HTTPException:
#         raise
#     except Exception as ex:
#         raise HTTPException(status_code=500, detail=str(ex))
