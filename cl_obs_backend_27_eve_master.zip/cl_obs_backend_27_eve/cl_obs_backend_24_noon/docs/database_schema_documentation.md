# ARE Observability Platform — Database Schema Documentation

This document outlines the purpose, utility, and column definitions for all 19 database tables in the ARE Observability Platform. The tables are logically grouped by their domains.

---

## 1. Reference & Architecture Domain
These tables define the static infrastructure, architectural tiers, and business customer journeys.

### `tiers`
**Purpose**: Defines the high-level architectural layers (e.g., Presentation, Application, Integration, Data, Infrastructure).
- `tier_id` (String): Unique identifier (e.g., 'pres', 'app').
- `name` (String): Display name (e.g., 'Presentation').
- `display_order` (Integer): Order for UI rendering.
- `icon` (String): Emoji or icon identifier.
- `level` (String): Current overall health status ('ok', 'deg', 'crit').

### `monitoring_tools`
**Purpose**: Defines the source observability tools that emit alerts (e.g., Dynatrace, Splunk, Datadog).
- `tool_id` (String): Unique identifier.
- `name` (String): Full display name.
- `short_name` (String): Compact name for UI badges.
- `color_hex` (String): UI color code for visual distinction.

### `components`
**Purpose**: Represents Configuration Items (CIs) such as databases, microservices, and gateways.
- `component_id` (String): Unique identifier.
- `name` (String): Display name.
- `sub_label` (String): Subtitle for extra context (e.g., 'Oracle RAC 19c').
- `tier_id` (String): Foreign key linking the component to its architectural tier.
- `layout_row`, `display_order` (Integer): Positioning data for the correlation diagram.
- `level` (String): Current health status.
- `is_rc` (Boolean): Flag indicating if this component is currently a root cause of an incident.

### `component_dependencies`
**Purpose**: Defines the topology graph (edges) showing how components rely on each other.
- `dep_id` (Integer): Primary key.
- `from_component` (String): Source component ID.
- `to_component` (String): Target (downstream) component ID.
- `is_critical` (Boolean): Indicates if this is a hard dependency.
- `display_order` (Integer): Edge rendering order.

### `journeys`
**Purpose**: Defines top-level business customer journeys (e.g., 'Group Benefits Enrollment').
- `journey_id` (String): Unique identifier.
- `name` (String): Display name.
- `segment` (String): Market segment (e.g., 'individual', 'wealth').
- `display_order` (Integer): UI ordering.

### `sub_journeys`
**Purpose**: Defines the specific step-by-step phases within a Journey (e.g., 'Upload Receipts').
- `sub_journey_id` (String): Unique identifier.
- `journey_id` (String): The parent journey it belongs to.
- `name` (String): Display name.
- `api_label` (String): Technical label for API linking.
- `display_order` (Integer): Chronological order in the journey flow.

### `sub_journey_components`
**Purpose**: Junction table that links a specific sub-journey to the infrastructure components that power it.
- `sub_journey_id` (String): Foreign key to the sub-journey.
- `component_id` (String): Foreign key to the component.
- `role` (String): The role the component plays ('primary', 'downstream', 'observability').

---

## 2. Alerting & Metrics Domain
These tables store raw incoming alerts and time-series telemetry data.

### `alerts`
**Purpose**: Stores individual monitoring alerts ingested from third-party tools.
- `alert_ref` (String): Primary key / external alert ID.
- `name` (String): Name of the alert (e.g., 'ThreadPoolExhaustion').
- `description` (Text): Detailed error message.
- `severity` (String): Severity level ('crit', 'high', 'medium', 'low').
- `tier_id`, `tool_id`, `component_id` (String): Foreign keys mapping the alert to architecture.
- `detected_at` (DateTime): When the system received the alert.
- `first_seen_today` (Time): When the alert first triggered.
- `occurrences_7d`, `occurrences_30d` (Integer): Historical frequency counters.

### `alert_metrics`
**Purpose**: Stores flexible key/value telemetry data associated with a specific alert (e.g., CPU=99%).
- `id` (Integer): Primary key.
- `alert_ref` (String): Link to parent alert.
- `metric_key` (String): The metric name (e.g., 'Response Time').
- `metric_value` (String): The metric value (e.g., '6200 ms').
- `display_order` (Integer): UI ordering.

### `journey_metrics` & `sub_journey_metrics`
**Purpose**: Time-series tables storing User Experience (UX) and performance metrics (Happy/Frustrated percentages, latency, availability).
- Features common metrics like `happy_pct`, `frustrated_pct`, `availability_pct`, and `snapshot_at` (timestamp for the time-series). `sub_journey_metrics` also includes `avg_response_ms`, `p95_ms`, and `error_rate_pct`.

---

## 3. Correlation & Incidents Domain
These tables power the Correlation Engine, grouping raw alerts into consolidated incidents.

### `correlation_rules`
**Purpose**: Defines AIOps rules that dictate how alerts should be grouped.
- `rule_id` (String): Unique identifier.
- `name`, `plain_english` (String/Text): Human-readable descriptions.
- `confidence_score` (Float): Base confidence that this rule is accurate (0.0 to 1.0).
- `trigger_when`, `trigger_target` (String): Anchor conditions to start evaluation.
- `combine_logic` (Text): Rules engine syntax for time windows and topology paths.
- `output_summary` (Text): Summary applied to incidents created by this rule.

### `rule_combine_inputs`
**Purpose**: Lists the exact monitoring signals expected by a `correlation_rule`.
- `rule_id` (String): Link to parent rule.
- `tool_id` (String): Expected monitoring tool.
- `signal_pattern` (String): String pattern to match alert names against.

### `rule_explanations`
**Purpose**: Stores paragraph-by-paragraph justifications explaining *why* a rule exists (used in the UI details view).
- `rule_id`, `paragraph_order`, `text`.

### `incidents`
**Purpose**: Represents a consolidated problem (group of alerts) synthesized by the Correlation Engine.
- `incident_id` (String): Unique identifier.
- `title`, `root_cause_desc` (String/Text): Generated summaries.
- `root_cause_component_id` (String): Points to the CI responsible for the outage.
- `affected_sub_journey_id` (String, nullable): Points to the primary impacted sub-journey (if known).
- `raw_alerts_grouped`, `tools_contributing` (Integer): Impact metrics.
- `correlation_confidence_pct` (Float): Dynamic confidence score calculated at runtime.
- `status` (String): Incident state ('open', 'investigating', 'resolved').

### `incident_alerts`
**Purpose**: Junction table linking raw `alerts` to an `incident`, and assigning them an operational role.
- `incident_id`, `alert_ref` (Strings).
- `role` (String): Defines whether the alert is a 'root_cause', 'symptom', 'contributing', or 'downstream' factor.

### `tier_incident_summary`
**Purpose**: Stores AI-generated (or fallback) textual summaries of how an incident specifically impacted a single architectural tier.
- `incident_id`, `tier_id`.
- `is_root_cause` (Boolean).
- `summary_text` (Text).

### `rule_firings` & `rule_firing_alerts`
**Purpose**: Audit logs recording exactly when a rule fired and which specific alerts triggered it.

---

## 4. AI Rule Discovery Domain
These tables support the Pattern Mining and LLM Rule Synthesizer features.

### `ci_tool_coverage`
**Purpose**: Tracks which CIs are monitored by which tools, establishing baseline coverage.
- `component_id`, `tool_id`, `signal_pattern`, `notes`.

### `discovered_patterns`
**Purpose**: Stores temporal co-firing alert patterns mined from historical data.
- `pattern_id` (String).
- `support_count` (Integer): How many times the pattern occurred.
- `avg_time_delta_s` (Integer): Average time window between alerts.
- `signals_json`, `cis_json`, `tiers_json` (Text): JSON arrays storing the pattern signature.
- `status` (String): 'new', 'used', or 'ignored'.

### `ai_rule_proposals`
**Purpose**: Stores AI-generated (LLM) correlation rules awaiting human SRE approval.
- `proposal_id` (String).
- `source_pattern_id` (String): Links back to the mined pattern.
- `confidence_score`, `expected_precision` (Float): AI-estimated metrics.
- `expected_alert_reduction` (Integer).
- `status` (String): Lifecycle state ('pending', 'approved', 'tuned', 'rejected', 'deployed').
- Contains rule logic definitions similar to `correlation_rules`.

### `rule_review_events`
**Purpose**: Audit log of SRE actions (approve, tune, reject, deploy) taken on AI rule proposals.
- `proposal_id`, `reviewer_id`, `decision`, `comment`, `tuned_json`.

---

## 5. Analytics Domain
These tables store pre-computed aggregates for fast dashboard rendering.

### `tier_historical_stats`
**Purpose**: Weekly/monthly aggregate alert counts and MTTR per tier.
- `tier_id`, `alerts_today`, `alerts_last_7d`, `alerts_last_30d`, `median_mttr_minutes`.

### `tier_top_causes`
**Purpose**: Ranked list of historical failure modes per tier.
- `tier_id`, `rank` (1-10), `cause_name`, `percentage`.
