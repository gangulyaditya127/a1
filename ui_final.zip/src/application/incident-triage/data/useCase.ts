import type { UseCaseDef } from "@/shared/types";

/** Solution definition for this service area. */
export const useCase: UseCaseDef = {
  code: "S1",
  title: "Incident Triage & Resolution",
  tagline: "From alert to resolution with agent-guided triage and comms",
  status: "In discovery",
  lead: "Soumaydeep (TCS)",
  scenario:
    "A priority incident lands. Agents classify and enrich it instantly, retrieve the most relevant knowledge, coordinate across suppliers, guide the engineer through resolution and keep every stakeholder informed — then learn from the outcome.",
  agents: ["Intelligent Triage", "Resolution Recommender", "Comms Orchestrator"],
  journey: [
    { step: "Instant triage", detail: "Classify, prioritize and route the incident with full context attached." },
    { step: "Knowledge retrieval", detail: "Surface the most relevant KBs, past incidents and runbooks." },
    { step: "Cross-supplier coordination", detail: "One thread across TCS, Canada Life and third parties." },
    { step: "Guided resolution", detail: "Step-by-step recommendations with confidence and precedent." },
    { step: "Automated communications", detail: "Stakeholder updates drafted and sent on cadence." },
    { step: "Continuous learning", detail: "Outcomes feed back into triage and recommendation quality." },
  ],
  outcomes: [
    "Faster MTTA / MTTR on P1–P2 incidents",
    "Less analyst effort per ticket",
    "Consistent, auditable resolution steps",
    "SLA compliance protected during surges",
  ],
  plannedModules: [
    { title: "Live triage console", description: "Queue with agent classifications, confidence and routing." },
    { title: "War-room workspace", description: "Single pane for majors: timeline, actions, comms." },
    { title: "Comms composer", description: "Agent-drafted stakeholder updates with approval flow." },
    { title: "Post-incident learning", description: "What the agents learned from each resolution." },
  ],
};
