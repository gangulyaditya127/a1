import { UseCaseScaffold } from "@/shared/usecase/UseCaseScaffold";
import { useCase } from "../data/useCase";

export function IncidentTriageHome() {
  return <UseCaseScaffold useCase={useCase} />;
}
