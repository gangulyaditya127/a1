import { GitBranch, LayoutDashboard, MessageSquare, Siren, Sparkles } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { IncidentTriageHome } from "./pages/HomePage";

export const incidentTriageApp: AppManifest = {
  id: "incident-triage",
  code: "S1",
  name: "Incident Triage & Resolution",
  description:
    "Agent-guided triage, knowledge retrieval, guided resolution and automated stakeholder comms for priority incidents.",
  icon: Siren,
  entry: "/incident-triage",
  status: "preview",
  paths: ["/incident-triage"],
  nav: [
    { label: "Use-case overview", to: "/incident-triage", icon: LayoutDashboard },
    { label: "Triage console", to: "#", icon: Siren, disabled: true, soon: true },
    { label: "War-room workspace", to: "#", icon: GitBranch, disabled: true, soon: true },
    { label: "Comms composer", to: "#", icon: MessageSquare, disabled: true, soon: true },
    { label: "Post-incident learning", to: "#", icon: Sparkles, disabled: true, soon: true },
  ],
  routes: [{ path: "incident-triage", element: <IncidentTriageHome /> }],
};
