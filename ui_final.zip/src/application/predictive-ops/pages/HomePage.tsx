import { UseCaseScaffold } from "@/shared/usecase/UseCaseScaffold";
import { useCase } from "../data/useCase";

export function PredictiveOpsHome() {
  return <UseCaseScaffold useCase={useCase} />;
}
