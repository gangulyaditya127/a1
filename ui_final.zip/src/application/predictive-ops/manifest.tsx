import { Activity, Filter, LayoutDashboard, Radar, ScrollText } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { PredictiveOpsHome } from "./pages/HomePage";

export const predictiveOpsApp: AppManifest = {
  id: "predictive-ops",
  code: "S5",
  name: "Proactive & Predictive Ops",
  description:
    "Event correlation that cuts alert noise, risk forecasting ahead of impact, and approved self-healing runbooks with full audit.",
  icon: Radar,
  entry: "/predictive-ops",
  status: "preview",
  paths: ["/predictive-ops"],
  nav: [
    { label: "Use-case overview", to: "/predictive-ops", icon: LayoutDashboard },
    { label: "Alert noise funnel", to: "#", icon: Filter, disabled: true, soon: true },
    { label: "Risk forecasts", to: "#", icon: Radar, disabled: true, soon: true },
    { label: "Self-healing run log", to: "#", icon: ScrollText, disabled: true, soon: true },
    { label: "Capacity outlook", to: "#", icon: Activity, disabled: true, soon: true },
  ],
  routes: [{ path: "predictive-ops", element: <PredictiveOpsHome /> }],
};
