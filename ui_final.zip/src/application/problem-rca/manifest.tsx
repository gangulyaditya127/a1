import { BookOpen, Layers, LayoutDashboard, Microscope, Wrench } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { ProblemRcaHome } from "./pages/HomePage";

export const problemRcaApp: AppManifest = {
  id: "problem-rca",
  code: "S2",
  name: "Problem & Root Cause",
  description:
    "Pattern detection across incidents, evidence-backed root-cause discovery and permanent-fix tracking to stop the repeats.",
  icon: Microscope,
  entry: "/problem-rca",
  status: "preview",
  paths: ["/problem-rca"],
  nav: [
    { label: "Use-case overview", to: "/problem-rca", icon: LayoutDashboard },
    { label: "Recurrence clusters", to: "#", icon: Layers, disabled: true, soon: true },
    { label: "RCA workbench", to: "#", icon: Microscope, disabled: true, soon: true },
    { label: "Fix tracker", to: "#", icon: Wrench, disabled: true, soon: true },
    { label: "Known-error base", to: "#", icon: BookOpen, disabled: true, soon: true },
  ],
  routes: [{ path: "problem-rca", element: <ProblemRcaHome /> }],
};
