import { UseCaseScaffold } from "@/shared/usecase/UseCaseScaffold";
import { useCase } from "../data/useCase";

export function ProblemRcaHome() {
  return <UseCaseScaffold useCase={useCase} />;
}
