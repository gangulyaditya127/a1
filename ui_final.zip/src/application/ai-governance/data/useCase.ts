import type { UseCaseDef } from "@/shared/types";

/** Solution definition for this service area. */
export const useCase: UseCaseDef = {
  code: "General",
  title: "AI Adoption Governance",
  tagline: "Trustworthy agents: explainable, logged, permissioned, reversible",
  status: "Cross-cutting track",
  lead: "Ram (TCS)",
  scenario:
    "Every agent action across S1–S6 is explainable, traceable and reversible. This track gives Canada Life the controls to adopt AI with confidence: who approved what, why the agent acted, what it touched, and how to roll it back.",
  agents: ["Applies to all ARE agents"],
  journey: [
    { step: "Decision explainability", detail: "Plain-language 'why' for every agent decision." },
    { step: "Action logging & traceability", detail: "Immutable audit trail across systems." },
    { step: "Privilege & access management", detail: "Least-privilege execution with approvals." },
    { step: "Rollback management", detail: "One-click reversal for automated changes." },
    { step: "Human feedback loop", detail: "Corrections retrain agent behavior." },
    { step: "Governance dashboard", detail: "Adoption, risk and control posture in one view." },
  ],
  outcomes: [
    "Confident, auditable AI adoption",
    "Reduced operational and compliance risk",
    "Secure, least-privilege agent execution",
    "Governance that scales with adoption",
  ],
  plannedModules: [
    { title: "Explainability viewer", description: "Decision rationale, inputs and confidence." },
    { title: "Action audit trail", description: "Searchable log of every agent action." },
    { title: "Privilege manager", description: "Agent entitlements and approval chains." },
    { title: "Rollback console", description: "Reverse automated changes safely." },
    { title: "Feedback studio", description: "Route human corrections into training." },
  ],
};
