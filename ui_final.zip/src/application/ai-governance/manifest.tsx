import { KeyRound, LayoutDashboard, MessageCircle, ScrollText, ShieldCheck, Undo2 } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { AiGovernanceHome } from "./pages/HomePage";

export const aiGovernanceApp: AppManifest = {
  id: "ai-governance",
  code: "General",
  name: "AI Adoption Governance",
  description:
    "The cross-cutting trust layer for every ARE agent: explainability, action logging, privilege management, rollback and human feedback.",
  icon: ShieldCheck,
  entry: "/ai-governance",
  status: "preview",
  paths: ["/ai-governance"],
  nav: [
    { label: "Use-case overview", to: "/ai-governance", icon: LayoutDashboard },
    { label: "Explainability viewer", to: "#", icon: MessageCircle, disabled: true, soon: true },
    { label: "Action audit trail", to: "#", icon: ScrollText, disabled: true, soon: true },
    { label: "Privilege manager", to: "#", icon: KeyRound, disabled: true, soon: true },
    { label: "Rollback console", to: "#", icon: Undo2, disabled: true, soon: true },
  ],
  routes: [{ path: "ai-governance", element: <AiGovernanceHome /> }],
};
