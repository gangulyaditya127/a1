import { UseCaseScaffold } from "@/shared/usecase/UseCaseScaffold";
import { useCase } from "../data/useCase";

export function AiGovernanceHome() {
  return <UseCaseScaffold useCase={useCase} />;
}
