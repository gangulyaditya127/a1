import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { CanadaLifeLogo, TcsLogo } from "@/shared/components/Logos";
import { ThemeToggle } from "@/shared/layout/ThemeToggle";
import { Badge } from "@/shared/ui/badge";
import { APPS } from "@/app/registry";
import { cn } from "@/shared/lib/utils";
import type { AppManifest } from "@/shared/types";

/**
 * The portal's front door: one card per application.
 * Cards are driven entirely by app manifests — the launcher knows nothing
 * about any application beyond its manifest contract.
 */
export function LauncherPage() {
  const featured = APPS.filter((a) => a.status === "live");
  const previews = APPS.filter((a) => a.status !== "live");

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-20 border-b bg-card/95 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-6xl items-center gap-3 px-4 md:px-6">
          <CanadaLifeLogo />
          <div className="ml-auto flex items-center gap-2.5">
            <ThemeToggle />
            <div className="hidden items-center gap-2 sm:flex">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-secondary text-[11px] font-semibold text-secondary-foreground">
                SM
              </span>
              <div className="leading-tight">
                <p className="text-xs font-medium">Sudipta Maiti</p>
                <p className="text-[10.5px] text-muted-foreground">
                  Service Owner · Group Benefits
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 md:px-6">
        <div className="mb-8 max-w-2xl">
          <div className="mb-2 flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              Canada Life · AMS
            </p>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">
            AMS Service Console
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Agentic applications for running the Canada Life application
            portfolio — built with TCS on the ARE platform. Pick an application
            to open it.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {featured.map((app) => (
            <AppCard key={app.id} app={app} featured />
          ))}
          {previews.map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      </main>

      <footer className="border-t">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-4 md:px-6">
          <div className="flex items-center gap-2.5">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Delivered by
            </p>
            <TcsLogo />
          </div>
          <p className="text-[11px] text-muted-foreground">
            © 2026 The Canada Life Assurance Company
          </p>
        </div>
      </footer>
    </div>
  );
}

function AppCard({
  app,
  featured = false,
}: {
  app: AppManifest;
  featured?: boolean;
}) {
  return (
    <Link
      to={app.entry}
      className={cn(
        "group flex flex-col rounded-lg border bg-card p-5 shadow-card transition-all hover:-translate-y-0.5 hover:border-brand/50 hover:shadow-md",
        featured && "md:col-span-2 xl:col-span-2",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-brand-soft">
          <app.icon className="h-5 w-5 text-brand" />
        </span>
        <div className="flex items-center gap-1.5">
          <Badge variant="secondary">{app.code}</Badge>
          <Badge variant={app.status === "live" ? "success" : "muted"}>
            {app.status === "live" ? "Live" : "Preview"}
          </Badge>
        </div>
      </div>

      <h2 className="mt-3.5 text-[15px] font-semibold leading-5">{app.name}</h2>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
        {app.description}
      </p>

      {featured && app.stats && (
        <div className="mt-4 grid grid-cols-3 gap-2 border-t pt-3.5">
          {app.stats.map((s) => (
            <div key={s.label}>
              <p className="num text-base font-semibold leading-5">{s.value}</p>
              <p className="text-[10.5px] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      <div className="mt-auto flex items-center gap-1 pt-4 text-xs font-medium text-brand">
        Open application
        <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
      </div>
    </Link>
  );
}
