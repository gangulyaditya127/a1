/**
 * Domain types owned by the Governance & Reporting application.
 * Applications are organized in two levels: Portfolio (parent) ▸ Application (child).
 * Nothing outside src/application/governance should import from here.
 */
export type { TimeRange, MonthPoint } from "@/shared/types";

export type HealthStatus = "on-track" | "at-risk" | "breached";

/** SLA condition — red breaching, amber inside tolerance, green meeting. */
export type RagStatus = "red" | "amber" | "green";

export type IncidentPriority = "P1" | "P2" | "P3" | "P4";

/* ------------------------------ applications ------------------------------ */

export interface Owner {
  name: string;
  role: string;
}

export interface EstateApp {
  id: string;
  name: string;
  portfolio: string;
  portfolioId: string;
  tier: "Tier 1" | "Tier 2" | "Tier 3";
  xla: number;
  xlaDelta: number;
  openP1: number;
  openP2: number;
  risk: HealthStatus;
  owner: Owner;
  /** 12-month history, oldest → newest. */
  xlaSeries: number[];
}


/* ------------------------------- SLA matrix ------------------------------- */

/** A contracted SLA measure and its obligation wording. */
export interface SlaKpiDef {
  id: string;
  measure: string;
  obligation: string;
  category: "response" | "resolution" | "aging";
  priority: IncidentPriority;
  targetPct: number;
}

export interface KpiCellValue {
  actualPct: number;
  status: RagStatus;
  /** Monthly performance for this exact application/KPI obligation. */
  trendPct: number[];
}

/** One row of the SLA grid: a KPI measure with its per-application values. */
export interface SlaKpiRow {
  id: string;
  measure: string;
  obligation: string;
  category: SlaKpiDef["category"];
  priority: IncidentPriority;
  targetPct: number;
  red: number;
  amber: number;
  green: number;
  cells: Record<string, KpiCellValue>;
}

export interface StatusCounts {
  red: number;
  amber: number;
  green: number;
}

export interface SlaSummary {
  csat: number;
  csatDelta: number;
}

/* --------------------------- XLA: CSAT & sentiment ------------------------ */

export type Sentiment = "positive" | "neutral" | "negative";

export interface SentimentSummary {
  analyzed: number;
  positivePct: number;
  neutralPct: number;
  negativePct: number;
  negativeDeltaPts: number;
}

export interface SentimentTheme {
  id: string;
  theme: string;
  sentiment: Sentiment;
  mentions: number;
  deltaPct: number;
}

export interface UserComment {
  id: string;
  when: string;
  portfolio: string;
  application: string;
  rating: number;
  sentiment: Sentiment;
  text: string;
}

/* ---------------------------- incident drilldown --------------------------- */

/** Outcome of a single incident against its SLA target. */
export type IncidentOutcome = "Breached" | "Met";

/**
 * The most granular record in the console: one ticket behind an SLA count.
 * Every red/amber/green figure can be traced down to a list of these.
 */
export interface IncidentRecord {
  id: string;
  appId: string;
  application: string;
  portfolioId: string;
  portfolio: string;
  kpiId: string;
  measure: string;
  rag: RagStatus;
  priority: IncidentPriority;
  openedAt: string;
  openedAtTs: number;
  durationMin: number;
  targetMin: number;
  outcome: IncidentOutcome;
  summary: string;
}

/** Narrows incidentsFor() to a measure, application, portfolio and/or status. */
export interface IncidentFilter {
  kpiId?: string;
  appId?: string;
  portfolioId?: string;
  status?: RagStatus;
}

/** What the incident drilldown dialog should show and how it was scoped. */
export interface DrillSpec {
  title: string;
  subtitle?: string;
  filter: IncidentFilter;
  /** Console section owning the drill; "Open …" buttons stay inside it. */
  section?: "sla";
}

/* ------------------------------- live breaches --------------------------- */

/** Forecast horizon in minutes. */
export type BreachWindow = 30 | 60 | 120 | 180;

export interface LiveBreachRisk {
  id: string;
  /** The at-risk ticket. */
  incident: string;
  kpiId: string;
  appId: string;
  application: string;
  portfolio: string;
  metric: string;
  priority: IncidentPriority;
  assignmentGroup: string;
  assignee: string;
  windowMin: BreachWindow;
  /** Minutes until the SLA is missed. */
  etaMin: number;
  /** 0–100 model confidence. */
  probability: number;
  impact: string;
  driver: string;
  owner: Owner;
  notifiedAt: string | null;
}

/* ------------------------- stakeholder notifications --------------------- */

export interface DigestRule {
  id: string;
  name: string;
  audience: string;
  channel: "Email" | "Teams";
  cadence: string;
  nextRun: string;
  lastSent: string;
  active: boolean;
}

export interface SentNotification {
  id: string;
  to: string;
  subject: string;
  at: string;
}

/* ------------------------------ productivity ----------------------------- */

export interface ProductivitySummary {
  ticketsHandled: number;
  avgResolutionHrs: number;
  avgResolutionDeltaPct: number;
  automationCoveragePct: number;
  hoursSaved: number;
  savingsCad: number;
  backlog: number;
  backlogDeltaPct: number;
}

export interface AutomationRecord {
  id: string;
  name: string;
  tickets: number;
  hoursSaved: number;
  successPct: number;
}

/** Delivery figures rolled up where accountability sits: the portfolio. */
export interface PortfolioDeliveryRow {
  id: string;
  portfolio: string;
  portfolioId: string;
  resources: number;
  /** Tickets resolved, quarter to date. */
  resolved: number;
  /** Tickets resolved per resource in the latest month. */
  throughput: number;
  avgResolutionHrs: number;
  /** Incidents caused by this portfolio's changes, quarter to date. */
  changeIncidents: number;
  changeIncidentsDeltaPct: number;
}

export interface IndividualRow {
  id: string;
  name: string;
  portfolio: string;
  portfolioId: string;
  resolved: number;
  /** Tickets that came back after this associate closed them (QTD). */
  reopened: number;
  avgHandleHrs: number;
  csat: number;
  trendPct: number;
}

/* ------------------------ service friction (XLA) -------------------------- */

/** Reopens, hand-offs and first-contact resolution — the "user was not
 *  satisfied" signals, per application. */
export interface AppFrictionRow {
  appId: string;
  application: string;
  portfolio: string;
  portfolioId: string;
  /** Tickets resolved for this application, quarter to date. */
  resolvedQtd: number;
  /** Incidents reopened after closure, quarter to date. */
  reopened: number;
  /** Reopened ÷ resolved for this application. */
  reopenRatePct: number;
  /** Average assignment hops before resolution. */
  avgHops: number;
  /** Resolved at first contact, %. */
  fcrPct: number;
}

export interface FrictionSummary {
  reopened: number;
  reopenedDeltaPct: number;
  fcrPct: number;
  fcrDeltaPts: number;
  avgHops: number;
  avgHopsDelta: number;
}

/* ----------------------------- quality impact ----------------------------- */

/** Incidents prevented by closing out problem records — the payoff of RCA work. */
export interface QualitySummary {
  avoidedQtd: number;
  avoidedYtd: number;
}
