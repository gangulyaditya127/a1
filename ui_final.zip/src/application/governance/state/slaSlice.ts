import {
  createAsyncThunk,
  createSlice,
  nanoid,
  type PayloadAction,
} from "@reduxjs/toolkit";
import type {
  AppFrictionRow,
  BreachWindow,
  DigestRule,
  EstateApp,
  FrictionSummary,
  LiveBreachRisk,
  MonthPoint,
  SentimentSummary,
  SentimentTheme,
  SentNotification,
  SlaKpiRow,
  SlaSummary,
  StatusCounts,
  TimeRange,
  UserComment,
} from "@/application/governance/types";
import { fetchLiveRisks, fetchSla } from "@/application/governance/services/api";

interface SlaState {
  status: "idle" | "loading" | "succeeded";
  summary: SlaSummary | null;
  csatTrend: MonthPoint[];
  statusCounts: StatusCounts | null;
  kpiMatrix: SlaKpiRow[];
  redRankedAppIds: string[];
  sentiment: {
    summary: SentimentSummary | null;
    trend: MonthPoint[];
    themes: SentimentTheme[];
    comments: UserComment[];
  };
  friction: {
    summary: FrictionSummary | null;
    apps: AppFrictionRow[];
  };
  estate: EstateApp[];
  liveRisks: LiveBreachRisk[];
  liveStatus: "idle" | "refreshing";
  liveUpdatedAt: string | null;
  refreshTick: number;
  digests: DigestRule[];
  sends: SentNotification[];
}

const initialState: SlaState = {
  status: "idle",
  summary: null,
  csatTrend: [],
  statusCounts: null,
  kpiMatrix: [],
  redRankedAppIds: [],
  sentiment: { summary: null, trend: [], themes: [], comments: [] },
  friction: { summary: null, apps: [] },
  estate: [],
  liveRisks: [],
  liveStatus: "idle",
  liveUpdatedAt: null,
  refreshTick: 0,
  digests: [],
  sends: [],
};

export const fetchSlaData = createAsyncThunk(
  "sla/fetch",
  async (range: TimeRange) => fetchSla(range)
);

export const refreshLiveRisks = createAsyncThunk(
  "sla/refreshLive",
  async (_: void, { getState }) => {
    const tick =
      (getState() as { governance: { sla: SlaState } }).governance.sla
        .refreshTick + 1;
    return fetchLiveRisks(tick);
  }
);

const now = () =>
  new Date().toLocaleTimeString("en-CA", { hour: "2-digit", minute: "2-digit" });

const slaSlice = createSlice({
  name: "sla",
  initialState,
  reducers: {
    /** Alert the owner of a single forecast breach. */
    notifyRisk: {
      prepare: (id: string) => ({ payload: { id, at: now() } }),
      reducer(state, action: PayloadAction<{ id: string; at: string }>) {
        const r = state.liveRisks.find((x) => x.id === action.payload.id);
        if (!r || r.notifiedAt) return;
        r.notifiedAt = action.payload.at;
        state.sends.unshift({
          id: nanoid(6),
          to: r.owner.name,
          subject: `Breach risk · ${r.application} — ${r.metric}`,
          at: `Today · ${action.payload.at}`,
        });
      },
    },
    /** Alert every un-notified risk inside a forecast window. */
    notifyWindow: {
      prepare: (windowMin: BreachWindow | "all") => ({
        payload: { windowMin, at: now() },
      }),
      reducer(
        state,
        action: PayloadAction<{ windowMin: BreachWindow | "all"; at: string }>
      ) {
        const limit =
          action.payload.windowMin === "all" ? 180 : action.payload.windowMin;
        const hit = state.liveRisks.filter(
          (r) => !r.notifiedAt && r.windowMin <= limit
        );
        for (const r of hit) r.notifiedAt = action.payload.at;
        if (hit.length)
          state.sends.unshift({
            id: nanoid(6),
            to: `${hit.length} application owner${hit.length > 1 ? "s" : ""}`,
            subject: `Breach-risk alert — next ${limit >= 60 ? `${limit / 60} h` : `${limit} min`}`,
            at: `Today · ${action.payload.at}`,
          });
      },
    },
    /** Ad-hoc SLA/XLA summary to one application owner. */
    notifyOwner: {
      prepare: (app: { name: string; owner: string }) => ({
        payload: { ...app, at: now() },
      }),
      reducer(
        state,
        action: PayloadAction<{ name: string; owner: string; at: string }>
      ) {
        state.sends.unshift({
          id: nanoid(6),
          to: action.payload.owner,
          subject: `SLA & XLA summary — ${action.payload.name}`,
          at: `Today · ${action.payload.at}`,
        });
      },
    },
    toggleDigest(state, action: PayloadAction<string>) {
      const d = state.digests.find((x) => x.id === action.payload);
      if (d) d.active = !d.active;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSlaData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchSlaData.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.csatTrend = action.payload.csatTrend;
        state.statusCounts = action.payload.statusCounts;
        state.kpiMatrix = action.payload.kpiMatrix;
        state.redRankedAppIds = action.payload.redRankedAppIds;
        state.sentiment = action.payload.sentiment;
        state.friction = action.payload.friction;
        state.estate = action.payload.estate;
        // Live feed, digests and the send log persist across range changes.
        if (state.liveRisks.length === 0) {
          state.liveRisks = action.payload.liveRisks;
          state.liveUpdatedAt = new Date().toISOString();
        }
        if (state.digests.length === 0) state.digests = action.payload.digests;
        if (state.sends.length === 0) state.sends = action.payload.sends;
      })
      .addCase(refreshLiveRisks.pending, (state) => {
        state.liveStatus = "refreshing";
      })
      .addCase(refreshLiveRisks.fulfilled, (state, action) => {
        const notified = new Map(
          state.liveRisks
            .filter((r) => r.notifiedAt)
            .map((r) => [r.id, r.notifiedAt] as const)
        );
        state.liveRisks = action.payload.risks.map((r) => ({
          ...r,
          notifiedAt: notified.get(r.id) ?? null,
        }));
        state.refreshTick = action.payload.tick;
        state.liveUpdatedAt = action.payload.at;
        state.liveStatus = "idle";
      });
  },
});

export const { notifyRisk, notifyWindow, notifyOwner, toggleDigest } =
  slaSlice.actions;
export default slaSlice.reducer;
