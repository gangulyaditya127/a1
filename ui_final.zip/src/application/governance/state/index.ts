import { combineReducers } from "@reduxjs/toolkit";
import slaReducer from "./slaSlice";
import productivityReducer from "./productivitySlice";
import qualityReducer from "./qualitySlice";

/**
 * The governance application exposes exactly one reducer to the root store.
 * Its internal slice layout is an implementation detail of this app.
 */
export const governanceReducer = combineReducers({
  sla: slaReducer,
  productivity: productivityReducer,
  quality: qualityReducer,
});
