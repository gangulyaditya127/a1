import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type {
  AutomationRecord,
  IndividualRow,
  MonthPoint,
  PortfolioDeliveryRow,
  ProductivitySummary,
  TimeRange,
} from "@/application/governance/types";
import { fetchProductivity } from "@/application/governance/services/api";

interface ProductivityState {
  status: "idle" | "loading" | "succeeded";
  summary: ProductivitySummary | null;
  volumeTrend: MonthPoint[];
  savingsTrend: MonthPoint[];
  throughputTrend: MonthPoint[];
  topAutomations: AutomationRecord[];
  portfolios: PortfolioDeliveryRow[];
  individuals: IndividualRow[];
}

const initialState: ProductivityState = {
  status: "idle",
  summary: null,
  volumeTrend: [],
  savingsTrend: [],
  throughputTrend: [],
  topAutomations: [],
  portfolios: [],
  individuals: [],
};

export const fetchProductivityData = createAsyncThunk(
  "productivity/fetch",
  async (range: TimeRange) => fetchProductivity(range)
);

const productivitySlice = createSlice({
  name: "productivity",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProductivityData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchProductivityData.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.volumeTrend = action.payload.volumeTrend;
        state.savingsTrend = action.payload.savingsTrend;
        state.throughputTrend = action.payload.throughputTrend;
        state.topAutomations = action.payload.topAutomations;
        state.portfolios = action.payload.portfolios;
        state.individuals = action.payload.individuals;
      });
  },
});

export default productivitySlice.reducer;
