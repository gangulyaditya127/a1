import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { MonthPoint, QualitySummary, TimeRange } from "@/application/governance/types";
import { fetchQuality } from "@/application/governance/services/api";

interface QualityState {
  status: "idle" | "loading" | "succeeded";
  summary: QualitySummary | null;
  avoidedTrend: MonthPoint[];
}

const initialState: QualityState = {
  status: "idle",
  summary: null,
  avoidedTrend: [],
};

export const fetchQualityData = createAsyncThunk(
  "quality/fetch",
  async (range: TimeRange) => fetchQuality(range)
);

const qualitySlice = createSlice({
  name: "quality",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchQualityData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchQualityData.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.avoidedTrend = action.payload.avoidedTrend;
      });
  },
});

export default qualitySlice.reducer;
