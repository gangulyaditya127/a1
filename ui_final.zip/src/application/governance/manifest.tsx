import { Gauge, LayoutDashboard, Smile, Zap } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { OverviewPage } from "./pages/OverviewPage";
import { SlaCompliancePage } from "./pages/SlaCompliancePage";
import { SlaPortfolioPage } from "./pages/SlaPortfolioPage";
import { SlaApplicationPage } from "./pages/SlaApplicationPage";
import { XlaPage } from "./pages/XlaPage";
import { XlaPortfolioPage } from "./pages/XlaPortfolioPage";
import { XlaApplicationPage } from "./pages/XlaApplicationPage";
import { PortfolioPage } from "./pages/PortfolioPage";
import { ApplicationPage } from "./pages/ApplicationPage";
import { ProductivityPage } from "./pages/ProductivityPage";
import { ProductivityPortfolioPage } from "./pages/ProductivityPortfolioPage";
import { ProductivityApplicationPage } from "./pages/ProductivityApplicationPage";

/**
 * Governance & Reporting — the compliance and productivity command centre.
 * Every top-level section (overview, SLA, XLA, productivity) has dedicated
 * portfolio- and application-level drill pages; the incident list is the
 * floor of every path.
 */
export const governanceApp: AppManifest = {
  id: "governance",
  code: "S6",
  name: "Governance & Reporting",
  description:
    "SLA and XLA compliance with live breach forecasting, portfolio-to-application drilldown down to the incident, and team and automation productivity.",
  icon: Gauge,
  entry: "/governance",
  status: "live",
  usesTimeRange: true,
  stats: [
    { label: "Applications", value: "4 portfolios · 19 apps" },
    { label: "Breach watch", value: "3 h horizon" },
    { label: "Contracted measures", value: "12 SLA rules" },
  ],
  paths: ["/governance", "/sla", "/xla", "/productivity"],
  dynamicPaths: ["/portfolio", "/application", "/sla", "/xla", "/productivity"],
  nav: [
    {
      label: "Overview",
      to: "/governance",
      icon: LayoutDashboard,
      activePrefixes: ["/portfolio", "/application"],
    },
    { label: "SLA", to: "/sla", icon: Gauge, activePrefixes: ["/sla"] },
    { label: "XLA", to: "/xla", icon: Smile, activePrefixes: ["/xla"] },
    {
      label: "Productivity",
      to: "/productivity",
      icon: Zap,
      activePrefixes: ["/productivity"],
    },
  ],
  routes: [
    { path: "governance", element: <OverviewPage /> },
    { path: "sla", element: <SlaCompliancePage /> },
    { path: "sla/portfolio/:portfolioId", element: <SlaPortfolioPage /> },
    { path: "sla/application/:appId", element: <SlaApplicationPage /> },
    { path: "xla", element: <XlaPage /> },
    { path: "xla/portfolio/:portfolioId", element: <XlaPortfolioPage /> },
    { path: "xla/application/:appId", element: <XlaApplicationPage /> },
    { path: "portfolio/:portfolioId", element: <PortfolioPage /> },
    { path: "application/:appId", element: <ApplicationPage /> },
    { path: "productivity", element: <ProductivityPage /> },
    { path: "productivity/portfolio/:portfolioId", element: <ProductivityPortfolioPage /> },
    { path: "productivity/application/:appId", element: <ProductivityApplicationPage /> },
  ],
};
