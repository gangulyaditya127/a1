import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import { AlertTriangle, ArrowUpRight, Boxes, Smile } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { cn } from "@/shared/lib/utils";
import { MONTHS } from "@/application/governance/data/slaData";
import { ragForApp, ragForPortfolio, rollup } from "@/application/governance/lib/estate";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { IncidentDrilldown } from "@/application/governance/components/IncidentDrilldown";
import { NotifyButton, StatusCell } from "@/application/governance/components/gridCells";
import { SlaKpiTrendChart } from "@/application/governance/components/SlaKpiTrendChart";
import type { DrillSpec, EstateApp } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const PALETTE = [CHART.red, CHART.blue, CHART.green, CHART.violet, CHART.amber, CHART.sky, "#0e7490"];
const RAG_COLORS = { red: "#dc2626", amber: "#d97706", green: "#059669" };
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const RANGE_MONTHS = { "3m": 3, "6m": 6, "12m": 12 } as const;

type PortfolioApplicationRow = EstateApp & { red: number; amber: number; green: number };

const APP_COLS: ColDef<PortfolioApplicationRow>[] = [
  { field: "name", headerName: "Application", flex: 1.8, minWidth: 220, cellClass: "font-medium" },
  { field: "tier", headerName: "Tier", maxWidth: 100 },
  { field: "red", headerName: "Red", type: "rightAligned", maxWidth: 85, sort: "desc" },
  { field: "amber", headerName: "Amber", type: "rightAligned", maxWidth: 90 },
  { field: "green", headerName: "Met", type: "rightAligned", maxWidth: 85 },
  { field: "xla", headerName: "XLA", type: "rightAligned", maxWidth: 100 },
  { field: "openP1", headerName: "P1", type: "rightAligned", maxWidth: 80 },
  { field: "openP2", headerName: "P2", type: "rightAligned", maxWidth: 80 },
  { field: "risk", headerName: "Status", cellRenderer: StatusCell, maxWidth: 130 },
];

export function PortfolioPage() {
  const { portfolioId = "" } = useParams();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const [metric, setMetric] = useState<"sla" | "xla">("sla");
  const [drill, setDrill] = useState<DrillSpec | null>(null);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const apps = useMemo(
    () => sla.estate.filter((a) => a.portfolioId === portfolioId),
    [sla.estate, portfolioId]
  );
  const loading = sla.status !== "succeeded";

  const applicationRows = useMemo<PortfolioApplicationRow[]>(
    () => apps.map((app) => ({ ...app, ...ragForApp(sla.kpiMatrix, app.id) })),
    [apps, sla.kpiMatrix]
  );

  const xlaTrend = useMemo(() => {
    const start = MONTHS.length - RANGE_MONTHS[range];

    return MONTHS.slice(start).map((month, offset) => {
      const i = start + offset;
      const row: Record<string, string | number> = { month };
      for (const a of apps) row[a.name] = a.xlaSeries[i];
      return row;
    });
  }, [apps, range]);

  if (!loading && apps.length === 0)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Portfolio not found.</p>
        <Button asChild size="sm">
          <Link to="/governance">Back to overview</Link>
        </Button>
      </div>
    );

  const name = apps[0]?.portfolio ?? "";
  const r = rollup(apps);
  const rag = ragForPortfolio(sla.kpiMatrix, sla.estate, portfolioId);
  const risks = sla.liveRisks.filter((x) => apps.some((a) => a.id === x.appId));
  const atRisk = apps.filter((a) => a.risk !== "on-track");

  const views = [
    { label: "SLA view", to: `/sla/portfolio/${portfolioId}` },
    { label: "XLA view", to: `/xla/portfolio/${portfolioId}` },
    { label: "Productivity view", to: `/productivity/portfolio/${portfolioId}` },
  ];

  const metricToggle = (
    <div className="flex gap-1.5">
      {(["sla", "xla"] as const).map((m) => (
        <button
          key={m}
          onClick={() => setMetric(m)}
          className={cn(
            "rounded-md border px-2.5 py-1 text-[11px] font-medium uppercase transition-colors",
            metric === m
              ? "border-brand/40 bg-brand-soft text-accent-foreground"
              : "text-muted-foreground hover:bg-secondary"
          )}
        >
          {m}
        </button>
      ))}
    </div>
  );

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[{ label: "Overview", to: "/governance" }, { label: "Portfolios" }]}
        title={name}
        description={`${apps.length} applications`}
        actions={!loading ? <StatusBadge status={r.risk} /> : undefined}
      />

      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-medium text-muted-foreground">Drill into:</span>
        {views.map((v) => (
          <Link
            key={v.to}
            to={v.to}
            className="inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-[11.5px] font-medium text-brand transition-colors hover:bg-brand-soft"
          >
            {v.label}
            <ArrowUpRight className="h-3 w-3" />
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground">SLA condition</p>
            {loading ? (
              <Skeleton className="mt-2 h-7 w-24" />
            ) : (
              <div className="mt-1.5 flex items-center gap-3">
                {([["red", rag.red], ["amber", rag.amber], ["green", rag.green]] as const).map(([tone, v]) => (
                  <button
                    key={tone}
                    type="button"
                    disabled={v === 0}
                    onClick={() =>
                      setDrill({
                        title: `${cap(tone)} SLA incidents`,
                        subtitle: name,
                        filter: { portfolioId, status: tone },
                        section: "sla",
                      })
                    }
                    className={cn("-mx-1 inline-flex items-center gap-1.5 rounded px-1", v > 0 && "hover:bg-secondary/70")}
                  >
                    <span className="h-2 w-2 rounded-full" style={{ background: RAG_COLORS[tone] }} />
                    <span className={cn("num text-lg font-semibold", tone === "red" && v > 0 && "text-red-600 dark:text-red-400")}>{v}</span>
                  </button>
                ))}
              </div>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">SLA instances by status — click a count for incidents</p>
          </CardContent>
        </Card>
        <KpiCard label="Experience (XLA)" value={loading ? "—" : String(r.xla)} icon={Smile} loading={loading}
          trend={{ value: `${r.xlaDelta > 0 ? "+" : ""}${r.xlaDelta} pts`, direction: r.xlaDelta >= 0 ? "up" : "down", positive: r.xlaDelta >= 0 }} />
        <KpiCard label="Open P1 / P2" value={loading ? "—" : `${r.openP1} / ${r.openP2}`} icon={Boxes} loading={loading} />
        <KpiCard label="Breach risk · 3 h" value={loading ? "—" : String(risks.length)} icon={AlertTriangle} loading={loading} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {metric === "sla" ? (
            <SlaKpiTrendChart
              mode="portfolio"
              matrix={sla.kpiMatrix}
              appIds={apps.map((app) => app.id)}
              range={range}
              loading={loading}
              height={260}
              action={metricToggle}
            />
          ) : (
            <ChartCard
              title="Application XLA comparison"
              subtitle="Monthly experience score by application · target 85"
              loading={loading}
              height={260}
              action={metricToggle}
            >
              <ApacheEChart
                ariaLabel="Application XLA comparison"
                option={{
                  grid: { top: 12, right: 16, bottom: 50, left: 42 },
                  tooltip: { trigger: "axis" },
                  legend: { bottom: 4, type: "scroll" },
                  xAxis: { type: "category", boundaryGap: false, data: xlaTrend.map((point) => point.month), splitLine: { show: false } },
                  yAxis: { type: "value", min: 68, max: 96 },
                  series: apps.map((app, index) => ({
                    name: app.name,
                    type: "line",
                    smooth: true,
                    showSymbol: false,
                    lineStyle: { width: 2, color: PALETTE[index % PALETTE.length] },
                    itemStyle: { color: PALETTE[index % PALETTE.length] },
                    data: xlaTrend.map((point) => point[app.name]),
                    markLine: index === 0 ? { silent: true, symbol: "none", label: { show: false }, lineStyle: { color: CHART.sky, type: "dashed" }, data: [{ yAxis: 85 }] } : undefined,
                  })),
                }}
              />
            </ChartCard>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Applications</CardTitle>
              <CardDescription>Click a row to open the application</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-64 w-full" />
              ) : (
                <DataGrid<PortfolioApplicationRow>
                  height="auto"
                  rowData={applicationRows}
                  columnDefs={APP_COLS}
                  onRowClicked={(e) => e.data && navigate(`/application/${e.data.id}`)}
                />
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live breach risk</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {risks.length === 0 ? (
                <p className="rounded-md border border-dashed px-3 py-5 text-center text-xs text-muted-foreground">
                  No forecast breaches in the next 3 hours.
                </p>
              ) : (
                risks.map((r2) => (
                  <div key={r2.id} className="rounded-md border px-3 py-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs font-semibold">{r2.application}</p>
                      <Badge variant={r2.windowMin <= 30 ? "danger" : r2.windowMin <= 60 ? "warning" : "muted"}>
                        {r2.etaMin} min
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                      {r2.incident} · {r2.metric}
                    </p>
                    <div className="mt-2">
                      <NotifyButton risk={r2} />
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <AiInsight source="Portfolio analysis">
            {atRisk.length > 0
              ? `${atRisk.map((a) => a.name).join(" and ")} ${atRisk.length > 1 ? "are" : "is"} carrying the portfolio's reds — fixes for both sit in the Jul 24 change window.`
              : "All applications are on track; compliance headroom is stable across the portfolio."}
          </AiInsight>
        </div>
      </div>

      <IncidentDrilldown spec={drill} onClose={() => setDrill(null)} />
    </div>
  );
}
