import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import {
  CheckCheck,
  MessageSquareText,
  Route,
  RotateCcw,
  ThumbsDown,
  ThumbsUp,
  X,
} from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { TrendIndicator } from "@/shared/components/TrendIndicator";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { cn, fmtNum } from "@/shared/lib/utils";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import {
  GroupOpenCell,
  ReopenCountCell,
  SentimentCell,
  TitleSubCell,
} from "@/application/governance/components/gridCells";
import type {
  AppFrictionRow,
  Sentiment,
  UserComment,
} from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const RAG_COLORS = { red: "#dc2626", green: "#059669" };
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

const COMMENT_COLS: ColDef<UserComment>[] = [
  { field: "when", headerName: "Date", maxWidth: 90 },
  { field: "application", headerName: "Application", minWidth: 170, cellRenderer: TitleSubCell, cellRendererParams: { subField: "portfolio" } },
  { field: "rating", headerName: "CSAT", type: "rightAligned", maxWidth: 90, valueFormatter: (p) => `${p.value} / 5` },
  { field: "sentiment", headerName: "Sentiment", cellRenderer: SentimentCell, maxWidth: 120 },
  { field: "text", headerName: "Comment", flex: 3, minWidth: 320, wrapText: true, autoHeight: true, cellClass: "leading-snug py-2" },
];

const FRICTION_COLS: ColDef<AppFrictionRow>[] = [
  { field: "portfolio", rowGroup: true, hide: true },
  { field: "application", headerName: "Application", flex: 1.6, minWidth: 220, cellClass: "font-medium" },
  { field: "reopened", headerName: "Reopened · QTD", aggFunc: "sum", type: "rightAligned", maxWidth: 150, cellRenderer: ReopenCountCell, sort: "desc" },
  { field: "reopenRatePct", headerName: "Reopen rate", aggFunc: "avg", type: "rightAligned", maxWidth: 130, valueFormatter: (p) => (p.value == null ? "" : `${Number(p.value).toFixed(1)}%`) },
  { field: "avgHops", headerName: "Avg hops", aggFunc: "avg", type: "rightAligned", maxWidth: 110, headerTooltip: "Average assignment hand-offs before resolution", valueFormatter: (p) => (p.value == null ? "" : Number(p.value).toFixed(1)) },
  { field: "fcrPct", headerName: "FCR", aggFunc: "avg", type: "rightAligned", maxWidth: 100, headerTooltip: "Resolved at first contact", valueFormatter: (p) => (p.value == null ? "" : `${Number(p.value).toFixed(1)}%`) },
];

export function XlaPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const [commentFilter, setCommentFilter] = useState<Sentiment | null>(null);
  const commentsRef = useRef<HTMLDivElement>(null);
  const scrollToCommentsRef = useRef(false);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const loading = sla.status !== "succeeded";
  const sent = sla.sentiment;
  const friction = sla.friction;

  const visibleComments = useMemo(
    () => (commentFilter ? sent.comments.filter((c) => c.sentiment === commentFilter) : sent.comments),
    [sent.comments, commentFilter]
  );

  useEffect(() => {
    if (!scrollToCommentsRef.current) return;
    scrollToCommentsRef.current = false;

    requestAnimationFrame(() => {
      commentsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, [commentFilter]);

  const selectCommentSentiment = (sentiment: Sentiment) => {
    scrollToCommentsRef.current = true;
    setCommentFilter((current) => (current === sentiment ? null : sentiment));
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="XLA"
        description="How the service feels: CSAT, comment sentiment, and the friction users hit."
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground">CSAT</p>
            {loading ? (
              <Skeleton className="mt-2 h-7 w-16" />
            ) : (
              <div className="mt-1 flex items-end gap-2">
                <span className="num text-2xl font-semibold">{sla.summary?.csat}</span>
                <span className="pb-0.5 text-xs text-muted-foreground">/ 5</span>
                <TrendIndicator className="mb-0.5 ml-auto" trend={{ value: "+0.1", direction: "up", positive: true }} />
              </div>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">closed-ticket surveys</p>
          </CardContent>
        </Card>
        <button
          type="button"
          onClick={() => selectCommentSentiment("positive")}
          className="block text-left"
        >
          <Card className={cn("h-full transition-colors hover:bg-secondary/40", commentFilter === "positive" && "ring-2 ring-emerald-500/50")}>
            <CardContent className="p-4">
              <div className="flex items-center gap-1.5">
                <ThumbsUp className="h-3.5 w-3.5 text-emerald-600" />
                <p className="text-xs font-medium text-muted-foreground">Positive sentiment</p>
              </div>
              {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
                <p className="num mt-1 text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{sent.summary?.positivePct}%</p>
              )}
              <p className="mt-0.5 text-[10.5px] text-muted-foreground">of analyzed comments</p>
            </CardContent>
          </Card>
        </button>
        <button
          type="button"
          onClick={() => selectCommentSentiment("negative")}
          className="block text-left"
        >
          <Card className={cn("h-full transition-colors hover:bg-secondary/40", commentFilter === "negative" && "ring-2 ring-red-500/50")}>
            <CardContent className="p-4">
              <div className="flex items-center gap-1.5">
                <ThumbsDown className="h-3.5 w-3.5 text-red-600" />
                <p className="text-xs font-medium text-muted-foreground">Negative sentiment</p>
              </div>
              {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
                <div className="mt-1 flex items-end gap-2">
                  <p className="num text-2xl font-semibold text-red-600 dark:text-red-400">{sent.summary?.negativePct}%</p>
                  <TrendIndicator className="mb-0.5 ml-auto" trend={{ value: `${sent.summary?.negativeDeltaPts} pts`, direction: "down", positive: true }} />
                </div>
              )}
              <p className="mt-0.5 text-[10.5px] text-muted-foreground">improving is good</p>
            </CardContent>
          </Card>
        </button>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <MessageSquareText className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-xs font-medium text-muted-foreground">Comments analyzed</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
              <p className="num mt-1 text-2xl font-semibold">{fmtNum(sent.summary?.analyzed ?? 0)}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">this quarter</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard title="CSAT" subtitle="Average rating, monthly" loading={loading} height={230}>
          <ApacheEChart
            ariaLabel="Monthly CSAT trend"
            option={{
              grid: { top: 12, right: 16, bottom: 28, left: 42 },
              tooltip: { trigger: "axis" },
              xAxis: { type: "category", boundaryGap: false, data: sla.csatTrend.map((point) => point.month), splitLine: { show: false } },
              yAxis: { type: "value", min: 3.5, max: 5 },
              series: [{ name: "CSAT", type: "line", smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.green }, itemStyle: { color: CHART.green }, data: sla.csatTrend.map((point) => point.csat) }],
            }}
          />
        </ChartCard>

        <ChartCard title="Comment sentiment" subtitle="Share of analyzed comments" loading={loading} height={230}>
          <ApacheEChart
            ariaLabel="Monthly comment sentiment share"
            option={{
              grid: { top: 12, right: 16, bottom: 50, left: 48 },
              tooltip: { trigger: "axis", valueFormatter: (value: unknown) => `${value}%` },
              legend: { bottom: 4 },
              xAxis: { type: "category", boundaryGap: false, data: sent.trend.map((point) => point.month), splitLine: { show: false } },
              yAxis: { type: "value", min: 0, max: 100, axisLabel: { formatter: "{value}%" } },
              series: [
                { name: "Positive", type: "line", stack: "sentiment", smooth: true, showSymbol: false, lineStyle: { color: RAG_COLORS.green }, areaStyle: { color: RAG_COLORS.green, opacity: 0.35 }, itemStyle: { color: RAG_COLORS.green }, data: sent.trend.map((point) => point.positive) },
                { name: "Neutral", type: "line", stack: "sentiment", smooth: true, showSymbol: false, lineStyle: { color: CHART.slate }, areaStyle: { color: CHART.slate, opacity: 0.25 }, itemStyle: { color: CHART.slate }, data: sent.trend.map((point) => point.neutral) },
                { name: "Negative", type: "line", stack: "sentiment", smooth: true, showSymbol: false, lineStyle: { color: RAG_COLORS.red }, areaStyle: { color: RAG_COLORS.red, opacity: 0.35 }, itemStyle: { color: RAG_COLORS.red }, data: sent.trend.map((point) => point.negative) },
              ],
            }}
          />
        </ChartCard>
      </div>

      {/* --------------------------- service friction -------------------------- */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <RotateCcw className="h-3.5 w-3.5 text-red-600" />
              <p className="text-xs font-medium text-muted-foreground">Reopened incidents</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
              <div className="mt-1 flex items-end gap-2">
                <p className="num text-2xl font-semibold text-red-600 dark:text-red-400">{friction.summary?.reopened}</p>
                <TrendIndicator className="mb-0.5 ml-auto" trend={{ value: `${friction.summary?.reopenedDeltaPct}% q/q`, direction: "down", positive: true }} />
              </div>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">closed, then came back — QTD</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <CheckCheck className="h-3.5 w-3.5 text-emerald-600" />
              <p className="text-xs font-medium text-muted-foreground">First contact resolution</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
              <div className="mt-1 flex items-end gap-2">
                <p className="num text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{friction.summary?.fcrPct}%</p>
                <TrendIndicator className="mb-0.5 ml-auto" trend={{ value: `+${friction.summary?.fcrDeltaPts} pts`, direction: "up", positive: true }} />
              </div>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">resolved without a hand-off · target ≥ 70%</p>
          </CardContent>
        </Card>
        <Card className="col-span-2 xl:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <Route className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-xs font-medium text-muted-foreground">Avg assignment hops</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-16" /> : (
              <div className="mt-1 flex items-end gap-2">
                <p className="num text-2xl font-semibold">{friction.summary?.avgHops}</p>
                <TrendIndicator className="mb-0.5 ml-auto" trend={{ value: `${friction.summary?.avgHopsDelta}`, direction: "down", positive: true }} />
              </div>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">hand-offs between groups before resolution</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Where the friction is</CardTitle>
          <CardDescription>
            Reopens, hand-offs and first-contact resolution — Portfolio ▸ Application · open a portfolio or click an application to drill in
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <DataGrid<AppFrictionRow>
              height={420}
              rowData={friction.apps}
              columnDefs={FRICTION_COLS}
              groupDefaultExpanded={1}
              suppressAggFuncInHeader
              autoGroupColumnDef={{
                headerName: "Portfolio",
                minWidth: 220,
                flex: 1.2,
                cellRendererParams: { innerRenderer: GroupOpenCell, basePath: "/xla/portfolio" },
              }}
              onRowClicked={(e) => {
                if (e.node.group) e.node.setExpanded(!e.node.expanded);
                else if (e.data) navigate(`/xla/application/${e.data.appId}`);
              }}
            />
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>What people talk about</CardTitle>
            <CardDescription>Themes from comment analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {sent.themes.map((t) => (
              <div key={t.id} className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span className={cn("h-2 w-2 shrink-0 rounded-full", t.sentiment === "positive" ? "bg-emerald-500" : t.sentiment === "negative" ? "bg-red-500" : "bg-slate-400")} />
                  <p className="truncate text-xs font-medium">{t.theme}</p>
                </div>
                <span className="num shrink-0 text-[11px] text-muted-foreground">
                  {t.mentions} · {t.deltaPct > 0 ? "+" : ""}{t.deltaPct}%
                </span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card ref={commentsRef} className="scroll-mt-4 lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Recent comments</CardTitle>
              <CardDescription>Sentiment scored automatically on every survey</CardDescription>
            </div>
            {commentFilter && (
              <button
                onClick={() => setCommentFilter(null)}
                className="inline-flex shrink-0 items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                {cap(commentFilter)} only
                <X className="h-3 w-3" />
              </button>
            )}
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <DataGrid<UserComment>
                key={commentFilter ?? "all"}
                height="auto"
                rowData={visibleComments}
                columnDefs={COMMENT_COLS}
              />
            )}
          </CardContent>
        </Card>
      </div>

      <AiInsight source="Sentiment analysis">
        Negative sentiment concentrates on claim-status visibility and
        advisor portal timeouts — the same two applications driving red
        SLAs and most reopens. Positive mentions of instant password reset
        keep rising since the automation went live.
      </AiInsight>
    </div>
  );
}
