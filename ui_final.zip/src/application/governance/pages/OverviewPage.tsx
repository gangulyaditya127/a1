import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import type { CellClickedEvent, ColDef, ICellRendererParams } from "ag-grid-community";
import { ArrowRight, BellRing, Clock3, Siren, Sparkles } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { cn, fmtNum } from "@/shared/lib/utils";
import { ragForApp } from "@/application/governance/lib/estate";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { fetchProductivityData } from "@/application/governance/state/productivitySlice";
import { fetchQualityData } from "@/application/governance/state/qualitySlice";
import { IncidentDrilldown } from "@/application/governance/components/IncidentDrilldown";
import { SlaRuleForecastChart } from "@/application/governance/components/SlaRuleForecastChart";
import {
  EstateGroupCell,
  RagCountCell,
  StatusCell,
} from "@/application/governance/components/gridCells";
import type {
  DrillSpec,
  EstateApp,
  RagStatus,
} from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const RAG_COLORS = { red: "#dc2626", amber: "#d97706", green: "#059669" };

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** A row's red/amber/green counts across every SLA measure it appears in. */
type ApplicationRow = EstateApp & { redCount: number; amberCount: number; greenCount: number };

/** Compact forecast stat card; red is reserved for rules expected to miss. */
function StatusCard({
  tone,
  label,
  value,
  hint,
  loading,
  onClick,
}: {
  tone: "red" | "amber" | "green";
  label: string;
  value: number | null;
  hint: string;
  loading: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} disabled={loading} className="block w-full min-w-0 text-left">
      <Card
        className={cn(
          "h-full transition-colors",
          tone === "red"
            ? "border-red-500/45 bg-red-500/[0.05] hover:bg-red-500/[0.08] dark:bg-red-500/[0.09]"
            : "hover:bg-secondary/40"
        )}
      >
        <CardContent className="p-4">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ background: RAG_COLORS[tone] }} />
            <p className="text-xs font-medium text-muted-foreground">{label}</p>
          </div>
          {loading ? (
            <Skeleton className="mt-2 h-7 w-14" />
          ) : (
            <p
              className={cn(
                "num mt-1.5 text-2xl font-semibold tracking-tight",
                tone === "red" && "text-red-600 dark:text-red-400"
              )}
            >
              {value ?? "—"}
            </p>
          )}
          <p className="mt-0.5 text-[10.5px] text-muted-foreground">{hint}</p>
        </CardContent>
      </Card>
    </button>
  );
}

export function OverviewPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const prod = useAppSelector((s) => s.governance.productivity);
  const quality = useAppSelector((s) => s.governance.quality);
  const [drill, setDrill] = useState<DrillSpec | null>(null);

  useEffect(() => {
    dispatch(fetchSlaData(range));
    dispatch(fetchProductivityData(range));
    dispatch(fetchQualityData(range));
  }, [dispatch, range]);

  const loading = sla.status !== "succeeded";
  const prodLoading = prod.status !== "succeeded";

  const urgent = useMemo(
    () => [...sla.liveRisks].sort((a, b) => b.probability - a.probability).slice(0, 3),
    [sla.liveRisks]
  );

  const lastMix = prod.volumeTrend[prod.volumeTrend.length - 1];
  const mixData = lastMix
    ? [
        { name: "Auto-resolved", value: Number(lastMix.autoResolved), color: CHART.green },
        { name: "AI-assisted", value: Number(lastMix.aiAssisted), color: CHART.blue },
        { name: "Manual", value: Number(lastMix.manual), color: CHART.slate },
      ]
    : [];

  const forecastRuleCount = new Set(sla.liveRisks.map((risk) => risk.kpiId)).size;
  const dueIn30 = sla.liveRisks.filter((risk) => risk.etaMin <= 30);
  const pendingOwnerAlerts = sla.liveRisks.filter((risk) => !risk.notifiedAt).length;
  const openP1 = sla.estate.reduce((count, app) => count + app.openP1, 0);
  const openP2 = sla.estate.reduce((count, app) => count + app.openP2, 0);
  const immediateRules = [...new Set(dueIn30.map((risk) => risk.metric))];
  const immediateApplications = dueIn30.map((risk) => risk.application);

  const changeIncidents = prod.portfolios.reduce((n, p) => n + p.changeIncidents, 0);

  /** Application rows enriched with their own RAG counts — additive, so a
   *  portfolio group can sum them without blending unrelated percentages. */
  const rows = useMemo<ApplicationRow[]>(
    () =>
      sla.estate.map((a) => {
        const c = ragForApp(sla.kpiMatrix, a.id);
        return { ...a, redCount: c.red, amberCount: c.amber, greenCount: c.green };
      }),
    [sla.estate, sla.kpiMatrix]
  );

  const countSpec = (rag: RagStatus) => (params: ICellRendererParams): DrillSpec | null => {
    if (params.node?.group) {
      const portfolioId = params.node.allLeafChildren?.[0]?.data?.portfolioId as string | undefined;
      if (!portfolioId) return null;
      return {
        title: `${cap(rag)} SLA incidents`,
        subtitle: params.node.key ?? undefined,
        filter: { status: rag, portfolioId },
      };
    }
    const row = params.data as ApplicationRow | undefined;
    return row
      ? { title: `${cap(rag)} SLA incidents`, subtitle: row.name, filter: { status: rag, appId: row.id } }
      : null;
  };

  const APPLICATIONS_COLS: ColDef<ApplicationRow>[] = [
    { field: "portfolio", rowGroup: true, hide: true },
    { field: "tier", headerName: "Tier", maxWidth: 100 },
    { field: "redCount", headerName: "Red", aggFunc: "sum", maxWidth: 90, cellRenderer: RagCountCell, cellRendererParams: { rag: "red", buildSpec: countSpec("red") } },
    { field: "amberCount", headerName: "Amber", aggFunc: "sum", maxWidth: 90, cellRenderer: RagCountCell, cellRendererParams: { rag: "amber", buildSpec: countSpec("amber") } },
    { field: "greenCount", headerName: "Green", aggFunc: "sum", maxWidth: 90, cellRenderer: RagCountCell, cellRendererParams: { rag: "green", buildSpec: countSpec("green") } },
    { field: "openP1", headerName: "P1", aggFunc: "sum", type: "rightAligned", maxWidth: 80 },
    { field: "openP2", headerName: "P2", aggFunc: "sum", type: "rightAligned", maxWidth: 80 },
    { field: "risk", headerName: "Status", cellRenderer: StatusCell, maxWidth: 130 },
  ];

  const onApplicationsCellClicked = (e: CellClickedEvent<ApplicationRow>) => {
    if (["redCount", "amberCount", "greenCount"].includes(e.column.getColId())) return;
    if (e.node.group) {
      e.node.setExpanded(!e.node.expanded);
      return;
    }
    if (e.data) navigate(`/application/${e.data.id}`);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Overview"
        description="Immediate SLA intervention, open priority workload, service experience, and application-level evidence."
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatusCard
          tone="red"
          label="SLA rules likely to breach"
          value={loading ? null : forecastRuleCount}
          hint={`of ${sla.kpiMatrix.length} contracted rules · next 3 h`}
          loading={loading}
          onClick={() => navigate("/sla?tab=live")}
        />
        <Link to="/sla?tab=live" className="block">
          <KpiCard
            label="Breaches due in 30 min"
            value={String(dueIn30.length)}
            icon={Clock3}
            loading={loading}
            hint="tickets needing immediate action"
          />
        </Link>
        <Link to="/sla?tab=live" className="block">
          <KpiCard
            label="Breach alerts pending"
            value={String(pendingOwnerAlerts)}
            icon={BellRing}
            loading={loading}
            hint="owner notifications not yet sent"
          />
        </Link>
        <KpiCard
          label="Open priority incidents"
          value={`${openP1} P1 · ${openP2} P2`}
          icon={Siren}
          loading={loading}
          hint="active across the application estate"
        />
        <Link to="/xla" className="block">
          <KpiCard
            label="CSAT"
            value={sla.summary ? `${sla.summary.csat} / 5` : "—"}
            icon={Sparkles}
            loading={loading}
            trend={{ value: "+0.1", direction: "up", positive: true }}
          />
        </Link>
      </div>

      <AiInsight
        source="Compliance forecast · 06:00 ET"
        actions={
          <Button size="sm" variant="outline" className="h-7 text-xs" asChild>
            <Link to="/sla?tab=live">
              View live risk
              <ArrowRight className="h-3 w-3" />
            </Link>
          </Button>
        }
      >
        {dueIn30.length} tickets are expected to miss {immediateRules.join(" and ")} in the next
        30 minutes. {pendingOwnerAlerts} breach alerts remain pending;{" "}
        {immediateApplications.join(" and ")} need intervention first.
      </AiInsight>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <ChartCard
            title="SLA breach forecast by rule"
            subtitle="Forecast tickets by SLA rule and time-to-breach · next 3 hours"
            loading={loading}
            height={390}
          >
            <SlaRuleForecastChart risks={sla.liveRisks} />
          </ChartCard>

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Applications</CardTitle>
                <CardDescription>
                  Portfolio ▸ Application. Click a RAG count for incidents, or a name to open the application.
                </CardDescription>
              </div>
              <Badge variant="secondary">{sla.estate.length} applications</Badge>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-72 w-full" />
              ) : (
                <DataGrid<ApplicationRow>
                  height={460}
                  rowData={rows}
                  columnDefs={APPLICATIONS_COLS}
                  groupDefaultExpanded={1}
                  suppressAggFuncInHeader
                  autoGroupColumnDef={{
                    headerName: "Portfolio / Application",
                    flex: 2,
                    minWidth: 260,
                    field: "name",
                    cellRendererParams: { innerRenderer: EstateGroupCell },
                  }}
                  context={{ onDrill: (spec: DrillSpec) => setDrill(spec) }}
                  onCellClicked={onApplicationsCellClicked}
                />
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Live breach radar</CardTitle>
                <CardDescription>Highest probability first</CardDescription>
              </div>
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
              </span>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {loading ? (
                <>
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </>
              ) : (
                <>
                  {urgent.map((r) => (
                    <Link
                      key={r.id}
                      to="/sla?tab=live"
                      className="block rounded-md border px-3 py-2 transition-colors hover:bg-secondary/60"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="truncate text-xs font-semibold">{r.application}</p>
                        <Badge variant={r.windowMin <= 30 ? "danger" : r.windowMin <= 60 ? "warning" : "muted"}>
                          {r.etaMin} min
                        </Badge>
                      </div>
                      <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
                        {r.incident} · {r.metric}
                      </p>
                    </Link>
                  ))}
                  <Button variant="ghost" size="sm" className="w-full text-xs" asChild>
                    <Link to="/sla?tab=live">
                      All forecast windows
                      <ArrowRight className="h-3 w-3" />
                    </Link>
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          <ChartCard title="Resolution share" subtitle="Latest month" loading={prodLoading} height={190}>
            <ApacheEChart
              ariaLabel="Resolution share"
              option={{
                tooltip: { trigger: "item" },
                legend: { bottom: 0 },
                series: [
                  {
                    name: "Resolution share",
                    type: "pie",
                    radius: ["50%", "72%"],
                    center: ["50%", "43%"],
                    padAngle: 2,
                    label: { show: false },
                    itemStyle: { borderWidth: 0 },
                    data: mixData.map((item) => ({
                      name: item.name,
                      value: item.value,
                      itemStyle: { color: item.color },
                    })),
                  },
                ],
              }}
            />
          </ChartCard>

          <Card>
            <CardHeader>
              <CardTitle>This quarter at a glance</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-x-2 gap-y-3 text-center">
              <div>
                <p className="num text-lg font-semibold">
                  {prod.summary ? fmtNum(prod.summary.hoursSaved) : "—"}
                </p>
                <p className="text-[10.5px] text-muted-foreground">hours returned</p>
              </div>
              <div>
                <p className="num text-lg font-semibold">
                  {quality.summary ? quality.summary.avoidedQtd : "—"}
                </p>
                <p className="text-[10.5px] text-muted-foreground">incidents avoided (PRB)</p>
              </div>
              <div>
                <p className="num text-lg font-semibold">{prodLoading ? "—" : changeIncidents}</p>
                <p className="text-[10.5px] text-muted-foreground">change-induced incidents</p>
              </div>
              <div>
                <p className="num text-lg font-semibold">{sla.summary ? `${sla.summary.csat} / 5` : "—"}</p>
                <p className="text-[10.5px] text-muted-foreground">CSAT</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <IncidentDrilldown spec={drill} onClose={() => setDrill(null)} />
    </div>
  );
}
