import { useEffect, useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowUpRight, BellRing, Boxes, Gauge, Layers, Smile } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/shared/ui/card";
import { fetchSlaData, notifyOwner } from "@/application/governance/state/slaSlice";
import { NotifyButton } from "@/application/governance/components/gridCells";
import { SlaKpiTrendChart } from "@/application/governance/components/SlaKpiTrendChart";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

export function ApplicationPage() {
  const { appId = "" } = useParams();
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const app = sla.estate.find((a) => a.id === appId);
  const loading = sla.status !== "succeeded";

  /** This application's slice of the SLA matrix, for the insight line. */
  const kpis = useMemo(
    () =>
      sla.kpiMatrix
        .filter((row) => row.cells[appId])
        .map((row) => ({
          measure: row.measure,
          targetPct: row.targetPct,
          actualPct: row.cells[appId].actualPct,
          status: row.cells[appId].status,
        })),
    [sla.kpiMatrix, appId]
  );

  const risks = sla.liveRisks.filter((r) => r.appId === appId);
  const lastSend = sla.sends.find((s) => s.subject.includes(app?.name ?? "§"));

  if (!loading && !app)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Application not found.</p>
        <Button asChild size="sm">
          <Link to="/governance">Back to overview</Link>
        </Button>
      </div>
    );

  const reds = kpis.filter((k) => k.status === "red");
  const ambers = kpis.filter((k) => k.status === "amber");
  const greens = kpis.filter((k) => k.status === "green");
  const worst = [...kpis].sort((a, b) => a.actualPct - a.targetPct - (b.actualPct - b.targetPct))[0];

  const views = [
    { label: "SLA view", to: `/sla/application/${appId}` },
    { label: "XLA view", to: `/xla/application/${appId}` },
    { label: "Productivity view", to: `/productivity/application/${appId}` },
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[
          { label: "Overview", to: "/governance" },
          { label: app?.portfolio ?? "…", to: app ? `/portfolio/${app.portfolioId}` : undefined },
        ]}
        title={app?.name ?? "…"}
        description={app ? `${app.tier} · Owner ${app.owner.name}` : undefined}
        actions={
          app && (
            <>
              <StatusBadge status={app.risk} />
              <Button
                size="sm"
                variant="outline"
                onClick={() => dispatch(notifyOwner({ name: app.name, owner: app.owner.name }))}
              >
                <BellRing className="h-3.5 w-3.5" />
                Send summary to owner
              </Button>
            </>
          )
        }
      />

      {lastSend && (
        <p className="-mt-3 text-[11px] text-muted-foreground">
          Last sent: {lastSend.subject} · {lastSend.at}
        </p>
      )}

      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-medium text-muted-foreground">Drill into:</span>
        {views.map((v) => (
          <Link
            key={v.to}
            to={v.to}
            className="inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-[11.5px] font-medium text-brand transition-colors hover:bg-brand-soft"
          >
            {v.label}
            <ArrowUpRight className="h-3 w-3" />
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard
          label="SLA obligations at risk"
          value={app ? String(reds.length + ambers.length) : "—"}
          icon={Gauge}
          loading={loading}
          hint={app ? `${reds.length} red · ${ambers.length} amber · ${greens.length} met` : undefined}
        />
        <KpiCard label="Experience (XLA)" value={app ? String(app.xla) : "—"} icon={Smile} loading={loading}
          trend={app ? { value: `${app.xlaDelta > 0 ? "+" : ""}${app.xlaDelta} pts`, direction: app.xlaDelta >= 0 ? "up" : "down", positive: app.xlaDelta >= 0 } : undefined} />
        <KpiCard label="Open P1 / P2" value={app ? `${app.openP1} / ${app.openP2}` : "—"} icon={Boxes} loading={loading} />
        <KpiCard label="Breach risk · 3 h" value={String(risks.length)} icon={Layers} loading={loading} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SlaKpiTrendChart
          mode="application"
          matrix={sla.kpiMatrix}
          appId={appId}
          range={range}
          loading={loading}
          height={260}
          className="lg:col-span-2"
        />

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live breach risk</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {risks.length === 0 ? (
                <p className="rounded-md border border-dashed px-3 py-5 text-center text-xs text-muted-foreground">
                  No forecast breaches in the next 3 hours.
                </p>
              ) : (
                risks.map((r) => (
                  <div key={r.id} className="rounded-md border px-3 py-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-xs font-semibold">{r.metric}</p>
                      <Badge variant={r.windowMin <= 30 ? "danger" : r.windowMin <= 60 ? "warning" : "muted"}>
                        {r.etaMin} min
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                      {r.incident} · {r.assignee} · {r.probability}%
                    </p>
                    <div className="mt-2">
                      <NotifyButton risk={r} />
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {app && worst && (
            <AiInsight source="Application analysis">
              {reds.length > 0
                ? `${reds.length} obligation${reds.length > 1 ? "s are" : " is"} red — ${worst.measure} sits at ${worst.actualPct}% against ${worst.targetPct}%. The SLA view lists every incident behind those numbers.`
                : `All obligations met; ${worst.measure} has the least headroom (${worst.actualPct}% vs ${worst.targetPct}%).`}
            </AiInsight>
          )}
        </div>
      </div>
    </div>
  );
}
