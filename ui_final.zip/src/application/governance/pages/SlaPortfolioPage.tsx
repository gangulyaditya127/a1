import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { ColDef, ICellRendererParams } from "ag-grid-community";
import { AiInsight } from "@/shared/components/AiInsight";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { cn } from "@/shared/lib/utils";
import { ragForApp, ragForPortfolio } from "@/application/governance/lib/estate";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { IncidentDrilldown } from "@/application/governance/components/IncidentDrilldown";
import { RagCell, RagCountCell } from "@/application/governance/components/gridCells";
import { SlaKpiTrendChart } from "@/application/governance/components/SlaKpiTrendChart";
import type { DrillSpec, KpiCellValue, RagStatus } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const RAG_COLORS = { red: "#dc2626", amber: "#d97706", green: "#059669" };
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** One row per application: its RAG counts plus its value on every measure. */
interface AppSlaRow {
  appId: string;
  name: string;
  tier: string;
  red: number;
  amber: number;
  green: number;
  cells: Record<string, KpiCellValue>;
}

export function SlaPortfolioPage() {
  const { portfolioId = "" } = useParams();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const [drill, setDrill] = useState<DrillSpec | null>(null);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const apps = useMemo(
    () => sla.estate.filter((a) => a.portfolioId === portfolioId),
    [sla.estate, portfolioId]
  );
  const loading = sla.status !== "succeeded";
  const name = apps[0]?.portfolio ?? "";

  /** Transpose the matrix: applications as rows, measures as columns. */
  const rows = useMemo<AppSlaRow[]>(
    () =>
      apps.map((a) => {
        const counts = ragForApp(sla.kpiMatrix, a.id);
        const cells: Record<string, KpiCellValue> = {};
        for (const row of sla.kpiMatrix) if (row.cells[a.id]) cells[row.id] = row.cells[a.id];
        return { appId: a.id, name: a.name, tier: a.tier, ...counts, cells };
      }),
    [apps, sla.kpiMatrix]
  );

  const cols = useMemo<ColDef<AppSlaRow>[]>(() => {
    const countSpec = (rag: RagStatus) => (params: ICellRendererParams): DrillSpec | null => {
      const row = params.data as AppSlaRow | undefined;
      if (!row) return null;
      return {
        title: `${cap(rag)} SLA incidents`,
        subtitle: row.name,
        filter: { appId: row.appId, status: rag },
        section: "sla",
      };
    };
    const cellSpec = (kpiId: string, measure: string, obligation: string) =>
      (params: ICellRendererParams): DrillSpec | null => {
        const row = params.data as AppSlaRow | undefined;
        if (!row || !row.cells[kpiId]) return null;
        return {
          title: measure,
          subtitle: `${row.name} · ${obligation}`,
          filter: { kpiId, appId: row.appId },
          section: "sla",
        };
      };
    return [
      { field: "name", headerName: "Application", pinned: "left", minWidth: 200, width: 220, flex: 0, cellClass: "font-medium" },
      { field: "red", headerName: "R", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "red", buildSpec: countSpec("red") }, sort: "desc" },
      { field: "amber", headerName: "A", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "amber", buildSpec: countSpec("amber") } },
      { field: "green", headerName: "G", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "green", buildSpec: countSpec("green") } },
      ...sla.kpiMatrix.map<ColDef<AppSlaRow>>((k) => ({
        colId: k.id,
        headerName: k.measure,
        headerTooltip: k.obligation,
        minWidth: 130,
        sortable: false,
        cellRenderer: RagCell,
        cellRendererParams: { buildSpec: cellSpec(k.id, k.measure, k.obligation) },
      })),
    ];
  }, [sla.kpiMatrix]);

  if (!loading && apps.length === 0)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Portfolio not found.</p>
        <Button asChild size="sm">
          <Link to="/sla">Back to SLA</Link>
        </Button>
      </div>
    );

  const rag = ragForPortfolio(sla.kpiMatrix, sla.estate, portfolioId);
  const worstApp = [...rows].sort((a, b) => b.red - a.red || b.amber - a.amber)[0];

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[{ label: "SLA", to: "/sla" }, { label: "Portfolios" }]}
        title={name}
        description={`Application-wise SLA · ${apps.length} applications × ${sla.kpiMatrix.length} measures`}
      />

      <div className="flex flex-wrap items-center gap-2">
        {([
          ["red", rag.red, "Red"],
          ["amber", rag.amber, "Amber"],
          ["green", rag.green, "Green"],
        ] as const).map(([tone, v, label]) => (
          <button
            key={tone}
            type="button"
            disabled={v === 0}
            onClick={() =>
              setDrill({
                title: `${label} SLA incidents`,
                subtitle: name,
                filter: { portfolioId, status: tone },
                section: "sla",
              })
            }
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium transition-colors",
              v > 0 && "hover:bg-secondary/60",
              tone === "red" && v > 0 && "border-red-500/40 bg-red-500/[0.06]"
            )}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: RAG_COLORS[tone] }} />
            {label}
            <span className={cn("num font-semibold", tone === "red" && "text-red-600 dark:text-red-400")}>{v}</span>
          </button>
        ))}
        <span className="ml-auto text-[11px] text-muted-foreground">
          Click any count or value for the incidents behind it
        </span>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Application-wise SLA</CardTitle>
          <CardDescription>
            One row per application, one column per contracted measure. Click a row to open the application's SLA view.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <DataGrid<AppSlaRow>
              height="auto"
              rowData={rows}
              columnDefs={cols}
              defaultColDef={{ sortable: true, resizable: true, flex: 1, minWidth: 70, suppressHeaderMenuButton: true }}
              context={{ onDrill: (spec: DrillSpec) => setDrill(spec) }}
              onRowClicked={(e) => e.data && navigate(`/sla/application/${e.data.appId}`)}
            />
          )}
        </CardContent>
      </Card>

      <SlaKpiTrendChart
        mode="portfolio"
        matrix={sla.kpiMatrix}
        appIds={apps.map((app) => app.id)}
        range={range}
        loading={loading}
        height={240}
      />

      {worstApp && (
        <AiInsight source="Compliance analysis">
          {rag.red > 0
            ? `${worstApp.name} carries the most pressure in ${name} — ${worstApp.red} red and ${worstApp.amber} amber measures. Open its SLA view for the incident-level evidence.`
            : `No red measures in ${name}; ${worstApp.name} has the thinnest headroom and is worth a glance.`}
        </AiInsight>
      )}

      <IncidentDrilldown spec={drill} onClose={() => setDrill(null)} />
    </div>
  );
}
