import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import {
  ArrowDownRight,
  ArrowUpRight,
  Inbox,
  GitPullRequestArrow,
  ShieldCheck,
  Timer,
  Users,
} from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import { CHART } from "@/shared/lib/chart";
import { cn, fmtNum } from "@/shared/lib/utils";
import { fetchProductivityData } from "@/application/governance/state/productivitySlice";
import { fetchQualityData } from "@/application/governance/state/qualitySlice";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { DeltaCell, GroupOpenCell, ReopenCountCell, TitleSubCell } from "@/application/governance/components/gridCells";
import type {
  AppFrictionRow,
  AutomationRecord,
  IndividualRow,
  PortfolioDeliveryRow,
} from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const PORTFOLIO_LINES: { key: string; color: string }[] = [
  { key: "Group Benefits", color: CHART.red },
  { key: "Wealth", color: CHART.blue },
  { key: "Advisor & Digital", color: CHART.violet },
  { key: "Corporate", color: CHART.green },
];

const DELIVERY_COLS: ColDef<PortfolioDeliveryRow>[] = [
  { field: "portfolio", headerName: "Portfolio", flex: 1.6, minWidth: 180, cellClass: "font-medium" },
  { field: "resources", headerName: "Resources", type: "rightAligned", maxWidth: 120 },
  { field: "resolved", headerName: "Resolved · QTD", type: "rightAligned", maxWidth: 140, valueFormatter: (p) => fmtNum(p.value) },
  {
    field: "throughput",
    headerName: "Throughput",
    headerTooltip: "Tickets resolved per resource per month (latest month)",
    type: "rightAligned",
    minWidth: 150,
    sort: "desc",
    valueFormatter: (p) => (p.value == null ? "" : `${p.value} /resource/mo`),
  },
  { field: "avgResolutionHrs", headerName: "Avg resolution", type: "rightAligned", maxWidth: 140, valueFormatter: (p) => `${p.value} h` },
  { field: "changeIncidents", headerName: "Change incidents", type: "rightAligned", maxWidth: 150 },
  { field: "changeIncidentsDeltaPct", headerName: "Δ q/q", cellRenderer: DeltaCell, maxWidth: 110 },
];

const PEOPLE_COLS: ColDef<IndividualRow>[] = [
  { field: "name", headerName: "Associate", flex: 1.5, minWidth: 180, cellRenderer: TitleSubCell, cellRendererParams: { subField: "portfolio" } },
  { field: "resolved", headerName: "Resolved", type: "rightAligned", maxWidth: 110, sort: "desc" },
  { field: "reopened", headerName: "Reopened", type: "rightAligned", maxWidth: 110 },
  { field: "avgHandleHrs", headerName: "Avg handle", type: "rightAligned", maxWidth: 120, valueFormatter: (p) => `${p.value} h` },
  { field: "csat", headerName: "CSAT", type: "rightAligned", maxWidth: 100, valueFormatter: (p) => `${p.value} / 5` },
  { field: "trendPct", headerName: "Trend", cellRenderer: DeltaCell, maxWidth: 110 },
];

const AUTOMATION_COLS: ColDef<AutomationRecord>[] = [
  { field: "name", headerName: "Automation", flex: 2, minWidth: 220 },
  { field: "tickets", headerName: "Tickets", type: "rightAligned", valueFormatter: (p) => fmtNum(p.value) },
  { field: "hoursSaved", headerName: "Hours saved", type: "rightAligned", valueFormatter: (p) => fmtNum(p.value) },
  { field: "successPct", headerName: "Success", type: "rightAligned", valueFormatter: (p) => `${Number(p.value).toFixed(1)}%` },
];

const REOPEN_APP_COLS: ColDef<AppFrictionRow>[] = [
  { field: "portfolio", rowGroup: true, hide: true },
  { field: "application", headerName: "Application", flex: 1.6, minWidth: 220, cellClass: "font-medium" },
  { field: "reopened", headerName: "Reopened · QTD", aggFunc: "sum", type: "rightAligned", maxWidth: 150, cellRenderer: ReopenCountCell, sort: "desc" },
  { field: "reopenRatePct", headerName: "Reopen rate", aggFunc: "avg", type: "rightAligned", maxWidth: 130, valueFormatter: (p) => (p.value == null ? "" : `${Number(p.value).toFixed(1)}%`) },
  { field: "avgHops", headerName: "Avg hops", aggFunc: "avg", type: "rightAligned", maxWidth: 110, valueFormatter: (p) => (p.value == null ? "" : Number(p.value).toFixed(1)) },
  { field: "fcrPct", headerName: "FCR", aggFunc: "avg", type: "rightAligned", maxWidth: 100, valueFormatter: (p) => (p.value == null ? "" : `${Number(p.value).toFixed(1)}%`) },
];

const REOPEN_PEOPLE_COLS: ColDef<IndividualRow>[] = [
  { field: "portfolio", rowGroup: true, hide: true },
  { field: "name", headerName: "Associate", flex: 1.6, minWidth: 200, cellClass: "font-medium" },
  { field: "reopened", headerName: "Reopened · QTD", aggFunc: "sum", type: "rightAligned", maxWidth: 150, cellRenderer: ReopenCountCell, sort: "desc" },
  { field: "resolved", headerName: "Resolved", aggFunc: "sum", type: "rightAligned", maxWidth: 120 },
  {
    headerName: "Reopen rate",
    type: "rightAligned",
    maxWidth: 130,
    valueGetter: (p) =>
      p.data && p.data.resolved > 0 ? Number(((p.data.reopened / p.data.resolved) * 100).toFixed(1)) : null,
    valueFormatter: (p) => (p.value == null ? "" : `${p.value}%`),
  },
  { field: "csat", headerName: "CSAT", type: "rightAligned", maxWidth: 100, valueFormatter: (p) => (p.value == null ? "" : `${p.value} / 5`) },
];

export function ProductivityPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const prod = useAppSelector((s) => s.governance.productivity);
  const quality = useAppSelector((s) => s.governance.quality);
  const sla = useAppSelector((s) => s.governance.sla);
  const [reopenView, setReopenView] = useState<"application" | "associate">("application");

  useEffect(() => {
    dispatch(fetchProductivityData(range));
    dispatch(fetchQualityData(range));
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const loading = prod.status !== "succeeded";
  const frictionLoading = sla.status !== "succeeded";

  const totals = useMemo(() => {
    const resources = prod.portfolios.reduce((n, p) => n + p.resources, 0);
    const resolved = prod.portfolios.reduce((n, p) => n + p.resolved, 0);
    const changeInc = prod.portfolios.reduce((n, p) => n + p.changeIncidents, 0);
    const latest = prod.throughputTrend[prod.throughputTrend.length - 1];
    return {
      resources,
      resolved,
      changeInc,
      throughput: latest ? Number(latest.Overall) : 0,
    };
  }, [prod.portfolios, prod.throughputTrend]);

  const top = useMemo(
    () => [...prod.individuals].sort((a, b) => b.resolved - a.resolved).slice(0, 3),
    [prod.individuals]
  );
  const bottom = useMemo(
    () => [...prod.individuals].sort((a, b) => a.resolved - b.resolved).slice(0, 3),
    [prod.individuals]
  );

  const reopenTotal = sla.friction.apps.reduce((n, a) => n + a.reopened, 0);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Productivity"
        description="Delivery by portfolio, the associates behind it, and what automation returns."
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <KpiCard label="Tickets resolved" value={loading ? "—" : fmtNum(totals.resolved)} icon={Inbox} loading={loading} hint="quarter to date" />
        <KpiCard
          label="Throughput"
          value={loading ? "—" : String(totals.throughput)}
          icon={Users}
          loading={loading}
          hint={`tickets resolved per resource per month · ${totals.resources} resources`}
        />
        <KpiCard label="Avg resolution" value={prod.summary ? `${prod.summary.avgResolutionHrs} h` : "—"} icon={Timer} loading={loading}
          trend={{ value: "−18%", direction: "down", positive: true }} />
        <KpiCard label="Change-induced incidents" value={loading ? "—" : String(totals.changeInc)} icon={GitPullRequestArrow} loading={loading}
          trend={{ value: "−28% q/q", direction: "down", positive: true }} />
        <KpiCard label="Incidents avoided" value={quality.summary ? String(quality.summary.avoidedQtd) : "—"} icon={ShieldCheck} loading={quality.status !== "succeeded"} hint={quality.summary ? `problem-record closures · ${quality.summary.avoidedYtd} YTD` : "problem-record closures"} />
      </div>

      <Tabs defaultValue="portfolios">
        <TabsList>
          <TabsTrigger value="portfolios">Portfolios</TabsTrigger>
          <TabsTrigger value="agents">Automation & agents</TabsTrigger>
        </TabsList>

        {/* -------------------------------- portfolios ----------------------------- */}
        <TabsContent value="portfolios" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Delivery by portfolio</CardTitle>
              <CardDescription>Throughput = tickets resolved per resource per month · click a row to open the portfolio</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-44 w-full" />
              ) : (
                <DataGrid<PortfolioDeliveryRow>
                  height="auto"
                  rowData={prod.portfolios}
                  columnDefs={DELIVERY_COLS}
                  onRowClicked={(e) => e.data && navigate(`/productivity/portfolio/${e.data.portfolioId}`)}
                />
              )}
            </CardContent>
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <ChartCard
              title="Throughput trend"
              subtitle="Tickets resolved per resource per month, by portfolio"
              loading={loading}
              height={250}
            >
              <ApacheEChart
                ariaLabel="Throughput trend by portfolio"
                option={{
                  grid: { top: 12, right: 16, bottom: 50, left: 42 },
                  tooltip: { trigger: "axis" },
                  legend: { bottom: 4, type: "scroll" },
                  xAxis: { type: "category", boundaryGap: false, data: prod.throughputTrend.map((point) => point.month), splitLine: { show: false } },
                  yAxis: { type: "value", min: 26, max: 40 },
                  series: [
                    ...PORTFOLIO_LINES.map((line) => ({ name: line.key, type: "line" as const, smooth: true, showSymbol: false, lineStyle: { width: 2, color: line.color }, itemStyle: { color: line.color }, data: prod.throughputTrend.map((point) => point[line.key]) })),
                    { name: "Overall", type: "line", smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.slate, type: "dashed" }, itemStyle: { color: CHART.slate }, data: prod.throughputTrend.map((point) => point.Overall) },
                  ],
                }}
              />
            </ChartCard>

            <ChartCard title="Incidents caused by change" subtitle="By portfolio, quarter to date — lower is better" loading={loading} height={250}>
              <ApacheEChart
                ariaLabel="Incidents caused by change by portfolio"
                option={{
                  grid: { top: 8, right: 20, bottom: 24, left: 130 },
                  tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
                  xAxis: { type: "value", minInterval: 1 },
                  yAxis: { type: "category", inverse: true, data: prod.portfolios.map((portfolio) => portfolio.portfolio), splitLine: { show: false } },
                  series: [{ name: "Change incidents", type: "bar", barMaxWidth: 18, itemStyle: { color: CHART.red, borderRadius: [0, 4, 4, 0] }, data: prod.portfolios.map((portfolio) => portfolio.changeIncidents) }],
                }}
              />
            </ChartCard>
          </div>

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Reopened tickets</CardTitle>
                <CardDescription>
                  {reopenView === "application"
                    ? "Where closures come back — Portfolio ▸ Application"
                    : "Who they come back to — Portfolio ▸ Associate"}
                  {!frictionLoading && ` · ${reopenTotal} reopened this quarter`}
                </CardDescription>
              </div>
              <div className="flex shrink-0 gap-1.5">
                {(["application", "associate"] as const).map((v) => (
                  <button
                    key={v}
                    onClick={() => setReopenView(v)}
                    className={cn(
                      "rounded-md border px-2.5 py-1 text-[11.5px] font-medium capitalize transition-colors",
                      reopenView === v
                        ? "border-brand/40 bg-brand-soft text-accent-foreground"
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    )}
                  >
                    By {v}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              {reopenView === "application" ? (
                frictionLoading ? (
                  <Skeleton className="h-64 w-full" />
                ) : (
                  <DataGrid<AppFrictionRow>
                    height={420}
                    rowData={sla.friction.apps}
                    columnDefs={REOPEN_APP_COLS}
                    groupDefaultExpanded={1}
                    suppressAggFuncInHeader
                    autoGroupColumnDef={{
                      headerName: "Portfolio",
                      minWidth: 220,
                      flex: 1.2,
                      cellRendererParams: { innerRenderer: GroupOpenCell, basePath: "/productivity/portfolio" },
                    }}
                    onRowClicked={(e) => {
                      if (e.node.group) e.node.setExpanded(!e.node.expanded);
                      else if (e.data) navigate(`/productivity/application/${e.data.appId}`);
                    }}
                  />
                )
              ) : loading ? (
                <Skeleton className="h-64 w-full" />
              ) : (
                <DataGrid<IndividualRow>
                  height={420}
                  rowData={prod.individuals}
                  columnDefs={REOPEN_PEOPLE_COLS}
                  groupDefaultExpanded={1}
                  suppressAggFuncInHeader
                  autoGroupColumnDef={{
                    headerName: "Portfolio",
                    minWidth: 220,
                    flex: 1.2,
                    cellRendererParams: { innerRenderer: GroupOpenCell, basePath: "/productivity/portfolio" },
                  }}
                  onRowClicked={(e) => e.node.group && e.node.setExpanded(!e.node.expanded)}
                />
              )}
            </CardContent>
          </Card>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-1.5">
                    <ArrowUpRight className="h-4 w-4 text-emerald-600" />
                    Top performers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {top.map((p, i) => (
                    <div key={p.id} className="flex items-center gap-2.5 rounded-md border px-3 py-2">
                      <span className="num grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-500/10 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        {i + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-semibold">{p.name}</p>
                        <p className="text-[10.5px] text-muted-foreground">{p.portfolio}</p>
                      </div>
                      <span className="num text-xs font-semibold">{p.resolved}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-1.5">
                    <ArrowDownRight className="h-4 w-4 text-amber-600" />
                    Needs attention
                  </CardTitle>
                  <CardDescription>Coaching queue for the portfolio leads</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {bottom.map((p) => (
                    <div key={p.id} className="flex items-center gap-2.5 rounded-md border px-3 py-2">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-semibold">{p.name}</p>
                        <p className="text-[10.5px] text-muted-foreground">
                          {p.portfolio} · {p.reopened} reopened
                        </p>
                      </div>
                      <span className="num text-xs font-semibold">{p.resolved}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Associate performance</CardTitle>
                <CardDescription>Sortable — resolved, reopened, handle time, CSAT</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <Skeleton className="h-72 w-full" />
                ) : (
                  <DataGrid<IndividualRow> height="auto" rowData={prod.individuals} columnDefs={PEOPLE_COLS} />
                )}
              </CardContent>
            </Card>
          </div>

          <ChartCard
            title="Incidents avoided via problem-record closures"
            subtitle="Monthly and cumulative"
            loading={quality.status !== "succeeded"}
            height={230}
          >
            <ApacheEChart
              ariaLabel="Monthly and cumulative incidents avoided"
              option={{
                grid: { top: 12, right: 48, bottom: 50, left: 42 },
                tooltip: { trigger: "axis" },
                legend: { bottom: 4 },
                xAxis: { type: "category", data: quality.avoidedTrend.map((point) => point.month), splitLine: { show: false } },
                yAxis: [{ type: "value" }, { type: "value", position: "right", splitLine: { show: false } }],
                series: [
                  { name: "Avoided / month", type: "bar", yAxisIndex: 0, barMaxWidth: 16, itemStyle: { color: CHART.green, borderRadius: [3, 3, 0, 0] }, data: quality.avoidedTrend.map((point) => point.avoided) },
                  { name: "Cumulative", type: "line", yAxisIndex: 1, smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.blue }, itemStyle: { color: CHART.blue }, data: quality.avoidedTrend.map((point) => point.cumulative) },
                ],
              }}
            />
          </ChartCard>

          <AiInsight source="Delivery analysis">
            Corporate leads throughput at 36.3 resolved per resource this
            month; Advisor & Digital has recovered its spring dip. Reopens
            concentrate on two associates in the coaching queue — both new
            joiners — and on Claims Processing, where the claim-status fix
            lands Jul 24.
          </AiInsight>
        </TabsContent>

        {/* ------------------------------ automation ------------------------------ */}
        <TabsContent value="agents" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <ChartCard title="Volume & resolution mix" subtitle="Monthly" loading={loading} height={240}>
              <ApacheEChart
                ariaLabel="Monthly volume and resolution mix"
                option={{
                  grid: { top: 12, right: 16, bottom: 50, left: 48 },
                  tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
                  legend: { bottom: 4 },
                  xAxis: { type: "category", data: prod.volumeTrend.map((point) => point.month), splitLine: { show: false } },
                  yAxis: { type: "value" },
                  series: [
                    { name: "Auto-resolved", type: "bar", stack: "volume", itemStyle: { color: CHART.green }, data: prod.volumeTrend.map((point) => point.autoResolved) },
                    { name: "AI-assisted", type: "bar", stack: "volume", itemStyle: { color: CHART.blue }, data: prod.volumeTrend.map((point) => point.aiAssisted) },
                    { name: "Manual", type: "bar", stack: "volume", itemStyle: { color: CHART.slate, borderRadius: [3, 3, 0, 0] }, data: prod.volumeTrend.map((point) => point.manual) },
                  ],
                }}
              />
            </ChartCard>

            <ChartCard title="Effort returned" subtitle="Cumulative hours saved by automation" loading={loading} height={240}>
              <ApacheEChart
                ariaLabel="Cumulative hours saved by automation"
                option={{
                  grid: { top: 12, right: 16, bottom: 28, left: 54 },
                  tooltip: { trigger: "axis" },
                  xAxis: { type: "category", boundaryGap: false, data: prod.savingsTrend.map((point) => point.month), splitLine: { show: false } },
                  yAxis: { type: "value" },
                  series: [{ name: "Hours", type: "line", smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.green }, itemStyle: { color: CHART.green }, areaStyle: { color: CHART.green, opacity: 0.14 }, data: prod.savingsTrend.map((point) => point.hours) }],
                }}
              />
            </ChartCard>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Top automations</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-44 w-full" />
              ) : (
                <DataGrid<AutomationRecord> height="auto" rowData={prod.topAutomations} columnDefs={AUTOMATION_COLS} />
              )}
            </CardContent>
          </Card>

          <AiInsight source="Automation analysis">
            Password resets and batch restarts account for 61% of auto-resolved
            volume. Next best candidates: claim document re-index (≈140 h/qtr)
            and advisor access provisioning (≈90 h/qtr).
          </AiInsight>
        </TabsContent>
      </Tabs>
    </div>
  );
}
