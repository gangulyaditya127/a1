import { useEffect, useMemo } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import { Boxes, GitPullRequestArrow, Inbox, Users } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { fmtNum } from "@/shared/lib/utils";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { fetchProductivityData } from "@/application/governance/state/productivitySlice";
import {
  DeltaCell,
  ReopenCountCell,
} from "@/application/governance/components/gridCells";
import type { AppFrictionRow, IndividualRow } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const PEOPLE_COLS: ColDef<IndividualRow>[] = [
  { field: "name", headerName: "Associate", flex: 1.5, minWidth: 180, cellClass: "font-medium" },
  { field: "resolved", headerName: "Resolved", type: "rightAligned", maxWidth: 110, sort: "desc" },
  { field: "reopened", headerName: "Reopened", type: "rightAligned", maxWidth: 110 },
  { field: "avgHandleHrs", headerName: "Avg handle", type: "rightAligned", maxWidth: 120, valueFormatter: (p) => `${p.value} h` },
  { field: "csat", headerName: "CSAT", type: "rightAligned", maxWidth: 100, valueFormatter: (p) => `${p.value} / 5` },
  { field: "trendPct", headerName: "Trend", cellRenderer: DeltaCell, maxWidth: 110 },
];

const REOPEN_COLS: ColDef<AppFrictionRow>[] = [
  { field: "application", headerName: "Application", flex: 1.6, minWidth: 220, cellClass: "font-medium" },
  { field: "resolvedQtd", headerName: "Resolved · QTD", type: "rightAligned", maxWidth: 140, valueFormatter: (p) => fmtNum(p.value) },
  { field: "reopened", headerName: "Reopened · QTD", type: "rightAligned", maxWidth: 150, cellRenderer: ReopenCountCell, sort: "desc" },
  { field: "reopenRatePct", headerName: "Reopen rate", type: "rightAligned", maxWidth: 130, valueFormatter: (p) => `${Number(p.value).toFixed(1)}%` },
  { field: "fcrPct", headerName: "FCR", type: "rightAligned", maxWidth: 100, valueFormatter: (p) => `${Number(p.value).toFixed(1)}%` },
];

export function ProductivityPortfolioPage() {
  const { portfolioId = "" } = useParams();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const prod = useAppSelector((s) => s.governance.productivity);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchProductivityData(range));
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const loading = prod.status !== "succeeded";
  const frictionLoading = sla.status !== "succeeded";

  const delivery = prod.portfolios.find((p) => p.portfolioId === portfolioId);
  const name = delivery?.portfolio ?? "";

  const associates = useMemo(
    () => prod.individuals.filter((p) => p.portfolioId === portfolioId),
    [prod.individuals, portfolioId]
  );
  const frictionApps = useMemo(
    () => sla.friction.apps.filter((a) => a.portfolioId === portfolioId),
    [sla.friction.apps, portfolioId]
  );

  const throughputData = useMemo(
    () =>
      prod.throughputTrend.map((m) => ({
        month: m.month,
        [name]: m[name],
        Overall: m.Overall,
      })),
    [prod.throughputTrend, name]
  );

  if (!loading && !delivery)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Portfolio not found.</p>
        <Button asChild size="sm">
          <Link to="/productivity">Back to Productivity</Link>
        </Button>
      </div>
    );

  const worstAssociate = [...associates].sort((a, b) => b.reopened - a.reopened)[0];

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[{ label: "Productivity", to: "/productivity" }, { label: "Portfolios" }]}
        title={name || "…"}
        description={delivery ? `${delivery.resources} resources · ${associates.length} named associates` : undefined}
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard label="Tickets resolved" value={delivery ? fmtNum(delivery.resolved) : "—"} icon={Inbox} loading={loading} hint="quarter to date" />
        <KpiCard
          label="Throughput"
          value={delivery ? String(delivery.throughput) : "—"}
          icon={Users}
          loading={loading}
          hint={delivery ? `tickets resolved per resource per month · ${delivery.resources} resources` : undefined}
        />
        <KpiCard label="Avg resolution" value={delivery ? `${delivery.avgResolutionHrs} h` : "—"} icon={Boxes} loading={loading} />
        <KpiCard
          label="Change-induced incidents"
          value={delivery ? String(delivery.changeIncidents) : "—"}
          icon={GitPullRequestArrow}
          loading={loading}
          trend={delivery ? { value: `${delivery.changeIncidentsDeltaPct > 0 ? "+" : ""}${delivery.changeIncidentsDeltaPct}% q/q`, direction: delivery.changeIncidentsDeltaPct <= 0 ? "down" : "up", positive: delivery.changeIncidentsDeltaPct <= 0 } : undefined}
        />
      </div>

      <ChartCard
        title="Throughput trend"
        subtitle={`Tickets resolved per resource per month — ${name} vs overall`}
        loading={loading}
        height={250}
      >
        <ApacheEChart
          ariaLabel="Portfolio throughput trend"
          option={{
            grid: { top: 12, right: 16, bottom: 50, left: 42 },
            tooltip: { trigger: "axis" },
            legend: { bottom: 4 },
            xAxis: { type: "category", boundaryGap: false, data: throughputData.map((point) => point.month), splitLine: { show: false } },
            yAxis: { type: "value", min: 26, max: 40 },
            series: [
              { name, type: "line", smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.red }, itemStyle: { color: CHART.red }, data: throughputData.map((point) => point[name]) },
              { name: "Overall", type: "line", smooth: true, showSymbol: false, lineStyle: { width: 2, color: CHART.slate, type: "dashed" }, itemStyle: { color: CHART.slate }, data: throughputData.map((point) => point.Overall) },
            ],
          }}
        />
      </ChartCard>

      <Card>
        <CardHeader>
          <CardTitle>Reopens by application</CardTitle>
          <CardDescription>Click an application to open its productivity view</CardDescription>
        </CardHeader>
        <CardContent>
          {frictionLoading ? (
            <Skeleton className="h-52 w-full" />
          ) : (
            <DataGrid<AppFrictionRow>
              height="auto"
              rowData={frictionApps}
              columnDefs={REOPEN_COLS}
              onRowClicked={(e) => e.data && navigate(`/productivity/application/${e.data.appId}`)}
            />
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Associates</CardTitle>
          <CardDescription>Named associates working {name}</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-44 w-full" />
          ) : associates.length === 0 ? (
            <p className="rounded-md border border-dashed px-3 py-8 text-center text-xs text-muted-foreground">
              No named associates recorded for this portfolio.
            </p>
          ) : (
            <DataGrid<IndividualRow> height="auto" rowData={associates} columnDefs={PEOPLE_COLS} />
          )}
        </CardContent>
      </Card>

      {worstAssociate && (
        <AiInsight source="Delivery analysis">
          {worstAssociate.reopened >= 5
            ? `${worstAssociate.name} accounts for the largest share of reopens in ${name} (${worstAssociate.reopened} QTD) — flagged in the coaching queue.`
            : `Reopens are evenly spread across the ${name} associates; throughput is tracking ${delivery && delivery.throughput >= 32 ? "above" : "near"} the blended overall line.`}
        </AiInsight>
      )}
    </div>
  );
}
