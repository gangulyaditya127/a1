import { useEffect, useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { CheckCheck, Inbox, Layers, RotateCcw } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Button } from "@/shared/ui/button";
import { CHART } from "@/shared/lib/chart";
import { fmtNum } from "@/shared/lib/utils";
import { appResolvedTrend } from "@/application/governance/data/frictionData";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

export function ProductivityApplicationPage() {
  const { appId = "" } = useParams();
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const app = sla.estate.find((a) => a.id === appId);
  const loading = sla.status !== "succeeded";
  const friction = sla.friction.apps.find((a) => a.appId === appId);
  const resolvedTrend = useMemo(() => (app ? appResolvedTrend(app.id) : []), [app]);

  if (!loading && !app)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Application not found.</p>
        <Button asChild size="sm">
          <Link to="/productivity">Back to Productivity</Link>
        </Button>
      </div>
    );

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[
          { label: "Productivity", to: "/productivity" },
          { label: app?.portfolio ?? "…", to: app ? `/productivity/portfolio/${app.portfolioId}` : undefined },
        ]}
        title={app?.name ?? "…"}
        description={app ? `${app.tier} · Owner ${app.owner.name}` : undefined}
        actions={app ? <StatusBadge status={app.risk} /> : undefined}
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard label="Tickets resolved" value={friction ? fmtNum(friction.resolvedQtd) : "—"} icon={Inbox} loading={loading} hint="quarter to date" />
        <KpiCard label="Reopened" value={friction ? String(friction.reopened) : "—"} icon={RotateCcw} loading={loading} hint="quarter to date" />
        <KpiCard label="Reopen rate" value={friction ? `${friction.reopenRatePct}%` : "—"} icon={Layers} loading={loading} hint="of resolved tickets" />
        <KpiCard label="First contact resolution" value={friction ? `${friction.fcrPct}%` : "—"} icon={CheckCheck} loading={loading} hint="target ≥ 70%" />
      </div>

      <ChartCard title="Tickets resolved" subtitle="Monthly, this application — the reopen rate is computed over the last three months" loading={loading} height={250}>
        <ApacheEChart
          ariaLabel="Monthly tickets resolved"
          option={{
            grid: { top: 12, right: 16, bottom: 28, left: 46 },
            tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
            xAxis: { type: "category", data: resolvedTrend.map((point) => point.month), splitLine: { show: false } },
            yAxis: { type: "value", minInterval: 1 },
            series: [{ name: "Resolved", type: "bar", barMaxWidth: 20, itemStyle: { color: CHART.green, borderRadius: [3, 3, 0, 0] }, data: resolvedTrend.map((point) => point.resolved) }],
          }}
        />
      </ChartCard>

      <AiInsight source="Delivery analysis">
        {friction && friction.reopenRatePct >= 6
          ? `Reopen rate is running at ${friction.reopenRatePct}% — above the 5% comfort line. Coaching on closure quality and the pending permanent fix should pull it back.`
          : `Reopen rate is inside the 5% comfort line; resolved volume is trending up without a quality trade-off.`}
      </AiInsight>
    </div>
  );
}
