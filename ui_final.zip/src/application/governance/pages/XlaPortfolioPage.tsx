import { useEffect, useMemo } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import { CheckCheck, Route, RotateCcw } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { MONTHS } from "@/application/governance/data/slaData";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { ReopenCountCell, SentimentCell } from "@/application/governance/components/gridCells";
import type { AppFrictionRow, UserComment } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const FRICTION_COLS: ColDef<AppFrictionRow>[] = [
  { field: "application", headerName: "Application", flex: 1.6, minWidth: 220, cellClass: "font-medium" },
  { field: "reopened", headerName: "Reopened · QTD", type: "rightAligned", maxWidth: 150, cellRenderer: ReopenCountCell, sort: "desc" },
  { field: "reopenRatePct", headerName: "Reopen rate", type: "rightAligned", maxWidth: 130, valueFormatter: (p) => `${Number(p.value).toFixed(1)}%` },
  { field: "avgHops", headerName: "Avg hops", type: "rightAligned", maxWidth: 110, headerTooltip: "Average assignment hand-offs before resolution", valueFormatter: (p) => Number(p.value).toFixed(1) },
  { field: "fcrPct", headerName: "FCR", type: "rightAligned", maxWidth: 100, headerTooltip: "Resolved at first contact", valueFormatter: (p) => `${Number(p.value).toFixed(1)}%` },
];

const COMMENT_COLS: ColDef<UserComment>[] = [
  { field: "when", headerName: "Date", maxWidth: 90 },
  { field: "application", headerName: "Application", minWidth: 160 },
  { field: "rating", headerName: "CSAT", type: "rightAligned", maxWidth: 90, valueFormatter: (p) => `${p.value} / 5` },
  { field: "sentiment", headerName: "Sentiment", cellRenderer: SentimentCell, maxWidth: 120 },
  { field: "text", headerName: "Comment", flex: 3, minWidth: 300, wrapText: true, autoHeight: true, cellClass: "leading-snug py-2" },
];

export function XlaPortfolioPage() {
  const { portfolioId = "" } = useParams();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const apps = useMemo(
    () => sla.estate.filter((a) => a.portfolioId === portfolioId),
    [sla.estate, portfolioId]
  );
  const loading = sla.status !== "succeeded";
  const name = apps[0]?.portfolio ?? "";

  const frictionApps = useMemo(
    () => sla.friction.apps.filter((a) => a.portfolioId === portfolioId),
    [sla.friction.apps, portfolioId]
  );
  const comments = useMemo(
    () => sla.sentiment.comments.filter((c) => c.portfolio === name),
    [sla.sentiment.comments, name]
  );

  const fr = useMemo(() => {
    const n = frictionApps.length || 1;
    return {
      reopened: frictionApps.reduce((a, f) => a + f.reopened, 0),
      fcr: Number((frictionApps.reduce((a, f) => a + f.fcrPct, 0) / n).toFixed(1)),
      hops: Number((frictionApps.reduce((a, f) => a + f.avgHops, 0) / n).toFixed(1)),
    };
  }, [frictionApps]);

  const trendData = useMemo(
    () =>
      MONTHS.map((month, i) => ({
        month,
        xla: apps.length
          ? Math.round(apps.reduce((n, a) => n + a.xlaSeries[i], 0) / apps.length)
          : null,
      })),
    [apps]
  );

  if (!loading && apps.length === 0)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Portfolio not found.</p>
        <Button asChild size="sm">
          <Link to="/xla">Back to XLA</Link>
        </Button>
      </div>
    );

  const worst = [...frictionApps].sort((a, b) => b.reopened - a.reopened)[0];

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[{ label: "XLA", to: "/xla" }, { label: "Portfolios" }]}
        title={name}
        description={`Experience and friction · ${apps.length} applications`}
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <RotateCcw className="h-3.5 w-3.5 text-red-600" />
              <p className="text-xs font-medium text-muted-foreground">Reopened incidents</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold text-red-600 dark:text-red-400">{fr.reopened}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">quarter to date</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <CheckCheck className="h-3.5 w-3.5 text-emerald-600" />
              <p className="text-xs font-medium text-muted-foreground">First contact resolution</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{fr.fcr}%</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">target ≥ 70%</p>
          </CardContent>
        </Card>
        <Card className="col-span-2 xl:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <Route className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-xs font-medium text-muted-foreground">Avg assignment hops</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold">{fr.hops}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">hand-offs before resolution</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Friction by application</CardTitle>
            <CardDescription>Click an application to open its XLA view</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-52 w-full" />
            ) : (
              <DataGrid<AppFrictionRow>
                height="auto"
                rowData={frictionApps}
                columnDefs={FRICTION_COLS}
                onRowClicked={(e) => e.data && navigate(`/xla/application/${e.data.appId}`)}
              />
            )}
          </CardContent>
        </Card>

        <ChartCard title="Experience trend" subtitle="Mean XLA of applications · target 85" loading={loading} height={280}>
          <ApacheEChart
            ariaLabel="Portfolio experience trend"
            option={{
              grid: { top: 12, right: 16, bottom: 28, left: 42 },
              tooltip: { trigger: "axis" },
              xAxis: { type: "category", boundaryGap: false, data: trendData.map((point) => point.month), splitLine: { show: false } },
              yAxis: { type: "value", min: 68, max: 96 },
              series: [{
                name: "XLA",
                type: "line",
                smooth: true,
                showSymbol: false,
                lineStyle: { width: 2, color: CHART.blue },
                itemStyle: { color: CHART.blue },
                data: trendData.map((point) => point.xla),
                markLine: { silent: true, symbol: "none", label: { show: false }, lineStyle: { color: CHART.sky, type: "dashed" }, data: [{ yAxis: 85 }] },
              }],
            }}
          />
        </ChartCard>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent comments</CardTitle>
          <CardDescription>Survey comments from {name} users</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-40 w-full" />
          ) : comments.length === 0 ? (
            <p className="rounded-md border border-dashed px-3 py-8 text-center text-xs text-muted-foreground">
              No survey comments for this portfolio in the current window.
            </p>
          ) : (
            <DataGrid<UserComment> height="auto" rowData={comments} columnDefs={COMMENT_COLS} />
          )}
        </CardContent>
      </Card>

      {worst && (
        <AiInsight source="Experience analysis">
          {worst.reopened >= 8
            ? `${worst.application} drives most of the reopens in ${name} (${worst.reopened} QTD) — the same tickets surfacing in negative comments.`
            : `Friction is spread thin across ${name}; no single application dominates the reopen count.`}
        </AiInsight>
      )}
    </div>
  );
}
