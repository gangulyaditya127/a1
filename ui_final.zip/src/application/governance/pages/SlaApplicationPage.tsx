import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import { X } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { cn } from "@/shared/lib/utils";
import { incidentsFor } from "@/application/governance/data/slaData";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import {
  DurationCell,
  OutcomeCell,
} from "@/application/governance/components/IncidentDrilldown";
import { SlaKpiTrendChart } from "@/application/governance/components/SlaKpiTrendChart";
import type { IncidentRecord, RagStatus } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const RAG_COLORS = { red: "#dc2626", amber: "#d97706", green: "#059669" };
const RAG_DOT: Record<RagStatus, string> = {
  red: "bg-red-500",
  amber: "bg-amber-500",
  green: "bg-emerald-500",
};
const RAG_LABEL: Record<RagStatus, string> = { red: "Red", amber: "Amber", green: "Green" };

interface AppKpiRow {
  id: string;
  measure: string;
  obligation: string;
  targetPct: number;
  actualPct: number;
  status: RagStatus;
}

const KPI_COLS: ColDef<AppKpiRow>[] = [
  { field: "measure", headerName: "KPI measure", flex: 1.2, minWidth: 160, cellClass: "font-medium" },
  { field: "obligation", headerName: "Obligation", flex: 1.8, minWidth: 240, cellClass: "text-muted-foreground text-[12px]" },
  {
    field: "actualPct",
    headerName: "Actual",
    type: "rightAligned",
    maxWidth: 110,
    cellRenderer: (p: { value: number | null; data?: AppKpiRow }) =>
      p.value == null ? null : (
        <span className={`num text-xs ${p.data?.status === "red" ? "font-semibold text-red-600 dark:text-red-400" : "font-medium"}`}>
          {p.value}%
        </span>
      ),
  },
  {
    field: "status",
    headerName: "Status",
    maxWidth: 120,
    cellRenderer: (p: { value: RagStatus | null }) =>
      p.value ? (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium">
          <span className={`h-2 w-2 rounded-full ${RAG_DOT[p.value]}`} />
          {RAG_LABEL[p.value]}
        </span>
      ) : null,
    comparator: (a: RagStatus, b: RagStatus) => {
      const rank = { red: 0, amber: 1, green: 2 };
      return rank[a] - rank[b];
    },
  },
];

const INCIDENT_COLS: ColDef<IncidentRecord>[] = [
  { field: "id", headerName: "Incident", maxWidth: 125, cellClass: "num font-semibold" },
  { field: "measure", headerName: "Measure", flex: 1.1, minWidth: 160 },
  { field: "priority", headerName: "Priority", maxWidth: 95 },
  { field: "openedAt", headerName: "Opened", maxWidth: 130 },
  { headerName: "Duration vs target", cellRenderer: DurationCell, minWidth: 190, flex: 1 },
  { field: "outcome", headerName: "Outcome", cellRenderer: OutcomeCell, maxWidth: 110 },
];

export function SlaApplicationPage() {
  const { appId = "" } = useParams();
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const [kpiFilter, setKpiFilter] = useState<{ id: string; measure: string } | null>(null);
  const [statusFilter, setStatusFilter] = useState<RagStatus | null>(null);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const app = sla.estate.find((a) => a.id === appId);
  const loading = sla.status !== "succeeded";

  const kpis = useMemo<AppKpiRow[]>(
    () =>
      sla.kpiMatrix
        .filter((row) => row.cells[appId])
        .map((row) => ({
          id: row.id,
          measure: row.measure,
          obligation: row.obligation,
          targetPct: row.targetPct,
          actualPct: row.cells[appId].actualPct,
          status: row.cells[appId].status,
        })),
    [sla.kpiMatrix, appId]
  );

  const counts = useMemo(
    () =>
      kpis.reduce(
        (acc, k) => ({ ...acc, [k.status]: acc[k.status] + 1 }),
        { red: 0, amber: 0, green: 0 } as Record<RagStatus, number>
      ),
    [kpis]
  );

  /** The evidence: every ticket that entered this application's SLA calculation. */
  const incidents = useMemo(
    () =>
      incidentsFor({
        appId,
        kpiId: kpiFilter?.id,
        status: statusFilter ?? undefined,
      }),
    [appId, kpiFilter, statusFilter]
  );
  const breached = incidents.filter((i) => i.outcome === "Breached").length;

  if (!loading && !app)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Application not found.</p>
        <Button asChild size="sm">
          <Link to="/sla">Back to SLA</Link>
        </Button>
      </div>
    );

  const filtered = kpiFilter !== null || statusFilter !== null;

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[
          { label: "SLA", to: "/sla" },
          { label: app?.portfolio ?? "…", to: app ? `/sla/portfolio/${app.portfolioId}` : undefined },
        ]}
        title={app?.name ?? "…"}
        description={app ? `${app.tier} · Owner ${app.owner.name}` : undefined}
        actions={app ? <StatusBadge status={app.risk} /> : undefined}
      />

      <div className="flex flex-wrap items-center gap-2">
        {([
          ["red", counts.red, "Red"],
          ["amber", counts.amber, "Amber"],
          ["green", counts.green, "Green"],
        ] as const).map(([tone, v, label]) => (
          <button
            key={tone}
            type="button"
            onClick={() => setStatusFilter((f) => (f === tone ? null : tone))}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium transition-colors hover:bg-secondary/60",
              tone === "red" && v > 0 && "border-red-500/40 bg-red-500/[0.06]",
              statusFilter === tone && "ring-2 ring-brand/50"
            )}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: RAG_COLORS[tone] }} />
            {label}
            <span className={cn("num font-semibold", tone === "red" && "text-red-600 dark:text-red-400")}>{v}</span>
          </button>
        ))}
        <span className="ml-auto text-[11px] text-muted-foreground">
          Click a status or an obligation row to filter the incident evidence below
        </span>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Service levels</CardTitle>
          <CardDescription>Contracted SLA rule order · click a row to see the incidents behind it</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-52 w-full" />
          ) : (
            <DataGrid<AppKpiRow>
              height="auto"
              rowData={kpis}
              columnDefs={KPI_COLS}
              onRowClicked={(e) =>
                e.data &&
                setKpiFilter((f) =>
                  f?.id === e.data!.id ? null : { id: e.data!.id, measure: e.data!.measure }
                )
              }
            />
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle>Incidents behind these values</CardTitle>
            <CardDescription>
              Every ticket that entered the SLA calculation this period —{" "}
              {loading ? "…" : `${incidents.length} incident${incidents.length === 1 ? "" : "s"} · ${breached} breached`}
            </CardDescription>
          </div>
          {filtered && (
            <div className="flex shrink-0 flex-wrap justify-end gap-1.5">
              {kpiFilter && (
                <button
                  onClick={() => setKpiFilter(null)}
                  className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  {kpiFilter.measure}
                  <X className="h-3 w-3" />
                </button>
              )}
              {statusFilter && (
                <button
                  onClick={() => setStatusFilter(null)}
                  className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-medium capitalize text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  {statusFilter} only
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          )}
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full" />
          ) : incidents.length === 0 ? (
            <p className="rounded-md border border-dashed px-3 py-10 text-center text-xs text-muted-foreground">
              No incidents match the current filters.
            </p>
          ) : (
            <DataGrid<IncidentRecord> height={380} rowData={incidents} columnDefs={INCIDENT_COLS} />
          )}
        </CardContent>
      </Card>

      <SlaKpiTrendChart
        mode="application"
        matrix={sla.kpiMatrix}
        appId={appId}
        range={range}
        loading={loading}
        height={240}
      />

      <AiInsight source="Compliance analysis">
        {counts.red > 0
          ? `${counts.red} obligation${counts.red > 1 ? "s are" : " is"} red for ${app?.name ?? "this application"} — the breached incidents above are the exact tickets pulling the percentages down.`
          : `All obligations are met for ${app?.name ?? "this application"}; the incident list shows the volume the percentages are computed over.`}
      </AiInsight>
    </div>
  );
}
