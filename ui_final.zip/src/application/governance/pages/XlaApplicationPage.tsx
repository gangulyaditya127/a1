import { useEffect, useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import type { ColDef } from "ag-grid-community";
import { CheckCheck, Layers, Route, RotateCcw } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { CHART } from "@/shared/lib/chart";
import { MONTHS } from "@/application/governance/data/slaData";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { SentimentCell } from "@/application/governance/components/gridCells";
import type { UserComment } from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const COMMENT_COLS: ColDef<UserComment>[] = [
  { field: "when", headerName: "Date", maxWidth: 90 },
  { field: "rating", headerName: "CSAT", type: "rightAligned", maxWidth: 90, valueFormatter: (p) => `${p.value} / 5` },
  { field: "sentiment", headerName: "Sentiment", cellRenderer: SentimentCell, maxWidth: 120 },
  { field: "text", headerName: "Comment", flex: 3, minWidth: 300, wrapText: true, autoHeight: true, cellClass: "leading-snug py-2" },
];

export function XlaApplicationPage() {
  const { appId = "" } = useParams();
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const app = sla.estate.find((a) => a.id === appId);
  const loading = sla.status !== "succeeded";
  const friction = sla.friction.apps.find((a) => a.appId === appId);

  const comments = useMemo(
    () =>
      app ? sla.sentiment.comments.filter((c) => c.application.includes(app.name)) : [],
    [sla.sentiment.comments, app]
  );

  const trendData = useMemo(
    () => MONTHS.map((month, i) => ({ month, xla: app?.xlaSeries[i] ?? null })),
    [app]
  );

  if (!loading && !app)
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
        <p className="text-sm text-muted-foreground">Application not found.</p>
        <Button asChild size="sm">
          <Link to="/xla">Back to XLA</Link>
        </Button>
      </div>
    );

  return (
    <div className="space-y-4">
      <PageHeader
        crumbs={[
          { label: "XLA", to: "/xla" },
          { label: app?.portfolio ?? "…", to: app ? `/xla/portfolio/${app.portfolioId}` : undefined },
        ]}
        title={app?.name ?? "…"}
        description={app ? `${app.tier} · Owner ${app.owner.name}` : undefined}
        actions={app ? <StatusBadge status={app.risk} /> : undefined}
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <RotateCcw className="h-3.5 w-3.5 text-red-600" />
              <p className="text-xs font-medium text-muted-foreground">Reopened incidents</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold text-red-600 dark:text-red-400">{friction?.reopened ?? "—"}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">quarter to date</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <Layers className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-xs font-medium text-muted-foreground">Reopen rate</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold">{friction ? `${friction.reopenRatePct}%` : "—"}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">of resolved tickets</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <Route className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-xs font-medium text-muted-foreground">Avg assignment hops</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold">{friction?.avgHops ?? "—"}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">hand-offs before resolution</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-1.5">
              <CheckCheck className="h-3.5 w-3.5 text-emerald-600" />
              <p className="text-xs font-medium text-muted-foreground">First contact resolution</p>
            </div>
            {loading ? <Skeleton className="mt-2 h-7 w-14" /> : (
              <p className="num mt-1 text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{friction ? `${friction.fcrPct}%` : "—"}</p>
            )}
            <p className="mt-0.5 text-[10.5px] text-muted-foreground">target ≥ 70%</p>
          </CardContent>
        </Card>
      </div>

      <ChartCard title="Experience trend" subtitle="Monthly XLA · target 85" loading={loading} height={240}>
        <ApacheEChart
          ariaLabel="Monthly application experience trend"
          option={{
            grid: { top: 12, right: 16, bottom: 28, left: 42 },
            tooltip: { trigger: "axis" },
            xAxis: { type: "category", boundaryGap: false, data: trendData.map((point) => point.month), splitLine: { show: false } },
            yAxis: { type: "value", min: 68, max: 96 },
            series: [{
              name: "XLA",
              type: "line",
              smooth: true,
              showSymbol: false,
              lineStyle: { width: 2, color: CHART.blue },
              itemStyle: { color: CHART.blue },
              data: trendData.map((point) => point.xla),
              markLine: { silent: true, symbol: "none", label: { show: false }, lineStyle: { color: CHART.sky, type: "dashed" }, data: [{ yAxis: 85 }] },
            }],
          }}
        />
      </ChartCard>

      <Card>
        <CardHeader>
          <CardTitle>Recent comments</CardTitle>
          <CardDescription>Survey comments mentioning {app?.name}</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-40 w-full" />
          ) : comments.length === 0 ? (
            <p className="rounded-md border border-dashed px-3 py-8 text-center text-xs text-muted-foreground">
              No survey comments for this application in the current window.
            </p>
          ) : (
            <DataGrid<UserComment> height="auto" rowData={comments} columnDefs={COMMENT_COLS} />
          )}
        </CardContent>
      </Card>

      <AiInsight source="Experience analysis">
        {friction && friction.reopened >= 8
          ? `${app?.name ?? "This application"} reopens ${friction.reopened} tickets a quarter at ${friction.avgHops} hops on average — the friction users describe in the comments above.`
          : `Friction is low for ${app?.name ?? "this application"}; first-contact resolution at ${friction?.fcrPct ?? "—"}% is holding above target.`}
      </AiInsight>
    </div>
  );
}
