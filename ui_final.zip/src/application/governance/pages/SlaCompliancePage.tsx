import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import type { ColDef, ColGroupDef, ICellRendererParams } from "ag-grid-community";
import { BellRing, RefreshCw } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { DataGrid } from "@/shared/components/DataGrid";
import { PageHeader } from "@/shared/components/PageHeader";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import { cn } from "@/shared/lib/utils";
import {
  fetchSlaData,
  notifyWindow,
  refreshLiveRisks,
  toggleDigest,
} from "@/application/governance/state/slaSlice";
import { IncidentDrilldown } from "@/application/governance/components/IncidentDrilldown";
import {
  AppHeader,
  EtaCell,
  NotifyCell,
  PortfolioGroupHeader,
  ProbabilityCell,
  RagCell,
  RagCountCell,
  TitleSubCell,
  WindowCell,
} from "@/application/governance/components/gridCells";
import type {
  BreachWindow,
  DrillSpec,
  LiveBreachRisk,
  RagStatus,
  SlaKpiRow,
} from "@/application/governance/types";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const RAG_COLORS = { red: "#dc2626", amber: "#d97706", green: "#059669" };
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** Live breach feed — incident-first, as it lands in the ITSM queue. */
const LIVE_COLS: ColDef<LiveBreachRisk>[] = [
  { field: "incident", headerName: "Incident", minWidth: 125, maxWidth: 135, cellClass: "num font-semibold", pinned: "left" },
  { field: "application", headerName: "Application", flex: 1.3, minWidth: 170, cellRenderer: TitleSubCell, cellRendererParams: { subField: "portfolio" } },
  { field: "metric", headerName: "SLA at risk", flex: 1.3, minWidth: 180, cellRenderer: TitleSubCell, cellRendererParams: { subField: "driver" } },
  { field: "priority", headerName: "Priority", maxWidth: 95 },
  { field: "assignmentGroup", headerName: "Assignment group", minWidth: 190 },
  { field: "assignee", headerName: "Assignee", minWidth: 140 },
  { field: "etaMin", headerName: "SLA miss in", cellRenderer: EtaCell, maxWidth: 120, sort: "asc", headerTooltip: "Minutes until the SLA is missed at current pace" },
  { field: "windowMin", headerName: "Window", cellRenderer: WindowCell, maxWidth: 105 },
  { field: "probability", headerName: "Probability", cellRenderer: ProbabilityCell, minWidth: 135 },
  { headerName: "", cellRenderer: NotifyCell, minWidth: 160, sortable: false, resizable: false },
];

const WINDOWS: { label: string; value: BreachWindow | "all" }[] = [
  { label: "All", value: "all" },
  { label: "30 min", value: 30 },
  { label: "1 h", value: 60 },
  { label: "2 h", value: 120 },
  { label: "3 h", value: 180 },
];

export function SlaCompliancePage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get("tab") === "live" ? "live" : "obligations";
  const [window, setWindow] = useState<BreachWindow | "all">("all");
  const [drill, setDrill] = useState<DrillSpec | null>(null);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const loading = sla.status !== "succeeded";
  const counts = sla.statusCounts;
  const widestRedRule = sla.kpiMatrix.reduce<SlaKpiRow | undefined>(
    (widest, rule) =>
      !widest || rule.red > widest.red || (rule.red === widest.red && rule.amber > widest.amber)
        ? rule
        : widest,
    undefined
  );
  const widestRedApplications = widestRedRule
    ? sla.estate
        .filter((app) => widestRedRule.cells[app.id]?.status === "red")
        .slice(0, 2)
        .map((app) => app.name)
    : [];

  /* -------- SLA matrix columns: portfolio groups ▸ application columns ------ */
  const matrixCountSpec = (rag: RagStatus) => (params: ICellRendererParams): DrillSpec | null => {
    const row = params.data as SlaKpiRow | undefined;
    if (!row) return null;
    return { title: `${cap(rag)} — ${row.measure}`, subtitle: row.obligation, filter: { kpiId: row.id, status: rag }, section: "sla" };
  };

  const matrixCellSpec = (params: ICellRendererParams): DrillSpec | null => {
    const row = params.data as SlaKpiRow | undefined;
    const appId = params.colDef?.colId;
    if (!row || !appId || !row.cells[appId]) return null;
    return {
      title: row.measure,
      subtitle: `${params.colDef?.headerName ?? "Application"} · ${row.obligation}`,
      filter: { kpiId: row.id, appId },
      section: "sla",
    };
  };

  const matrixCols = useMemo<(ColDef<SlaKpiRow> | ColGroupDef<SlaKpiRow>)[]>(() => {
    const visible = new Set(sla.redRankedAppIds.slice(0, 5));
    const byPortfolio = new Map<string, typeof sla.estate>();
    for (const a of sla.estate) {
      const list = byPortfolio.get(a.portfolio) ?? [];
      list.push(a);
      byPortfolio.set(a.portfolio, list);
    }
    const groups: ColGroupDef<SlaKpiRow>[] = [...byPortfolio.entries()].map(
      ([portfolio, apps]) => ({
        headerName: portfolio,
        headerGroupComponent: PortfolioGroupHeader,
        headerGroupComponentParams: { to: `/sla/portfolio/${apps[0].portfolioId}` },
        children: apps.map<ColDef<SlaKpiRow>>((a) => ({
          colId: a.id,
          headerName: a.name,
          minWidth: 128,
          sortable: false,
          hide: !visible.has(a.id),
          cellRenderer: RagCell,
          cellRendererParams: { buildSpec: matrixCellSpec },
          headerComponent: AppHeader,
          headerComponentParams: { to: `/sla/application/${a.id}` },
        })),
      })
    );
    return [
      { field: "measure", headerName: "KPI measure", pinned: "left", minWidth: 170, flex: 0, width: 190, cellClass: "font-medium" },
      { field: "obligation", headerName: "Obligation", pinned: "left", minWidth: 230, width: 250, flex: 0, cellClass: "text-muted-foreground text-[12px]" },
      { field: "red", headerName: "R", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "red", buildSpec: matrixCountSpec("red") } },
      { field: "amber", headerName: "A", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "amber", buildSpec: matrixCountSpec("amber") } },
      { field: "green", headerName: "G", maxWidth: 70, cellRenderer: RagCountCell, cellRendererParams: { rag: "green", buildSpec: matrixCountSpec("green") } },
      ...groups,
    ];
  }, [sla.estate, sla.redRankedAppIds]);

  /* ------------------------------ live helpers ----------------------------- */
  const visibleRisks = useMemo(
    () =>
      window === "all" ? sla.liveRisks : sla.liveRisks.filter((r) => r.windowMin <= window),
    [sla.liveRisks, window]
  );
  const pendingCount = visibleRisks.filter((r) => !r.notifiedAt).length;
  const countIn = (w: BreachWindow) => sla.liveRisks.filter((r) => r.windowMin <= w).length;
  const updated = sla.liveUpdatedAt
    ? new Date(sla.liveUpdatedAt).toLocaleTimeString("en-CA", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "—";

  return (
    <div className="space-y-4">
      <PageHeader
        title="SLA"
        description="Contracted obligations by measure and application, and the live breach queue."
      />

      <Tabs
        value={tab}
        onValueChange={(v) =>
          setSearchParams(v === "live" ? { tab: "live" } : {}, { replace: true })
        }
      >
        <TabsList>
          <TabsTrigger value="obligations">Obligations</TabsTrigger>
          <TabsTrigger value="live">
            Live breaches
            {sla.liveRisks.some((r) => !r.notifiedAt) && (
              <span className="grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[9.5px] font-bold text-white">
                {sla.liveRisks.filter((r) => !r.notifiedAt).length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ------------------------------- obligations ----------------------------- */}
        <TabsContent value="obligations" className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            {counts &&
              ([
                ["red", counts.red, "Red"],
                ["amber", counts.amber, "Amber"],
                ["green", counts.green, "Green"],
              ] as const).map(([tone, v, label]) => (
                <span
                  key={tone}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium",
                    tone === "red" && v > 0 && "border-red-500/40 bg-red-500/[0.06]"
                  )}
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: RAG_COLORS[tone] }} />
                  {label}
                  <span className={cn("num font-semibold", tone === "red" && "text-red-600 dark:text-red-400")}>{v}</span>
                </span>
              ))}
            <span className="ml-auto text-[11px] text-muted-foreground">
              Worst applications shown first — open <span className="font-medium">Columns</span> to add the rest
            </span>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Obligations by measure</CardTitle>
              <CardDescription>
                Click a portfolio or application header to drill in; click a count for incidents.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-72 w-full" />
              ) : (
                <DataGrid<SlaKpiRow>
                  height={380}
                  rowData={sla.kpiMatrix}
                  columnDefs={matrixCols}
                  defaultColDef={{ sortable: true, resizable: true, flex: 1, minWidth: 70, suppressHeaderMenuButton: true }}
                  context={{ onDrill: (spec: DrillSpec) => setDrill(spec) }}
                  sideBar={{
                    toolPanels: [
                      {
                        id: "columns",
                        labelDefault: "Columns",
                        labelKey: "columns",
                        iconKey: "columns",
                        toolPanel: "agColumnsToolPanel",
                        toolPanelParams: {
                          suppressRowGroups: true,
                          suppressValues: true,
                          suppressPivots: true,
                          suppressPivotMode: true,
                        },
                      },
                    ],
                    defaultToolPanel: "",
                  }}
                />
              )}
            </CardContent>
          </Card>

          <AiInsight source="Compliance analysis">
            {widestRedRule
              ? `${widestRedRule.measure} has the widest current-period exposure, with ${widestRedRule.red} applications red. ${widestRedApplications.join(" and ")} need service-owner review first; open the rule count to inspect the ticket evidence.`
              : "Current-period rule exposure is loading."}
          </AiInsight>
        </TabsContent>

        {/* ------------------------------ live breaches ---------------------------- */}
        <TabsContent value="live" className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="relative mr-1 flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
            </span>
            <span className="text-xs font-medium">Live</span>
            <span className="text-[11px] text-muted-foreground">updated {updated}</span>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs"
              disabled={sla.liveStatus === "refreshing"}
              onClick={() => dispatch(refreshLiveRisks())}
            >
              <RefreshCw className={cn("h-3 w-3", sla.liveStatus === "refreshing" && "animate-spin")} />
              Refresh
            </Button>

            <div className="ml-auto flex flex-wrap items-center gap-1.5">
              {WINDOWS.map((w) => (
                <button
                  key={String(w.value)}
                  onClick={() => setWindow(w.value)}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-[11.5px] font-medium transition-colors",
                    window === w.value
                      ? "border-brand/40 bg-brand-soft text-accent-foreground"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  {w.label}
                  {w.value !== "all" && (
                    <span className="num ml-1 text-[10px] opacity-70">{countIn(w.value as BreachWindow)}</span>
                  )}
                </button>
              ))}
              <Button size="sm" className="h-7 text-xs" disabled={pendingCount === 0} onClick={() => dispatch(notifyWindow(window))}>
                <BellRing className="h-3 w-3" />
                Notify all ({pendingCount})
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="pt-4">
              {loading ? (
                <Skeleton className="h-72 w-full" />
              ) : (
                <DataGrid<LiveBreachRisk>
                  height="auto"
                  rowData={visibleRisks}
                  columnDefs={LIVE_COLS}
                  getRowId={(p) => p.data.id}
                />
              )}
            </CardContent>
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Stakeholder digests</CardTitle>
                <CardDescription>Recurring updates to application owners</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {sla.digests.map((d) => (
                  <div key={d.id} className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold">{d.name}</p>
                      <p className="truncate text-[10.5px] text-muted-foreground">
                        {d.audience} · {d.channel} · {d.cadence}
                      </p>
                      <p className="text-[10.5px] text-muted-foreground">Next: {d.nextRun}</p>
                    </div>
                    <button onClick={() => dispatch(toggleDigest(d.id))} className="shrink-0">
                      <Badge variant={d.active ? "success" : "muted"} className="cursor-pointer">
                        {d.active ? "Active" : "Paused"}
                      </Badge>
                    </button>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent notifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {sla.sends.slice(0, 6).map((s) => (
                  <div key={s.id} className="rounded-md border px-3 py-2">
                    <p className="truncate text-[11.5px] font-medium">{s.subject}</p>
                    <p className="text-[10.5px] text-muted-foreground">To {s.to} · {s.at}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          <AiInsight source="Breach forecasting">
            Forecasts combine open-ticket aging, event signals and seasonal
            volume, refreshed each minute. Notifying an owner records the alert
            in the audit trail; monitoring continues until the risk clears.
          </AiInsight>
        </TabsContent>
      </Tabs>

      <IncidentDrilldown spec={drill} onClose={() => setDrill(null)} />
    </div>
  );
}
