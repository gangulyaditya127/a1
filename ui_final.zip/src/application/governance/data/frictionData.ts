import type {
  AppFrictionRow,
  FrictionSummary,
  MonthPoint,
} from "@/application/governance/types";
import { ESTATE, MONTHS } from "@/application/governance/data/slaData";
import { clamp, hashStr, mulberry32 } from "@/application/governance/lib/rand";

const r1 = (n: number) => Number(n.toFixed(1));

/** Deterministic monthly resolved volume per application, oldest → newest. */
function monthlyResolvedFor(appId: string): number[] {
  const rng = mulberry32(hashStr(appId + "vol"));
  const base = 34 + (Math.abs(hashStr(appId)) % 46); // 34–79 / month
  const drift = 0.4 + rng() * 0.9;
  return MONTHS.map((_, i) =>
    Math.round(clamp(base + drift * i + (rng() - 0.5) * 6, 18, 130))
  );
}

/** Tickets resolved per month for one application — the Productivity drill. */
export function appResolvedTrend(appId: string): MonthPoint[] {
  const monthly = monthlyResolvedFor(appId);
  return MONTHS.map((month, i) => ({ month, resolved: monthly[i] }));
}

/**
 * Reopens, hand-offs and first-contact resolution per application — derived
 * from each application's experience score so the friction story lines up
 * with the XLA and sentiment views (worse experience ⇒ more reopens, more
 * hops, lower FCR). resolvedQtd is the sum of the last three months of the
 * same series the Productivity drilldown charts, so the two always agree.
 */
export const appFriction: AppFrictionRow[] = ESTATE.map((app) => {
  const rng = mulberry32(hashStr(app.id) + 31);
  const monthly = monthlyResolvedFor(app.id);
  const resolvedQtd = monthly[9] + monthly[10] + monthly[11];
  const reopened = Math.round(clamp((90 - app.xla) * 1.9 + rng() * 4 - 2, 1, 34));
  const fcrPct = r1(clamp(60 + (app.xla - 80) * 1.5 + rng() * 3, 48, 88));
  const avgHops = r1(clamp(3.4 - (app.xla - 78) * 0.09 + rng() * 0.5, 1.3, 3.6));
  return {
    appId: app.id,
    application: app.name,
    portfolio: app.portfolio,
    portfolioId: app.portfolioId,
    resolvedQtd,
    reopened,
    reopenRatePct: r1((reopened / resolvedQtd) * 100),
    avgHops,
    fcrPct,
  };
});

export const frictionSummary: FrictionSummary = (() => {
  const reopened = appFriction.reduce((n, a) => n + a.reopened, 0);
  const fcr = r1(appFriction.reduce((n, a) => n + a.fcrPct, 0) / appFriction.length);
  const hops = r1(appFriction.reduce((n, a) => n + a.avgHops, 0) / appFriction.length);
  return {
    reopened,
    reopenedDeltaPct: -12,
    fcrPct: fcr,
    fcrDeltaPts: 1.6,
    avgHops: hops,
    avgHopsDelta: -0.3,
  };
})();
