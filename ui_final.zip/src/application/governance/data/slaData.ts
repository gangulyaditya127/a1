import type {
  BreachWindow,
  DigestRule,
  EstateApp,
  HealthStatus,
  IncidentFilter,
  IncidentRecord,
  KpiCellValue,
  LiveBreachRisk,
  MonthPoint,
  Owner,
  RagStatus,
  SentimentSummary,
  SentimentTheme,
  SentNotification,
  SlaKpiDef,
  SlaKpiRow,
  SlaSummary,
  StatusCounts,
  UserComment,
} from "@/application/governance/types";
import { clamp, hashStr, mulberry32, slug } from "@/application/governance/lib/rand";

/** Aug 2025 → Jul 2026 (Jul is month-to-date). */
export const MONTHS = [
  "Aug 25", "Sep 25", "Oct 25", "Nov 25", "Dec 25", "Jan 26",
  "Feb 26", "Mar 26", "Apr 26", "May 26", "Jun 26", "Jul 26",
] as const;

const series = (values: number[], key: string): MonthPoint[] =>
  MONTHS.map((month, i) => ({ month, [key]: values[i] }));

function makeSeries(
  seed: number,
  end: number,
  drift: number,
  vol: number,
  lo: number,
  hi: number
): number[] {
  const rng = mulberry32(seed);
  const arr = MONTHS.map((_, i) =>
    Number(clamp(end - drift * (11 - i) + (rng() - 0.5) * vol, lo, hi).toFixed(1))
  );
  arr[11] = end;
  return arr;
}

/* -------------------------------- headline ------------------------------- */

export const slaSummary: SlaSummary = { csat: 4.4, csatDelta: 0.1 };

export const csatTrend: MonthPoint[] = series(
  [4.0, 4.0, 4.1, 4.1, 4.2, 4.2, 4.2, 4.3, 4.3, 4.3, 4.4, 4.4],
  "csat"
);

/* ------------------------ estate: Portfolio ▸ App ------------------------- */

interface AppSpec {
  name: string;
  tier: EstateApp["tier"];
  reliabilityBias: number;
  xla: number;
  owner: Owner;
  openP1?: number;
  openP2?: number;
}

const SPEC: { portfolio: string; apps: AppSpec[] }[] = [
  {
    portfolio: "Group Benefits",
    apps: [
      { name: "Claims Processing", tier: "Tier 1", reliabilityBias: 93.4, xla: 81, owner: { name: "Priya Raman", role: "Application Owner" }, openP2: 4 },
      { name: "Claims Intake Portal", tier: "Tier 2", reliabilityBias: 97.2, xla: 88, owner: { name: "Marc Tremblay", role: "Application Owner" } },
      { name: "Adjudication Engine", tier: "Tier 1", reliabilityBias: 96.4, xla: 85, owner: { name: "Priya Raman", role: "Application Owner" }, openP2: 2 },
      { name: "GroupNet", tier: "Tier 1", reliabilityBias: 95.6, xla: 86, owner: { name: "Dana Whitfield", role: "Application Owner" }, openP2: 3 },
      { name: "Billing Engine", tier: "Tier 2", reliabilityBias: 97.9, xla: 90, owner: { name: "Aaron Chen", role: "Application Owner" } },
      { name: "Payments Hub", tier: "Tier 1", reliabilityBias: 94.1, xla: 83, owner: { name: "Luis Ortega", role: "Application Owner" }, openP1: 1, openP2: 3 },
      { name: "Disbursements", tier: "Tier 2", reliabilityBias: 97.5, xla: 89, owner: { name: "Luis Ortega", role: "Application Owner" } },
    ],
  },
  {
    portfolio: "Wealth",
    apps: [
      { name: "Wealth Portal", tier: "Tier 1", reliabilityBias: 97.6, xla: 90, owner: { name: "Sofia Marchetti", role: "Application Owner" } },
      { name: "Retirement Admin", tier: "Tier 2", reliabilityBias: 98.1, xla: 88, owner: { name: "Sofia Marchetti", role: "Application Owner" } },
      { name: "Fund Accounting", tier: "Tier 1", reliabilityBias: 98.4, xla: 87, owner: { name: "Ken Osei", role: "Application Owner" } },
      { name: "Trade Gateway", tier: "Tier 1", reliabilityBias: 97.1, xla: 85, owner: { name: "Ken Osei", role: "Application Owner" }, openP2: 1 },
    ],
  },
  {
    portfolio: "Advisor & Digital",
    apps: [
      { name: "Advisor Workspace", tier: "Tier 2", reliabilityBias: 95.2, xla: 79, owner: { name: "Nadia Boucher", role: "Application Owner" }, openP2: 2 },
      { name: "CRM Sync", tier: "Tier 3", reliabilityBias: 97.8, xla: 86, owner: { name: "Nadia Boucher", role: "Application Owner" } },
      { name: "Client Mobile App", tier: "Tier 1", reliabilityBias: 98.2, xla: 91, owner: { name: "Jordan Blake", role: "Application Owner" } },
      { name: "Web Experience", tier: "Tier 1", reliabilityBias: 97.4, xla: 89, owner: { name: "Jordan Blake", role: "Application Owner" } },
    ],
  },
  {
    portfolio: "Corporate",
    apps: [
      { name: "Policy Admin", tier: "Tier 1", reliabilityBias: 98.7, xla: 88, owner: { name: "Grace Lindqvist", role: "Application Owner" } },
      { name: "Document Services", tier: "Tier 3", reliabilityBias: 97.9, xla: 84, owner: { name: "Grace Lindqvist", role: "Application Owner" } },
      { name: "Integration Bus", tier: "Tier 1", reliabilityBias: 98.0, xla: 85, owner: { name: "Tomás Ferreira", role: "Application Owner" } },
      { name: "Reporting Warehouse", tier: "Tier 2", reliabilityBias: 96.9, xla: 83, owner: { name: "Tomás Ferreira", role: "Application Owner" }, openP2: 1 },
    ],
  },
];

const riskFor = (app: AppSpec): HealthStatus => {
  if ((app.openP1 ?? 0) > 0) return "breached";
  if (app.reliabilityBias < 95.5 || (app.openP2 ?? 0) >= 3) return "at-risk";
  return "on-track";
};

const RELIABILITY_BIAS = new Map(
  SPEC.flatMap(({ apps }) => apps.map((app) => [slug(app.name), app.reliabilityBias] as const))
);

export const ESTATE: EstateApp[] = SPEC.flatMap(({ portfolio, apps }) =>
  apps.map((a) => {
    const seed = hashStr(a.name);
    const rng = mulberry32(seed);
    const xlaSeries = makeSeries(seed + 1, a.xla, 0.35, 3, 68, 96).map(Math.round);
    return {
      id: slug(a.name),
      name: a.name,
      portfolio,
      portfolioId: slug(portfolio),
      tier: a.tier,
      xla: a.xla,
      xlaDelta: a.xla - xlaSeries[10],
      openP1: a.openP1 ?? 0,
      openP2: a.openP2 ?? Math.floor(rng() * 2),
      risk: riskFor(a),
      owner: a.owner,
      xlaSeries,
    };
  })
);

/* ----------------------- SLA matrix: measure × app ------------------------ */

export const KPI_DEFS: SlaKpiDef[] = [
  { id: "k-resp-p1", measure: "Response Time - P1", obligation: "Acknowledge within 15 min · 95% of tickets", category: "response", priority: "P1", targetPct: 95 },
  { id: "k-resp-p2", measure: "Response Time - P2", obligation: "Acknowledge within 30 min · 95% of tickets", category: "response", priority: "P2", targetPct: 95 },
  { id: "k-resp-p3", measure: "Response Time - P3", obligation: "Acknowledge within 4 business h · 90% of tickets", category: "response", priority: "P3", targetPct: 90 },
  { id: "k-resp-p4", measure: "Response Time - P4", obligation: "Acknowledge within 8 business h · 90% of tickets", category: "response", priority: "P4", targetPct: 90 },
  { id: "k-res-p1", measure: "Resolution Time - P1", obligation: "Restore service within 4 h · 95% of incidents", category: "resolution", priority: "P1", targetPct: 95 },
  { id: "k-res-p2", measure: "Resolution Time - P2", obligation: "Restore service within 8 h · 95% of incidents", category: "resolution", priority: "P2", targetPct: 95 },
  { id: "k-res-p3", measure: "Resolution Time - P3", obligation: "Resolve within 3 business days · 90% of tickets", category: "resolution", priority: "P3", targetPct: 90 },
  { id: "k-res-p4", measure: "Resolution Time - P4", obligation: "Resolve within 5 business days · 90% of tickets", category: "resolution", priority: "P4", targetPct: 90 },
  { id: "k-age-p1", measure: "Aging - P1", obligation: "No active P1 older than 4 h · 100% of tickets", category: "aging", priority: "P1", targetPct: 100 },
  { id: "k-age-p2", measure: "Aging - P2", obligation: "No active P2 older than 8 h · 98% of tickets", category: "aging", priority: "P2", targetPct: 98 },
  { id: "k-age-p3", measure: "Aging - P3", obligation: "Keep active P3 backlog within 5 business days · 90%", category: "aging", priority: "P3", targetPct: 90 },
  { id: "k-age-p4", measure: "Aging - P4", obligation: "Keep active P4 backlog within 10 business days · 90%", category: "aging", priority: "P4", targetPct: 90 },
];

/** Canonical display order for SLA rules across every view and chart. */
export const SLA_RULE_ORDER = KPI_DEFS.map((definition) => definition.measure);

/** Red is a breach; amber is inside the 1.2-pt tolerance band. */
export function ragFor(actual: number, target: number): RagStatus {
  if (actual >= target) return "green";
  if (actual >= target - 1.2) return "amber";
  return "red";
}

function cellFor(app: EstateApp, def: SlaKpiDef): KpiCellValue {
  const rng = mulberry32(hashStr(app.id + def.id));
  const scale = def.category === "resolution" ? 1.15 : def.category === "aging" ? 0.85 : 1;
  const reliabilityBias = RELIABILITY_BIAS.get(app.id) ?? 96.2;
  const actual = Number(
    clamp(
      def.targetPct + (reliabilityBias - 96.2) * scale + (rng() - 0.42) * 2.2,
      84,
      100
    ).toFixed(1)
  );

  const trendRng = mulberry32(hashStr(`${app.id}:${def.id}:trend`));
  const volatility = def.category === "aging" ? 1.1 : 1.35;
  const drift = def.category === "aging" ? 0.1 : 0.12;
  const trendPct = MONTHS.map((_, i) =>
    Number(
      clamp(
        actual - drift * (MONTHS.length - 1 - i) + (trendRng() - 0.5) * volatility,
        82,
        100
      ).toFixed(1)
    )
  );
  trendPct[trendPct.length - 1] = actual;

  return { actualPct: actual, status: ragFor(actual, def.targetPct), trendPct };
}

/** Rows retain the canonical response, resolution, then aging display order. */
export const KPI_MATRIX: SlaKpiRow[] = KPI_DEFS.map((def) => {
  const cells: Record<string, KpiCellValue> = {};
  let red = 0,
    amber = 0,
    green = 0;
  for (const app of ESTATE) {
    const c = cellFor(app, def);
    cells[app.id] = c;
    if (c.status === "red") red += 1;
    else if (c.status === "amber") amber += 1;
    else green += 1;
  }
  return {
    id: def.id,
    measure: def.measure,
    obligation: def.obligation,
    category: def.category,
    priority: def.priority,
    targetPct: def.targetPct,
    red,
    amber,
    green,
    cells,
  };
});

/** Estate-wide RAG counts across every SLA instance (measure × app). */
export const STATUS_COUNTS: StatusCounts = KPI_MATRIX.reduce(
  (acc, r) => ({ red: acc.red + r.red, amber: acc.amber + r.amber, green: acc.green + r.green }),
  { red: 0, amber: 0, green: 0 }
);

/** Applications ranked worst-first across the matrix, then by active incident pressure. */
export function rankAppsByRed(): string[] {
  const score = new Map<string, { red: number; amber: number }>();
  for (const app of ESTATE) score.set(app.id, { red: 0, amber: 0 });
  for (const row of KPI_MATRIX)
    for (const [appId, cell] of Object.entries(row.cells)) {
      const s = score.get(appId)!;
      if (cell.status === "red") s.red += 1;
      else if (cell.status === "amber") s.amber += 1;
    }
  return [...ESTATE]
    .sort((a, b) => {
      const sa = score.get(a.id)!;
      const sb = score.get(b.id)!;
      return (
        sb.red - sa.red ||
        sb.amber - sa.amber ||
        b.openP1 - a.openP1 ||
        b.openP2 - a.openP2 ||
        a.name.localeCompare(b.name)
      );
    })
    .map((a) => a.id);
}

/* ------------------------------- incidents -------------------------------- */

/** Nominal target duration (minutes) used to judge each incident, per measure. */
const INCIDENT_TARGET_MIN: Record<string, number> = {
  "k-resp-p1": 15,
  "k-resp-p2": 30,
  "k-resp-p3": 240,
  "k-resp-p4": 480,
  "k-res-p1": 240,
  "k-res-p2": 480,
  "k-res-p3": 1440,
  "k-res-p4": 2400,
  "k-age-p1": 240,
  "k-age-p2": 480,
  "k-age-p3": 2400,
  "k-age-p4": 4800,
};

const SHORT_MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
/** "Now", inside the console — kept fixed so every incident timestamp is reproducible. */
const TODAY = new Date(2026, 6, 17);

function openedAtFor(daysAgo: number, hh: number, mm: number) {
  const d = new Date(TODAY);
  d.setDate(d.getDate() - daysAgo);
  const label = `${SHORT_MONTH[d.getMonth()]} ${d.getDate()} · ${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  return { label, ts: d.getTime() + hh * 3_600_000 + mm * 60_000 };
}

function incidentsForCell(row: SlaKpiRow, app: EstateApp, cell: KpiCellValue): IncidentRecord[] {
  const rng = mulberry32(hashStr(app.id + row.id) + 11);
  const count = cell.status === "red" ? 3 : cell.status === "amber" ? 2 : 1;
  const targetMin = INCIDENT_TARGET_MIN[row.id] ?? 240;
  const priority = row.priority;
  const breachChance = cell.status === "red" ? 0.75 : cell.status === "amber" ? 0.4 : 0.08;
  const [breachedLine, metLine] =
    row.category === "response"
      ? ["Initial response exceeded the contracted window", "Acknowledged within the contracted window"]
      : row.category === "resolution"
        ? ["Resolution exceeded the contracted window", "Resolved within the contracted window"]
        : ["Ticket exceeded the agreed aging threshold", "Backlog age remained within threshold"];

  return Array.from({ length: count }, (_, i) => {
    const daysAgo = 1 + Math.floor(rng() * 29);
    const hh = Math.floor(rng() * 24);
    const mm = Math.floor(rng() * 60);
    const breached = rng() < breachChance;
    const durationMin = Math.round(
      targetMin * (breached ? 1.1 + rng() * 0.9 : 0.35 + rng() * 0.55)
    );
    const { label, ts } = openedAtFor(daysAgo, hh, mm);
    const ticket = 1048000 + (Math.abs(hashStr(`${app.id}:${row.id}:${i}`)) % 8999);
    return {
      id: `INC${ticket}`,
      appId: app.id,
      application: app.name,
      portfolioId: app.portfolioId,
      portfolio: app.portfolio,
      kpiId: row.id,
      measure: row.measure,
      rag: cell.status,
      priority,
      openedAt: label,
      openedAtTs: ts,
      durationMin,
      targetMin,
      outcome: breached ? "Breached" : "Met",
      summary: breached ? breachedLine : metLine,
    };
  });
}

/**
 * Incident-level detail behind any RAG count. Every drilldown in the console —
 * an Overview stat card, a matrix count, a portfolio condition chip, a single
 * application cell — resolves to a call here.
 */
export function incidentsFor(filter: IncidentFilter): IncidentRecord[] {
  const rows = filter.kpiId ? KPI_MATRIX.filter((r) => r.id === filter.kpiId) : KPI_MATRIX;
  const out: IncidentRecord[] = [];
  for (const row of rows) {
    for (const [appId, cell] of Object.entries(row.cells)) {
      if (filter.appId && appId !== filter.appId) continue;
      if (filter.status && cell.status !== filter.status) continue;
      const app = ESTATE.find((a) => a.id === appId);
      if (!app) continue;
      if (filter.portfolioId && app.portfolioId !== filter.portfolioId) continue;
      out.push(...incidentsForCell(row, app, cell));
    }
  }
  return out.sort((a, b) => b.openedAtTs - a.openedAtTs);
}

/* --------------------------- XLA: CSAT & sentiment ------------------------ */

export const sentimentSummary: SentimentSummary = {
  analyzed: 3184,
  positivePct: 64,
  neutralPct: 22,
  negativePct: 14,
  negativeDeltaPts: -3,
};

export const sentimentTrend: MonthPoint[] = MONTHS.map((month, i) => {
  const negative = [21, 20, 20, 19, 18, 18, 17, 16, 16, 15, 14, 14][i];
  const positive = [55, 56, 56, 57, 58, 59, 60, 61, 62, 62, 63, 64][i];
  return { month, positive, neutral: 100 - positive - negative, negative };
});

export const sentimentThemes: SentimentTheme[] = [
  { id: "t1", theme: "Slow claim status updates", sentiment: "negative", mentions: 214, deltaPct: -18 },
  { id: "t2", theme: "Advisor portal timeouts", sentiment: "negative", mentions: 122, deltaPct: 9 },
  { id: "t3", theme: "Password reset is instant now", sentiment: "positive", mentions: 341, deltaPct: 24 },
  { id: "t4", theme: "Clear outage communications", sentiment: "positive", mentions: 187, deltaPct: 12 },
  { id: "t5", theme: "Enrolment forms confusing", sentiment: "negative", mentions: 96, deltaPct: -4 },
  { id: "t6", theme: "Mobile app feels faster", sentiment: "positive", mentions: 158, deltaPct: 15 },
];

export const userComments: UserComment[] = [
  { id: "c1", when: "Jul 16", portfolio: "Group Benefits", application: "Claims Processing", rating: 2, sentiment: "negative", text: "Claim has said 'in review' for three days — the status page tells me nothing new." },
  { id: "c2", when: "Jul 16", portfolio: "Advisor & Digital", application: "Client Mobile App", rating: 5, sentiment: "positive", text: "App is noticeably quicker since the last update. Biometric login works every time." },
  { id: "c3", when: "Jul 15", portfolio: "Group Benefits", application: "GroupNet", rating: 3, sentiment: "neutral", text: "Got logged out twice this morning but it worked fine after that." },
  { id: "c4", when: "Jul 15", portfolio: "Advisor & Digital", application: "Advisor Workspace", rating: 2, sentiment: "negative", text: "Case screen times out when I attach documents — second week in a row." },
  { id: "c5", when: "Jul 14", portfolio: "Group Benefits", application: "Payments Hub", rating: 4, sentiment: "positive", text: "Disbursement landed same day. Nice improvement over last quarter." },
  { id: "c6", when: "Jul 14", portfolio: "Corporate", application: "Document Services", rating: 4, sentiment: "positive", text: "Letter regenerated in seconds after I fixed the address. Painless." },
  { id: "c7", when: "Jul 12", portfolio: "Group Benefits", application: "Claims Intake Portal", rating: 3, sentiment: "neutral", text: "Upload worked, though the progress bar froze at 90% for a while." },
  { id: "c8", when: "Jul 11", portfolio: "Wealth", application: "Wealth Portal", rating: 5, sentiment: "positive", text: "Statements downloaded instantly, and support answered in under a minute." },
  { id: "c9", when: "Jul 10", portfolio: "Group Benefits", application: "Enrolment — GroupNet", rating: 2, sentiment: "negative", text: "The dependant form rejected my entry three times with no explanation." },
  { id: "c10", when: "Jul 9", portfolio: "Wealth", application: "Trade Gateway", rating: 4, sentiment: "positive", text: "Trade confirmations arriving faster than the old cut-off. Good work." },
];

/* ----------------------------- live breach feed --------------------------- */

interface LiveSpec {
  appId: string;
  incident: string;
  kpiId: string;
  metric: string;
  priority: LiveBreachRisk["priority"];
  assignmentGroup: string;
  assignee: string;
  windowMin: BreachWindow;
  baseEta: number;
  baseProb: number;
  impact: string;
  driver: string;
}

const LIVE_SPEC: LiveSpec[] = [
  { appId: "payments-hub", incident: "INC1049310", kpiId: "k-res-p1", metric: "Resolution Time - P1", priority: "P1", assignmentGroup: "AMS – Payments L2", assignee: "Imran Dar", windowMin: 30, baseEta: 24, baseProb: 84, impact: "Tonight's disbursement window", driver: "EOD chain step 4 running 22 min behind" },
  { appId: "claims-processing", incident: "INC1049233", kpiId: "k-res-p2", metric: "Resolution Time - P2", priority: "P2", assignmentGroup: "AMS – Claims L2", assignee: "Farah Siddiqui", windowMin: 30, baseEta: 28, baseProb: 76, impact: "~1,400 pending claim updates", driver: "Claim-status API latency at 3.1× baseline" },
  { appId: "groupnet", incident: "INC1049274", kpiId: "k-age-p3", metric: "Aging - P3", priority: "P3", assignmentGroup: "AMS – Digital Channels L2", assignee: "Ben Carver", windowMin: 60, baseEta: 52, baseProb: 63, impact: "Member self-serve logins", driver: "Session-store evictions climbing" },
  { appId: "adjudication-engine", incident: "INC1049301", kpiId: "k-age-p2", metric: "Aging - P2", priority: "P2", assignmentGroup: "AMS – Claims L2", assignee: "Lena Vogel", windowMin: 60, baseEta: 47, baseProb: 58, impact: "Same-day adjudication", driver: "Document queue at 2× normal depth" },
  { appId: "advisor-workspace", incident: "INC1049198", kpiId: "k-resp-p2", metric: "Response Time - P2", priority: "P2", assignmentGroup: "AMS – Digital Channels L2", assignee: "Hana Yoshida", windowMin: 120, baseEta: 96, baseProb: 54, impact: "Advisor case turnaround", driver: "L2 queue above staffing threshold" },
  { appId: "trade-gateway", incident: "INC1049325", kpiId: "k-resp-p2", metric: "Response Time - P2", priority: "P2", assignmentGroup: "AMS – Wealth Ops L2", assignee: "Devon Marsh", windowMin: 120, baseEta: 110, baseProb: 41, impact: "16:00 ET cut-off", driver: "Upstream feed retries increasing" },
  { appId: "reporting-warehouse", incident: "INC1049256", kpiId: "k-age-p4", metric: "Aging - P4", priority: "P4", assignmentGroup: "AMS – Data & Integration L2", assignee: "Greg Olszewski", windowMin: 180, baseEta: 155, baseProb: 46, impact: "Morning reporting refresh", driver: "Two ETL stages re-queued" },
  { appId: "web-experience", incident: "INC1049342", kpiId: "k-resp-p1", metric: "Response Time - P1", priority: "P1", assignmentGroup: "AMS – Platform L2", assignee: "Marco Silva", windowMin: 180, baseEta: 168, baseProb: 33, impact: "Public site availability", driver: "Elevated 5xx on content service" },
];

/** Deterministic snapshot of the live feed; `tick` adds refresh jitter. */
export function liveRisksAt(tick: number): LiveBreachRisk[] {
  return LIVE_SPEC.map((s, i) => {
    const app = ESTATE.find((a) => a.id === s.appId)!;
    const rng = mulberry32(hashStr(s.appId) + tick * 97 + i);
    return {
      id: `lr-${s.appId}-${i}`,
      incident: s.incident,
      kpiId: s.kpiId,
      appId: app.id,
      application: app.name,
      portfolio: app.portfolio,
      metric: s.metric,
      priority: s.priority,
      assignmentGroup: s.assignmentGroup,
      assignee: s.assignee,
      windowMin: s.windowMin,
      etaMin: Math.max(4, Math.round(s.baseEta + (rng() - 0.55) * 8)),
      probability: Math.round(clamp(s.baseProb + (rng() - 0.5) * 6, 15, 97)),
      impact: s.impact,
      driver: s.driver,
      owner: app.owner,
      notifiedAt: null,
    };
  }).sort((a, b) => a.etaMin - b.etaMin);
}

/* --------------------------- stakeholder digests -------------------------- */

export const digestRules: DigestRule[] = [
  { id: "dg1", name: "Daily SLA position", audience: "Application owners", channel: "Email", cadence: "Daily · 08:00 ET", nextRun: "Jul 18 · 08:00", lastSent: "Today · 08:00", active: true },
  { id: "dg2", name: "Breach-risk alerts", audience: "Owners of affected apps", channel: "Teams", cadence: "Real time", nextRun: "On trigger", lastSent: "Today · 11:42", active: true },
  { id: "dg3", name: "Portfolio weekly summary", audience: "Portfolio leads", channel: "Email", cadence: "Mondays · 07:30 ET", nextRun: "Jul 20 · 07:30", lastSent: "Jul 13 · 07:30", active: true },
  { id: "dg4", name: "Experience (CSAT) monthly", audience: "Service owners", channel: "Email", cadence: "1st business day", nextRun: "Aug 4 · 08:00", lastSent: "Jul 2 · 08:00", active: false },
];

export const seedSends: SentNotification[] = [
  { id: "sn1", to: "Luis Ortega", subject: "Breach risk · Payments Hub — batch completion", at: "Today · 11:42" },
  { id: "sn2", to: "Application owners (19)", subject: "Daily SLA position — Jul 17", at: "Today · 08:00" },
  { id: "sn3", to: "Portfolio leads (4)", subject: "Portfolio weekly summary — wk 29", at: "Jul 13 · 07:30" },
];
