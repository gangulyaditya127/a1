import type {
  AutomationRecord,
  IndividualRow,
  MonthPoint,
  PortfolioDeliveryRow,
  ProductivitySummary,
} from "@/application/governance/types";
import { MONTHS } from "@/application/governance/data/slaData";
import { slug } from "@/application/governance/lib/rand";

/* --------------------------- portfolio delivery --------------------------- */

interface DeliverySpec {
  portfolio: string;
  resources: number;
  /** Tickets resolved each month, oldest → newest. */
  monthlyResolved: number[];
  avgResolutionHrs: number;
  changeIncidents: number;
  changeIncidentsDeltaPct: number;
}

const DELIVERY: DeliverySpec[] = [
  {
    portfolio: "Group Benefits",
    resources: 23,
    monthlyResolved: [644, 652, 667, 675, 682, 690, 701, 712, 718, 726, 733, 741],
    avgResolutionHrs: 6.9,
    changeIncidents: 19,
    changeIncidentsDeltaPct: -26,
  },
  {
    portfolio: "Wealth",
    resources: 8,
    monthlyResolved: [252, 254, 258, 255, 260, 262, 265, 268, 270, 266, 272, 275],
    avgResolutionHrs: 5.2,
    changeIncidents: 4,
    changeIncidentsDeltaPct: -20,
  },
  {
    portfolio: "Advisor & Digital",
    resources: 10,
    monthlyResolved: [305, 300, 296, 290, 285, 292, 300, 308, 314, 320, 326, 331],
    avgResolutionHrs: 6.0,
    changeIncidents: 6,
    changeIncidentsDeltaPct: 20,
  },
  {
    portfolio: "Corporate",
    resources: 7,
    monthlyResolved: [222, 225, 229, 231, 234, 238, 240, 243, 246, 248, 251, 254],
    avgResolutionHrs: 5.6,
    changeIncidents: 2,
    changeIncidentsDeltaPct: -50,
  },
];

const r1 = (n: number) => Number(n.toFixed(1));
const qtd = (ms: number[]) => ms[9] + ms[10] + ms[11];

/** One row per portfolio — resolved is quarter-to-date, throughput is the
 *  latest month's tickets resolved per resource. */
export const portfolioDelivery: PortfolioDeliveryRow[] = DELIVERY.map((d) => ({
  id: slug(d.portfolio),
  portfolio: d.portfolio,
  portfolioId: slug(d.portfolio),
  resources: d.resources,
  resolved: qtd(d.monthlyResolved),
  throughput: r1(d.monthlyResolved[11] / d.resources),
  avgResolutionHrs: d.avgResolutionHrs,
  changeIncidents: d.changeIncidents,
  changeIncidentsDeltaPct: d.changeIncidentsDeltaPct,
}));

/** Tickets resolved per resource per month — one series per portfolio,
 *  plus the blended overall line. */
export const throughputTrend: MonthPoint[] = MONTHS.map((month, i) => {
  const row: Record<string, string | number> = { month };
  let resolved = 0;
  let resources = 0;
  for (const d of DELIVERY) {
    row[d.portfolio] = r1(d.monthlyResolved[i] / d.resources);
    resolved += d.monthlyResolved[i];
    resources += d.resources;
  }
  row.Overall = r1(resolved / resources);
  return row as MonthPoint;
});

export const productivitySummary: ProductivitySummary = {
  ticketsHandled: portfolioDelivery.reduce((n, p) => n + p.resolved, 0),
  avgResolutionHrs: 6.2,
  avgResolutionDeltaPct: -18,
  automationCoveragePct: 44,
  hoursSaved: 1240,
  savingsCad: 412000,
  backlog: 312,
  backlogDeltaPct: -12,
};

/* ------------------------------- associates ------------------------------- */

/** Named associates behind the numbers; `reopened` = their closures that came back. */
export const individuals: IndividualRow[] = [
  { id: "p1", name: "Ananya Iyer", portfolio: "Group Benefits", portfolioId: "group-benefits", resolved: 168, reopened: 1, avgHandleHrs: 4.9, csat: 4.7, trendPct: 12 },
  { id: "p2", name: "Ben Carver", portfolio: "Group Benefits", portfolioId: "group-benefits", resolved: 154, reopened: 1, avgHandleHrs: 5.3, csat: 4.6, trendPct: 9 },
  { id: "p3", name: "Chloé Bergeron", portfolio: "Advisor & Digital", portfolioId: "advisor-digital", resolved: 149, reopened: 2, avgHandleHrs: 5.1, csat: 4.6, trendPct: 7 },
  { id: "p4", name: "Devon Marsh", portfolio: "Wealth", portfolioId: "wealth", resolved: 141, reopened: 1, avgHandleHrs: 4.7, csat: 4.5, trendPct: 5 },
  { id: "p5", name: "Farah Siddiqui", portfolio: "Group Benefits", portfolioId: "group-benefits", resolved: 133, reopened: 2, avgHandleHrs: 5.8, csat: 4.4, trendPct: 4 },
  { id: "p6", name: "Greg Olszewski", portfolio: "Corporate", portfolioId: "corporate", resolved: 126, reopened: 2, avgHandleHrs: 5.5, csat: 4.4, trendPct: 2 },
  { id: "p7", name: "Hana Yoshida", portfolio: "Advisor & Digital", portfolioId: "advisor-digital", resolved: 118, reopened: 3, avgHandleHrs: 6.2, csat: 4.3, trendPct: 1 },
  { id: "p8", name: "Imran Dar", portfolio: "Group Benefits", portfolioId: "group-benefits", resolved: 104, reopened: 4, avgHandleHrs: 6.6, csat: 4.2, trendPct: -2 },
  { id: "p9", name: "Jenna Fortin", portfolio: "Wealth", portfolioId: "wealth", resolved: 96, reopened: 4, avgHandleHrs: 6.9, csat: 4.1, trendPct: -4 },
  { id: "p10", name: "Karl Nyberg", portfolio: "Corporate", portfolioId: "corporate", resolved: 87, reopened: 5, avgHandleHrs: 7.4, csat: 4.0, trendPct: -6 },
  { id: "p11", name: "Lena Vogel", portfolio: "Group Benefits", portfolioId: "group-benefits", resolved: 78, reopened: 7, avgHandleHrs: 8.1, csat: 3.9, trendPct: -9 },
  { id: "p12", name: "Marco Silva", portfolio: "Advisor & Digital", portfolioId: "advisor-digital", resolved: 71, reopened: 9, avgHandleHrs: 8.6, csat: 3.8, trendPct: -12 },
];

/* ------------------------------- automation ------------------------------- */

/** Monthly ticket volume split by how the work got done. */
export const volumeTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  manual: [520, 505, 488, 496, 452, 438, 421, 402, 378, 356, 330, 310][i],
  aiAssisted: [180, 192, 205, 214, 228, 241, 252, 264, 276, 288, 295, 300][i],
  autoResolved: [60, 72, 84, 92, 108, 122, 138, 152, 168, 184, 198, 210][i],
}));

/** Cumulative effort returned to the business (hours). */
export const savingsTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  hours: [120, 260, 420, 610, 830, 1080, 1370, 1690, 2040, 2430, 2860, 3320][i],
}));

export const topAutomations: AutomationRecord[] = [
  { id: "t1", name: "Password & access resets", tickets: 1860, hoursSaved: 620, successPct: 99.2 },
  { id: "t2", name: "Batch job restart (EOD chain)", tickets: 412, hoursSaved: 310, successPct: 97.1 },
  { id: "t3", name: "Disk & queue cleanup", tickets: 388, hoursSaved: 96, successPct: 98.4 },
  { id: "t4", name: "Claim-status sync retry", tickets: 296, hoursSaved: 88, successPct: 96.8 },
  { id: "t5", name: "Certificate renewal", tickets: 240, hoursSaved: 120, successPct: 100 },
];
