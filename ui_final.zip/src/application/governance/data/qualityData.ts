import type { MonthPoint, QualitySummary } from "@/application/governance/types";
import { MONTHS } from "@/application/governance/data/slaData";

/** Business payoff of problem management: incidents that never happened. */
export const qualitySummary: QualitySummary = {
  avoidedQtd: 68,
  avoidedYtd: 141,
};

/** Incidents avoided each month via problem-record fixes, plus a running total. */
export const avoidedTrend: MonthPoint[] = (() => {
  const monthly = [4, 6, 8, 9, 11, 13, 15, 17, 18, 21, 23, 24];
  let cum = 0;
  return MONTHS.map((month, i) => {
    cum += monthly[i];
    return { month, avoided: monthly[i], cumulative: cum };
  });
})();
