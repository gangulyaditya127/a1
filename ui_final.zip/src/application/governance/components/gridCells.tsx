import type {
  ICellRendererParams,
  IHeaderGroupParams,
  IHeaderParams,
} from "ag-grid-community";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight, BellRing, Check } from "lucide-react";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { TrendIndicator } from "@/shared/components/TrendIndicator";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import { Progress } from "@/shared/ui/progress";
import { useAppDispatch } from "@/app/hooks";
import { notifyRisk } from "@/application/governance/state/slaSlice";
import type { DrillSpec, LiveBreachRisk } from "@/application/governance/types";

/* ------------------------------ generic cells ----------------------------- */

export function StatusCell(p: ICellRendererParams) {
  if (p.node.group || p.value == null) return null;
  return <StatusBadge status={p.value} />;
}

export function DeltaCell(p: ICellRendererParams) {
  if (p.value == null) return null;
  const v = Number(p.value);
  return (
    <TrendIndicator
      trend={{
        value: `${v > 0 ? "+" : ""}${v} pts`,
        direction: v > 0 ? "up" : v < 0 ? "down" : "flat",
        positive: v >= 0,
      }}
    />
  );
}

/** Percentage with a small bar; green when at/above `target` (default 95). */
export function PctBarCell(p: ICellRendererParams & { target?: number }) {
  if (p.value == null) return null;
  const v = Number(p.value);
  const target = p.target ?? (p.data?.targetPct as number | undefined) ?? 95;
  return (
    <div className="flex w-full items-center gap-2">
      <Progress
        value={Math.min(100, v)}
        className="h-1.5 w-16"
        indicatorClassName={v >= target ? "bg-emerald-500" : "bg-amber-500"}
      />
      <span className="num text-xs font-medium">{v.toFixed(1)}%</span>
    </div>
  );
}

export function TitleSubCell(p: ICellRendererParams & { subField?: string }) {
  const sub = p.subField ? (p.data?.[p.subField] as string) : undefined;
  return (
    <div className="leading-tight">
      <p className="text-[12.5px] font-medium">{p.value}</p>
      {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
    </div>
  );
}

/* ------------------------------- estate grid ------------------------------ */

/**
 * Inner renderer for the auto-group column: group/app name, plus an
 * "open portfolio" affordance on top-level groups.
 */
export function EstateGroupCell(p: ICellRendererParams) {
  const navigate = useNavigate();
  const isPortfolio = p.node.group && p.node.level === 0;
  const portfolioId = p.data?.portfolioId ?? p.node.allLeafChildren?.[0]?.data?.portfolioId;
  return (
    <span className="flex items-center gap-1.5">
      <span className={p.node.group ? "font-semibold" : "font-medium"}>{p.value}</span>
      {isPortfolio && portfolioId && (
        <button
          className="inline-flex items-center gap-0.5 rounded px-1 text-[10.5px] font-medium text-brand opacity-80 transition-opacity hover:opacity-100"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/portfolio/${portfolioId}`);
          }}
        >
          Open
          <ArrowUpRight className="h-3 w-3" />
        </button>
      )}
    </span>
  );
}

/* ----------------------------- live-breach grid ---------------------------- */

const WINDOW_LABEL: Record<number, string> = {
  30: "≤ 30 min",
  60: "≤ 1 h",
  120: "≤ 2 h",
  180: "≤ 3 h",
};

export function WindowCell(p: ICellRendererParams) {
  if (p.value == null) return null;
  const w = Number(p.value);
  return (
    <Badge variant={w <= 30 ? "danger" : w <= 60 ? "warning" : "muted"}>
      {WINDOW_LABEL[w] ?? `${w} min`}
    </Badge>
  );
}

export function EtaCell(p: ICellRendererParams) {
  if (p.value == null) return null;
  const m = Number(p.value);
  return (
    <span className="num text-xs font-semibold">
      {m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} m` : `${m} min`}
    </span>
  );
}

export function ProbabilityCell(p: ICellRendererParams) {
  if (p.value == null) return null;
  const v = Number(p.value);
  return (
    <div className="flex w-full items-center gap-2">
      <Progress
        value={v}
        className="h-1.5 w-14"
        indicatorClassName={v >= 70 ? "bg-red-500" : v >= 50 ? "bg-amber-500" : "bg-sky-500"}
      />
      <span className="num text-xs font-medium">{v}%</span>
    </div>
  );
}

export function OwnerCell(p: ICellRendererParams) {
  const owner = p.data?.owner as { name: string } | undefined;
  if (!owner) return null;
  return <span className="text-xs">{owner.name}</span>;
}

export function NotifyCell(p: ICellRendererParams<LiveBreachRisk>) {
  if (!p.data) return null;
  return <NotifyButton risk={p.data} />;
}

export function NotifyButton({ risk }: { risk: LiveBreachRisk }) {
  const dispatch = useAppDispatch();
  if (risk.notifiedAt)
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
        <Check className="h-3 w-3" />
        Notified · {risk.notifiedAt}
      </span>
    );
  return (
    <Button
      size="sm"
      variant="outline"
      className="h-7 px-2.5 text-[11px]"
      onClick={(e) => {
        e.stopPropagation();
        dispatch(notifyRisk(risk.id));
      }}
    >
      <BellRing className="h-3 w-3" />
      Notify owner
    </Button>
  );
}

/* ------------------------------- RAG matrix ------------------------------- */

const RAG_DOT: Record<string, string> = {
  red: "bg-red-500",
  amber: "bg-amber-500",
  green: "bg-emerald-500",
};

/** Cell of the SLA matrix: coloured status dot + actual %. Opens the incident
 *  drilldown when a `buildSpec` is supplied via cellRendererParams. */
export function RagCell(
  p: ICellRendererParams & { buildSpec?: (params: ICellRendererParams) => DrillSpec | null }
) {
  const cell = (p.data?.cells as Record<string, { actualPct: number; status: string }> | undefined)?.[
    p.colDef?.colId ?? ""
  ];
  if (!cell) return <span className="text-muted-foreground">—</span>;
  const onDrill = (p.context as { onDrill?: (spec: DrillSpec) => void } | undefined)?.onDrill;
  const spec = p.buildSpec?.(p) ?? null;
  const clickable = Boolean(onDrill && spec);
  return (
    <button
      type="button"
      disabled={!clickable}
      onClick={(e) => {
        e.stopPropagation();
        if (clickable) onDrill!(spec!);
      }}
      className={`-mx-1 inline-flex items-center gap-1.5 rounded px-1 ${clickable ? "cursor-pointer hover:bg-secondary/70" : ""}`}
    >
      <span className={`h-2 w-2 rounded-full ${RAG_DOT[cell.status]}`} />
      <span className={`num text-xs ${cell.status === "red" ? "font-semibold text-red-600 dark:text-red-400" : "font-medium"}`}>
        {cell.actualPct}%
      </span>
    </button>
  );
}

export function RagCountCell(
  p: ICellRendererParams & {
    rag: "red" | "amber" | "green";
    buildSpec?: (params: ICellRendererParams) => DrillSpec | null;
  }
) {
  if (p.value == null) return null;
  const v = Number(p.value);
  const tone =
    p.rag === "red"
      ? v > 0
        ? "bg-red-500/10 text-red-600 dark:text-red-400 font-semibold"
        : "text-muted-foreground"
      : p.rag === "amber"
        ? "bg-amber-500/10 text-amber-600 dark:text-amber-400 font-medium"
        : "text-emerald-600 dark:text-emerald-400 font-medium";
  const onDrill = (p.context as { onDrill?: (spec: DrillSpec) => void } | undefined)?.onDrill;
  const spec = p.buildSpec?.(p) ?? null;
  const clickable = Boolean(onDrill && spec && v > 0);
  return (
    <button
      type="button"
      disabled={!clickable}
      onClick={(e) => {
        e.stopPropagation();
        if (clickable) onDrill!(spec!);
      }}
      className={`num inline-flex min-w-7 justify-center rounded px-1.5 py-0.5 text-xs ${tone} ${
        clickable ? "cursor-pointer hover:opacity-70" : ""
      }`}
    >
      {v}
    </button>
  );
}

const SENTIMENT_STYLE: Record<string, string> = {
  positive: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  neutral: "bg-secondary text-muted-foreground",
  negative: "bg-red-500/10 text-red-600 dark:text-red-400",
};

export function SentimentCell(p: ICellRendererParams) {
  if (!p.value) return null;
  return (
    <span className={`rounded px-1.5 py-0.5 text-[10.5px] font-semibold capitalize ${SENTIMENT_STYLE[p.value]}`}>
      {p.value}
    </span>
  );
}

/** Reopened-count cell — loud when it's actually a problem. */
export function ReopenCountCell(p: ICellRendererParams) {
  if (p.value == null) return null;
  const v = Number(p.value);
  const hot = v >= (p.node?.group ? 20 : 8);
  return (
    <span
      className={`num inline-flex min-w-7 justify-center rounded px-1.5 py-0.5 text-xs font-medium ${
        hot ? "bg-red-500/10 font-semibold text-red-600 dark:text-red-400" : ""
      }`}
    >
      {v}
    </span>
  );
}

/* ---------------------- drill navigation (headers/groups) ------------------- */

/**
 * Inner renderer for auto-group columns whose groups are portfolios:
 * shows the portfolio name plus an "Open" affordance that lands on the
 * given tab of the portfolio page.
 */
export function GroupOpenCell(p: ICellRendererParams & { basePath?: string }) {
  const navigate = useNavigate();
  if (!p.node.group) return p.value ?? null;
  const portfolioId = p.node.allLeafChildren?.[0]?.data?.portfolioId as string | undefined;
  const base = p.basePath ?? "/portfolio";
  return (
    <span className="flex items-center gap-1.5">
      <span className="font-semibold">{p.value}</span>
      {portfolioId && (
        <button
          className="inline-flex items-center gap-0.5 rounded px-1 text-[10.5px] font-medium text-brand opacity-80 transition-opacity hover:opacity-100"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`${base}/${portfolioId}`);
          }}
        >
          Open
          <ArrowUpRight className="h-3 w-3" />
        </button>
      )}
    </span>
  );
}

/** Application column header that drills into a dedicated application page. */
export function AppHeader(p: IHeaderParams & { to: string }) {
  const navigate = useNavigate();
  return (
    <button
      className="flex w-full items-center gap-1 truncate text-left transition-colors hover:text-brand"
      title={`${p.displayName} — open application view`}
      onClick={() => navigate(p.to)}
    >
      <span className="truncate">{p.displayName}</span>
      <ArrowUpRight className="h-3 w-3 shrink-0 opacity-60" />
    </button>
  );
}

/** Portfolio column-group header that drills into a dedicated portfolio page. */
export function PortfolioGroupHeader(p: IHeaderGroupParams & { to: string }) {
  const navigate = useNavigate();
  return (
    <button
      className="mx-auto flex items-center gap-1 truncate transition-colors hover:text-brand"
      title={`${p.displayName} — open portfolio view`}
      onClick={() => navigate(p.to)}
    >
      <span className="truncate">{p.displayName}</span>
      <ArrowUpRight className="h-3 w-3 shrink-0 opacity-60" />
    </button>
  );
}
