import { useMemo } from "react";
import type { EChartsCoreOption } from "echarts/core";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { SLA_RULE_ORDER } from "@/application/governance/data/slaData";
import type { LiveBreachRisk } from "@/application/governance/types";

const FORECAST_WINDOWS = ["0-30 min", "31-60 min", "1-2 h", "2-3 h"] as const;
type ForecastWindow = (typeof FORECAST_WINDOWS)[number];
type RuleForecastRow = { rule: string } & Record<ForecastWindow, number>;

const WINDOW_COLORS: Record<ForecastWindow, string> = {
  "0-30 min": "#ef3340",
  "31-60 min": "#f59e0b",
  "1-2 h": "#3b82f6",
  "2-3 h": "#94a3b8",
};

function forecastWindow(etaMin: number): ForecastWindow {
  if (etaMin <= 30) return "0-30 min";
  if (etaMin <= 60) return "31-60 min";
  if (etaMin <= 120) return "1-2 h";
  return "2-3 h";
}

export function SlaRuleForecastChart({ risks }: { risks: LiveBreachRisk[] }) {
  const rows = useMemo<RuleForecastRow[]>(() => {
    const byRule = new Map<string, RuleForecastRow>(
      SLA_RULE_ORDER.map((rule) => [
        rule,
        {
          rule,
          "0-30 min": 0,
          "31-60 min": 0,
          "1-2 h": 0,
          "2-3 h": 0,
        },
      ])
    );

    for (const risk of risks) {
      const row = byRule.get(risk.metric);
      if (row) row[forecastWindow(risk.etaMin)] += 1;
    }

    return SLA_RULE_ORDER.map((rule) => byRule.get(rule)!);
  }, [risks]);

  const option = useMemo<EChartsCoreOption>(() => {
    const maxTickets = Math.max(
      2,
      ...rows.map((row) =>
        FORECAST_WINDOWS.reduce((total, window) => total + row[window], 0)
      )
    );

    return {
      grid: { top: 8, right: 18, bottom: 48, left: 152 },
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" },
      },
      legend: {
        bottom: 4,
        itemWidth: 10,
        itemHeight: 8,
        itemGap: 14,
        textStyle: { fontSize: 10 },
      },
      xAxis: {
        type: "value",
        min: 0,
        max: maxTickets,
        minInterval: 1,
        axisLabel: { fontSize: 10 },
      },
      yAxis: {
        type: "category",
        inverse: true,
        data: rows.map((row) => row.rule),
        axisLabel: { fontSize: 10, width: 140, overflow: "truncate" },
      },
      series: FORECAST_WINDOWS.map((window) => ({
        name: window,
        type: "bar",
        stack: "forecast-window",
        barMaxWidth: 18,
        itemStyle: { color: WINDOW_COLORS[window] },
        emphasis: { focus: "series" },
        data: rows.map((row) => row[window]),
      })),
    };
  }, [rows]);

  return <ApacheEChart option={option} ariaLabel="SLA breach forecast by rule" />;
}
