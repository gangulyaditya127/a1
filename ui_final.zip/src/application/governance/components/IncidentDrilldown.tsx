import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight, X } from "lucide-react";
import type { ColDef } from "ag-grid-community";
import { DataGrid } from "@/shared/components/DataGrid";
import { incidentsFor } from "@/application/governance/data/slaData";
import type { DrillSpec, IncidentRecord } from "@/application/governance/types";

export function DurationCell(p: { data?: IncidentRecord }) {
  if (!p.data) return null;
  const fmt = (m: number) => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`);
  const over = p.data.durationMin > p.data.targetMin;
  return (
    <span className="text-xs">
      <span className={`num font-medium ${over ? "text-red-600 dark:text-red-400" : ""}`}>
        {fmt(p.data.durationMin)}
      </span>
      <span className="text-muted-foreground"> / {fmt(p.data.targetMin)} target</span>
    </span>
  );
}

export function OutcomeCell(p: { value?: string }) {
  if (!p.value) return null;
  const breached = p.value === "Breached";
  return (
    <span
      className={`rounded px-1.5 py-0.5 text-[10.5px] font-semibold ${
        breached
          ? "bg-red-500/10 text-red-600 dark:text-red-400"
          : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
      }`}
    >
      {p.value}
    </span>
  );
}

const INCIDENT_COLS: ColDef<IncidentRecord>[] = [
  { field: "portfolio", rowGroup: true, hide: true },
  { field: "application", rowGroup: true, hide: true },
  { field: "id", headerName: "Ticket", maxWidth: 120, cellClass: "num font-medium" },
  { field: "measure", headerName: "Measure", flex: 1.1, minWidth: 150 },
  { field: "priority", headerName: "Priority", maxWidth: 90 },
  { field: "openedAt", headerName: "Opened", maxWidth: 130 },
  { headerName: "Duration vs target", cellRenderer: DurationCell, minWidth: 190, flex: 1 },
  { field: "outcome", headerName: "Outcome", cellRenderer: OutcomeCell, maxWidth: 110 },
];

/**
 * The floor of every drilldown: click a red/amber/green count anywhere in the
 * console and it resolves to this — real tickets, grouped Portfolio ▸
 * Application, each with its duration against target and outcome.
 */
export function IncidentDrilldown({
  spec,
  onClose,
}: {
  spec: DrillSpec | null;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const rows = useMemo(() => (spec ? incidentsFor(spec.filter) : []), [spec]);

  if (!spec) return null;

  const breached = rows.filter((r) => r.outcome === "Breached").length;
  const distinctApps = new Set(rows.map((r) => r.appId)).size;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="flex max-h-[85vh] w-full max-w-4xl flex-col rounded-lg border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b px-5 py-4">
          <div className="min-w-0">
            <h2 className="text-sm font-semibold">{spec.title}</h2>
            {spec.subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{spec.subtitle}</p>}
            <p className="mt-1 text-[11px] text-muted-foreground">
              {rows.length} incident{rows.length === 1 ? "" : "s"} · {breached} breached
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            {spec.filter.appId && (
              <button
                onClick={() => {
                  onClose();
                  navigate(`${spec.section ? `/${spec.section}` : ""}/application/${spec.filter.appId}`);
                }}
                className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-medium text-brand transition-colors hover:bg-brand-soft"
              >
                Open application
                <ArrowUpRight className="h-3 w-3" />
              </button>
            )}
            {!spec.filter.appId && spec.filter.portfolioId && (
              <button
                onClick={() => {
                  onClose();
                  navigate(`${spec.section ? `/${spec.section}` : ""}/portfolio/${spec.filter.portfolioId}`);
                }}
                className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-medium text-brand transition-colors hover:bg-brand-soft"
              >
                Open portfolio
                <ArrowUpRight className="h-3 w-3" />
              </button>
            )}
            <button
              onClick={onClose}
              aria-label="Close"
              className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-hidden p-4">
          {rows.length === 0 ? (
            <p className="rounded-md border border-dashed px-3 py-10 text-center text-xs text-muted-foreground">
              No incidents match this view.
            </p>
          ) : (
            <DataGrid<IncidentRecord>
              height={440}
              rowData={rows}
              columnDefs={INCIDENT_COLS}
              groupDefaultExpanded={distinctApps <= 3 ? -1 : 1}
              autoGroupColumnDef={{ headerName: "Portfolio / Application", minWidth: 220, flex: 1.4 }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
