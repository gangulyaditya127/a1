import { useMemo, useState, type ReactNode } from "react";
import type { EChartsCoreOption } from "echarts/core";
import { ApacheEChart } from "@/shared/components/ApacheEChart";
import { ChartCard } from "@/shared/components/ChartCard";
import { Tabs, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import { CHART } from "@/shared/lib/chart";
import { MONTHS } from "@/application/governance/data/slaData";
import type {
  MonthPoint,
  SlaKpiRow,
  TimeRange,
} from "@/application/governance/types";

const PRIORITY_COLORS: Record<SlaKpiRow["priority"], string> = {
  P1: CHART.red,
  P2: CHART.amber,
  P3: CHART.blue,
  P4: CHART.green,
};

const CATEGORY_LABELS: Record<SlaKpiRow["category"], string> = {
  response: "Response",
  resolution: "Resolution",
  aging: "Aging",
};

const CATEGORY_ORDER: SlaKpiRow["category"][] = ["response", "resolution", "aging"];

const RANGE_MONTHS: Record<TimeRange, number> = { "3m": 3, "6m": 6, "12m": 12 };

interface CommonProps {
  matrix: SlaKpiRow[];
  range: TimeRange;
  loading: boolean;
  title?: string;
  subtitle?: string;
  action?: ReactNode;
  className?: string;
  height?: number;
}

type SlaKpiTrendChartProps = CommonProps &
  (
    | { mode: "application"; appId: string }
    | { mode: "portfolio"; appIds: string[] }
  );

export function SlaKpiTrendChart(props: SlaKpiTrendChartProps) {
  const {
    matrix,
    range,
    loading,
    title,
    subtitle,
    action,
    className,
    height = 250,
    mode,
  } = props;
  const appId = mode === "application" ? props.appId : null;
  const portfolioAppIds = mode === "portfolio" ? props.appIds : null;
  const [selectedCategory, setSelectedCategory] = useState<SlaKpiRow["category"]>("response");
  const scopeIds = useMemo(
    () => (appId ? [appId] : portfolioAppIds ?? []),
    [appId, portfolioAppIds]
  );
  const start = MONTHS.length - RANGE_MONTHS[range];

  const availableCategories = useMemo(
    () => CATEGORY_ORDER.filter((category) => matrix.some((row) => row.category === category)),
    [matrix]
  );
  const activeCategory = availableCategories.includes(selectedCategory)
    ? selectedCategory
    : availableCategories[0];

  const kpis = useMemo(
    () =>
      matrix.filter(
        (row) =>
          row.category === activeCategory && scopeIds.some((appId) => row.cells[appId])
      ),
    [activeCategory, matrix, scopeIds]
  );

  const categoryControl = availableCategories.length > 1 ? (
    <Tabs
      value={activeCategory}
      onValueChange={(value) => setSelectedCategory(value as SlaKpiRow["category"])}
    >
      <TabsList className="h-8" aria-label="SLA obligation family">
        {availableCategories.map((category) => (
          <TabsTrigger key={category} value={category} className="px-2.5 py-0.5">
            {CATEGORY_LABELS[category]}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  ) : null;

  const chartAction = action || categoryControl ? (
    <div className="flex flex-wrap items-center justify-end gap-2">
      {action}
      {categoryControl}
    </div>
  ) : undefined;

  const data = useMemo<MonthPoint[]>(
    () =>
      MONTHS.slice(start).map((month, offset) => {
        const monthIndex = start + offset;
        const point: MonthPoint = { month };

        for (const row of kpis) {
          if (mode === "application") {
            const cell = row.cells[scopeIds[0]];
            if (!cell) continue;
            const precision = row.targetPct >= 99 ? 2 : 1;
            point[row.measure] = Number(
              (cell.trendPct[monthIndex] - row.targetPct).toFixed(precision)
            );
          } else {
            point[row.measure] = scopeIds.reduce((count, appId) => {
              const cell = row.cells[appId];
              return count + (cell && cell.trendPct[monthIndex] < row.targetPct ? 1 : 0);
            }, 0);
          }
        }

        return point;
      }),
    [kpis, mode, scopeIds, start]
  );

  const applicationMode = mode === "application";
  const exceptionPeak = applicationMode
    ? 1
    : Math.max(
        1,
        ...data.flatMap((point) =>
          kpis.map((row) => Number(point[row.measure] ?? 0))
        )
      );
  const exceptionCeiling = Math.max(2, Math.ceil(exceptionPeak * 1.15));
  const option = useMemo<EChartsCoreOption>(
    () => ({
      grid: { top: 12, right: 16, bottom: 50, left: 48 },
      tooltip: { trigger: "axis" },
      legend: { bottom: 4, type: "scroll" },
      xAxis: {
        type: "category",
        boundaryGap: false,
        data: data.map((point) => point.month),
        splitLine: { show: false },
      },
      yAxis: {
        type: "value",
        min: applicationMode ? undefined : 0,
        max: applicationMode ? undefined : exceptionCeiling,
        minInterval: applicationMode ? undefined : 1,
        axisLabel: applicationMode
          ? { formatter: (value: number) => `${value > 0 ? "+" : ""}${value}` }
          : undefined,
      },
      series: kpis.map((row, index) => ({
        name: row.measure,
        type: "line",
        smooth: true,
        showSymbol: false,
        lineStyle: { width: 2, color: PRIORITY_COLORS[row.priority] },
        itemStyle: { color: PRIORITY_COLORS[row.priority] },
        data: data.map((point) => point[row.measure] ?? null),
        markLine:
          applicationMode && index === 0
            ? {
                silent: true,
                symbol: "none",
                label: { show: false },
                lineStyle: { color: CHART.red, type: "dashed" },
                data: [{ yAxis: 0 }],
              }
            : undefined,
      })),
    }),
    [applicationMode, data, exceptionCeiling, kpis]
  );

  return (
    <ChartCard
      title={title ?? (applicationMode ? "SLA KPI performance vs target" : "SLA KPI exceptions trend")}
      subtitle={subtitle ?? (
        applicationMode
          ? "Monthly percentage-point headroom against each KPI's own target"
          : "Applications below target, shown separately for each contracted KPI"
      )}
      loading={loading}
      height={height}
      action={chartAction}
      className={className}
    >
      <ApacheEChart option={option} ariaLabel={applicationMode ? "SLA KPI performance versus target" : "SLA KPI exceptions trend"} />
    </ChartCard>
  );
}
