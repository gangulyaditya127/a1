import type {
  EstateApp,
  HealthStatus,
  SlaKpiRow,
} from "@/application/governance/types";

const RISK_RANK: Record<HealthStatus, number> = {
  "on-track": 0,
  "at-risk": 1,
  breached: 2,
};

const avg = (ns: number[]) => ns.reduce((a, b) => a + b, 0) / (ns.length || 1);
const r1 = (n: number) => Number(n.toFixed(1));

export interface Rollup {
  xla: number;
  xlaDelta: number;
  openP1: number;
  openP2: number;
  risk: HealthStatus;
  count: number;
}

export function rollup(apps: EstateApp[]): Rollup {
  const worst = apps.reduce<HealthStatus>(
    (w, a) => (RISK_RANK[a.risk] > RISK_RANK[w] ? a.risk : w),
    "on-track"
  );
  return {
    xla: Math.round(avg(apps.map((a) => a.xla))),
    xlaDelta: r1(avg(apps.map((a) => a.xlaDelta))),
    openP1: apps.reduce((n, a) => n + a.openP1, 0),
    openP2: apps.reduce((n, a) => n + a.openP2, 0),
    risk: worst,
    count: apps.length,
  };
}

/** RAG counts for one application across every measure in the matrix. */
export function ragForApp(matrix: SlaKpiRow[], appId: string) {
  let red = 0,
    amber = 0,
    green = 0;
  for (const row of matrix) {
    const c = row.cells[appId];
    if (!c) continue;
    if (c.status === "red") red += 1;
    else if (c.status === "amber") amber += 1;
    else green += 1;
  }
  return { red, amber, green };
}

/** RAG counts for a portfolio (all instances across its apps). */
export function ragForPortfolio(
  matrix: SlaKpiRow[],
  estate: EstateApp[],
  portfolioId: string
) {
  const ids = estate.filter((a) => a.portfolioId === portfolioId).map((a) => a.id);
  return ids.reduce(
    (acc, id) => {
      const r = ragForApp(matrix, id);
      return { red: acc.red + r.red, amber: acc.amber + r.amber, green: acc.green + r.green };
    },
    { red: 0, amber: 0, green: 0 }
  );
}
