import type { MonthPoint, TimeRange } from "@/application/governance/types";
import * as sla from "@/application/governance/data/slaData";
import * as prod from "@/application/governance/data/productivityData";
import * as quality from "@/application/governance/data/qualityData";
import * as friction from "@/application/governance/data/frictionData";

/**
 * In-memory service layer with realistic latency so loading states are
 * honest. Replace these with live API calls (same shapes) — the state
 * layer and pages won't need to change.
 */

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

const RANGE_MONTHS: Record<TimeRange, number> = { "3m": 3, "6m": 6, "12m": 12 };

export function sliceMonths(series: MonthPoint[], range: TimeRange): MonthPoint[] {
  return series.slice(-RANGE_MONTHS[range]);
}

export async function fetchSla(range: TimeRange) {
  await delay(450);
  return {
    summary: sla.slaSummary,
    csatTrend: sliceMonths(sla.csatTrend, range),
    statusCounts: sla.STATUS_COUNTS,
    kpiMatrix: sla.KPI_MATRIX,
    redRankedAppIds: sla.rankAppsByRed(),
    sentiment: {
      summary: sla.sentimentSummary,
      trend: sliceMonths(sla.sentimentTrend, range),
      themes: sla.sentimentThemes,
      comments: sla.userComments,
    },
    friction: {
      summary: friction.frictionSummary,
      apps: friction.appFriction,
    },
    estate: sla.ESTATE,
    liveRisks: sla.liveRisksAt(0),
    digests: sla.digestRules,
    sends: sla.seedSends,
  };
}

export async function fetchLiveRisks(tick: number) {
  await delay(600);
  return { tick, risks: sla.liveRisksAt(tick), at: new Date().toISOString() };
}

export async function fetchProductivity(range: TimeRange) {
  await delay(500);
  return {
    summary: prod.productivitySummary,
    volumeTrend: sliceMonths(prod.volumeTrend, range),
    savingsTrend: sliceMonths(prod.savingsTrend, range),
    throughputTrend: sliceMonths(prod.throughputTrend, range),
    topAutomations: prod.topAutomations,
    portfolios: prod.portfolioDelivery,
    individuals: prod.individuals,
  };
}

export async function fetchQuality(range: TimeRange) {
  await delay(320);
  return {
    summary: quality.qualitySummary,
    avoidedTrend: sliceMonths(quality.avoidedTrend, range),
  };
}
