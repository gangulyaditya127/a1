import { Link, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { CanadaLifeLogo, TcsLogo } from "@/shared/components/Logos";
import { Badge } from "@/shared/ui/badge";
import { closeSidebar } from "@/shared/state/uiSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { isNavItemActive } from "@/shared/lib/navigation";
import { cn } from "@/shared/lib/utils";
import type { AppManifest } from "@/shared/types";

/**
 * The sidebar belongs to the shared frame but renders whatever the active
 * application's manifest declares — it has no knowledge of specific apps.
 */
export function Sidebar({ app }: { app: AppManifest }) {
  const open = useAppSelector((s) => s.ui.sidebarOpen);
  const dispatch = useAppDispatch();
  const { pathname } = useLocation();

  return (
    <>
      {/* mobile scrim */}
      <div
        className={cn(
          "fixed inset-0 z-30 bg-foreground/30 backdrop-blur-[2px] transition-opacity md:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={() => dispatch(closeSidebar())}
      />

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r bg-card transition-transform md:static md:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-14 items-center border-b px-4">
          <CanadaLifeLogo />
        </div>

        <div className="border-b px-3 py-3">
          <Link
            to="/"
            onClick={() => dispatch(closeSidebar())}
            className="mb-2.5 flex items-center gap-1.5 px-1 text-[11px] font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-3 w-3" />
            All applications
          </Link>
          <div className="flex items-center gap-2.5 px-1">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-brand-soft">
              <app.icon className="h-4 w-4 text-brand" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-[13px] font-semibold leading-4">{app.name}</p>
              <p className="text-[10.5px] text-muted-foreground">
                {app.code === "General" ? "Platform services" : app.code}
              </p>
            </div>
          </div>
        </div>

        <nav className="scrollbar-thin flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-0.5">
            {app.nav.map((item) => {
              const active = isNavItemActive(item, pathname);

              return item.disabled ? (
                <li key={item.label}>
                  <span className="flex cursor-default items-center gap-2.5 rounded-md px-2 py-1.5 text-[13px] font-medium text-muted-foreground/60">
                    <item.icon className="h-4 w-4 shrink-0 opacity-60" />
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.soon && (
                      <Badge variant="muted" className="px-1.5 text-[9.5px]">
                        Soon
                      </Badge>
                    )}
                  </span>
                </li>
              ) : (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    aria-current={active ? "page" : undefined}
                    onClick={() => dispatch(closeSidebar())}
                    className={cn(
                      "group relative flex items-center gap-2.5 rounded-md px-2 py-1.5 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
                      active && "bg-brand-soft text-accent-foreground"
                    )}
                  >
                    {/* red square from the brand mark = active cue */}
                    <span
                      className={cn(
                        "absolute -left-[3px] top-1/2 h-2 w-2 -translate-y-1/2 rounded-[2.5px] bg-brand opacity-0 transition-opacity",
                        active && "opacity-100"
                      )}
                    />
                    <item.icon
                      className={cn(
                        "h-4 w-4 shrink-0",
                        active
                          ? "text-brand"
                          : "text-muted-foreground/70 group-hover:text-foreground"
                      )}
                    />
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.soon && (
                      <Badge variant="muted" className="px-1.5 text-[9.5px]">
                        Soon
                      </Badge>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t px-4 py-3">
          <p className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">
            Delivered by
          </p>
          <div className="flex items-center justify-between">
            <TcsLogo full />
            <span className="text-[10px] text-muted-foreground">AMS Service Console</span>
          </div>
        </div>
      </aside>
    </>
  );
}
