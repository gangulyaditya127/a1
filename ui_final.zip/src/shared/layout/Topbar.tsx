import { useLocation } from "react-router-dom";
import { Bell, PanelLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/shared/ui/select";
import { Separator } from "@/shared/ui/separator";
import { ThemeToggle } from "@/shared/layout/ThemeToggle";
import { isNavItemActive } from "@/shared/lib/navigation";
import { setTimeRange, toggleSidebar } from "@/shared/state/uiSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import type { AppManifest, TimeRange } from "@/shared/types";

const RANGES: { value: TimeRange; label: string }[] = [
  { value: "3m", label: "Last 3 months" },
  { value: "6m", label: "Last 6 months" },
  { value: "12m", label: "Last 12 months" },
];

export function Topbar({ app }: { app: AppManifest }) {
  const dispatch = useAppDispatch();
  const timeRange = useAppSelector((s) => s.ui.timeRange);
  const { pathname } = useLocation();

  const title =
    app.nav.find((n) => isNavItemActive(n, pathname))?.label ?? app.name;

  return (
    <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b bg-card/95 px-4 backdrop-blur">
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden"
        onClick={() => dispatch(toggleSidebar())}
        aria-label="Toggle navigation"
      >
        <PanelLeft className="h-4 w-4" />
      </Button>

      <div className="min-w-0">
        <p className="truncate text-sm font-semibold">{title}</p>
        <p className="hidden text-[11px] text-muted-foreground sm:block">
          {app.name} · AMS Service Console
        </p>
      </div>

      <div className="ml-auto flex items-center gap-2.5">
        {app.usesTimeRange && (
          <Select
            value={timeRange}
            onValueChange={(v) => dispatch(setTimeRange(v as TimeRange))}
          >
            <SelectTrigger className="h-8 w-[150px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {RANGES.map((r) => (
                <SelectItem key={r.value} value={r.value} className="text-xs">
                  {r.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        <ThemeToggle />

        <Button
          variant="ghost"
          size="icon"
          className="relative"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4" />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-brand" />
        </Button>

        <Separator orientation="vertical" className="hidden h-6 sm:block" />

        <div className="hidden items-center gap-2 sm:flex">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-secondary text-[11px] font-semibold text-secondary-foreground">
            SM
          </span>
          <div className="leading-tight">
            <p className="text-xs font-medium">Sudipta Maiti</p>
            <p className="text-[10.5px] text-muted-foreground">
              Service Owner · Group Benefits
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}
