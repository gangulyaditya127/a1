import type { LucideIcon } from "lucide-react";
import type { RouteObject } from "react-router-dom";

/* ------------------------------ cross-cutting ----------------------------- */

export type TimeRange = "3m" | "6m" | "12m";

export type Theme = "light" | "dark";

/** Generic month point; series keys vary per chart. */
export interface MonthPoint {
  month: string;
  [series: string]: string | number;
}

/* ------------------------------- navigation ------------------------------ */

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  /** Route prefixes that belong to this section, including drill-down pages. */
  activePrefixes?: string[];
  /** Rendered but not clickable — used for planned modules. */
  disabled?: boolean;
  soon?: boolean;
}

/* ------------------------------ app manifest ------------------------------ */

/**
 * Every application under src/application/<name> exports one of these.
 * The manifest is the ONLY contract the rest of the portal knows about:
 * the root registry composes manifests into the router, launcher and layout.
 * Applications never import from each other.
 */
export interface AppManifest {
  id: string;
  /** Planner code, e.g. "S6" or "General". */
  code: string;
  name: string;
  description: string;
  icon: LucideIcon;
  /** Route the launcher card opens. */
  entry: string;
  /** Every top-level path this app owns (drives active-app detection). */
  paths: string[];
  /** Prefixes for parameterised routes this app owns, e.g. "/portfolio". */
  dynamicPaths?: string[];
  /** Per-app sidebar navigation. */
  nav: NavItem[];
  /** Route objects mounted under the shared app frame. */
  routes: RouteObject[];
  status: "live" | "preview";
  /** Show the global reporting-window selector in the topbar. */
  usesTimeRange?: boolean;
  /** Optional headline stats for the launcher card. */
  stats?: { label: string; value: string }[];
}

/* --------------------------- use-case scaffolding ------------------------- */

export interface PlannedModule {
  title: string;
  description: string;
}

export interface UseCaseDef {
  code: string;
  title: string;
  tagline: string;
  status: string;
  lead: string;
  scenario: string;
  agents: string[];
  journey: { step: string; detail: string }[];
  outcomes: string[];
  plannedModules: PlannedModule[];
}
