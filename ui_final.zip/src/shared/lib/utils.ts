import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** 4812 -> "4,812" */
export function fmtNum(n: number): string {
  return new Intl.NumberFormat("en-CA").format(n);
}

/** 412000 -> "CA$412K", 1410000 -> "CA$1.41M" */
export function fmtCad(n: number): string {
  if (Math.abs(n) >= 1_000_000) return `CA$${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000) return `CA$${Math.round(n / 1_000)}K`;
  return `CA$${fmtNum(n)}`;
}

export function fmtPct(n: number, digits = 1): string {
  return `${n.toFixed(digits)}%`;
}

/** ISO string -> "Jul 17, 2026" (en-CA short) */
export function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-CA", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

/** ISO string -> "Jul 17, 09:12" */
export function fmtDateTime(iso: string): string {
  return new Date(iso).toLocaleString("en-CA", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}
