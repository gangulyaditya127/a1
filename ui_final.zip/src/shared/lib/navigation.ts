import type { NavItem } from "@/shared/types";

export function isNavItemActive(item: NavItem, pathname: string) {
  if (pathname === item.to) return true;

  return item.activePrefixes?.some(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
  ) ?? false;
}
