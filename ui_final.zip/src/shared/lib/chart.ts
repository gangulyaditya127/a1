/** Canvas-safe ECharts series colors chosen to read on both themes. */
export const CHART = {
  red: "#EF3340",
  slate: "#94A3B8",
  blue: "#3B82F6",
  sky: "#0EA5E9",
  green: "#10B981",
  amber: "#F59E0B",
  violet: "#8B5CF6",
} as const;
