/**
 * AG Grid Enterprise setup — imported once by the DataGrid wrapper.
 * The quartz theme's CSS variables are remapped to the design system in
 * src/index.css, so grids follow light/dark automatically.
 */
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import "ag-grid-enterprise";
import { LicenseManager } from "ag-grid-enterprise";

const key = (import.meta as { env?: Record<string, string> }).env
  ?.VITE_AG_GRID_LICENSE_KEY;
if (key) LicenseManager.setLicenseKey(key);

export const AG_THEME_CLASS = "ag-theme-quartz";
