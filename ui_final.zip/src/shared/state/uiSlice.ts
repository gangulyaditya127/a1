import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { Theme, TimeRange } from "@/shared/types";

const THEME_KEY = "cl-theme";

function initialTheme(): Theme {
  if (typeof window === "undefined") return "light";
  const stored = window.localStorage.getItem(THEME_KEY);
  if (stored === "light" || stored === "dark") return stored;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

interface UiState {
  theme: Theme;
  timeRange: TimeRange;
  sidebarOpen: boolean;
}

const initialState: UiState = {
  theme: initialTheme(),
  timeRange: "6m",
  sidebarOpen: false, // mobile drawer; desktop sidebar is always visible
};

const uiSlice = createSlice({
  name: "ui",
  initialState,
  reducers: {
    setTheme(state, action: PayloadAction<Theme>) {
      state.theme = action.payload;
    },
    toggleTheme(state) {
      state.theme = state.theme === "dark" ? "light" : "dark";
    },
    setTimeRange(state, action: PayloadAction<TimeRange>) {
      state.timeRange = action.payload;
    },
    toggleSidebar(state) {
      state.sidebarOpen = !state.sidebarOpen;
    },
    closeSidebar(state) {
      state.sidebarOpen = false;
    },
  },
});

export const { setTheme, toggleTheme, setTimeRange, toggleSidebar, closeSidebar } =
  uiSlice.actions;
export { THEME_KEY };
export default uiSlice.reducer;
