import { AgGridReact, type AgGridReactProps } from "ag-grid-react";
import { AG_THEME_CLASS } from "@/shared/lib/agGrid";
import { cn } from "@/shared/lib/utils";

interface DataGridProps<T> extends AgGridReactProps<T> {
  /** Fixed pixel height, or "auto" to size to rows. */
  height?: number | "auto";
  className?: string;
}

/**
 * Themed AG Grid Enterprise wrapper — the standard table for the console.
 * Sensible defaults: sortable/resizable columns, quiet focus, animated rows.
 */
export function DataGrid<T>({
  height = 420,
  className,
  defaultColDef,
  ...props
}: DataGridProps<T>) {
  return (
    <div
      className={cn(AG_THEME_CLASS, "w-full", className)}
      style={height === "auto" ? undefined : { height }}
    >
      <AgGridReact<T>
        animateRows
        suppressCellFocus
        domLayout={height === "auto" ? "autoHeight" : "normal"}
        defaultColDef={{
          sortable: true,
          resizable: true,
          flex: 1,
          minWidth: 110,
          suppressHeaderMenuButton: true,
          ...defaultColDef,
        }}
        {...props}
      />
    </div>
  );
}
