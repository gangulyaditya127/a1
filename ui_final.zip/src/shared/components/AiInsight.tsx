import type { ReactNode } from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/shared/lib/utils";

/**
 * Signature treatment for AI-generated content: a quiet card with a soft
 * brand glow, a labelled header and an optional action row. Used
 * consistently so AI output is recognisable at a glance.
 */
export function AiInsight({
  children,
  source,
  title,
  actions,
  className,
}: {
  children: ReactNode;
  source?: string;
  title?: string;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg border bg-card p-4 shadow-card",
        className
      )}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -left-12 -top-14 h-36 w-36 rounded-full bg-brand/[0.09] blur-2xl"
      />
      <div className="relative flex gap-3">
        <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-md bg-brand-soft">
          <Sparkles className="h-3.5 w-3.5 text-brand" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <span className="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-brand">
              AI insight
            </span>
            {source && (
              <span className="text-[11px] text-muted-foreground">{source}</span>
            )}
          </div>
          {title && (
            <p className="mt-1 text-[13px] font-semibold leading-4">{title}</p>
          )}
          <div className="mt-1 text-[12.5px] leading-relaxed text-foreground/80">
            {children}
          </div>
          {actions && (
            <div className="mt-2.5 flex flex-wrap items-center gap-2">{actions}</div>
          )}
        </div>
      </div>
    </div>
  );
}
