import { useEffect, useMemo, useRef } from "react";
import * as echarts from "echarts/core";
import { BarChart, LineChart, PieChart } from "echarts/charts";
import {
  AriaComponent,
  GridComponent,
  LegendComponent,
  MarkLineComponent,
  TooltipComponent,
} from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";
import type { EChartsCoreOption, EChartsType } from "echarts/core";
import { useAppSelector } from "@/app/hooks";

echarts.use([
  AriaComponent,
  BarChart,
  CanvasRenderer,
  GridComponent,
  LegendComponent,
  LineChart,
  MarkLineComponent,
  PieChart,
  TooltipComponent,
]);

type OptionRecord = Record<string, unknown>;

function themedAxis(axis: unknown, text: string, grid: string): unknown {
  if (axis == null) return undefined;
  if (Array.isArray(axis)) return axis.map((item) => themedAxis(item, text, grid));
  const value = (axis ?? {}) as OptionRecord;
  const axisLabel = (value.axisLabel ?? {}) as OptionRecord;
  const splitLine = (value.splitLine ?? {}) as OptionRecord;
  const splitLineStyle = (splitLine.lineStyle ?? {}) as OptionRecord;

  return {
    axisLine: { show: false, ...((value.axisLine ?? {}) as OptionRecord) },
    axisTick: { show: false, ...((value.axisTick ?? {}) as OptionRecord) },
    splitLine: {
      ...splitLine,
      lineStyle: { color: grid, type: "dashed", ...splitLineStyle },
    },
    ...value,
    axisLabel: { color: text, fontSize: 11, ...axisLabel },
  };
}

export function ApacheEChart({
  option,
  ariaLabel,
  className = "h-full w-full",
}: {
  option: EChartsCoreOption;
  ariaLabel: string;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<EChartsType | null>(null);
  const theme = useAppSelector((state) => state.ui.theme);

  const themedOption = useMemo<EChartsCoreOption>(() => {
    const dark = theme === "dark";
    const text = dark ? "#cbd5e1" : "#475569";
    const grid = dark ? "#334155" : "#e2e8f0";
    const tooltip = (option.tooltip ?? {}) as OptionRecord;
    const tooltipText = (tooltip.textStyle ?? {}) as OptionRecord;
    const legend = (option.legend ?? {}) as OptionRecord;
    const legendText = (legend.textStyle ?? {}) as OptionRecord;

    return {
      animationDuration: 350,
      backgroundColor: "transparent",
      aria: { enabled: true },
      textStyle: { color: text, fontFamily: "Inter, system-ui, sans-serif", fontSize: 11 },
      ...option,
      ...(option.tooltip !== undefined
        ? {
            tooltip: {
              backgroundColor: dark ? "#111827" : "#ffffff",
              borderColor: dark ? "#475569" : "#cbd5e1",
              borderWidth: 1,
              padding: [8, 10],
              ...tooltip,
              textStyle: { color: text, fontSize: 12, ...tooltipText },
            },
          }
        : {}),
      ...(option.legend !== undefined
        ? {
            legend: {
              itemWidth: 12,
              itemHeight: 8,
              itemGap: 16,
              ...legend,
              textStyle: { color: text, fontSize: 11, ...legendText },
            },
          }
        : {}),
      xAxis: themedAxis(option.xAxis, text, grid),
      yAxis: themedAxis(option.yAxis, text, grid),
    };
  }, [option, theme]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const chart = echarts.init(container, undefined, { renderer: "canvas" });
    chartRef.current = chart;
    const resizeObserver = new ResizeObserver(() => chart.resize());
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      chart.dispose();
      chartRef.current = null;
    };
  }, []);

  useEffect(() => {
    chartRef.current?.setOption(themedOption, { notMerge: true });
  }, [themedOption]);

  return <div ref={containerRef} className={className} aria-label={ariaLabel} />;
}
