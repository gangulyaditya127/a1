import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn } from "@/shared/lib/utils";

export interface Trend {
  /** Display string, e.g. "+0.6 pts" or "−18%" */
  value: string;
  direction: "up" | "down" | "flat";
  /** Is this movement good news? Drives the color, not the arrow. */
  positive: boolean;
}

export function TrendIndicator({
  trend,
  className,
}: {
  trend: Trend;
  className?: string;
}) {
  const Icon =
    trend.direction === "up"
      ? ArrowUpRight
      : trend.direction === "down"
        ? ArrowDownRight
        : Minus;

  return (
    <span
      className={cn(
        "num inline-flex items-center gap-0.5 text-[11px] font-medium",
        trend.positive ? "text-emerald-600" : "text-red-600",
        trend.direction === "flat" && "text-muted-foreground",
        className
      )}
    >
      <Icon className="h-3 w-3" />
      {trend.value}
    </span>
  );
}
