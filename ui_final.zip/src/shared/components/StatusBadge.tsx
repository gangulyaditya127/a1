import { Badge } from "@/shared/ui/badge";

type KnownStatus =
  | "on-track"
  | "at-risk"
  | "breached"
  | "live"
  | "pilot"
  | "planned"
  | "idea"
  | "in-progress"
  | "delivered"
  | "open"
  | "closed"
  | "ready"
  | "generating"
  | "scheduled"
  | "monitoring"
  | "fix-in-progress"
  | "pending"
  | "approved"
  | "rejected";

const MAP: Record<
  KnownStatus,
  { label: string; variant: React.ComponentProps<typeof Badge>["variant"] }
> = {
  "on-track": { label: "On track", variant: "success" },
  "at-risk": { label: "At risk", variant: "warning" },
  breached: { label: "Breached", variant: "danger" },
  live: { label: "Live", variant: "success" },
  pilot: { label: "Pilot", variant: "info" },
  planned: { label: "Planned", variant: "muted" },
  idea: { label: "Idea", variant: "muted" },
  "in-progress": { label: "In progress", variant: "info" },
  delivered: { label: "Delivered", variant: "success" },
  open: { label: "Open", variant: "warning" },
  closed: { label: "Closed", variant: "success" },
  ready: { label: "Ready", variant: "success" },
  generating: { label: "Generating…", variant: "info" },
  scheduled: { label: "Scheduled", variant: "muted" },
  monitoring: { label: "Monitoring", variant: "info" },
  "fix-in-progress": { label: "Fix in progress", variant: "warning" },
  pending: { label: "Awaiting review", variant: "warning" },
  approved: { label: "Approved", variant: "success" },
  rejected: { label: "Rejected", variant: "danger" },
};

export function StatusBadge({ status }: { status: KnownStatus }) {
  const { label, variant } = MAP[status];
  return (
    <Badge variant={variant} className="whitespace-nowrap">
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {label}
    </Badge>
  );
}
