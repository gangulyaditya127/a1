import type { ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { Button } from "@/shared/ui/button";

export interface Crumb {
  label: string;
  to?: string;
}

interface PageHeaderProps {
  title: string;
  description?: string;
  crumbs?: Crumb[];
  actions?: ReactNode;
}

export function PageHeader({ title, description, crumbs, actions }: PageHeaderProps) {
  const navigate = useNavigate();
  const trail = crumbs ? [...crumbs, { label: title }] : [];

  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        {trail.length > 0 && (
          <div className="mb-2 flex min-w-0 flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-8 shrink-0 px-2 text-xs text-muted-foreground"
              onClick={() => navigate(-1)}
              title="Back to previous page"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back
            </Button>
            <nav
              aria-label="Breadcrumb"
              className="flex min-w-0 flex-wrap items-center gap-1 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] text-muted-foreground"
            >
              {trail.map((c, i) => {
                const current = i === trail.length - 1;

                return (
                  <span key={`${c.label}-${i}`} className="flex min-w-0 items-center gap-1">
                    {c.to ? (
                      <Link to={c.to} className="font-medium transition-colors hover:text-brand">
                        {c.label}
                      </Link>
                    ) : (
                      <span
                        aria-current={current ? "page" : undefined}
                        className={
                          current
                            ? "truncate rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70"
                            : undefined
                        }
                      >
                        {c.label}
                      </span>
                    )}
                    {!current && (
                      <ChevronRight className="h-3 w-3 shrink-0 text-brand/45" />
                    )}
                  </span>
                );
              })}
            </nav>
          </div>
        )}
        <div className="flex items-center gap-2">
          {/* the red square from the brand mark, reused as a section cue */}
          <span className="h-2.5 w-2.5 shrink-0 rounded-[3px] bg-brand" />
          <h1 className="truncate text-xl font-semibold tracking-tight">{title}</h1>
        </div>
        {description && (
          <p className="mt-1 max-w-2xl text-[13px] text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}
