import { cn } from "@/shared/lib/utils";

/**
 * PLACEHOLDER BRAND MARKS
 * -----------------------
 * These approximate the Canada Life lock-up ("canada" + "life" inside the red
 * square) and the monochrome TCS wordmark so the console reads on-brand.
 * For any real deployment, replace with the official SVG assets from each
 * brand team and delete these components:
 *   <img src="/assets/canada-life.svg" ... />
 *   <img src="/assets/tcs.svg" ... />
 */

export function CanadaLifeLogo({
  className,
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn("flex select-none items-center gap-1.5", className)}
      aria-label="Canada Life"
      title="Canada Life"
    >
      {!compact && (
        <span className="text-[21px] font-semibold leading-none tracking-tight text-foreground">
          canada
        </span>
      )}
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[7px] bg-brand pb-0.5 font-serif text-[16px] italic leading-none text-white">
        life
      </span>
    </div>
  );
}

export function TcsLogo({
  className,
  full = false,
}: {
  className?: string;
  full?: boolean;
}) {
  return (
    <div
      className={cn("select-none leading-none", className)}
      aria-label="Tata Consultancy Services"
      title="Tata Consultancy Services"
    >
      <span className="text-sm font-bold tracking-[0.22em] text-foreground">
        TCS
      </span>
      {full && (
        <span className="mt-0.5 block text-[8.5px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          Tata Consultancy Services
        </span>
      )}
    </div>
  );
}
