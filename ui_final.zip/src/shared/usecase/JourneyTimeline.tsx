interface JourneyStep {
  step: string;
  detail: string;
}

/** Ordered agentic journey — numbering is meaningful here (it's a sequence). */
export function JourneyTimeline({ steps }: { steps: JourneyStep[] }) {
  return (
    <ol className="relative space-y-4 border-l border-border pl-5">
      {steps.map((s, i) => (
        <li key={s.step} className="relative">
          <span className="absolute -left-[27px] grid h-4 w-4 place-items-center rounded-[4px] bg-brand text-[8.5px] font-bold text-white">
            {i + 1}
          </span>
          <p className="text-[13px] font-semibold leading-4">{s.step}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{s.detail}</p>
        </li>
      ))}
    </ol>
  );
}
