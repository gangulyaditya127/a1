import { configureStore } from "@reduxjs/toolkit";
import uiReducer from "@/shared/state/uiSlice";
import { governanceReducer } from "@/application/governance/state";

/**
 * Root store — pure composition. Each application contributes at most one
 * reducer under its own key; `ui` is the shared cross-app slice (theme,
 * reporting window, sidebar). The skeleton apps are stateless for now; when
 * one grows state, export a reducer from its state/ folder and add it here.
 */
export const store = configureStore({
  reducer: {
    ui: uiReducer,
    governance: governanceReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
