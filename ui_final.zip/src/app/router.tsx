import { createBrowserRouter } from "react-router-dom";
import { RootLayout } from "@/app/RootLayout";
import { AppFrame } from "@/app/AppFrame";
import { NotFoundPage } from "@/app/NotFoundPage";
import { LauncherPage } from "@/application/launcher/LauncherPage";
import { APPS } from "@/app/registry";

/**
 * URL scheme
 *   /                     launcher (all applications)
 *   /governance /sla /productivity /agents /improvement /reports   → S6 app
 *   /incident-triage      → S1 app
 *   /problem-rca          → S2 app
 *   /predictive-ops       → S5 app
 *   /ai-governance        → General track app
 * Application routes come from each app's manifest via the registry.
 */
export const router = createBrowserRouter([
  {
    element: <RootLayout />,
    children: [
      { index: true, element: <LauncherPage /> },
      { element: <AppFrame />, children: APPS.flatMap((a) => a.routes) },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);
