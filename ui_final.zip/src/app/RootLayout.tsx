import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { THEME_KEY } from "@/shared/state/uiSlice";
import { useAppSelector } from "@/app/hooks";

/** Syncs the theme in the store to the <html> class and localStorage. */
export function RootLayout() {
  const theme = useAppSelector((s) => s.ui.theme);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    try {
      localStorage.setItem(THEME_KEY, theme);
    } catch {
      /* private mode etc. — non-fatal */
    }
  }, [theme]);

  return <Outlet />;
}
