import { useLocation } from "react-router-dom";
import { AppLayout } from "@/shared/layout/AppLayout";
import { findAppByPath } from "@/app/registry";
import { NotFoundPage } from "@/app/NotFoundPage";

/**
 * Resolves which application owns the current path and hands its manifest to
 * the shared layout. The shared layer never imports applications directly —
 * this frame is the composition seam.
 */
export function AppFrame() {
  const { pathname } = useLocation();
  const app = findAppByPath(pathname);
  if (!app) return <NotFoundPage />;
  return <AppLayout app={app} />;
}
