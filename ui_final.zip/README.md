# Canada Life AMS Portal — S6 Governance & Reporting

A React console for the TCS ↔ Canada Life application-management engagement. The live
application is **S6 Governance & Reporting**: SLA and XLA compliance with live breach
forecasting, portfolio-to-application drilldown down to the individual incident, and
team and automation productivity.

## Stack & running it

- React 18 · TypeScript (strict) · Vite
- react-router v6, Redux Toolkit, Tailwind CSS, shadcn/ui primitives
- Apache ECharts for charts, AG Grid Enterprise 32 for grids, lucide-react icons

```bash
npm install
npm run dev        # http://localhost:5173
```

Optional: set `VITE_AG_GRID_LICENSE_KEY` in `.env` to silence the AG Grid Enterprise
watermark. The service layer (`services/api.ts`) is in-memory with realistic latency;
swap its functions for live API calls of the same shapes and nothing above it changes.

For application manifests, registry setup, sidebar ownership, and route examples, see
[APPLICATION_ROUTES_README.md](./APPLICATION_ROUTES_README.md).

## Route map

| Route | Page | What it shows |
|---|---|---|
| `/governance` | Overview | Rules likely to breach, immediate misses, pending owner alerts, open P1/P2 workload, rule-level 3-hour breach forecast, Applications grid, live breach radar |
| `/portfolio/:portfolioId` | Portfolio overview | Rollup KPIs, application comparison chart, application list, live risks; link chips into the three metric views |
| `/application/:appId` | Application overview | SLA/XLA KPIs and trend, live risks; link chips into the three metric views |
| `/sla` | SLA | Obligations-by-measure matrix (portfolio column groups), live breach queue, digests, notification log |
| `/sla/portfolio/:portfolioId` | SLA · portfolio | **Application-wise SLA**: one row per application, R/A/G counts plus a value column per measure; portfolio SLA trend |
| `/sla/application/:appId` | SLA · application | Obligations for the application and the **inline list of incidents the values are calculated from**, filterable by measure and status |
| `/xla` | XLA | CSAT, comment sentiment, service friction (reopens, hops, FCR), themes, comments |
| `/xla/portfolio/:portfolioId` | XLA · portfolio | Scoped friction stats, friction by application, XLA trend, portfolio comments |
| `/xla/application/:appId` | XLA · application | Reopened / reopen rate / hops / FCR cards, XLA trend, comments mentioning the app |
| `/productivity` | Productivity | Delivery by portfolio, throughput trend, reopened tickets (by application / by associate), associates, automation |
| `/productivity/portfolio/:portfolioId` | Productivity · portfolio | Delivery KPIs, throughput vs overall, reopens by application, associates |
| `/productivity/application/:appId` | Productivity · application | Resolved QTD, reopen stats, monthly resolved chart |

Every red/amber/green count anywhere in the console opens the **incident drilldown**
(ticket id, measure, priority, opened, duration vs target, outcome) — the floor of
every calculation.

---

# Data dictionary

All data is deterministic and generated in `src/application/governance/data/`. Seeded
PRNGs (`mulberry32(hashStr(key))`) make every derived figure reproducible; "today" is
fixed at **Jul 17 2026** so incident timestamps never shift. Reporting months run
**Aug 25 → Jul 26** (Jul is month-to-date); the global range selector slices the last
3 / 6 / 12 months.

## Portfolios & applications (`slaData.ts`)

Two-level hierarchy: **Portfolio ▸ Application**. Application ids are slugs of their
names (e.g. `claims-processing`).

| Field | Description |
|---|---|
| `tier` | Business criticality used for application context and escalation priority |
| `xla` | Experience score 0–100 blending CSAT, sentiment and friction (`xlaSeries` likewise) |
| `xlaDelta` | Month-over-month XLA movement in points (derived from the series) |
| `openP1` / `openP2` | Open priority-1/2 incidents right now |
| `risk` | Overall service-health flag based on active priority incidents and reliability pressure |
| `owner` | Accountable application owner (notify actions address them) |

| Portfolio | Application | Tier | XLA | Open P1/P2 | Owner |
|---|---|---|---|---|---|
| Group Benefits | Claims Processing | 1 | 81 | 0/4 | Priya Raman |
| Group Benefits | Claims Intake Portal | 2 | 88 | 0/0 | Marc Tremblay |
| Group Benefits | Adjudication Engine | 1 | 85 | 0/2 | Priya Raman |
| Group Benefits | GroupNet | 1 | 86 | 0/3 | Dana Whitfield |
| Group Benefits | Billing Engine | 2 | 90 | 0/0 | Aaron Chen |
| Group Benefits | Payments Hub | 1 | 83 | 1/3 | Luis Ortega |
| Group Benefits | Disbursements | 2 | 89 | 0/0 | Luis Ortega |
| Wealth | Wealth Portal | 1 | 90 | 0/0 | Sofia Marchetti |
| Wealth | Retirement Admin | 2 | 88 | 0/0 | Sofia Marchetti |
| Wealth | Fund Accounting | 1 | 87 | 0/0 | Ken Osei |
| Wealth | Trade Gateway | 1 | 85 | 0/1 | Ken Osei |
| Advisor & Digital | Advisor Workspace | 2 | 79 | 0/2 | Nadia Boucher |
| Advisor & Digital | CRM Sync | 3 | 86 | 0/0 | Nadia Boucher |
| Advisor & Digital | Client Mobile App | 1 | 91 | 0/0 | Jordan Blake |
| Advisor & Digital | Web Experience | 1 | 89 | 0/0 | Jordan Blake |
| Corporate | Policy Admin | 1 | 88 | 0/0 | Grace Lindqvist |
| Corporate | Document Services | 3 | 84 | 0/0 | Grace Lindqvist |
| Corporate | Integration Bus | 1 | 85 | 0/0 | Tomás Ferreira |
| Corporate | Reporting Warehouse | 2 | 83 | 0/1 | Tomás Ferreira |

## SLA measures & RAG (`slaData.ts`)

Contracted obligations (`KPI_DEFS`). There is **no blended SLA percentage anywhere**.
The Overview reports distinct rules forecast to breach in the next three hours; the
detailed SLA views retain RAG counts of rule × application instances so leaders can
trace current-period performance to the affected application and incident.

| Id | Measure | Operational obligation | Target % |
|---|---|---|---|
| `k-resp-p1` | Response Time - P1 | Acknowledge within 15 min · 95% of tickets | 95 |
| `k-resp-p2` | Response Time - P2 | Acknowledge within 30 min · 95% of tickets | 95 |
| `k-resp-p3` | Response Time - P3 | Acknowledge within 4 business h · 90% of tickets | 90 |
| `k-resp-p4` | Response Time - P4 | Acknowledge within 8 business h · 90% of tickets | 90 |
| `k-res-p1` | Resolution Time - P1 | Restore service within 4 h · 95% of incidents | 95 |
| `k-res-p2` | Resolution Time - P2 | Restore service within 8 h · 95% of incidents | 95 |
| `k-res-p3` | Resolution Time - P3 | Resolve within 3 business days · 90% of tickets | 90 |
| `k-res-p4` | Resolution Time - P4 | Resolve within 5 business days · 90% of tickets | 90 |
| `k-age-p1` | Aging - P1 | No active P1 older than 4 h · 100% of tickets | 100 |
| `k-age-p2` | Aging - P2 | No active P2 older than 8 h · 98% of tickets | 98 |
| `k-age-p3` | Aging - P3 | Keep active P3 backlog within 5 business days · 90% | 90 |
| `k-age-p4` | Aging - P4 | Keep active P4 backlog within 10 business days · 90% | 90 |

**RAG thresholds** (`ragFor`): green when actual ≥ target; amber when within 1.2 pts
below target (the tolerance band); red otherwise. Each cell has its own deterministic
12-month `trendPct`, generated from the application's reliability profile and the
specific KPI target. Console totals: `STATUS_COUNTS` sums the matrix, while
portfolio and estate trends keep one line per KPI and count applications below target.

## Incident evidence (`incidentsFor` in `slaData.ts`)

Every RAG figure resolves to concrete tickets. Per measure × application cell the
generator emits **3 incidents if red, 2 if amber, 1 if green**, with breach
probability **75% / 40% / 8%** respectively. Ticket ids are `INC10480xx–INC10569xx`
(hash-derived), opened 1–29 days before Jul 17 2026.

| Rule family | P1 | P2 | P3 | P4 |
|---|---:|---:|---:|---:|
| Response Time | 15 min | 30 min | 240 min (4 bh) | 480 min (8 bh) |
| Resolution Time | 240 min | 480 min | 1 440 min (3 bd) | 2 400 min (5 bd) |
| Aging | 240 min | 480 min | 2 400 min (5 bd) | 4 800 min (10 bd) |

Breached incidents run 1.1–2.0× target; met ones 0.35–0.9×. `incidentsFor(filter)`
accepts any of `kpiId`, `appId`, `portfolioId`, `status` and returns newest-first —
the single function behind the drilldown modal and the inline evidence grid on
`/sla/application/:appId`.

## Live breach queue (`liveRisksAt`)

Eight incident-centric risks refreshed with seeded jitter per tick (`etaMin` ±8,
`probability` ±6, floors 4 min / 15%). Sorted soonest-first. Notifying stamps
`notifiedAt` and appends to the notification log; state survives refreshes.

| Incident | Application | SLA at risk | Priority | Assignment group | Assignee | Window | ETA base | Prob. |
|---|---|---|---|---|---|---|---|---|
| INC1049310 | Payments Hub | Resolution Time - P1 | P1 | AMS – Payments L2 | Imran Dar | ≤30 m | 24 | 84 |
| INC1049233 | Claims Processing | Resolution Time - P2 | P2 | AMS – Claims L2 | Farah Siddiqui | ≤30 m | 28 | 76 |
| INC1049274 | GroupNet | Aging - P3 | P3 | AMS – Digital Channels L2 | Ben Carver | ≤1 h | 52 | 63 |
| INC1049301 | Adjudication Engine | Aging - P2 | P2 | AMS – Claims L2 | Lena Vogel | ≤1 h | 47 | 58 |
| INC1049198 | Advisor Workspace | Response Time - P2 | P2 | AMS – Digital Channels L2 | Hana Yoshida | ≤2 h | 96 | 54 |
| INC1049325 | Trade Gateway | Response Time - P2 | P2 | AMS – Wealth Ops L2 | Devon Marsh | ≤2 h | 110 | 41 |
| INC1049256 | Reporting Warehouse | Aging - P4 | P4 | AMS – Data & Integration L2 | Greg Olszewski | ≤3 h | 155 | 46 |
| INC1049342 | Web Experience | Response Time - P1 | P1 | AMS – Platform L2 | Marco Silva | ≤3 h | 168 | 33 |

**Digests** (`digestRules`): Daily SLA position (email, 08:00 ET), Breach-risk alerts
(Teams, real time), Portfolio weekly summary (Mondays 07:30), Experience monthly
(paused). Seeded sends: Luis Ortega breach alert, daily position to 19 owners, weekly
summary to 4 leads.

## XLA: CSAT, sentiment & friction

**CSAT** 4.4 / 5 (+0.1), from closed-ticket surveys; monthly trend 4.0 → 4.4.
**Sentiment** (`sentimentSummary`): 3 184 comments analyzed this quarter — 64%
positive / 22% neutral / 14% negative, negatives down 3 pts. Six themes (top:
"Password reset is instant now" 341 mentions +24%; worst: "Slow claim status updates"
214 −18%) and ten verbatim comments (c1–c10) tagged portfolio/application/rating.

**Service friction** (`frictionData.ts`) — the "user was not satisfied" signals, one
row per application, all derived from the app's XLA so the friction story matches the
experience story:

| Field | Formula (per app) | Meaning |
|---|---|---|
| `resolvedQtd` | sum of last 3 months of the seeded monthly-resolved series (34–79/mo + drift) | Tickets resolved, quarter to date |
| `reopened` | `clamp((90 − xla) × 1.9 + jitter, 1, 34)` | Closures that came back, QTD |
| `reopenRatePct` | `reopened ÷ resolvedQtd × 100` | Share of closures reopened |
| `avgHops` | `clamp(3.4 − (xla − 78) × 0.09 + jitter, 1.3, 3.6)` | Assignment hand-offs before resolution |
| `fcrPct` | `clamp(60 + (xla − 80) × 1.5 + jitter, 48, 88)` | Resolved at first contact (target ≥ 70%) |

`frictionSummary`: reopened = sum (≈ mid-100s, −12% q/q), FCR and hops are simple
means (+1.6 pts and −0.3 respectively). The same monthly series powers the resolved
chart on `/productivity/application/:appId`, so the reopen rate always reconciles.

## Productivity (`productivityData.ts`)

**Delivery by portfolio** — resources and monthly resolved arrays; `resolved` is the
sum of the last three months, **throughput = tickets resolved per resource in the
latest month** (`throughputTrend` carries all 12 months per portfolio plus a blended
Overall line, chart domain 26–40):

| Portfolio | Resources | Resolved QTD | Latest throughput | Avg resolution | Change incidents (Δ q/q) |
|---|---|---|---|---|---|
| Group Benefits | 23 | 2 200 | 32.2 | 6.9 h | 19 (−26%) |
| Wealth | 8 | 813 | 34.4 | 5.2 h | 4 (−20%) |
| Advisor & Digital | 10 | 977 | 33.1 | 6.0 h | 6 (+20%) |
| Corporate | 7 | 753 | 36.3 | 5.6 h | 2 (−50%) |

Totals: 48 resources, 4 743 tickets QTD, 31 change-induced incidents (also on the
Overview quarter card). `productivitySummary` adds avg resolution 6.2 h (−18%),
automation coverage 44%, 1 240 hours saved, CAD 412 000, backlog 312 (−12%).

**Associates** (`individuals`, p1–p12) — named engineers with portfolio, resolved,
**reopened** (their closures that came back), avg handle hrs, CSAT, trend. Top: Ananya
Iyer (GB, 168 resolved / 1 reopened); coaching queue: Marco Silva (A&D, 71 / 9), Lena
Vogel (GB, 78 / 7), Karl Nyberg (Corp, 87 / 5).

**Automation**: monthly volume mix shifts from 520 manual / 60 auto (Aug 25) to 310 /
210 (Jul 26); cumulative hours saved 120 → 3 320. Top automations: password & access
resets (1 860 tickets · 620 h · 99.2%), EOD batch restart (412 · 310 h · 97.1%),
disk & queue cleanup, claim-status sync retry, certificate renewal (100%).

## Quality impact (`qualityData.ts`)

Incidents that never happened thanks to problem-record closures: **68 avoided QTD,
141 YTD**, monthly ramp 4 → 24 with a cumulative line — charted on the Productivity
page and summarized on the Overview quarter card.

## Behavioural notes

- Notify actions (single owner, "Notify all" per window, application summary) stamp a
  timestamp, append to the notification log, and persist across live refreshes and
  range changes.
- The reporting-window selector (3m/6m/12m) slices monthly service series and the
  obligation-level KPI charts; summaries and counts are quarter-to-date regardless.
- Blended "overall SLA %" figures are deliberately absent. The Overview counts
  distinct forecast-red rules; detailed RAG counts remain traceable to incidents.
