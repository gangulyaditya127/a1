# Adding Application Routes

This portal uses application manifests as the routing contract. An application owns its pages, routes, and sidebar navigation under `src/application/<application-name>`. Shared code only discovers applications through `src/app/registry.ts`.

## How Routing Works

The routing flow is:

1. An application exports an `AppManifest` from its `manifest.tsx` file.
2. `src/app/registry.ts` adds that manifest to `APPS`.
3. `src/app/router.tsx` mounts every `manifest.routes` entry under the shared `AppFrame`.
4. `AppFrame` calls `findAppByPath()` to determine which manifest owns the current URL.
5. `AppLayout` uses the selected manifest to render the correct sidebar and topbar.
6. The launcher uses the same manifest to create the application's card.

There should normally be no need to edit `src/app/router.tsx` when adding an application or application route.

## Manifest File

Every application exports an object matching `AppManifest`, defined in `src/shared/types.ts`.

```tsx
import { Activity, LayoutDashboard } from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { ServiceHealthPage } from "./pages/ServiceHealthPage";
import { IncidentDetailPage } from "./pages/IncidentDetailPage";

export const serviceHealthApp: AppManifest = {
  id: "service-health",
  code: "S7",
  name: "Service Health",
  description: "Operational health and incident visibility.",
  icon: Activity,
  entry: "/service-health",
  status: "live",
  usesTimeRange: true,
  paths: ["/service-health"],
  dynamicPaths: ["/service-health"],
  nav: [
    {
      label: "Overview",
      to: "/service-health",
      icon: LayoutDashboard,
      activePrefixes: ["/service-health/incident"],
    },
  ],
  routes: [
    { path: "service-health", element: <ServiceHealthPage /> },
    {
      path: "service-health/incident/:incidentId",
      element: <IncidentDetailPage />,
    },
  ],
};
```

### Manifest Fields

| Field | Purpose |
| --- | --- |
| `id` | Stable unique identifier for the application. |
| `code` | Planner or use-case code displayed in the launcher and sidebar. |
| `name` | User-facing application name. |
| `description` | Launcher description. |
| `icon` | Lucide icon used by the launcher and application header. |
| `entry` | URL opened from the launcher card. Use a leading `/`. |
| `paths` | Exact top-level URLs owned by the application. These are used by `findAppByPath()`. |
| `dynamicPaths` | URL prefixes for nested or parameterized pages. A prefix `/service-health` matches `/service-health/incident/123`. |
| `nav` | Sidebar items for this application. |
| `routes` | React Router route objects rendered inside the shared application frame. |
| `status` | `live` places the application in the featured launcher group; `preview` places it in previews. |
| `usesTimeRange` | Shows the global reporting-window selector when `true`. |
| `stats` | Optional launcher-card statistics. |

Route entries in `routes` follow the existing project convention and omit the leading `/`. Manifest URLs such as `entry`, `paths`, `dynamicPaths`, `nav.to`, and `activePrefixes` use leading `/` characters.

## `paths` and `dynamicPaths`

`findAppByPath()` in `registry.ts` uses these fields to select the application shell.

```ts
a.paths.includes(pathname) ||
  a.dynamicPaths?.some((prefix) => pathname.startsWith(prefix + "/"))
```

Use `paths` for exact section roots:

```ts
paths: ["/service-health", "/service-calendar"]
```

Use `dynamicPaths` for nested routes:

```ts
dynamicPaths: ["/service-health", "/service-calendar"]
```

Without the matching exact path or prefix, React Router may render the page route, but `AppFrame` will not know which application layout owns it and will show the not-found page.

Keep route roots unique between applications. `findAppByPath()` returns the first matching manifest in `APPS`, so overlapping prefixes can assign a page to the wrong application.

## Sidebar Navigation

Each `nav` item has a destination and may list drill-down prefixes that should keep it highlighted.

```tsx
{
  label: "Incidents",
  to: "/service-health",
  icon: Activity,
  activePrefixes: ["/service-health/incident"],
}
```

The item is active when the current URL equals `to`, equals an `activePrefixes` value, or starts with an active prefix followed by `/`.

Use `disabled: true` and `soon: true` for a visible planned item that should not navigate.

## Add a Route to an Existing Application

1. Create the page inside the application, for example:

   `src/application/governance/pages/ServiceCalendarPage.tsx`

2. Import the page in the application's `manifest.tsx`.

3. Add its route:

```tsx
routes: [
  // existing routes
  { path: "service-calendar", element: <ServiceCalendarPage /> },
  {
    path: "service-calendar/:changeId",
    element: <ServiceCalendarDetailPage />,
  },
]
```

4. Add the exact root to `paths` and the nested prefix to `dynamicPaths`:

```ts
paths: ["/governance", "/sla", "/xla", "/productivity", "/service-calendar"],
dynamicPaths: [
  "/portfolio",
  "/application",
  "/sla",
  "/xla",
  "/productivity",
  "/service-calendar",
],
```

5. Add a sidebar item when users need direct access:

```tsx
{
  label: "Service calendar",
  to: "/service-calendar",
  icon: CalendarDays,
  activePrefixes: ["/service-calendar"],
}
```

No registry change is required when adding a route to an application that is already registered.

## Register a New Application

Create the application directory with at least this structure:

```text
src/application/service-health/
  manifest.tsx
  pages/
    ServiceHealthPage.tsx
```

Then import and add the manifest in `src/app/registry.ts`:

```ts
import { serviceHealthApp } from "@/application/service-health/manifest";

export const APPS: AppManifest[] = [
  governanceApp,
  incidentTriageApp,
  problemRcaApp,
  predictiveOpsApp,
  aiGovernanceApp,
  serviceHealthApp,
];
```

`registry.ts` is intentionally the only file that imports every application. Adding the manifest to `APPS` automatically makes its routes available to the router, adds its card to the launcher, and allows `AppFrame` to select its layout.

Applications should not import code from other application directories. Put genuinely shared components, types, state, or helpers under `src/shared` or `src/app`.

## Route Parameters and Links

Use normal React Router APIs inside application pages:

```tsx
import { Link, useParams } from "react-router-dom";

export function IncidentDetailPage() {
  const { incidentId = "" } = useParams();

  return <Link to="/service-health">Back to service health</Link>;
}
```

Prefer the shared `PageHeader` breadcrumbs and back button for drill-down pages so navigation remains consistent.

## Verification Checklist

- The launcher card opens `manifest.entry`.
- Directly opening every exact route renders the correct application shell.
- Refreshing a parameterized route still resolves the correct application.
- The correct sidebar item remains highlighted on drill-down pages.
- Route roots do not overlap another application's `paths` or `dynamicPaths`.
- `npm run typecheck` passes.
- `npm run build` passes.

