import json

from langchain_core.embeddings.embeddings import Embeddings

from .api_client import APIClient


class TCSEmbeddings(Embeddings):
    def __init__(self, client: APIClient, model_name: str):
        """
        Initialize the embeddings class.

        :param client: An instance of APIClient.
        :param model_name: The name of the embeddings model.
        """
        self.client = client
        self.model_name = model_name

    def embed_documents(self, documents: list, **kwargs) -> list:
        """
        Generate embeddings for a list of documents.

        :param documents: A list of documents to embed.
        :return: A list of embeddings.
        """
        payload = {"model": self.model_name, "prompt": documents, "options": {}}
        response = self.client.post("/utils/embeddings", json=json.dumps(payload))
        if "embedding" in response:
            return response["embedding"]
        else:
            raise Exception("Accept only 1024 tokens for vectorization")

    def embed_query(self, query: str, **kwargs) -> list:
        """
        Generate an embedding for a single query.

        :param query: The query to embed.
        :return: The embedding for the query.
        """
        return self.embed_documents([query], **kwargs)[0]

    def embed(self, texts: list, **kwargs) -> list:
        """
        Generate embeddings for a list of texts.

        :param texts: A list of texts to embed.
        :return: A list of embeddings.
        """
        return self.embed_documents(texts, **kwargs)

    @property
    def _model_type(self) -> str:
        """Return the model type."""
        return self.model_name
