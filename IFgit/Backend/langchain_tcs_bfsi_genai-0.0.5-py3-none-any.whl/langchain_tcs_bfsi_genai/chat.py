import json
import re
import sys
import uuid
from typing import (Any, Callable, Dict, List, Optional, Sequence, Type, Union, Iterator,
                    cast)

from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.language_models import LanguageModelInput
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (AIMessage, AIMessageChunk, BaseMessage,
                                     ToolCall)
from langchain_core.outputs import ChatGeneration, ChatResult, ChatGenerationChunk
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_tool

from .api_client import APIClient


def _lc_tool_call_to_openai_tool_call(tool_call: ToolCall) -> dict:
    """
    Convert a tool call to an OpenAI tool call format.

    :param tool_call: The tool call to convert.
    :return: A dictionary representing the OpenAI tool call.
    """
    ret_json = {
        "type": "function",
        "id": tool_call["id"],
        "function": {
            "name": tool_call["name"],
            "arguments": str(tool_call["args"]),
        },
    }
    return ret_json


class TCSChatModel(BaseChatModel):
    """Chat model for generating AI-driven responses."""

    model_name: str
    client: APIClient

    @property
    def _model_type(self) -> str:
        """Return the model type."""
        return self.model_name

    @property
    def _llm_type(self) -> str:
        """Return the LLM type."""
        return "TCSChatModel"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        Generate a chat response based on the input messages.

        :param messages: A list of messages to process.
        :param stop: Optional stop sequences.
        :param run_manager: Optional callback manager.
        :return: A ChatResult containing the generated response.
        """
        formatted_messages = self._format_messages(messages, kwargs)
        payload = self._create_payload(formatted_messages, kwargs)
        response = self.client.post("/core/chat-completion", json=json.dumps(payload))
        if "response" in response and isinstance(response["response"], dict):
            return self._process_response(response, kwargs)
        else:
            raise ValueError(str(response))

        # with self.client.stream("POST", "/core/chat-completion", json=payload) as response:
        #     if response.status_code != 200:
        #         raise ValueError(f"Request failed: {response.status_code}, {response.text}")

        #     # Iterate over streamed chunks
        #     for chunk in response.iter_lines():
        #         if chunk:
        #             data = json.loads(chunk.decode("utf-8"))
        #             if "response" in data and isinstance(data["response"], dict):
        #                 yield self._process_response(data, kwargs)
        #             #else:
        #             #    # Handle partial or error chunks gracefully

    def _stream(self, messages: List[BaseMessage], stop: Optional[List[str]] = None, run_manager: Optional[Any] = None, **kwargs: Any,) -> Iterator[ChatGenerationChunk]:
        """
        Generate a chat response based on the input messages.

        :param messages: A list of messages to process.
        :param stop: Optional stop sequences.
        :param run_manager: Optional callback manager.
        :return: A ChatResult containing the generated response.
        """
        formatted_messages = self._format_messages(messages, kwargs)
        payload = self._create_payload(formatted_messages, kwargs)
        with self.client.post("/core/chat-completion", json=json.dumps(payload), stream=True) as response:
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        # Lines start with "data: " and end with two newlines
                        line_str = line.decode("utf-8")
                        if line_str.startswith("data: "):
                            # Remove the prefix to get the JSON string
                            data = line_str[6:].strip()
                            
                            # End signal
                            if data == "[DONE]":
                                break
                            
                            chunk_data = json.loads(data)
                            
                            # Extract content from the LiteLLM (OpenAI) chunk structure
                            content = chunk_data["choices"][0]["delta"].get("content", "")
                            
                            if content:
                                yield self._process_response(response, kwargs)
                                # Create and yield the LangChain chunk
                                # yield ChatGenerationChunk(content=content)
                                
                    except json.JSONDecodeError:
                        # Ignore non-JSON lines or malformed data
                        continue



    def _format_messages(self, messages: List[BaseMessage], kwargs: Any) -> List[dict]:
        """
        Format the input messages for the chat completion API.

        :param messages: A list of messages to process.
        :return: A list of formatted messages.
        """
        formatted_messages = []

        for message in messages:
            if message.type == "human":
                formatted_messages.extend(self._format_human_message(message))
            elif message.type == "system":
                formatted_messages.append(self._format_system_message(message, kwargs))
            elif message.type == "ai":
                formatted_messages.append(self._format_ai_message(message))
            elif message.type == "tool":
                formatted_messages.append(self._format_tool_message(message))

        # print(formatted_messages)
        return formatted_messages

    def _format_human_message(self, message: BaseMessage) -> List[dict]:
        """
        Format a human message for the chat completion API.

        :param message: A human message to process.
        :return: A list of formatted messages.
        """
        formatted_messages = []

        content = message.content
        # print(content)
        # try:
        if isinstance(content, list) is False:
            # print(content)
            formatted_messages.append(
                {"role": "user", "content": [{"type": "text", "text": content}]}
            )
            # if "type" in content:
            # if content["type"] == "text":
            #     # formatted_messages.append({"role": "user", "content": [{"type": "text", "text": content["text"]}]})
            #     formatted_messages.append({"role": "user", "content":  content["text"]})
            #     # print(formatted_messages)
            # elif content["type"] == "image_url":
            #     # formatted_messages.append({"role": "user", "content": [{"type": "image_url", "image_url": content["image_url"]}]})
            #     formatted_messages.append({"role": "user", "content": content["image_url"]})
            # else:
            #     # formatted_messages.append({"role": "user", "content": [{"type": "text", "text": message.content}]})
            #     formatted_messages.append({"role": "user", "content":  content["text"]})
        else:
            for content in message.content:
                # formatted_messages.append({"role": "user", "content": [{"type": "text", "text": message.content}]})
                # formatted_messages.append({"role": "user", "content":  content["text"]})
                # formatted_messages.append({"role": "user", "content": [{"type": "text", "text": content["text"]}]})
                if content["type"] == "text":
                    formatted_messages.append(
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": content["text"]}],
                        }
                    )
                    # formatted_messages.append({"role": "user", "content":  content["text"]})
                    # print(formatted_messages)
                elif content["type"] == "image_url":
                    formatted_messages.append(
                        {
                            "role": "user",
                            "content": [
                                {"type": "image_url", "image_url": content["image_url"]}
                            ],
                        }
                    )
                    #     formatted_messages.append({"role": "user", "content": content["image_url"]})
        # except Exception as e:
        #     print(f"Error formatting human message. Plain text received: Error dump {e}")
        #     formatted_messages.append({"role": "user", "content": [{"type": "text", "text": content}]})
        # print(formatted_messages)
        return formatted_messages

    def _format_system_message(self, message: BaseMessage, kwargs: Any) -> dict:
        """
        Format a system message for the chat completion API.

        :param message: A system message to process.
        :param kwargs: Additional keyword arguments.
        :return: A formatted system message.
        """
        if self.model_name.startswith("llama") and len(kwargs.get("tools", [])) > 0:
            tools = kwargs.get("tools", [])
            tool_instructions = (
                f'Environment: ipython\n Tools: bing_search \n Cutting Knowledge Date: December 2023 \n Today Date: 23 July 2024 \n # Tool Instructions \n - Always execute python code in messages that you share. \n You have access to the following functions: \n\n{tools}\n If a you choose to call a function ONLY reply in the following format: <{start_tag}={function_name}>{parameters}{end_tag} \n where start_tag => `<function` parameters => a JSON dict with the function argument name as key and function argument value as value. end_tag => `</function>`\n Here is an example, <function=example_function_name>{{"example_name": "example_value"}}</function> \n\n Reminder: \n - Function calls MUST follow the specified format \n - Required parameters MUST be specified \n - Only call one function at a time \n - Put the entire function call reply on one line\n - Always add your sources when using search results to answer the user query.\n'
                + message.content
            )
            return {
                "role": "system",
                "content": [{"type": "text", "text": tool_instructions}],
            }
        else:
            return {
                "role": "system",
                "content": [{"type": "text", "text": message.content}],
            }

    def _format_ai_message(self, message: BaseMessage) -> dict:
        """
        Format an AI message for the chat completion API.

        :param message: An AI message to process.
        :return: A formatted AI message.
        """
        if message.content != "":
            return {
                "role": "assistant",
                "content": [{"type": "text", "text": message.content}],
            }
        else:
            tool_calls = (
                [
                    _lc_tool_call_to_openai_tool_call(tool_call)
                    for tool_call in message.tool_calls
                ]
                if message.tool_calls
                else None
            )
            return {"role": "assistant", "tool_calls": tool_calls}

    def _format_tool_message(self, message: BaseMessage) -> dict:
        """
        Format a tool message for the chat completion API.

        :param message: A tool message to process.
        :return: A formatted tool message.
        """
        if self.model_name.startswith("llama"):
            return {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"From the below content answer the above question\n Role:ipython, Tool:{message.tool_calls[0]['function']['name']}, \n{message.content}",
                    }
                ],
            }
        else:
            return {
                "role": "tool",
                "content": message.content,
                "tool_call_id": message.tool_call_id,
            }

    def _create_payload(self, formatted_messages: List[dict], kwargs: Any) -> dict:
        """
        Create the payload for the chat completion API.

        :param formatted_messages: A list of formatted messages.
        :param kwargs: Additional keyword arguments.
        :return: The payload for the chat completion API.
        """
        return {
            "llm": self.model_name,
            "messages": formatted_messages,
            "response_format": "text",
            "temperature": kwargs.get("temperature", 0.0),
            "stop": kwargs.get("stop", []),
            "usecase_id": kwargs.get("usecase_id", "NA"),
            "tools": kwargs.get("tools", []),
        }

    def _process_response(self, response: Any, kwargs: Any) -> ChatResult:
        """
        Process the response from the chat completion API.

        :param response: The response from the chat completion API.
        :param kwargs: Additional keyword arguments.
        :return: A ChatResult containing the generated response.
        """
        if self.model_name.startswith("llama") and len(kwargs.get("tools", [])) > 0:
            input_data = response["response"]["choices"][0]["message"]["content"]
            function_name_match = re.search(r"<function=(.*?)>", input_data)
            arguments_match = re.search(
                r"<function=[^>]+>(\{.*\})\\?</function>", input_data
            )
            if function_name_match and arguments_match:
                function_name = function_name_match.group(1)
                arguments_json = arguments_match.group(1)
                arguments = json.loads(arguments_json)
                new_json_format = {
                    "type": "function",
                    "id": str(uuid.uuid4()),
                    "function": {
                        "name": function_name,
                        "arguments": json.dumps(arguments),
                    },
                }
                tool_call = [new_json_format]
        elif self.model_name.startswith("llama") and len(kwargs.get("tools", [])) <= 0:
            # print(response)
            ai_message = response["response"]["choices"][0]["message"]["content"]
            tool_call = []
        else:
            # print(response)
            ai_message = response["response"]["choices"][0]["message"]["content"]
            tool_call = response["response"]["choices"][0]["message"]["tool_calls"]

        if tool_call is not None:
            functions_list = [
                {
                    "id": item["id"],
                    "name": item["function"]["name"],
                    "args": json.loads(item["function"]["arguments"].replace("\n", "")),
                }
                for item in tool_call
                if "function" in item
            ]
        else:
            functions_list = []

        if not ai_message:
            ai_message = ""
        ai_message = AIMessage(
            content=ai_message, tool_calls=cast(AIMessageChunk, functions_list)
        )
        generation = ChatGeneration(message=ai_message)
        return ChatResult(generations=[generation])

    def bind_tools(
        self,
        tools: Sequence[Union[Dict[str, Any], Type, Callable, BaseTool]],
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, BaseMessage]:
        """
        Bind tool-like objects to this chat model.

        :param tools: A list of tool definitions to bind.
        :param kwargs: Additional parameters for binding.
        :return: A Runnable object.
        """
        formatted_tools = [convert_to_openai_tool(tool) for tool in tools]
        return super().bind(tools=formatted_tools, **kwargs)
