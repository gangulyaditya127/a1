import requests


class APIClient:
    """Client for interacting with the backend API."""

    BASE_URL = "http://10.170.21.213:20071/tcs-bfsi-genai-playground/v1"
    MCP_AGENT_URL = "http://10.170.21.213:20027/tcs-bfsi-mcp-agents/v1"

    def __init__(self, access_token=None):
        """
        Initialize the API client.

        :param access_token: Optional access token for authentication.
        """
        self.access_token = access_token

    def set_access_token(self, token):
        """
        Set the access token for the client.

        :param token: The access token to be set.
        """
        self.access_token = token

    def _get_headers(self):
        """
        Generate headers for HTTP requests.

        :return: A dictionary of headers.
        """
        headers = (
            {
                "Authorization": f"Bearer {self.access_token}",
                "accept": "application/json",
                "Content-Type": "application/json",
            }
            if self.access_token
            else {
                "accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        return headers

    def post(self, endpoint, json=None):
        """
        Send a POST request to the specified endpoint.

        :param endpoint: The API endpoint.
        :param json: The JSON payload for the request.
        :return: The JSON response from the server.
        """
        # print(json)
        response = requests.post(
            f"{self.BASE_URL}{endpoint}", data=json, headers=self._get_headers()
        )
        response.raise_for_status()
        return response.json()

    def get(self, endpoint):
        """
        Send a GET request to the specified endpoint.

        :param endpoint: The API endpoint.
        :return: The JSON response from the server.
        """
        response = requests.get(
            f"{self.BASE_URL}{endpoint}", headers=self._get_headers(), verify=False
        )
        response.raise_for_status()
        return response.json()

    def post_mcp(self, endpoint, json=None):
        """
        Send a POST request to the specified endpoint (for MCP Agents).

        :param endpoint: The API endpoint.
        :param json: The JSON payload for the request.
        :return: The JSON response from the server.
        """
        # print(json)
        response = requests.post(
            f"{self.MCP_AGENT_URL}{endpoint}", json=json, headers=self._get_headers()
        )
        response.raise_for_status()
        return response.json()

    def get_mcp(self, endpoint):
        """
        Send a GET request to the specified endpoint (for MCP Agents).

        :param endpoint: The API endpoint.
        :return: The JSON response from the server.
        """
        response = requests.get(
            f"{self.MCP_AGENT_URL}{endpoint}", headers=self._get_headers(), verify=False
        )
        response.raise_for_status()
        return response.json()