import json
from typing import Any, List, Optional

from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.language_models.llms import LLM

from .api_client import APIClient


class TCSLLMs(LLM):
    """Language model for generating text responses."""

    model_name: str
    client: APIClient

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any
    ) -> str:
        """
        Generate a text response based on the input prompt.

        :param prompt: The input prompt for the model.
        :param stop: Optional stop sequences.
        :param run_manager: Optional callback manager.
        :return: The generated text response.
        """
        messages = kwargs.get("history", [])
        if len(messages) > 0:
            messages = messages[0]
        messages.append({"role": "user", "content": [{"type": "text", "text": prompt}]})
        payload = {
            "llm": self.model_name,
            "messages": messages,
            "response_format": "text",
            "temperature": kwargs.get("temperature", 0.1),
            # "max_tokens": kwargs.get("max_tokens", 4000),
            "stop": kwargs.get("stop", []),
            "usecase_id": kwargs.get("usecase_id", "NA"),
        }
        response = self.client.post("/core/chat-completion", json=json.dumps(payload))
        if "response" in response and isinstance(response["response"], dict):
            return response["response"]["choices"][0]["message"]["content"]
        else:
            print("Error:" + str(response))

    @property
    def _model_type(self) -> str:
        """Return the model type."""
        return self.model_name

    @property
    def _llm_type(self) -> str:
        """Return the LLM type."""
        return "TCSLLM"
