from typing import (Any, Dict, List, Optional)
from .api_client import APIClient

class MCPAgents:

    def __init__(self, client: APIClient):
        """
        Initialize the MCPAgents class with an API client.

        :param client: An instance of APIClient.
        """
        self.client = client

    def query_mcp_server(
        self,
        model_name: str,
        instruction: str,
        task: str 
    ) -> str:
        """
        Queries the master agent based on instruction and passes on the query for processing.

        :param model_name: The model to be used.
        :param instruction: One liner description of the instruction to be performed.
        :param task: The task to be processed.
        :return: The response of the master agent after task processing.
        """
        payload = {
                    "username": "",
                    "password": "",
                    "model_name": model_name,
                    "activity": instruction,
                    "query": "objective: "+instruction+"\n"+task
                }

        response = self.client.post_mcp("/query-agent", json=payload)
        if "output" in response and isinstance(response, dict):
            return response["output"]
        else:
            raise ValueError(str(response))

    def get_available_agents_list(self)->List:
        """
        Provides the list of agents available in the mcp server.
        """
        response = self.client.get_mcp("/check-tool-list")
        if "tool list" in response and isinstance(response, dict):
            return response["tool list"]
        else:
            raise ValueError(str(response))

    def query_mcp_server_with_specific_agents(
        self,
        model_name: str,
        task: str,
        agent_names: List[str] 
    ) -> str:
        """
        Queries the master agent with the task and uses the provided specific agents for processing.

        :param model_name: The model to be used.
        :param task: The task to be processed.
        :param agent_names: The list of agent names to be used.
        :return: The response of the master agent after task processing.
        """
        payload = {
                    "username": "",
                    "password": "",
                    "model_name": model_name,
                    "query": task,
                    "agent_names": agent_names
                    }

        response = self.client.post_mcp("/query-specific-agent", json=payload)
        if "output" in response and isinstance(response, dict):
            return response["output"]
        else:
            raise ValueError(str(response))