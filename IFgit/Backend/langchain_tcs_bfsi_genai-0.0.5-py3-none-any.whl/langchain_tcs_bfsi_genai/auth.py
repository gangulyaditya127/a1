from .api_client import APIClient


class Auth:
    """
    Handles authentication for the API client.
    """

    def __init__(self, client: APIClient):
        """
        Initialize the Auth class with an API client.

        :param client: An instance of APIClient.
        """
        self.client = client

    def login(self, username, password):
        """
        Perform login and set the access token for the client.

        :param username: The username for authentication.
        :param password: The password for authentication.
        :return: The response from the login API.
        """
        payload = {
            "grant_type": "password",
            "username": username,
            "password": password,
            "scope": "",
            "client_id": "",
            "client_secret": "",
        }
        response = self.client.post("/auth/login", json=payload)
        self.client.set_access_token(response["access_token"])
        return response
