from .api_client import APIClient


class UserInfo:
    """
    Fetches User Configuration Information
    """

    def __init__(self, client: APIClient):
        """
        Initialize the Auth class with an API client.

        :param client: An instance of APIClient.
        """
        self.client = client

    def get_available_llms(self):
        """
        Fetches the available llms and related info from the api.
        :return: The response from the login API.
        """
        response = self.client.get("/config/me/available-llms")
        return response
