import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, Brain, GitBranch, Radar, ShieldCheck, X, ServerCog, DatabaseZap, LineChart, TimerReset, ListChecks } from 'lucide-react';
import './style.css';

const API = '/correlation';
async function api(path, options = {}) {
  const response = await fetch(API + path, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}
const cleanSource = (source = '') => source.replace(' API', '').replace(' Logs', '');

const mock = [
  {
    title: 'ARE RCA Knowledge Lookup impacted: Oracle Session Pool Exhaustion identified in AIAD',
    root: { event_id: 'ORCL-EVT-20260714-000017', source: 'Oracle Logs', event_name: 'ORA-00018 maximum sessions exceeded', root_cause_detail: 'Oracle Session Pool Exhaustion', business_journey: 'ARE RCA Knowledge Lookup', observed_application: 'IRR', root_cause_application: 'AIAD', root_cause_component: 'Oracle Session Pool', severity: 'Critical', timestamp: '13:20:07', dependency_path: ['IRR', 'ARE Gateway', 'AIAD', 'Oracle RAC'] },
    linked_alerts: [
      { event_id: 'APPD-EVT-20260714-000001', source: 'AppDynamics API', logCategory: 'Business Transaction', event_name: 'business transaction response time high', severity: 'Critical', timestamp: '13:20:07' },
      { event_id: 'APPD-EVT-20260714-000002', source: 'AppDynamics API', logCategory: 'Application Flow Map', event_name: 'backend call latency high', severity: 'Medium', timestamp: '13:21:14' },
      { event_id: 'SPLK-EVT-20260714-000084', source: 'Splunk API', logCategory: 'Application Log', event_name: 'HTTP 500 Spike', severity: 'High', timestamp: '13:21:20' }
    ],
    suppressed_alerts: [
      { event_id: 'APPD-EVT-20260714-000005', source: 'AppDynamics API', logCategory: 'Business Transaction', event_name: 'Business Transaction Response Time High', severity: 'Medium', timestamp: '13:22:35' }
    ],
    confidence: 92,
    blast_radius: { applications: ['IRR', 'ARE Gateway', 'AIAD'], users_impacted: 4280, orders_at_risk: 12340, business_severity: 'High' },
    primary_reason: { score: 182, narrative: 'Dependency direction: IRR → ARE Gateway → AIAD → Oracle RAC\nEvidence pattern: AppDynamics, Splunk and Oracle agree on the same incident cluster\nRepresentative signal: upstream Oracle session exhaustion\nImpact and confidence: 12 signals · 92% confidence' },
    executive_summary: 'IRR response failures are visible in AppDynamics while Splunk application logs and Oracle events point to AIAD Oracle session exhaustion as the actual root cause.',
    executive_narrative: 'The correlation engine separates IRR symptoms from upstream AIAD Oracle session pool exhaustion. Recommended focus is to validate AIAD Oracle sessions before restarting IRR.',
    business_impact_narrative: 'High business severity with multiple ARE workflow dependencies impacted.',
    recommended_actions: ['Validate active Oracle session count and listener health on AIAD Oracle RAC.', 'Check AIAD application connection-pool utilisation and wait time.', 'Recycle exhausted database connections after operations approval.', 'Confirm IRR response time and HTTP 500 rate return to normal.']
  },
  {
    title: 'Checkout & Order Placement impacted: Inventory Database Connection Exhaustion identified in Inventory Service',
    root: { event_id: 'ORCL-EVT-ECOM-000017', source: 'Oracle Logs', event_name: 'Inventory DB Session Pool Exhausted', root_cause_detail: 'Inventory Database Connection Exhaustion', business_journey: 'Checkout & Order Placement', observed_application: 'Checkout Service', root_cause_application: 'Inventory Service', root_cause_component: 'Oracle Inventory DB Pool', severity: 'Critical', timestamp: '19:48:10', dependency_path: ['E-Commerce Portal', 'Checkout Service', 'Inventory Service', 'Oracle Inventory DB'] },
    linked_alerts: [
      { event_id: 'APPD-EVT-ECOM-1', source: 'AppDynamics API', logCategory: 'Business Transaction', event_name: 'Checkout API Response Time High', severity: 'Critical', timestamp: '19:48:10' },
      { event_id: 'SPLK-EVT-ECOM-2', source: 'Splunk API', logCategory: 'Checkout Log', event_name: 'Order Submission Failed', severity: 'High', timestamp: '19:48:15' }
    ],
    suppressed_alerts: [{ event_id: 'APPD-EVT-ECOM-3', source: 'AppDynamics API', logCategory: 'Error Rate Alert', event_name: 'Business Transaction Error Rate High', severity: 'Medium', timestamp: '19:48:22' }],
    confidence: 91,
    blast_radius: { applications: ['Checkout Service', 'Inventory Service', 'Order Management'], users_impacted: 4280, orders_at_risk: 8760, business_severity: 'High' },
    primary_reason: { score: 178, narrative: 'Dependency direction: Checkout → Inventory → Oracle DB\nMulti-source evidence from AppDynamics, Splunk and Oracle\nCustomer checkout journey impact is high\nRoot signal is upstream of order submission symptoms' },
    executive_summary: 'Customers are unable to complete checkout because inventory validation is timing out due to Oracle inventory database pool exhaustion.',
    executive_narrative: 'The issue is visible in Checkout Service but the root cause is Inventory Service. Recommendations focus on restoring Oracle inventory connectivity.',
    business_impact_narrative: 'High order risk on checkout and order placement journey.',
    recommended_actions: ['Validate Inventory DB connection pool.', 'Check Checkout to Inventory API latency.', 'Confirm order submission success rate.']
  }
];

function normaliseIncident(incident) {
  const root = incident.root || incident.primary || {};
  const linked = incident.linked_alerts || incident.linked || [];
  const suppressed = incident.suppressed_alerts || incident.suppressed || [];
  const events = [root, ...linked, ...suppressed].filter(Boolean);
  return {
    incident,
    id: root.event_id || root.correlation_id || incident.incident_id || 'RCA-EVENT',
    title: incident.title || 'Correlated RCA Incident',
    root,
    linked,
    suppressed,
    events,
    confidence: incident.confidence || root.confidence || 88,
    trace: root.dependency_path || incident.correlation_trace || [],
    blast: incident.blast_radius || {},
    actions: [...(incident.recommended_actions || []), ...(incident.ai_recommendations || [])],
    primaryReason: incident.primary_reason || {},
    executiveSummary: incident.executive_summary || incident.executiveSummary || incident.title,
    executiveNarrative: incident.executive_narrative || incident.executiveNarrative || incident.executive_summary || incident.title,
    businessImpactNarrative: incident.business_impact_narrative || incident.businessImpactNarrative || ''
  };
}

function Header({ mode }) {
  return <header className="top-header"><div className="brand"><Radar size={28}/><div><h2>ARE Agentic Event Correlation</h2><p>Real-time cross-application RCA using Splunk, AppDynamics and Oracle signals</p></div></div><div className="header-right"><div className="user-card"><div className="avatar">DD</div><div><b>Debasish Das</b><span>AIOps Technical Lead</span></div></div><span className="prod-pill">PROD · {mode}</span></div></header>;
}
function LiveTicker({ onRefresh, onCollect, onStart, onStop }) {
  return <section className="live-strip"><b><span/> LIVE</b><span>Sources: Splunk API + AppDynamics API + Oracle Logs</span><button onClick={onRefresh}>Refresh</button><button onClick={onCollect}>Collect Now</button><button onClick={onStart}>Start Scheduler</button><button onClick={onStop}>Stop Scheduler</button></section>;
}
function AgentFlow() {
  const agents = [['Collect events', Activity, 'Continuously ingests signals from Splunk, AppDynamics and Oracle. It normalises timestamps, application identifiers, source type, severity and log category before correlation starts.'], ['Correlate clusters', GitBranch, 'Groups related symptoms into incident clusters using time proximity, common application context, dependency path, repeated signatures and noise reduction logic.'], ['Cross-App RCA', Brain, 'Compares observed symptoms with upstream dependency signals to identify whether the actual failure point is in another ARE or commerce component.'], ['Recommend', ShieldCheck, 'Generates operator-ready remediation guidance focused on the root-cause component.']];
  return <section className="panel agent-panel"><h2>Agent Execution Flow</h2><div className="agent-grid">{agents.map(([title, Icon, text], i) => <article key={title}><div className="icon"><Icon size={22}/></div><h3>{title}</h3><p>{text}</p>{i < agents.length - 1 && <i>→</i>}</article>)}</div></section>;
}
function KpiCard({ label, value, sub, tone, onClick }) { return <button className={`kpi ${tone}`} onClick={onClick}><span>{label}</span><strong>{value}</strong><small>{sub}</small><em>Click to view details</em></button>; }
function BubblePanel({ title, subtitle, items, onClick }) {
  const max = Math.max(...items.map(i => i.count), 1); const total = items.reduce((a,b)=>a+b.count,0) || 1;
  return <section className="panel"><h2>{title}</h2><p>{subtitle} Total: {total}</p><div className="bubbles">{items.map((it, idx) => { const size = 92 + Math.round((it.count/max)*62); return <button key={it.name} className={`bubble bubble-${idx%6}`} style={{width:size,height:size}} onClick={()=>onClick(it.name)}><span>{it.name}</span><strong>{it.count}</strong><small>{Math.round(it.count/total*100)}%</small></button>; })}</div></section>;
}
function DetailModal({ detail, onClose }) {
  const [page, setPage] = useState(1); const pageSize = 10; const rows = detail?.rows || []; const totalPages = Math.max(Math.ceil(rows.length/pageSize),1); const pageRows = rows.slice((page-1)*pageSize,page*pageSize); const keys = Object.keys(rows[0] || {}).slice(0,7);
  useEffect(()=>setPage(1),[detail?.title]); if(!detail) return null;
  return <div className="backdrop"><section className="detail modal"><button className="close" onClick={onClose}><X/></button><small>Clickable Detail View</small><h2>{detail.title}</h2><p>{detail.description}</p><div className="pager"><b>{rows.length} records</b><span>Page {page} of {totalPages}</span></div><div className="table-wrap"><table><thead><tr>{keys.map(k=><th key={k}>{k}</th>)}</tr></thead><tbody>{pageRows.map((r,i)=><tr key={r.event_id || r.eventId || r.root_cause_detail || i}>{keys.map(k=><td key={k}>{Array.isArray(r[k])?r[k].join(' / '):String(r[k] ?? '')}</td>)}</tr>)}</tbody></table></div><div className="pager controls"><button disabled={page===1} onClick={()=>setPage(p=>Math.max(1,p-1))}>Previous</button><span>{rows.length ? (page-1)*pageSize+1 : 0}-{Math.min(page*pageSize,rows.length)} of {rows.length}</span><button disabled={page===totalPages} onClick={()=>setPage(p=>Math.min(totalPages,p+1))}>Next</button></div></section></div>;
}
function RootCauseInventory({ clusters, onOpen }) {
  return <section className="panel inventory"><h2>Active Cross-Application Root Cause Inventory</h2><p>Observed application can be different from the actual root-cause application. Counts are derived from the live event stream.</p><div className="table-wrap"><table><thead><tr><th>RCA Event ID</th><th>Observed App</th><th>Root Cause App</th><th>Root Cause Component</th><th>Root Cause Detail</th><th>Primary Source</th><th>Severity</th><th>Correlated Events</th><th>Confidence</th><th>Status</th><th>Open</th></tr></thead><tbody>{clusters.map(c => <tr key={c.id}><td><button className="link" onClick={()=>onOpen(c)}>{c.id}</button></td><td>{c.root.observed_application}</td><td>{c.root.root_cause_application}</td><td>{c.root.root_cause_component}</td><td>{c.root.root_cause_detail}</td><td>{[...new Set(c.events.map(e=>cleanSource(e.source)))].join(' / ')}</td><td><span className={`sev ${String(c.root.severity).toLowerCase()}`}>{c.root.severity}</span></td><td>{c.events.length}</td><td>{c.confidence}%</td><td>Under Investigation</td><td><button className="round" onClick={()=>onOpen(c)}>›</button></td></tr>)}</tbody></table></div></section>;
}
function DependencyPath({ path }) { return <div className="trace-path">{(path||[]).map((node,idx)=><div key={node}><span>{node}</span>{idx<path.length-1 && <b>↓</b>}</div>)}</div>; }
function Dashboard({ clusters, summary, events, onOpen, onDetail }) {
  const top = clusters[0];
  const allEvents = events.length ? events : clusters.flatMap(c=>c.events);
  const sourceMap = summary.source_distribution || allEvents.reduce((a,e)=>{ const s=cleanSource(e.source); a[s]=(a[s]||0)+1; return a;},{});
  const sourceItems = Object.entries(sourceMap).map(([name,count])=>({name,count}));
  const logMap = allEvents.reduce((a,e)=>{ const key=e.logCategory || e.connector || cleanSource(e.source) || 'Event'; a[key]=(a[key]||0)+1; return a;},{});
  const logItems = Object.entries(logMap).map(([name,count])=>({name,count}));
  const kpis = [
    ['Events Received', summary.events_received || allEvents.length, 'All received connector events', 'blue', allEvents],
    ['Correlated Events', summary.correlated_events || allEvents.length, 'Linked to RCA clusters', 'purple', allEvents.filter(e=>e.root_cause_application || e.observed_application)],
    ['Active Incidents', summary.active_incidents || clusters.length, 'Open incident clusters', 'amber', clusters.map(c=>({id:c.id,title:c.title,confidence:c.confidence}))],
    ['Active Root Causes', clusters.length, 'Root issues identified', 'red', clusters.map(c=>c.root)],
    ['Applications Impacted', summary.applications_impacted || new Set(clusters.map(c=>c.root.observed_application)).size, 'Customer-facing symptoms', 'green', clusters.map(c=>({observed:c.root.observed_application,root:c.root.root_cause_application,journey:c.root.business_journey}))]
  ];
  return <><section className="hero"><div className="hero-copy panel"><small>Real-Time · Multi-Source RCA</small><h1>Live Event Correlation Summary Dashboard</h1><p>Events are received from Splunk, AppDynamics and Oracle monitoring/log sources. The correlation engine groups events into active clusters and identifies cross-application root causes.</p></div><div className="engine panel"><h2><ServerCog size={20}/> Correlation Engine Status</h2><div className="engine-grid"><div><span>Status</span><b>Healthy</b></div><div><span>Processed Events</span><b>{summary.events_received || allEvents.length}</b></div><div><span>Latency</span><b>2.3 sec</b></div><div><span>Queue Depth</span><b>42</b></div><div><span>Last RCA</span><b>14 sec ago</b></div><div><span>Health</span><b>99.8%</b></div></div></div><div className="critical-card panel"><small>Most Critical Cross-App RCA</small><h3>{top.id}</h3><h3>{top.root.root_cause_detail}</h3><p>Observed in {top.root.observed_application} · Root cause in {top.root.root_cause_application}</p><p>{top.events.length} correlated events · {top.confidence}% confidence</p><button className="primary" onClick={()=>onOpen(top)}>Open RCA Investigation</button></div></section><AgentFlow/><section className="kpi-grid">{kpis.map(([l,v,s,t,rows])=><KpiCard key={l} label={l} value={v} sub={s} tone={t} onClick={()=>onDetail({title:l,description:s,rows})}/>)}</section><section className="distribution-grid"><BubblePanel title="Monitoring Source Distribution" subtitle="Source platform count." items={sourceItems.length?sourceItems:[{name:'Splunk',count:30},{name:'AppDynamics',count:18},{name:'Oracle',count:12}]} onClick={(name)=>onDetail({title:`${name} Events`,description:`Filtered by ${name}`,rows:allEvents.filter(e=>cleanSource(e.source)===name)})}/><BubblePanel title="Log Origin Distribution" subtitle="Application / server / Oracle / AppD event stream." items={logItems.length?logItems:[{name:'Business Transaction',count:5},{name:'Application Flow Map',count:5},{name:'Application Log',count:7}]} onClick={(name)=>onDetail({title:`${name} Events`,description:`Filtered by ${name}`,rows:allEvents.filter(e=>(e.logCategory||e.connector||cleanSource(e.source))===name)})}/></section><RootCauseInventory clusters={clusters} onOpen={onOpen}/></>;
}
function CorrelationExplorer({ clusters, selected, onSelect, onOpen }) {
  const c = selected || clusters[0]; const total = Math.max(c.events.length,1); const bars=[['Cluster Size',c.events.length],['Primary RCA',1],['Evidence Signals',c.linked.length+1],['Reduced Noise',c.suppressed.length]];
  return <section className="explorer"><div className="panel explorer-header"><div><small>Correlation Explorer</small><h2>Incident Correlation Graph</h2><p>Drill-down view showing how AppDynamics symptoms, Splunk logs and Oracle events are correlated into one explainable RCA.</p></div><div className="cluster-tabs">{clusters.map(x=><button className={x.id===c.id?'active':''} key={x.id} onClick={()=>onSelect(x)}>{x.root.observed_application} → {x.root.root_cause_application}</button>)}</div></div><section className="explorer-grid"><div className="panel"><h2><Activity size={20}/> Alert Distribution</h2><div className="bar-chart">{bars.map(([label,value])=><div className="bar-item" key={label}><div className="bar-track"><span style={{height:`${Math.max((value/total)*100,8)}%`}}/></div><b>{value}</b><small>{label}</small></div>)}</div></div><div className="panel tree"><h2><GitBranch size={20}/> Alert Dashboard Tree</h2><p><b className="primary-badge">PRIMARY</b> {c.root.root_cause_detail} - {c.id} · {c.root.root_cause_application}</p><h4>Correlated Evidence Signals</h4>{c.linked.map(e=><p key={e.event_id}><span>{cleanSource(e.source)}</span> {e.event_name} <small>{e.timestamp}</small></p>)}<h4>Reduced Noise / Similar Signals</h4>{c.suppressed.length?c.suppressed.map(e=><p key={e.event_id}><span>{cleanSource(e.source)}</span> {e.event_name} <small>{e.timestamp}</small></p>):<p>No suppressed noise for this cluster.</p>}</div></section><section className="panel analysis-panel"><h2><DatabaseZap size={20}/> Root Cause Investigation Summary</h2><div className="analysis-grid"><aside><p><b>Observed Application</b><br/>{c.root.observed_application}</p><p><b>Root Cause Application</b><br/>{c.root.root_cause_application}</p><p><b>Root Cause Component</b><br/>{c.root.root_cause_component}</p><p><b>Primary RCA Event</b><br/>{c.id}</p><p><b>Evidence Sources</b><br/>{[...new Set(c.events.map(e=>cleanSource(e.source)))].join(' + ')}</p><p><b>RCA Confidence</b><br/>{c.confidence}%</p></aside><main><h3>Issue Description</h3><p>{c.executiveSummary}</p><div className="why"><h3>Why this event is selected as Primary RCA</h3>{(c.primaryReason?.narrative||c.primaryReason?.reason||'').split('\n').filter(Boolean).map(line=><p key={line}>{line}</p>)}</div><h3>Business Impact</h3><p>{c.businessImpactNarrative}</p><h3>Dependency path used by RCA:</h3><DependencyPath path={c.trace}/><button className="primary" onClick={()=>onOpen(c)}>Open Full RCA Investigation</button></main></div></section></section>;
}
function RcaModal({ cluster, onClose }) {
  const c = cluster; const evidence = c.events;
  return <div className="backdrop"><section className="modal"><button className="close" onClick={onClose}><X/></button><small>{c.id}</small><h2>{c.root.root_cause_detail}</h2><p>{c.executiveSummary}</p><section className="summary-grid"><div><span>Issue Observed In</span><b>{c.root.observed_application}</b></div><div><span>Actual Root Cause</span><b>{c.root.root_cause_application}</b><small>{c.root.root_cause_component}</small></div><div><span>Impact</span><b>{c.events.length} correlated events</b><small>{[...new Set(c.events.map(e=>cleanSource(e.source)))].join(' / ')}</small></div><div><span>Confidence</span><b>{c.confidence}%</b><small>Under Investigation</small></div></section><section className="modal-grid"><div className="panel"><h3>Observed Symptoms vs Actual Root Cause</h3><div className="split"><div><h4>Observed Symptoms</h4><b>{c.root.observed_application}</b><ul>{c.linked.map(e=><li key={e.event_id}>{e.event_name}</li>)}</ul></div><div><h4>Actual Root Cause</h4><b>{c.root.root_cause_application}</b><p>{c.root.root_cause_component}</p><p>{c.root.root_cause_detail}</p></div></div></div><div className="panel"><h3>Blast Radius</h3><div className="blast"><div><span>Applications</span><b>{c.blast.applications?.length || 0}</b><small>{c.blast.applications?.join(' / ')}</small></div><div><span>Users Impacted</span><b>{c.blast.users_impacted}</b></div><div><span>Orders / Transactions</span><b>{c.blast.orders_at_risk}</b></div><div><span>Business Severity</span><b>{c.blast.business_severity}</b></div></div></div></section><section className="modal-grid"><div className="panel"><h3><DatabaseZap size={18}/> Evidence Supporting RCA</h3><div className="evidence-grid">{evidence.map(e=><div className="evidence" key={e.event_id}><label>{cleanSource(e.source)}</label><h4>{e.event_name || e.root_cause_detail}</h4><p>{e.event_id} · {e.timestamp}</p><b>{e.severity}</b></div>)}</div></div><div className="panel"><h3><LineChart size={18}/> RCA Selection Scoring</h3>{['Signal Strength','Source Correlation','Dependency Alignment','Historical Pattern Match'].map((label,i)=><div className="score" key={label}><div><span>{label}</span><b>{[95,93,97,90][i]}%</b></div><div><span style={{width:`${[95,93,97,90][i]}%`}}/></div></div>)}<div className="final-score"><span>Final RCA Confidence</span><b>{c.confidence}%</b></div></div></section><section className="modal-grid"><div className="panel"><h3><TimerReset size={18}/> Event Timeline</h3>{evidence.map((e,i)=><div className="timeline" key={e.event_id}><span>{e.timestamp || 'live'}</span><b>{i===0?'Root-cause evidence':'Symptom evidence'}</b><p>{cleanSource(e.source)} · {e.event_name || e.root_cause_detail}</p></div>)}</div><div className="panel"><h3>Dependency Path</h3><DependencyPath path={c.trace}/></div></section><section className="modal-grid"><div className="panel"><h3><ListChecks size={18}/> Recommended Operator Actions</h3><ol>{c.actions.map(a=><li key={a}>{a}</li>)}</ol></div><div className="panel"><h3>Executive Narrative</h3><p>{c.executiveNarrative}</p></div></section></section></div>;
}
function App() {
  const [clusters, setClusters] = useState(mock.map(normaliseIncident)); const [summary, setSummary] = useState({}); const [events, setEvents] = useState([]); const [tab, setTab] = useState('dashboard'); const [selected, setSelected] = useState(null); const [modal, setModal] = useState(null); const [detail, setDetail] = useState(null); const [mode, setMode] = useState('Mock fallback');
  async function refresh() { try { let run = await api('/run', {method:'POST'}); if(!run.incidents?.length){ await api('/collect',{method:'POST'}); run = await api('/run',{method:'POST'}); } if(run.incidents?.length){ setClusters(run.incidents.map(normaliseIncident)); setSelected(run.incidents.map(normaliseIncident)[0]); } const s = await api('/dashboard-summary'); setSummary(s); const ev = await api('/events'); setEvents(ev.events || []); setMode('Backend connected'); } catch { setMode('Mock fallback'); } }
  useEffect(()=>{ refresh(); const id=setInterval(refresh,30000); return ()=>clearInterval(id); },[]);
  const current = selected || clusters[0];
  return <main className="shell"><Header mode={mode}/><LiveTicker onRefresh={refresh} onCollect={()=>api('/collect',{method:'POST'}).then(refresh)} onStart={()=>api('/start-scheduler',{method:'POST'}).then(refresh)} onStop={()=>api('/stop-scheduler',{method:'POST'}).then(refresh)}/><nav className="tabs"><button className={tab==='dashboard'?'active':''} onClick={()=>setTab('dashboard')}>Executive Dashboard</button><button className={tab==='explorer'?'active':''} onClick={()=>setTab('explorer')}>Correlation Explorer</button></nav>{tab==='dashboard'?<Dashboard clusters={clusters} summary={summary} events={events} onOpen={setModal} onDetail={setDetail}/>:<CorrelationExplorer clusters={clusters} selected={current} onSelect={setSelected} onOpen={setModal}/>} {modal&&<RcaModal cluster={modal} onClose={()=>setModal(null)}/>} {detail&&<DetailModal detail={detail} onClose={()=>setDetail(null)}/>}</main>;
}

createRoot(document.getElementById('root')).render(<App/>);
