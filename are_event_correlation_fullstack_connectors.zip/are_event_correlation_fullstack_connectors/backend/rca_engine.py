ROOT_PRIORITY = [
    "Oracle Session Pool Exhaustion",
    "Inventory Database Connection Exhaustion",
    "AIAD Oracle Backend Connection Exhaustion",
    "Payment Gateway Authorisation Timeout",
    "Splunk Search Queue Saturation",
]
SOURCE_WEIGHT = {"Oracle Logs": 30, "Splunk API": 25, "AppDynamics API": 20}
SUPPRESS = {"Business Transaction Response Time High", "Business Transaction Error Rate High"}


def _score(event):
    detail = event.get("root_cause_detail") or event.get("event_name")
    pri = 100 - ROOT_PRIORITY.index(detail) * 5 if detail in ROOT_PRIORITY else 20
    return pri + SOURCE_WEIGHT.get(event.get("source"), 0) + min(event.get("business_impact_score", 0), 25) + (20 if event.get("is_root_candidate") else 0)


def correlate(events):
    if len(events) < 2:
        return None
    root = sorted(events, key=_score, reverse=True)[0]
    linked, suppressed = [], []
    for e in events:
        if e is root:
            continue
        (suppressed if e.get("event_name") in SUPPRESS else linked).append(e)
    sources = {e.get("source") for e in events}
    confidence = min(98, 60 + (15 if len(sources) > 1 else 0) + 10 + (5 if root.get("is_root_candidate") else 0) + 10)
    return {"root": root, "linked_alerts": linked, "suppressed_alerts": suppressed, "confidence": confidence}
