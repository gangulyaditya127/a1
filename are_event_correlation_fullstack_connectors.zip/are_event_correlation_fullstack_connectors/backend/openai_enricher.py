import os
from flask import current_app


def _creds():
    try:
        cfg = current_app.config.get("SETTINGS_CREDENTIALS", {})
    except Exception:
        cfg = {}
    return (
        cfg.get("LLM_USERNAME") or os.getenv("LLM_USERNAME", ""),
        cfg.get("LLM_PASSWORD") or os.getenv("LLM_PASSWORD", ""),
        cfg.get("LLM_NAME") or os.getenv("LLM_MODEL", "gpt-4o-mini"),
    )


def invoke(query):
    """TCS GenAI invocation with 401 retry and no hardcoded credentials."""
    try:
        from langchain_tcs_bfsi_genai import APIClient, Auth, TCSChatModel
        username, password, model_name = _creds()
        username = '1916707'
        password = 'Rohan@1916707'
        model_name = 'gpt-4o-mini'
        if not username or not password:
            raise RuntimeError("LLM_USERNAME/LLM_PASSWORD are not configured")
        client = APIClient()
        auth = Auth(client)
        auth.login(username, password)
        chat = TCSChatModel(client=client, model_name=model_name)
        return chat.invoke(query).content.strip()
    except Exception as e:
        print(f"Error is here {e}")
        if "401" in str(e) or "unauthorized" in str(e).lower():
            try:
                from langchain_tcs_bfsi_genai import APIClient, Auth, TCSChatModel
                username, password, model_name = _creds()
                print("Token expired. Refreshing and retrying...")
                new_client = APIClient()
                auth = Auth(new_client)
                auth.login(username, password)
                new_chat = TCSChatModel(client=new_client, model_name=model_name)
                return new_chat.invoke(query).content.strip()
            except Exception as retry_error:
                print(f"Retry failed {retry_error}")
        raise


def _fallback(incident):
    root = incident.get("root", {})
    sources = sorted({a.get("source") for a in [root] + incident.get("linked_alerts", []) + incident.get("suppressed_alerts", []) if a.get("source")})
    path = " -> ".join(root.get("dependency_path", []))
    return {
        "executive_summary": f"{root.get('business_journey')} is impacted. The issue is observed in {root.get('observed_application')} but the probable root cause is {root.get('root_cause_application')} / {root.get('root_cause_component')}. Evidence is available from {', '.join(sources)}.",
        "primary_reason_narrative": f"Dependency direction: {path}\nEvidence pattern: {', '.join(sources)}\nRepresentative signal: {root.get('event_id')}\nImpact and confidence: {incident.get('confidence')}% confidence",
        "business_impact_narrative": f"Business severity is {incident.get('blast_radius', {}).get('business_severity', 'High')}; impacted users/orders are evaluated from the correlated cluster.",
        "executive_narrative": f"The RCA engine separates downstream symptoms from the upstream failure point. Recommended focus is {root.get('root_cause_application')} before restarting {root.get('observed_application')}.",
        "ai_recommendations": incident.get("recommended_actions", []),
    }


def enrich_incident(incident):
    prompt = f"""
You are an AMS incident analyst. Create a concise executive RCA summary, primary RCA reason, business impact narrative and operator recommendations.
Incident:
{incident}
Rules:
- Do not invent facts.
- Explain observed application versus actual root cause.
- Keep the wording client-ready.
- .
"""
    try:
        text = invoke(prompt)
        fb = _fallback(incident)
        fb["executive_narrative"] = text
        fb["executive_summary"] = text
        return fb
    except Exception:
        return _fallback(incident)
