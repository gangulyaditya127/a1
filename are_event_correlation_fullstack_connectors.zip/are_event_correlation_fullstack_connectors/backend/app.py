import json, os, random, threading, time
from datetime import datetime, timezone, timedelta
from flask import Flask, jsonify, request
from flask_cors import CORS
from rca_engine import correlate
from openai_enricher import enrich_incident

APP = Flask(__name__)
CORS(APP)
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
RAW = os.path.join(DATA, "raw_events.json")
INC = os.path.join(DATA, "incidents.json")
os.makedirs(DATA, exist_ok=True)
for p, d in [(RAW, []), (INC, {"incidents": []})]:
    if not os.path.exists(p):
        with open(p, "w", encoding="utf-8") as f: json.dump(d, f, indent=2)
stop_flag = False
worker = None

def now(offset=0):
    return (datetime.now(timezone.utc) + timedelta(seconds=offset)).isoformat().replace("+00:00", "Z")

def tid(prefix, n):
    return f"{prefix}-EVT-20260714-{n:06d}"

def read(path, default):
    try:
        with open(path, encoding="utf-8") as f: return json.load(f)
    except Exception:
        return default

def write(path, data):
    with open(path, "w", encoding="utf-8") as f: json.dump(data, f, indent=2)

def append(events):
    data = read(RAW, [])
    write(RAW, events + data)

def cluster_definitions():
    return [
        {
            "correlation_id":"ARE-IRR-AIAD-ORCL", "root_id":"ORCL-EVT-20260714-000017", "journey":"ARE RCA Knowledge Lookup", "observed":"IRR", "root_app":"AIAD", "component":"Oracle Session Pool", "root_detail":"Oracle Session Pool Exhaustion", "severity":"Critical", "confidence":92,
            "path":["IRR","ARE Gateway","AIAD","Oracle RAC"], "users":4280, "orders":12340,
            "sources":["AppDynamics API","Splunk API","Oracle Logs"], "size":12,
            "signals":["business transaction response time high","backend call latency high","application error rate breach","slow transaction snapshot detected","HTTP 500 Spike","JDBC timeout exception","ORA-00018 maximum sessions exceeded"]
        },
        {"correlation_id":"ARE-DAHC-ANALYTICS", "root_id":"SPLK-EVT-20260714-000084", "journey":"ARE Health Analytics", "observed":"DAHC", "root_app":"ARE Analytics", "component":"Splunk Search Queue", "root_detail":"Splunk Search Queue Saturation", "severity":"High", "confidence":89, "path":["DAHC","ARE Analytics","Splunk Search Head"], "users":1870, "orders":5920, "sources":["Splunk API","AppDynamics API"], "size":9, "signals":["search queue saturation","report latency increased","health check response time high"]},
        {"correlation_id":"ARE-TRIAGE-GATEWAY", "root_id":"SPLK-EVT-20260714-000121", "journey":"Triage AI Case Creation", "observed":"Triage AI", "root_app":"ARE Gateway", "component":"Redis Token Cache", "root_detail":"Token Cache Lookup Failure", "severity":"High", "confidence":87, "path":["Triage AI","ARE Gateway","Redis Token Cache"], "users":960, "orders":2180, "sources":["AppDynamics API","Splunk API"], "size":8, "signals":["token cache lookup failure","prompt session create error","gateway token validation delay"]},
        {"correlation_id":"ARE-AIAD-KHUB", "root_id":"ORCL-EVT-20260714-000044", "journey":"AIAD Knowledge Graph Refresh", "observed":"AIAD", "root_app":"ARE Knowledge Hub", "component":"PostgreSQL Replica", "root_detail":"Knowledge Repository Replication Lag", "severity":"High", "confidence":86, "path":["AIAD","ARE Knowledge Hub","PostgreSQL Replica"], "users":740, "orders":1620, "sources":["Splunk API","Oracle Logs"], "size":7, "signals":["replication lag increased","dependency graph refresh failed","stale dependency read"]},
        {"correlation_id":"ECOM-CHECKOUT-INVENTORY", "root_id":"ORCL-EVT-ECOM-000017", "journey":"Checkout & Order Placement", "observed":"Checkout Service", "root_app":"Inventory Service", "component":"Oracle Inventory DB Pool", "root_detail":"Inventory Database Connection Exhaustion", "severity":"Critical", "confidence":91, "path":["E-Commerce Portal","Checkout Service","Inventory Service","Oracle Inventory DB"], "users":4280, "orders":8760, "sources":["AppDynamics API","Splunk API","Oracle Logs"], "size":12, "signals":["Checkout API Response Time High","Order Submission Failed","Inventory DB Session Pool Exhausted","SQL timeout during inventory validation"]},
        {"correlation_id":"ECOM-PAYMENT-PSP", "root_id":"APPD-EVT-ECOM-000084", "journey":"Payment Authorisation", "observed":"Payment Gateway", "root_app":"Payment Gateway", "component":"External PSP Authorisation API", "root_detail":"Payment Gateway Authorisation Timeout", "severity":"High", "confidence":88, "path":["Checkout Service","Payment Gateway","External PSP API"], "users":1870, "orders":3340, "sources":["AppDynamics API","Splunk API"], "size":7, "signals":["Payment Authorisation Response Time High","PSP Timeout Error","Payment retry spike"]},
        {"correlation_id":"ECOM-SEARCH-INDEX", "root_id":"SPLK-EVT-ECOM-000121", "journey":"Product Discovery", "observed":"Product Search", "root_app":"Search Platform", "component":"Search Index Refresh Worker", "root_detail":"Search Index Refresh Lag", "severity":"Medium", "confidence":84, "path":["E-Commerce Portal","Product Search","Search Platform","Index Refresh Worker"], "users":6120, "orders":2450, "sources":["Splunk API","AppDynamics API"], "size":5, "signals":["Product Search Response Time High","Search index refresh lag","zero result rate increased"]}
    ]

def generate_events():
    events = []
    counters = {"Splunk API":1, "AppDynamics API":1, "Oracle Logs":1}
    for c in cluster_definitions():
        for i in range(c["size"]):
            source = c["sources"][i % len(c["sources"])]
            prefix = {"Splunk API":"SPLK", "AppDynamics API":"APPD", "Oracle Logs":"ORCL"}[source]
            is_root = i == 0
            n = counters[source]; counters[source] += 1
            event_name = c["root_detail"] if is_root else c["signals"][i % len(c["signals"])]
            log_cat = {"Splunk API":"Application Log", "AppDynamics API":"Business Transaction", "Oracle Logs":"Oracle Alert Log"}[source]
            events.append({
                "event_id": c["root_id"] if is_root else tid(prefix, n),
                "EventId": c["root_id"] if is_root else tid(prefix, n),
                "source": source,
                "connector": source.replace(" API", "").replace(" Logs", "").lower(),
                "logCategory": log_cat,
                "event_name": event_name,
                "eventName": event_name,
                "root_cause_detail": c["root_detail"],
                "business_journey": c["journey"],
                "observed_application": c["observed"],
                "observedApplication": c["observed"],
                "root_cause_application": c["root_app"],
                "root_cause_component": c["component"],
                "severity": c["severity"] if is_root else ("High" if i % 3 == 0 else "Medium"),
                "is_root_candidate": is_root,
                "business_impact_score": 30 if is_root else 15,
                "dependency_path": c["path"],
                "correlation_id": c["correlation_id"],
                "timestamp": now(i*7),
                "isCorrelated": True
            })
    # add a few uncorrelated operational noise events so KPI and detail modals look realistic
    noise_sources = ["Splunk API", "AppDynamics API", "Oracle Logs"]
    for i in range(60 - len(events)):
        src = noise_sources[i % 3]
        prefix = {"Splunk API":"SPLK", "AppDynamics API":"APPD", "Oracle Logs":"ORCL"}[src]
        events.append({"event_id": tid(prefix, 900+i), "EventId": tid(prefix, 900+i), "source": src, "connector": src.replace(" API", "").replace(" Logs", "").lower(), "logCategory": "Server Log" if src=="Splunk API" else "Response Time Alert", "event_name": "background telemetry signal", "eventName": "background telemetry signal", "observed_application":"ARE Gateway", "observedApplication":"ARE Gateway", "severity":"Low", "correlation_id": f"NOISE-{i}", "timestamp": now(100+i), "isCorrelated": False})
    return events

def collect_seed():
    events = generate_events()
    write(RAW, events)
    return events

def build_incidents():
    events = read(RAW, [])
    if not events:
        events = collect_seed()
    groups = {}
    for e in events:
        if e.get("isCorrelated"):
            groups.setdefault(e.get("correlation_id"), []).append(e)
    incidents = []
    for key, evs in groups.items():
        res = correlate(evs)
        if not res: continue
        root = res["root"]
        cd = next((x for x in cluster_definitions() if x["correlation_id"] == key), None)
        blast = {"applications": list({root.get("observed_application"), root.get("root_cause_application"), *(cd.get("path", [])[:2] if cd else [])}), "users_impacted": cd.get("users") if cd else 800, "orders_at_risk": cd.get("orders") if cd else 1200, "business_severity": root.get("severity")}
        inc = {"title": f"{root.get('business_journey')} impacted: {root.get('root_cause_detail')} identified in {root.get('root_cause_application')}", "root": root, "linked_alerts": res["linked_alerts"][:6], "suppressed_alerts": res["suppressed_alerts"][:4], "confidence": cd.get("confidence") if cd else res["confidence"], "blast_radius": blast, "recommended_actions":["Validate root-cause component health.", "Check dependency path before restarting the observed application.", "Confirm business journey KPI recovery."], "primary_reason":{"score":182,"reason":"Selected using source confidence, dependency position, business impact and rule priority."}}
        inc.update(enrich_incident(inc))
        inc["primary_reason"]["narrative"] = inc.get("primary_reason_narrative")
        incidents.append(inc)
    write(INC, {"incidents": incidents})
    return incidents

@APP.get('/')
def health(): return {"status":"UP", "connectors":["Splunk API", "AppDynamics API", "Oracle Logs"], "llm_mode": os.getenv("LLM_MODE", "mock")}
@APP.post('/correlation/collect')
def collect():
    ev = collect_seed(); build_incidents(); return jsonify({"status":"COLLECTED", "inserted":len(ev), "events":ev})
@APP.post('/correlation/ingest')
def ingest():
    p = request.get_json(silent=True) or {}; alerts = p if isinstance(p, list) else p.get("alerts", [p]); data=read(RAW,[]); write(RAW, alerts+data); return jsonify({"status":"INGESTED", "inserted":len(alerts)})
@APP.post('/correlation/run')
def run():
    inc = build_incidents(); return jsonify({"status":"CORRELATED" if inc else "NONE", "incident_count":len(inc), "incidents":inc})
@APP.get('/correlation/events')
def events():
    data = read(RAW, [])
    if not data: data = collect_seed()
    src = request.args.get('source')
    if src: data = [e for e in data if e.get('source') == src or e.get('connector') == src]
    return jsonify({"count":len(data), "events":data})
@APP.get('/correlation/dashboard-summary')
def summary():
    ev = read(RAW, []) or collect_seed(); inc = read(INC, {"incidents": []})["incidents"] or build_incidents(); sd = {}
    for e in ev: sd[e.get("source")] = sd.get(e.get("source"),0)+1
    return jsonify({"events_received":len(ev), "correlated_events":len([e for e in ev if e.get('isCorrelated')]), "active_incidents":len({e.get('correlation_id') for e in ev if e.get('isCorrelated')}), "active_root_causes":len(inc), "applications_impacted":len({x.get('root',{}).get('observed_application') for x in inc}), "source_distribution":sd})
def find_inc(id):
    inc = read(INC, {"incidents": []})["incidents"] or build_incidents()
    for x in inc:
        r = x.get("root", {})
        if id in {r.get("event_id"), r.get("correlation_id")}: return x
@APP.get('/correlation/explorer')
def explorer():
    inc = read(INC, {"incidents": []})["incidents"] or build_incidents(); out=[]
    for x in inc:
        r=x.get('root',{}); out.append({"incident_id":r.get('event_id'), "title":x.get('title'), "business_journey":r.get('business_journey'), "observed_application":r.get('observed_application'), "root_cause_application":r.get('root_cause_application'), "root_cause_detail":r.get('root_cause_detail'), "confidence":x.get('confidence'), "primary":r, "linked":x.get('linked_alerts',[]), "suppressed":x.get('suppressed_alerts',[]), "correlation_trace":r.get('dependency_path',[]), "primary_reason":x.get('primary_reason'), "executive_summary":x.get('executive_summary'), "business_impact_narrative":x.get('business_impact_narrative'), "executive_narrative":x.get('executive_narrative'), "blast_radius":x.get('blast_radius'), "recommended_actions":x.get('recommended_actions',[])+x.get('ai_recommendations',[])})
    return jsonify({"count":len(out), "explorer":out})
@APP.get('/correlation/trace/<id>')
def trace(id):
    x=find_inc(id); return (jsonify({"correlation_trace":x["root"].get("dependency_path", [])}) if x else (jsonify({"status":"NOT_FOUND"}),404))
@APP.get('/correlation/root-cause/<id>')
def rootcause(id):
    x=find_inc(id); return (jsonify({"root":x.get("root"), "primary_reason":x.get("primary_reason")}) if x else (jsonify({"status":"NOT_FOUND"}),404))
@APP.get('/correlation/evidence/<id>')
def evidence(id):
    x=find_inc(id); return (jsonify({"events":[x.get("root")]+x.get("linked_alerts",[])+x.get("suppressed_alerts",[])}) if x else (jsonify({"status":"NOT_FOUND"}),404))
@APP.get('/correlation/executive-summary/<id>')
def execsum(id):
    x=find_inc(id); return (jsonify({"executive_summary":x.get("executive_summary"), "executive_narrative":x.get("executive_narrative")}) if x else (jsonify({"status":"NOT_FOUND"}),404))
@APP.get('/correlation/rca-explanation/<id>')
def exp(id):
    x=find_inc(id); return (jsonify({"primary_reason":x.get("primary_reason")}) if x else (jsonify({"status":"NOT_FOUND"}),404))
@APP.get('/correlation/recommendations/<id>')
def recs(id):
    x=find_inc(id); return (jsonify({"recommendations":x.get("recommended_actions", [])+x.get("ai_recommendations", [])}) if x else (jsonify({"status":"NOT_FOUND"}),404))
def loop():
    global stop_flag
    while not stop_flag:
        collect_seed(); build_incidents(); time.sleep(30)
@APP.post('/correlation/start-scheduler')
def start():
    global worker, stop_flag
    if worker and worker.is_alive(): return jsonify({"status":"already_running"})
    stop_flag=False; worker=threading.Thread(target=loop,daemon=True); worker.start(); return jsonify({"status":"started"})
@APP.post('/correlation/stop-scheduler')
def stop():
    global stop_flag; stop_flag=True; return jsonify({"status":"stopped"})
if __name__ == '__main__': APP.run(host='0.0.0.0', port=5000, debug=True)
