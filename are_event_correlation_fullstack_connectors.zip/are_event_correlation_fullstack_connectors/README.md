# ARE Agentic Event Correlation - Final Full Stack

Keeps the original dark Executive Dashboard / Correlation Explorer visual style and adds backend + TCS GenAI/OpenAI enricher.

## Backend
- Flask app
- Splunk API connector
- AppDynamics API connector
- Oracle Logs connector
- JSON event store
- Scheduler
- RCA engine
- TCS GenAI enricher in `backend/openai_enricher.py`

## Frontend
- Executive Dashboard
- Clickable KPI cards
- Bubble source distributions
- Active Cross-Application Root Cause Inventory
- Correlation Explorer
- Alert Dashboard Tree
- Primary RCA justification
- Correlation trace
- RCA modal

## Run backend
```bash
cd backend
python -m venv arenv
source arenv/bin/activate
pip install -r requirements.txt
python app.py
```

Windows:
```cmd
cd backend
python -m venv arenv
arenv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```

## TCS GenAI settings
Do not hardcode credentials. Use environment variables or Flask `SETTINGS_CREDENTIALS`:

```bash
LLM_USERNAME=your_tcs_user
LLM_PASSWORD=your_tcs_password
LLM_MODEL=gpt-4o-mini
```
