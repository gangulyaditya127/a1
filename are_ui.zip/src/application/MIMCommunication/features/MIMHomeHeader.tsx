// import { Icon } from "@/components/ui/icon";
// import { Separator } from "@/components/ui/seperator";
// import { Skeleton } from "@/components/ui/skeleton";


// const LoadingShimmer = () => {
//     return (
//         <div className="flex items-center gap-4">
//             <Skeleton className="w-32 h-20" />
//             <Skeleton className="w-32 h-20" />
//             <Skeleton className="w-32 h-20" />
//             <Skeleton className="w-32 h-20" />
//         </div>
//     )
// }

export default function MIMHomeHeader() {
    return (
        <div className="flex items-center justify-between">
            <div>
                <h4 className="text-sm font-medium uppercase text-muted-foreground">
                    TCS Application Reliability Engineering
                </h4>
                <h3 className="text-2xl font-medium">MIM Communication Dashboard</h3>
            </div>
            {/* {
                false ? <LoadingShimmer /> : //isLoading 
                    <div className="flex items-center gap-4">
                        <div className="">
                            <div className="flex gap-1">
                                <p className="text-muted-foreground">SLA Complaince</p>
                                <div className="flex -space-x-1">
                                    <Icon
                                        name="bar-chart-2"
                                        className="size-5 p-0 "
                                    />
                                    <Icon
                                        name="bar-chart"
                                        className="size-5 p-0 "
                                    />
                                </div>
                            </div>
                            <p className="text-2xl">
                                10
                                <span className="text-sm font-normal text-muted-foreground">
                                    %
                                </span>
                            </p>
                            
                        </div>
                        <Separator orientation="vertical" className="h-12" />
                        <div>
                            <div className="flex gap-1">
                                <p className="text-muted-foreground">Avg TAT</p>
                                <div className="flex -space-x-1">
                                    <Icon
                                        name="bar-chart-2"
                                        className="size-5 p-0"
                                    />
                                    <Icon
                                        name="bar-chart"
                                        className="size-5 p-0"
                                    />
                                </div>
                            </div>
                            <p className="text-2xl">
                                {10}
                                <span className="text-sm font-normal text-muted-foreground">
                                    Hrs
                                </span>
                            </p>
                           
                        </div>
                        <Separator orientation="vertical" className="h-12" />
                        <div>
                            <div className="flex gap-1">
                                <p className="text-muted-foreground">BMI</p>
                                <div className="flex -space-x-1">
                                    <Icon
                                        name="bar-chart-2"
                                        className="size-5 p-0"
                                    />
                                    <Icon
                                        name="bar-chart"
                                        className="size-5 p-0"
                                    />
                                </div>
                            </div>
                            <p className="text-2xl">
                                {11}
                                <span className="text-sm font-normal text-muted-foreground">
                                    %
                                </span>
                            </p>
                            
                        </div>

                    </div>
            } */}
        </div>
    )
}