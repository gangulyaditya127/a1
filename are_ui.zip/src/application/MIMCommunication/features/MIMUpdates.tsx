import { Icon } from "@/components/ui/icon";
import { useId, useRef, useState, MouseEvent, useEffect } from "react";
import AutoTextArea from "@/components/ui/auto-grow-text-area";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useAppSelector } from "@/lib/redux/hooks";
import { Skeleton } from "@/components/ui/skeleton";
import { MIMErrorContainer } from "../features/MIMErrorContainer";
import { useToast } from "@/components/ui/use-toast";
import { useGetTicketUpdatesQuery, useUpdateMIMMutation } from "../slice/MIMAPISlice";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function MIMUpdates({ ticketNumber }: { ticketNumber: string }) {
    const ref = useRef<HTMLTextAreaElement>(null)
    const id = useId();
    const [comment, setComment] = useState("");
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const { toast } = useToast();

    const { isLoading, isError, data } = useGetTicketUpdatesQuery({ ticketNumber }, {
        skip: !ticketNumber,
        pollingInterval: 1000 * 60
    })

    const [mutate, response] = useUpdateMIMMutation()

    const { isLoading: isSubmitting } = response

    useEffect(() => {
        if (response.isSuccess) {
            setComment("");
        }
        if (response.isError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "There was a problem while submitting response.",
            })
        }
    }, [response])

    const handleSumbit = async (e: MouseEvent<HTMLButtonElement>) => {
        e.preventDefault()
        if (comment.trim().length == 0) {
            return toast({
                variant: "destructive",
                title: "Uh oh! Invalid Update",
                description: "Update can't be empty",
            })
        }
        await mutate({
            empid: userDetails?.empid ?? "",
            comment: comment.trim(),
            ticketNumber
        });
    }

    return (
        <div className="pt-11 px-4 relative h-full relative">
            <div className="grid grid-rows-[1fr_auto] h-[calc(100%-20px)] mt-2">
                {
                    isError ? <MIMErrorContainer className="p-4" /> :
                        <div className="text-sm overflow-y-scroll space-y-4">
                            {
                                isLoading ? new Array(4).fill(0).map((_, i) => <Skeleton className="h-20 rounded-lg" key={i} />) : null
                            }
                            {
                                data?.map(el => (
                                    <ChatCard key={`${el.created}_${el.updated_by}`} name={el.updated_by} date={el.created} comment={el.comment} />
                                ))
                            }
                        </div>
                }

                <div className="space-y-1"> {/* absolute bottom-0 space-y-1 w-[90%] left-1/2 -translate-x-1/2 */}
                    <Label htmlFor={`mim_comment_${id}`}>Add Updates</Label>
                    <AutoTextArea placeholder="Add latest updates" className="" id={`mim_comment_${id}`} maxRows={6} defaultRows={3} ref={ref} onChange={(e) => { setComment(e.target.value) }} value={comment} />
                    <Button className="w-full mt-4 flex items-center gap-2 h-7 rounded-lg" variant="secondary" onClick={handleSumbit} disabled={isSubmitting}>
                        {isSubmitting && <Icon name="loader" className="animate-spin h-4 w-4" />}
                        Submit
                    </Button>
                </div>
            </div>
        </div>
    )
}

type CardProps = {
    name: string,
    date: string,
    comment: string
}

function ChatCard({ name, date, comment }: CardProps) {
    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="rounded-lg border p-3">
                        <div className="flex gap-2 items-center">
                            <p className="font-medium">{name}</p>
                            <p className="text-muted-foreground text-xs">{date}</p>
                        </div>
                        <p className="text-muted-foreground">{comment}</p>
                    </div>
                </TooltipTrigger>
                <TooltipContent>
                    <p>MIM Updates</p>
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>

    )
}
