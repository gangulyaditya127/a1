import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import ErrorContainer from "@/components/ui/error-container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useGetMIMDetailQuery } from "../slice/MIMAPISlice";
import { cn } from "@/lib/tailwind.utils";
import { Icon } from "@/components/ui/icon";
export default function MIMDetailForm({ ticketNumber }: { ticketNumber: string }) {
    const { data, isLoading, isError } = useGetMIMDetailQuery({ ticketNumber: ticketNumber ?? "" }, {
        skip: !ticketNumber
    });

    return (
        <div className="h-full overflow-scroll pt-4 pr-4 space-y-4 text-sm">
            <NavigateBackButton />
            {
                isLoading ? <LoadingSkelton /> : (
                    <>
                        <div>
                            <div className="font-medium text-xl flex items-center gap-3">
                                <span>MIM Communication for Tikcet #{ticketNumber}</span>
                                <Badge variant="outline" className="gap-1.5">
                                    <span className={cn("size-1.5 rounded-full bg-red-500", data?.[0]?.priority_or_severity == "High" ? "bg-red-500" : data?.[0]?.priority_or_severity == "Low" ? "bg-green-500" : "bg-amber-500")} aria-hidden="true"></span>
                                    {data?.[0]?.status}
                                </Badge>
                            </div>
                            <p className="text-muted-foreground flex gap-2 text-xs">
                                <span>Created At : {data?.[0]?.createdAt}</span>
                                <span>|</span>
                                <span>Last Updated At: {data?.[0]?.updateAsOf}</span>
                            </p>
                        </div>
                        {
                            isError ? <ErrorContainer /> : (
                                <>
                                    <div className="bg-blue-400 dark:bg-blue-600 rounded-lg p-4 grid grid-cols-2 gap-y-2 gap-x-4">
                                        <div className="flex gap-4">
                                            <p className="font-medium ">
                                                Meeting Url :
                                            </p>
                                            <a href={data?.[0]?.skype_link} target="_blank" className="hover:underline flex items-center gap-2">
                                                {data?.[0]?.skype_link}
                                                <Icon name="link" className="h-4 w-4" />
                                            </a>
                                        </div>
                                        <div className="flex gap-4">
                                            <p className="font-medium">Meeting Id :</p>
                                            <p className="">{data?.[0]?.meeting_id}</p>
                                        </div>
                                        <div className="flex gap-4">
                                            <p className="font-medium">Passcode :</p>
                                            <p className="">{data?.[0]?.passcode}</p>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-4 gap-4 border p-4 rounded-lg">
                                        <div className="">
                                            <p className="font-medium">App ID</p>
                                            <p className="text-muted-foreground">{data?.[0]?.app_id}</p>
                                        </div>
                                        <div className="">
                                            <p className="font-medium">Account</p>
                                            <p className="text-muted-foreground">{data?.[0]?.account}</p>
                                        </div>
                                        <div className="">
                                            <p className="font-medium">Project</p>
                                            <p className="text-muted-foreground">{data?.[0]?.project}</p>
                                        </div>
                                        <div className="flex gap-2">
                                            <p className="font-medium">Severity</p>
                                            <p className="text-muted-foreground">
                                                <Badge variant="secondary" className="gap-1.5">
                                                    <span className={cn("size-1.5 rounded-full bg-red-500", data?.[0]?.status == "Open" ? "bg-red-500" : data?.[0]?.priority_or_severity == "Closed" ? "bg-green-500" : "bg-amber-500")} aria-hidden="true"></span>
                                                    {data?.[0]?.priority_or_severity}
                                                </Badge>

                                            </p>
                                        </div>
                                    </div>

                                    <div className="">
                                        <p className="font-medium">Title</p>
                                        <p className="text-muted-foreground">{data?.[0]?.title}</p>
                                    </div>
                                    <div className="">
                                        <p className="font-medium">Description</p>
                                        <p className="text-muted-foreground">{data?.[0]?.incident_description}</p>
                                    </div>
                                    <div className="">
                                        <p className="font-medium">Business Impact</p>
                                        <p className="text-muted-foreground">{data?.[0]?.business_impact}</p>
                                    </div>
                                    <div className="">
                                        <p className="font-medium">Current Update</p>
                                        <p className="text-muted-foreground">{data?.[0]?.current_update}</p>
                                    </div>
                                    <div className="">
                                        <p className="font-medium">Causing Application</p>
                                        <p className="text-muted-foreground mt-2">
                                            <Badge variant="outline" className="gap-1.5">
                                                <span className={"size-1.5 rounded-full bg-red-500"} aria-hidden="true"></span>
                                                {data?.[0]?.causing_application}
                                            </Badge>
                                        </p>
                                    </div>
                                    <div className="">
                                        <p className="font-medium">Impacted Application</p>
                                        <p className="text-muted-foreground flex gap-2 mt-2">{
                                            data?.[0]?.impacted_applications.map((app) => (
                                                <Badge variant="secondary" className="gap-1.5" key={app}>
                                                    <span className={"size-1.5 rounded-full bg-red-500"} aria-hidden="true"></span>
                                                    {app}
                                                </Badge>
                                            ))
                                        }</p>
                                    </div>
                                </>
                            )
                        }
                    </>
                )
            }
        </div>
    )
}

function LoadingSkelton() {
    return (
        <>
            <Skeleton className="rounded-lg h-20" />
            <Skeleton className="rounded-lg h-20" />
            <Skeleton className="rounded-lg h-10 w-1/2" />
            <Skeleton className="rounded-lg h-10 w-3/4" />
            <Skeleton className="rounded-lg h-10 w-[60%]" />
            <Skeleton className="rounded-lg h-10 w-[20%]" />
            <Skeleton className="rounded-lg h-10 w-[80%]" />
        </>
    )
}