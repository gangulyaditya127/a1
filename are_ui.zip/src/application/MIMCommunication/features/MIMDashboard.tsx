import DataGrid from "@/components/ui/data-grid";
import { ColDef } from "ag-grid-charts-enterprise";
import { useMemo, useState } from "react";
import { useGetMIMListQuery } from "../slice/MIMAPISlice";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { MIMErrorContainer } from "./MIMErrorContainer";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/tailwind.utils";

export default function MIMDashboard() {
    // const [rowData] = useState([]);

    const { isLoading, isError, data: rowData } = useGetMIMListQuery({
        project: "PROJECT_1",
        account: "TCS_1"
    }, {
        pollingInterval: 1000 * 60
    })

    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);

    const [columnDefs] = useState<ColDef[]>([
        { field: "ticketNumber", headerName: "MIM Number", maxWidth: 200, filter: 'agTextColumnFilter', cellRenderer: MIMTicketRender },
        { field: "title", filter: 'agTextColumnFilter', headerName: "MIM Title" },
        { field: "priority", filter: 'agSetColumnFilter', maxWidth: 150, cellRenderer: PriorityRenderer },
        { field: "causingApplication", filter: 'agSetColumnFilter', cellRenderer: CausingAppRenderer },
        { field: "impactedApplication" },
        { field: "businessImpact" },
        { field: "currentUpdate" },
        { field: "lastUpdatedAt", type: 'date', filter: 'agDateColumnFilter' },
        { field: "timezone" },
    ]);

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);

    if (isLoading) {
        return <Skeleton className="h-[400px]" />
    }

    if (isError) {
        return <MIMErrorContainer className="h-[400px]" />
    }

    return (
        <div className="h-[400px]">
            <div
                style={gridStyle}
            >
                <DataGrid
                    rowData={rowData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    masterDetail={true}
                />
            </div>
        </div>
    )
}


const MIMTicketRender = ({ data }: any) => {
    const { ticketNumber } = data
    return (
        <Link to={`/mim-communication/${ticketNumber}`} className="w-full h-full hover:underline">
            {ticketNumber}
        </Link>
    )
}

const PriorityRenderer = ({ data }: any) => {
    const { priority } = data
    return (
        <Badge variant="secondary" className="gap-1.5">
            <span className={cn("size-1.5 rounded-full bg-red-500", priority == "High" ? "bg-red-500" : priority == "Low" ? "bg-green-500" : "bg-amber-500")} aria-hidden="true"></span>
            {priority}
        </Badge>
    )
}

const CausingAppRenderer = ({ data }: any) => {
    const { causingApplication } = data
    return (
        <Badge variant="outline" className="gap-1.5">
            <span className={cn("size-1.5 rounded-full bg-red-500")} aria-hidden="true"></span>
            {causingApplication}
        </Badge>
    )
}