import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "MIM Communication",
        route: "/mim-communication",
        key: "1",
    },
];
