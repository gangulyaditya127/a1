import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Home",
          icon: "home",
          route: "/mim-communication/home",
        },
      ],
    },
  ],
  bottomNavList: [
  ],
};

export default SIDEBAR_DATA;
