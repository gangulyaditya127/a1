import Container from "@/components/ui/container";
import MIMHomeHeader from "../features/MIMHomeHeader";
import MIMDashboard from "../features/MIMDashboard";

export default function MIMCommunicationHome() {
    return (
        <Container className="grid gap-8 my-6 mb-12">
            <MIMHomeHeader />
            <MIMDashboard />
        </Container>
    )
}