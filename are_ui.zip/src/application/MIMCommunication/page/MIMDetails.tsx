import Container from "@/components/ui/container";
import { useParams } from "react-router-dom";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import MIMDetailForm from "../features/MIMDetailForm";
import MIMUpdates from "../features/MIMUpdates";

export default function MIMDetails() {
    const { ticketNumber } = useParams()
    return (
        <Container className="h-[calc(100vh-58px)]">
            <ResizablePanelGroup
                direction="horizontal"
                className=""
            >
                <ResizablePanel defaultSize={75} maxSize={80}>
                    {ticketNumber && <MIMDetailForm ticketNumber={ticketNumber} />}
                </ResizablePanel>
                <ResizableHandle withHandle />
                <ResizablePanel defaultSize={25} maxSize={30}>
                    {ticketNumber && <MIMUpdates ticketNumber={ticketNumber} />}
                </ResizablePanel>
            </ResizablePanelGroup>
        </Container>
    )
}