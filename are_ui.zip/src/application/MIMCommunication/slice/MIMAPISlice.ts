import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export type MIMDeatilsResponse = MIMDeatils[]

export type MIMDeatils = {
    id: string
    ticket_type: string
    createdAt: string
    updateAsOf: string
    priority_or_severity: string
    status: string
    title: string
    causing_application: string
    impacted_applications: string[]
    meeting_id: string
    passcode: string
    skype_link: string
    current_update: string
    action_plan: string
    incident_description: string
    business_impact: string
    feed_delay_impact: string
    root_cause: string
    workaround: string
    permanent_fix_avoidance: string
    ref_ticket: string
    additional_details: string
    resolvedmail_sent_flag: string
    converted_ticket_number: string
    app_id: string
    cob: string
    any_extregsubmission_delayed: string
    any_regreport_copiedover: string
    any_regreport_delayed: string
    incident_type: string
    root_cause_category: string
    root_cause_subcategory: string
    data_flow: string
    account: string
    project: string
}

export type MIMUpdateList = MIMUpdate[]

export interface MIMUpdate {
    created: string
    comment: string
    updated_by: string
}


type MIMParams = {
    account: string,
    project: string
}

type MIMDetailParams = {
    ticketNumber: string
}

type UpdateMIMParams = {
    ticketNumber: string,
    empid: string,
    comment: string
}

export const mimAPISlice = createApi({
    reducerPath: 'mimAPISlice',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/imim/` }),
    tagTypes: ['mim_data_ticket'],
    endpoints: ({ query, mutation }) => ({
        getMIMList: query<any, MIMParams>({
            query: (queryParams) => ({ url: `getTickets`, params: queryParams }),
        }),
        getMIMDetail: query<MIMDeatilsResponse, MIMDetailParams>({
            query: (queryParams) => ({ url: `getTicketDetails`, params: queryParams }),
        }),
        getTicketUpdates: query<MIMUpdateList, MIMDetailParams>({
            query: (queryParams) => ({ url: `getTicketUpdatesIMIM`, params: queryParams }),
            providesTags: ["mim_data_ticket"]
        }),
        updateMIM: mutation<any, UpdateMIMParams>({
            query: (queryParams) => ({ url: `updateTicketComment`, params: queryParams, method: "GET" }),
            invalidatesTags: ["mim_data_ticket"]
        }),
    }),
})

export const {
    useGetMIMListQuery,
    useGetMIMDetailQuery,
    useGetTicketUpdatesQuery,
    useUpdateMIMMutation
} = mimAPISlice