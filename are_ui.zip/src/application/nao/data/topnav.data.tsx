import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Onboarding New Application",
        route: "/nao",
        key: "1",
    },
    {
        content: "Administration",
        route: "/nao/home",
        key: "2",
    },
    
];