import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";
const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Home",
          icon: "home",
          route: "/nao/home",
        },
        // {
        //         key: "2",
        //         content: "DD Cube",
        //         icon: "box",
        //         route: "/nao/DD-Cube",
        // },
      ],
    },
  ],
  bottomNavList: [
    {
        key: "8",
        content: "Sign Out",
        icon: "log-out",
        route: "/logout",
      },
  ],
};

export default SIDEBAR_DATA;