import {useState } from "react";

type Account={
    label:string;
    value:string;
}
// const USER_LIST: Account[]=[
//     {label:'Add New Account',value:'addNew'}
// ];
const AccountSection =()=>{
    const[accounts,setAccounts]=useState<Account[]>([
        { label: "CITI", value: 'CITI' },
        { label: "MetLife", value: 'MetLife' },
    ]); //Start with account list
    const [selectedAccount,setSelectedAccount]=useState<string>('');
    const[isAddingAccount,setIsAddingAccount]=useState<boolean>(false); // Add new account visibility
    const [newAccountName,setNewAccountName]=useState<string>('');
    const handleAccountChange =(event: React.ChangeEvent<HTMLSelectElement>)=>{
        setSelectedAccount(event.target.value);
    };
    const toggleAddNewAccount=()=>
        {
        setIsAddingAccount(true);
    };
    const handleAddAccount=()=>{
        if(newAccountName){
            const newAccount={ label:newAccountName, value:newAccountName};
            setAccounts([...accounts,newAccount]);
            setSelectedAccount(newAccountName);
            setIsAddingAccount(false);
            setNewAccountName('');
        }
            else{
                alert("Please Enter A Valid Account Name");
            }
        };
        const handleCancelAddAccount=()=>{
            setIsAddingAccount(false);
            setNewAccountName('');
        };
    return(
        <div className="mt-5 ml-16 border-2 border-black-800 p-3 rounded-md w-1/2">
            <h2 className="text-lg font-bold mb-6 text-muted-foreground uppercase ml-3">Account Details</h2>
            <div className="flex items-center gap-4 mb-4">
                <label htmlFor="accountSelect" className="font-normal ml-3">Account Name</label>
            <select id="accountSelect" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" value={selectedAccount} onChange={handleAccountChange}>
                <option value="" disabled hidden>Select Account Name</option>
            {accounts.map((account)=>(
                <option key={account.value} value={account.value} className="text-gray-200">
                    {account.label}
                    </option>))}
            </select>
            <button className="p-2 py-1 px-1 text-sm bg-blue-300 text-white rounded-md dark:bg-blue-600 ml-3" onClick={toggleAddNewAccount}>
                Add New Account
            </button></div>
            {/* Add New Account Section */}
            {isAddingAccount && (
                <div className="border-2 border p-4 rounded-md dark:border-gray-700 dark:bg-gray-900 mb-6 w-3/4 ml-4">
                    <h3 className="text-muted-foreground uppercase"> Add New Account</h3>
                    <div className="flex items-center gap-4 mb-4">
                        <label htmlFor="newAccountName" className="font-semibold mt-2">Account Name:</label>
                    <input type="text" value={newAccountName} onChange={(e)=>setNewAccountName(e.target.value)} placeholder="Enter New Account Name" className="py-1 px-2 mt-2 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none"/>
                    </div>
                    <div className="flex space-x-6"><button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none" onClick={handleAddAccount}>Save Account</button>
                <button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none " onClick={handleCancelAddAccount}>Cancel</button>
                </div></div>
                )}
                </div>
            );
        };
        export default AccountSection;
