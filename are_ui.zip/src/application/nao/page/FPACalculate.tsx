import React, { useEffect }  from "react";
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
// import { TOP_NAV_LIST } from "../data/topnav.data";
// import { TopNavItem } from "@/components/layout/slice/topbar-navigation";
import { Meteors } from "@/components/ui/meteors";
import { cn } from "@/lib/tailwind.utils";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useLocation} from 'react-router-dom';
// import { Download, FileWarningIcon, Loader } from "lucide-react";
// import PageLoader from "@/components/ui/loader"; 
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useGetFPADetailsMutation } from "../slice/MasterAndTransactDataAPISlice";
// import { CardItem } from "@/components/ui/3d-card";
// import { Icon } from "@/components/ui/icon";
// import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

import { useAppSelector } from "@/lib/redux/hooks";
import Administration from "./Administration";
import styles from "../style/onboard.module.css";

const FPACalculate: React.FC = () => {

const colors = ['#83d5f7', '#06435c', '#d47f17','#1d7eab','#03fcf8'];
const location = useLocation()
//console.log("state----",location.state) 
const { data }=location.state||{};

const [triggerFPADetails, dataMaster] = useGetFPADetailsMutation();
// const [triggerFPADataSave] =useSaveFPADetailsWithLookupDataMutation();

// const [calculateFPALoder, setCalculateFPALoder] = useState(false);
const [complexityData, setComplexityData] = useState(data.data.fpaLandscapeData.complexity);


//const complexityData = data.data.fpaLandscapeData.complexity;






const roleDetails = useAppSelector((state) => state.auth.roleDetails)
const [roleName, setRoleName] = useState<string>(''); 

useEffect(() => {
  
  const filterRoleDetail = roleDetails.filter(
    (roleDetails: any) => (location.state.selectedAccount === roleDetails["accountName"]));
setRoleName(filterRoleDetail[0]["roleName"])
 console.log("complexityData---",)


}, []);

const complexitykeys= new Set() as Set<any>;

for(let i=0;i<data.data.fpaLandscapeData.complexity.length;i++){
  Object.keys(data.data.fpaLandscapeData.complexity[i]).forEach((key:String)=>{
    if(key!="name" && key != 'gap'){
      complexitykeys.add(key)
    }
  })
}

const [criticalityData, setCriticalityData] = useState(data.data.fpaLandscapeData.criticality);
//const criticalityData = data.data.fpaLandscapeData.criticality;
const criticalitykeys= new Set() as Set<any>;
for(let i=0;i<data.data.fpaLandscapeData.criticality.length;i++){
  Object.keys(data.data.fpaLandscapeData.criticality[i]).forEach((key:String)=>{
    if(key!="name" && key != 'gap'){
      criticalitykeys.add(key)
    }
  })
}

const [technologyData, setTechnologyData] = useState(data.data.fpaLandscapeData.technology);
//const technologyData = data.data.fpaLandscapeData.technology;
const technologykeys= new Set() as Set<any>;
for(let i=0;i<data.data.fpaLandscapeData.technology.length;i++){
  Object.keys(data.data.fpaLandscapeData.technology[i]).forEach((key:String)=>{
    if(key!="name" && key != 'gap'){
      technologykeys.add(key)
    }
  })
}


const [stabilityData, setStabilityData] = useState(data.data.fpaLandscapeData.stability);
//const stabilityData = data.data.fpaLandscapeData.stability;

const stabilitykeys= new Set() as Set<any>;
for(let i=0;i<data.data.fpaLandscapeData.stability.length;i++){
  Object.keys(data.data.fpaLandscapeData.stability[i]).forEach((key:String)=>{
    if(key!="name" && key != 'gap'){
      stabilitykeys.add(key)
    }
  })
}




const [L1L2Weightage,setL1L2Weightage] =useState({
                                                  title: "L1 L2 Weightage",
                                                  jsonKey:"L1_L2_Weightage",
                                                  data: data.data.L1_L2_Weightage
                                                  })
  const [masterData, setMasterData] = useState([
    {
      title: "Alert Score",
      jsonKey:"Alert_Score",
      data: data.data.Alert_Score
    },
    {
      title: "Average Unit Effort",
      jsonKey:"Average_Unit_Effort",
      data: data.data.Average_Unit_Effort
    },
    {
      title: "Change Score",
      jsonKey:"Change_Score",
      data: data.data.Change_Score
    },
    {
      title: "Complexity",
      jsonKey:"Complexity",
      data: data.data.Complexity
    },
    {
      title: "Consumption",
      jsonKey:"Consumption",
      data: data.data.Consumption
    },
    {
      title: "Coverage Weightage",
      jsonKey:"Coverage_Weightage",
      data: data.data.Coverage_Weightage
    },
    {
      title: "Criticality",
      jsonKey:"Criticality",
      data: data.data.Criticality
    },
    {
      title: "Function Point",
      jsonKey:"Func_Point",
      data: data.data.Func_Point
    },
    {
      title: "If db",
      jsonKey:"Ifdb",
      data: data.data.Ifdb
    },
    {
      title: "Interfaces",
      jsonKey:"Interfaces",
      data: data.data.Interfaces
    },    
    {
      title: "Language",
      jsonKey:"Language",
      data: data.data.Language
    },
    {
      title: "Major Inc Score",
      jsonKey:"Major_Inc_Score",
      data: data.data.Major_Inc_Score
    },
    {
      title: "Problem Score",
      jsonKey:"Problem_Score",
      data: data.data.Problem_Score
    },
    {
      title: "Screens",
      jsonKey:"Screens",
      data: data.data.Screens
    },
    {
      title: "Stability",
      jsonKey:"Stability",
      data: data.data.Stability
    },
    {
      title: "Std Batch Score",
      jsonKey:"Std_Batch_Score",
      data: data.data.Std_Batch_Score
    },
    {
      title: "Std Inc Score",
      jsonKey:"Std_Inc_Score",
      data: data.data.Std_Inc_Score
    },
    {
      title: "User Query Score",
      jsonKey:"User_Query_Score",
      data: data.data.User_Query_Score
    }
  ]);

  
  const [selectedTab, setSelectedTab] = useState("FPAOutputData");
  const [appData, setAppData] = useState(data.data.FPAAppData);
  const [portFolioData, setPortFolioData] = useState(data.data.fpaPortFolioData);

// const [triggerGetFPADetails, fpaDetails] = useLazyGetFPADetailsDataQuery()

// const [fpaCalculateLoder, setFpaCalculateLoder] = useState(false);
// const navigate = useNavigate();

//   const [editRowIndex, setEditRowIndex] = useState(null);
//   const [editedData, setEditedData]=useState([...appData]);
  
//   const handleEditClick = (index: any) => {
  
//     setEditRowIndex(index)
//   }

  // const fpaCalculate = () => {
  //   console.log("state--fpaCalculate call--",location.state) 
  //  // setFpaCalculateLoder(true)
  //  // triggerGetFPADetails({ accountName: location.state.selectedAccount, setNo: location.state.selectedSet })
   
  // }
  // useEffect(() => {
  //   fpaCalculate()

  // }, []);

  // useEffect(() => {


  //   if (fpaDetails.status == 'fulfilled') {
  //     setFpaCalculateLoder(false)
    // set all the value for declared variable for all tabs
  //   }

  // }, [fpaDetails]);


  const [editingTable, setEditingTable] = useState<{
    tableIndex:number;
    rowIndex:number;
  }|null>(null);

  const [editL1L2WeightageRowIndex, setEditL1L2WeightageRowIndex] = useState(null);

  const handleEditL1L2WeightageClick = (index: any) => {

    setEditL1L2WeightageRowIndex(index)
  }

  // const handleSaveL1L2WeightageClick = () => {
   
  //   setEditL1L2WeightageRowIndex(null)
  //   calculateFPA()
   
  // }

  const handleEditL1L2WeightageChange = (rowIndex: any, field: any, value: any) => {

    let updatedData: any = {}
    updatedData = { ...L1L2Weightage };
    const updateValue = updatedData.data.map((rawData: any, index2: any) =>
      rowIndex === index2 ? { ...rawData, [field]: value } : rawData)

    const masterJson = { ...updatedData, ["data"]: updateValue }
    setL1L2Weightage(masterJson)

  }

  const handleKeyDown=(event:any) => {
    
    if(event.key ==="Enter"){
      setEditL1L2WeightageRowIndex(null)
      calculateFPA()
    }
  }
 

  // Function to toggle Edit/Save mode
  const toggleEdit = (tableIndex: number, rowIndex: number) => {
    
    if (editingTable?.tableIndex === tableIndex && editingTable?.rowIndex === rowIndex) {
      setEditingTable(null); // Save and exit edit mode
      calculateFPA()
    } else {
      setEditingTable({ tableIndex, rowIndex }); // Enter edit mode
    }
  };


  // State for Master Output Data
  

  // Handle input changes in editable tables
  const handleInputChange = (tableIndex: number, rowIndex: number, value: any) => {
    let masterJson = masterData[tableIndex]
    let updatedData = [...masterData]
    const updateValue = masterJson.data.map((rawData: any, index2: any) =>
      rowIndex === index2 ? { ...rawData, ["score"]: value } : rawData)

    masterJson = { ...masterJson, ["data"]: updateValue }
    updatedData[tableIndex] = masterJson
    setMasterData(updatedData);
  };

  const toggleEditWithEnter = (event:any,tableIndex: number, rowIndex: number) => {
    if(event.key ==="Enter"){
    if (editingTable?.tableIndex === tableIndex && editingTable?.rowIndex === rowIndex) {
      setEditingTable(null); // Save and exit edit mode
      calculateFPA()
      // call calculate FPA api
    } else {
      setEditingTable({ tableIndex, rowIndex }); // Enter edit mode
    }
  }
  };

 

  

  //const [outputData, setOutputData] = useState([masterData]);
  // Handle validation: Simulate output data update
  const calculateFPA = () => {
    // setCalculateFPALoder(true)
    console.log(location.state.selectedAccount);
    console.log(location.state.selectedSet);
    console.log("masterData-----",masterData);

    let updatedData=[]
     updatedData = [...masterData,...[L1L2Weightage]];

    let payload={
      accountName:location.state.selectedAccount,
      setNo:location.state.selectedSet,
     // masterData:masterData
       masterData: updatedData

    }
   // console.log(updatedData)
   // console.log("payload----",payload)
    triggerFPADetails(payload)
    //saveLookupFPAData(payload)
    
    
  };

  useEffect(()=>{
    
    if(dataMaster.status=='fulfilled'){
      // setCalculateFPALoder(false)
      setSelectedTab("FPAOutputData")
     //console.log( dataMaster.data.FPAAppData)
     setAppData(dataMaster.data.FPAAppData)
     setPortFolioData(dataMaster.data.fpaPortFolioData)

     setComplexityData(dataMaster.data.fpaLandscapeData.complexity);
     setCriticalityData(dataMaster.data.fpaLandscapeData.criticality)
     setTechnologyData(dataMaster.data.fpaLandscapeData.technology)
     setStabilityData(dataMaster.data.fpaLandscapeData.stability)

     for(let i=0;i<data.data.fpaLandscapeData.complexity.length;i++){
      Object.keys(data.data.fpaLandscapeData.complexity[i]).forEach((key:String)=>{
        if(key!="name" && key != 'gap'){
          complexitykeys.add(key)
        }
      })
    }

    for(let i=0;i<data.data.fpaLandscapeData.criticality.length;i++){
      Object.keys(data.data.fpaLandscapeData.criticality[i]).forEach((key:String)=>{
        if(key!="name" && key != 'gap'){
          criticalitykeys.add(key)
        }
      })
    }
     
     for(let i=0;i<data.data.fpaLandscapeData.technology.length;i++){
      Object.keys(data.data.fpaLandscapeData.technology[i]).forEach((key:String)=>{
        if(key!="name" && key != 'gap'){
          technologykeys.add(key)
        }
      })
    }

    for(let i=0;i<data.data.fpaLandscapeData.stability.length;i++){
      Object.keys(data.data.fpaLandscapeData.stability[i]).forEach((key:String)=>{
        if(key!="name" && key != 'gap'){
          stabilitykeys.add(key)
        }
      })
    }
    
    }
  
  },[dataMaster]);

  // const FPASave = () => {

  //   let updatedLookupData=[]
  //    updatedLookupData = [...masterData,...[L1L2Weightage]];
  //   console.log("updatedLookupData---",updatedLookupData)
  //   console.log("appData---",appData);

  //   let payload={
  //     accountName:location.state.selectedAccount,
  //     setNo:location.state.selectedSet,
  //     fpaAppData:appData,
  //     masterData:updatedLookupData
  //   }
  //  // triggerFPADataSave, fpaDataList

  //  triggerFPADataSave(payload)
  // //triggerFPADetails(payload)
  // }


  const handleSaveL1L2WeightageClick = (_row:any, _rowIndex:any) => {
   
    setEditL1L2WeightageRowIndex(null)
    calculateFPA()
   
  }

  return (
    <>
    <div className="mt-4 ml-2">
<NavigateBackButton />
    <Meteors number={6} />
    <Tabs className="m-2" defaultValue="dashboard" >
            <TabsList className="flex-x-4" >
              <TabsTrigger value="dashboard" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
             Dashboard
              </TabsTrigger>
              {(roleName == "SuperAdmin" || roleName == "AREAdmin") && (<TabsTrigger value="administration" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
          Administration
          </TabsTrigger>)}
            </TabsList>
    
            {/* Master Data Tab */}
            <TabsContent value="dashboard">
            <div className="mt-4 ml-4">
       {/* <Dialog open="true" >
      
      <DialogContent className="sm:max-w-[425px] rounded-2xl">
      <Icon name="loader-circle" className="animate-spin h-64 w-64" />
       
        
      </DialogContent>
    </Dialog> */}
    
    {/* <div style={{ position: "absolute",marginLeft: "35%",marginTop: "20%"}}>
          <Icon name="loader-circle" className="animate-spin h-64 w-64" />
      </div> */}
      
    <div className="mt-6 ml-6 p-4">
      {/* <h1 className="text-2xl font-bold mb-6">FPA CALCULATION</h1> */}

      {/* Tabs for Master Data and Master Output Data */}
      <Tabs  value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="flex-x-4">
        {(roleName == "SuperAdmin" || roleName == "AREAdmin") && (
          <TabsTrigger value="BinData" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
            BIN Data
          </TabsTrigger>)}
          <TabsTrigger value="FPAOutputData" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
            FPA Output
          </TabsTrigger>
        </TabsList>

        {/* Master Data Tab */}
        <TabsContent value="BinData">
          <div className="flex flex-wrap gap-10 mt-4 ">
            {masterData.map((table, tableIndex) => (
              <div key={table.title} className="border border gray-200">
                <h2 className="text-lg font-bold mb-2 mt-2 text-center">{table.title}</h2>
                <Table className="border border gray-200">
                  {table.title != "Average Unit Effort" ?
                  (<TableHeader className="bg-violet-400">
                    <TableRow>
                      <TableHead className="text-black dark:text-white">Bin</TableHead>
                      <TableHead className="text-black dark:text-white">Score</TableHead>
                      <TableHead className="text-black dark:text-white">Action</TableHead>
                    </TableRow >
                  </TableHeader>) :(<TableRow></TableRow>)
                  }
                  <TableBody>
            {table.data.map((row:any, rowIndex:any) => (
              <TableRow key={rowIndex}  className= {cn(
                "group/team-row border-0",
                rowIndex % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
              )}>
                <TableCell className="">{row.bin}</TableCell>
                <TableCell className="">
                  {editingTable?.tableIndex === tableIndex && editingTable?.rowIndex === rowIndex ? (
                    <input
                      type="text"
                     
                      value={row.score}
                      onChange={(e) => handleInputChange(tableIndex, rowIndex,  e.target.value)}
                      onKeyDown={(e) => toggleEditWithEnter(e, tableIndex, rowIndex)}
                      className="p-1 w-16 text-black border rounded"
                    />
                  ) : (
                    
                    row.score
                  )}
                </TableCell>
                <TableCell>
                  <button
                    onClick={() => toggleEdit(tableIndex, rowIndex)}
                    className="px-2 py-1 rounded bg-blue-500 text-white hover:bg-blue-600"
                  >
                    {editingTable?.tableIndex === tableIndex && editingTable?.rowIndex === rowIndex
                      ? "Save"
                      : "Edit"}
                  </button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>


                </Table>
              </div>
            ))}
            <div key={L1L2Weightage.title} className="border border gray-200">
                <h2 className="text-lg font-bold mb-2 mt-2 text-center">{L1L2Weightage.title}</h2>
                <Table className="border border gray-200">
                  <TableHeader className="bg-violet-400">
                    <TableRow>
                      <TableHead className="text-black dark:text-white">Bin</TableHead>
                      <TableHead className="text-black dark:text-white">L1</TableHead>
                      <TableHead className="text-black dark:text-white">L2</TableHead>
                      <TableHead className="text-black dark:text-white">Action</TableHead>
                    </TableRow >
                  </TableHeader>
                  <TableBody>
                  {L1L2Weightage.data.map((row:any, rowIndex:any) => (
                    <TableRow key={rowIndex}  className= {cn("group/team-row border-0",rowIndex % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                    )}>
                       <TableCell className="">{row.bin}</TableCell> 
                       <TableCell className="">{editL1L2WeightageRowIndex === rowIndex ? (<input className="text-gray-600" type="text" value={row.l1} onChange={(e) => handleEditL1L2WeightageChange(rowIndex, "l1", e.target.value)} onKeyDown={handleKeyDown} />) : (row.l1)}</TableCell> 
                       <TableCell className="">{editL1L2WeightageRowIndex === rowIndex ? (<input className="text-gray-600" type="text" value={row.l2} onChange={(e) => handleEditL1L2WeightageChange(rowIndex, "l2", e.target.value)} onKeyDown={handleKeyDown} />) : (row.l2)}</TableCell> 
                       <TableCell className={`place-items-center  text-center `}  >{editL1L2WeightageRowIndex === rowIndex ? (<button className="px-2 py-1 rounded bg-blue-500 text-white hover:bg-blue-600" onClick={() => handleSaveL1L2WeightageClick(row, rowIndex)}>Save</button>) : <button className="px-2 py-1 rounded bg-blue-500 text-white hover:bg-blue-600" onClick={() => handleEditL1L2WeightageClick(rowIndex)}>Edit</button>}</TableCell>
                    </TableRow>
                  ))}
                  </TableBody>
                </Table>
            </div>
          </div>
          
         
          {/* <div className="mt-5 text-center">
          <Button
              onClick={calculateFPA}
              className="rounded-lg text-black bg-green-500 hover:bg-green-700 text-center border border-gray-200 px-6 py-2 mt-4"
            >
            
              Calculate FPA   {calculateFPALoder && <Loader className="animate-spin" />}
            </Button>
          </div> */}

        </TabsContent>

        {/* Master Output Data Tab */}
        <TabsContent value="FPAOutputData">
          <Tabs defaultValue="Portfolio">
            <TabsList className="grid max-w-64  grid-cols-3 rounded-2xl dark:bg-violet-900/10">
          
              <TabsTrigger value="AppData" className="rounded-3xl tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
                App Data
              </TabsTrigger>
              <TabsTrigger value="Landscape" className="rounded-3xl tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
                Landscape
              </TabsTrigger>
              <TabsTrigger value="Portfolio" className="rounded-2xl tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
                Portfolio
              </TabsTrigger>
            </TabsList>

            {/* Portfolio Tab */}
            <TabsContent value="Portfolio">
                <h2 className="text-lg dark:text-white font-bold mb-4  text-center ">PORTFOLIO TABLE</h2>
                <div className={`overflow-x-scroll overflow-y-scroll h-[280px] ${styles['scrollbar-custom']}`} >
                <Table className="w-full border border gray-200"> 
                  <TableHeader className="bg-violet-400">
                    <TableRow className="font-bold text-center">
                      <TableHead colSpan={2} className="text-center border-2 text-black dark:text-white">
                        {/* {appData[0].region} */}SMNYL
                      </TableHead>
                      <TableHead colSpan={7} className="text-center border-2 text-black dark:text-white">
                        Work in Flow
                      </TableHead>
                      <TableHead colSpan={6} className="text-center border-2 text-black dark:text-white">
                        Estimate by Service
                      </TableHead>
                      <TableHead colSpan={6} className="text-center border-2 text-black dark:text-white">
                        Inscope Estimate
                      </TableHead>
                      
                    </TableRow>
                    </TableHeader>
                    <TableHeader className="sticky top-0 bg-violet-400">
          <TableHead className="min-w-[155px] place-items-center  text-center border-2 text-black dark:text-white">Portfolio</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Apps</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Major Inc</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Batch Inc</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">User Inc</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Problem Req</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Change Req</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Service Req</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Adhoc Req</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Incident Mgmt</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Problem Mgmt</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white ">Change Mgmt</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Request Mgmt</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">CSI</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Operation Mgmt</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">L1</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">L2</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Total</TableHead>
          </TableHeader>     
     <TableBody>
        {portFolioData.map((row:any, index:any) => (
          
          <TableRow key={index} className={cn(
                              "group/team-row border-0",
                              index % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                            )}>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.portfolio}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.application}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.majorIncident}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.batchIncident}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.userIncident}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.problemRecord}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.changeRequest}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.serviceRequest}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.adhocRequest}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.incidentManagement}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.problemManagement}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.changeManagement}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.requestManagement}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.csi}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.operationManagement}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.l1}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.l2}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.total}</TableCell>
          </TableRow>
          ))}
          </TableBody>
    </Table>
    </div>
            
            </TabsContent>
           




            {/* App Data Tab */}
            <TabsContent value="AppData">
                <h2 className="text-lg dark:text-white font-bold mb-4  text-center">APP DATA TABLE</h2>
                <div className={`overflow-x-scroll overflow-y-scroll h-[380px] ${styles['scrollbar-custom']}`} >
                <Table className=" border border gray-200"> 
                  <TableHeader className="bg-violet-400">
                    <TableRow className="font-bold text-center">
                      <TableHead colSpan={19} className="text-center border-2 text-black dark:text-white">
                      Master Data
                      </TableHead>
                      <TableHead colSpan={10} className="text-center border-2 text-black dark:text-white">
                      Transaction Data (Monthly Average)
                      </TableHead>
                      <TableHead colSpan={24} className="text-center border-2 text-black dark:text-white">
                      Calculated Factors
                      </TableHead>
                      <TableHead colSpan={10} className="text-center border-2 text-black dark:text-white">
                      Calculated Capacity
                      </TableHead>
                      
                    </TableRow>
                    </TableHeader>
                    <TableHeader className="sticky top-0 bg-violet-400">
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Region</TableHead>
          <TableHead className="min-w-[155px] place-items-center  text-center border-2 text-black dark:text-white">Portfolio</TableHead>
          <TableHead className="min-w-[186px] place-items-center  text-center border-2 text-black dark:text-white">App ID</TableHead>
          <TableHead className="min-w-[186px] place-items-center  text-center border-2 text-black dark:text-white">App Name</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Interfaces</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Internal Files</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Screens</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Batch Jobs</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Users</TableHead>
          <TableHead className="min-w-[86px] place-items-center  text-center border-2 text-black dark:text-white">Language</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Criticality</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white ">Coverage</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Stability</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">CSI ID</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">New Service</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">App Status</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Selected Region</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Status Selected</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Portfolio Selected</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Major Incidents</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Batch Incidents</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">User Incidents</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">User Queries</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Problem Tickets</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Change Requests</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Service Requests</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Adhoc Requests</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Alerts</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Tot Tkts</TableHead>

          {/* <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Service Requests</TableHead> */}
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Func Point</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Complexity</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Comp Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Lang Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Stability Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Coverage Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Criticality Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Cons Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Support Factor</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">MIScore</TableHead>          
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">BatchIncScore</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">StdIncScore</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">AlertScore</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">UQScore</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Prob Score</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Change Score</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">MI_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Batch_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">StdINC_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Alert_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">UQ_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Prb_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Chg_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">SREQ_AU</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">IMF</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">PMF</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">CMF</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">SR</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">OPS</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">CSI</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">L1</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">L2</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">FTE Total</TableHead>
          <TableHead className="place-items-center  text-center border-2 text-black dark:text-white">Action</TableHead>
          
          </TableHeader>     
     <TableBody>
        {appData.map((row:any, index:any) => (
          
          <TableRow key={index} className={cn(
                              "group/team-row border-0",
                              index % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                            )}>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.region}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.portfolio}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.appId}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.appName}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.interfaces}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.internalFiles}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.screens}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.batchJobs}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.users}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.language}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.criticality}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.coverage}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.stability}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.csiId}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.newService}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.appStatus}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.selectedRegion}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.statusSelected}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.portfolioSelected}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.majorIncidents}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.batchIncidents}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.userIncidents}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.userQueries}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.problemTickets).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.changeRequests).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.serviceRequests}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.adhocRequests}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.alerts}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.totalTickets).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.functionPoint}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.complexity}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.complexityFactor}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.languageFactor}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.stabilityFactor}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.coverageFactor}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.criticalityFactor}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.consFactor).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.supportFactor).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.miScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.batchIncScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.stdIncScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.alertScore}</TableCell>            
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.uqScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.probScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.changeScore}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.mi_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.batch_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.stdINC_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.alert_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.uq_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.prb_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.chg_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.sreq_AU}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.imf).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.pmf).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.cmf).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.sr).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.ops).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.csi).toFixed(2)}</TableCell>           
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.l1).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.l2).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{parseFloat(row.ftetotal).toFixed(2)}</TableCell>
            <TableCell className="place-items-center  text-center text-black dark:text-white">{row.show}</TableCell>
          </TableRow>
          ))}
          </TableBody>
    </Table>
    </div>
            </TabsContent>




            {/* Landscape Tab */}
            <TabsContent value="Landscape">

                <h2 className="text-lg dark:text-white font-bold mb-4  text-center">LANDSCAPE</h2>
                
                <div className="flex flex-wrap gap-10 mt-4 h-[300px]">
                
                <ResponsiveContainer width="48%" height="75%">
                 <>
                  <p className="text-center">Criticality</p>
                <BarChart
                  width={500}
                  height={250}
                  data={complexityData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout='vertical'
                    >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type='number' />
                  <YAxis type='category' dataKey='name' />
                  <Legend />
                  <Tooltip />
                  <>
                  {Array.from(complexitykeys).map((key: string, index: number): any => {
                    const bars = [];
                    bars.push(<Bar dataKey={key} stackId="a" fill={colors[index]} />);
                    /* Add a bar just for the gap after each bar */
                    // bars.push(<Bar dataKey='gap' stackId="a" fill='transparent' />);
                    return bars;
                  })}
                  </>
               
                </BarChart>
                
          </>
               
                </ResponsiveContainer>
               

                <ResponsiveContainer width="48%" height="75%">
                 <>
                  <p className="text-center">Complexity</p>
                <BarChart
                  width={500}
                  height={250}
                  data={criticalityData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout='vertical'
                    >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type='number' />
                  <YAxis type='category' dataKey='name' />
                  <Legend />
                  <Tooltip />
                  <>
                  {Array.from(criticalitykeys).map((key: string, index: number): any => {
                    const bars = [];
                    bars.push(<Bar dataKey={key} stackId="a" fill={colors[index]} />);
                    /* Add a bar just for the gap after each bar */
                    // bars.push(<Bar dataKey='gap' stackId="a" fill='transparent' />);
                    return bars;
                  })}
                  </>
               
                </BarChart>
                
          </>
               
                </ResponsiveContainer>


                <ResponsiveContainer width="48%" height="75%" >
               <>
                <p className="text-center">Stability</p>
                <BarChart
                  width={500}
                  height={250}
                  data={stabilityData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout='vertical'
                    >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type='number' />
                  <YAxis type='category' dataKey='name' />
                  <Legend />
                  <Tooltip />
                  <>
                  {Array.from(stabilitykeys).map((key: string, index: number): any => {
                    const bars = [];
                    bars.push(<Bar dataKey={key} stackId="a" fill={colors[index]} />);
                    /* Add a bar just for the gap after each bar */
                    // bars.push(<Bar dataKey='gap' stackId="a" fill='transparent' />);
                    return bars;
                  })}
                  </>
                </BarChart>
                </>
                </ResponsiveContainer>

                <ResponsiveContainer width="48%" height="75%">
                  <>
                <p className="text-center">Technology</p>
                <BarChart
                  width={500}
                  height={250}
                  data={technologyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout='vertical'
                    >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type='number' />
                  <YAxis type='category' dataKey='name' />
                  <Legend />
                  <Tooltip />
                  <>
                  {Array.from(technologykeys).map((key: string, index: number): any => {
                    const bars = [];
                    bars.push(<Bar dataKey={key} stackId="a" fill={colors[index]} />);
                    /* Add a bar just for the gap after each bar */
                    // bars.push(<Bar dataKey='gap' stackId="a" fill='transparent' />);
                    return bars;
                  })}
                  </>
                </BarChart>
                </>
                
                </ResponsiveContainer>
              </div>
            
          
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
      {/* <div className="mt-6 ml-1">
      <button onClick={FPASave} className=" p-1.5 w-4/4 -ml-1.5  rounded-lg text-white bg-blue-400 hover:bg-blue-600 ml-3">FPA Save</button>
      </div> */}
      
    </div>
    </div>
            </TabsContent>
            <TabsContent value="administration">
              
                      <Administration selectedAccountName= {location.state.selectedAccount} />
            </TabsContent>
      </Tabs>
      </div>
      </>
  );
};

export default FPACalculate;

