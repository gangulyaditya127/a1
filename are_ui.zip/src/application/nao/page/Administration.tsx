import React, { useEffect, useState }  from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {  useLazyGetFPAUserDetailsByAccountQuery, useLazyGetRoleDetailsByStatusQuery, useUpdateUserRoleMutation } from "../slice/FPAUserRoleAPISlice";
import { useToast } from "@/components/ui/use-toast";
import PageLoader from "@/components/ui/page-loader";
import { setUserActiveList,setUserPendingList } from "../slice/NAOSlice";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";


// type UserRequest = {
//     userId: string;
//     accountName: string;
//     roleName: string;
//     status: string;
//     tabType:"pendingApproval"|"userDetails";
//   };
  
  const Administration = ({selectedAccountName}:any) => {

    const dispatch = useAppDispatch();
  const userPendingList = useAppSelector((state) => state.nao.userPendingList);
  const userActiveList = useAppSelector((state) => state.nao.userActiveList);

    // const [userPendingList, setUserPendingList] = useState<any>([]);
    // const [userActiveList, setUserActiveList] = useState<any>([]);
    
    const [triggerGetFPAUserDetails, fpaUserAccountDetails] = useLazyGetFPAUserDetailsByAccountQuery();
    const [triggerfpaActiveRoleDetails, fpaActiveRoleDetails] = useLazyGetRoleDetailsByStatusQuery();
    const [triggerUpdateUserRole, updateUserRoleStatus] = useUpdateUserRoleMutation();
    const [fpaUserDetails,setfpaUserDetails]=useState(false);
    const [fpaActiveDetails]=useState(false);
    

    useEffect(() => {
      console.log("selectedAccountName--5555---",selectedAccountName)
     if(selectedAccountName !=""){
      setfpaUserDetails(true);

      triggerGetFPAUserDetails({ accountName: selectedAccountName });
      
      triggerfpaActiveRoleDetails({})
      

     }
      
    }, [selectedAccountName]);

    useEffect(() => {
      if (fpaUserAccountDetails.status == 'fulfilled') { 
          
        console.log("fpaUserAccountDetails----",fpaUserAccountDetails)
        dispatch(setUserPendingList(fpaUserAccountDetails.data));
        setfpaUserDetails(false);

      }    
    }, [fpaUserAccountDetails]);

    useEffect(() => {
      if (fpaActiveRoleDetails.status == 'fulfilled') {        
        console.log("fpaUserAccountDetails----",fpaActiveRoleDetails)
       dispatch(setUserActiveList(fpaActiveRoleDetails.data));
      
      } 
    
    }, [fpaActiveRoleDetails]);


    // Sample data for the table
    // const [pendingApprovalData, setPendingApprovalData] = useState<UserRequest[]>(userPendingList);
  
    // const [userDetailsData, setUserDetailsData] = useState<UserRequest[]>(userActiveList);
  
    // Function to update the status when Accept or Reject is clicked
    // const handleAction = (userId: string, newStatus: string) => {
    //   setPendingApprovalData((prevData) =>
    //     prevData.map((item) =>
    //       item.userId === userId ? { ...item, status: newStatus } : item
    //     )
    //   );
    // };
  

    type Account={
      label:string;
      value:string;
    }
    type Role={
      label:string;
      value:string;
    }
    const[roles,setRoles]=useState<Role[]>([
      { label: "USER", value: 'USER' },
      { label: "ADMIN", value: 'ADMIN' },
      { label: "DELIVERY PARTNER", value: 'DELIVERY PARTNER' },
    ]);
    type TableDataItem={
     accountName: string;
     roleName: string;
    };
     const[accounts,setAccounts]=useState<Account[]>([
            { label: "CITI", value: 'CITI' },
            { label: "MetLife", value: 'MetLife' },
        ]); //Start with account list
        const [selectedAccount,setSelectedAccount]=useState<string>('');
        const [selectedRole,setSelectedRole]=useState<string>('');
        const[isAddingAccount,setIsAddingAccount]=useState<boolean>(false); // Add new account visibility
        const[isAddingRole,setIsAddingRole]=useState<boolean>(false);
        const [newAccountName,setNewAccountName]=useState<string>('');
        const [newRoleName,setNewRoleName]=useState<string>('');
        const handleAccountChange =(event: React.ChangeEvent<HTMLSelectElement>)=>{
            setSelectedAccount(event.target.value);
        };
    
        const toggleAddNewAccount=()=>
            {
            setIsAddingAccount(true);
        };
        const handleRoleChange =(event: React.ChangeEvent<HTMLSelectElement>)=>{
          setSelectedRole(event.target.value);
      };
      const toggleAddNewRole=()=>
          {
            setIsAddingRole(true);
      };
        const handleAddAccount=()=>{
            if(newAccountName){
                const newAccount={ label:newAccountName, value:newAccountName};
                setAccounts([...accounts,newAccount]);
                setSelectedAccount(newAccountName);
                setIsAddingAccount(false);
                setNewAccountName('');
            }
                else{
                    alert("Please Enter A Valid Account Name");
                }
            };
            const handleCancelAddAccount=()=>{
                setIsAddingAccount(false);
                setNewAccountName('');
            };
    
    
            const handleAddRole=()=>{
              if(newRoleName){
                  const newRole={ label:newRoleName, value:newRoleName};
                  setRoles([...roles,newRole]);
                  setSelectedAccount(newRoleName);
                  setIsAddingRole(false);
                  setNewRoleName('');
              }
                  else{
                      alert("Please Enter A Valid Account Name");
                  }
              };
              const handleCancelAddRole=()=>{
                setIsAddingRole(false);
                  setNewRoleName('');
              };
              const [tableDataList, setTableDataList] = useState<TableDataItem[]>([]);
              const handleAddToTable = () => {
                if (selectedAccount && selectedRole) {
                  setTableDataList([...tableDataList, { accountName: selectedAccount, roleName: selectedRole }]);
                  setSelectedAccount('');
                  setSelectedRole('');
                } else {
                  alert('Please select both an account and a role.');
                }
              };
            
              const handleDeleteRow = (index: number) => {
                const updatedTable = tableDataList.filter((_, i) => i !== index);
                setTableDataList(updatedTable);
              };

    // State for dialog box
   const [selectedUser, setSelectedUser] = useState([]);
   const [actionType, setActionType] = useState<string>("");
   const [pedingDialog, setPedingDialog] = useState(false);
  //  const [setActiveDialog] = useState(false);
   const { toast } = useToast();
  // Function to update the status when the user confirms action
  const pendingDialogOpen=(selectedUser:any,actionType:any)=>{
    setPedingDialog(true)
    console.log("selectedUser--",selectedUser)
    console.log("actionType--",actionType)
    setActionType(actionType)
    setSelectedUser({ ...selectedUser, status: actionType })
    
  }

  const handleConfirmAction = () => {
 
 console.log("selectedUser---handleConfirmAction----",selectedUser)
     
    triggerUpdateUserRole(selectedUser)
    
  };

  useEffect(() => {
    if (updateUserRoleStatus.status == 'fulfilled') { 
    
        
     console.log("updateUserRoleStatus----",updateUserRoleStatus)
      triggerGetFPAUserDetails({ accountName: selectedAccountName });
       
      triggerfpaActiveRoleDetails({});
      toast({
        title: 'Data Save successfully',
        description: ''
      })
      setPedingDialog(false)
    }    
  }, [updateUserRoleStatus]);

  const closeDialog=()=>{
    setPedingDialog(false)
    // setActiveDialog(false)
  }
  
  

            
    return(
      <div className="p-6">
        <Tabs defaultValue="userMgmt">
          <TabsList className="space-x-4 ">
            <TabsTrigger value="userMgmt" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">User Management</TabsTrigger>
            <TabsTrigger value="accountMgmt" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">Account Management</TabsTrigger>
          </TabsList>
  
          {/* USER MANAGEMENT */}
          <TabsContent value="userMgmt">
            <Tabs defaultValue="pendingApproval">
              <TabsList className="space-x-4 mt-4">
                <TabsTrigger value="pendingApproval"  className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">Pending Approval</TabsTrigger>
                <TabsTrigger value="userDetails" className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">User Details</TabsTrigger>
              </TabsList>

              <Dialog open={pedingDialog} >
          <DialogContent className="[&>button]:hidden " >
            <h2 className="text-lg font-bold">Confirm Action</h2>
            <p>Do you want to {actionType.toLowerCase()} this request?</p>
            <div className="flex justify-end space-x-4 mt-4">
              <Button className="bg-blue-400  text-white" onClick={() => closeDialog()}>
                Close
              </Button>
              <Button className="bg-blue-400 text-white" onClick={handleConfirmAction}>
                Submit Request
              </Button>
            </div>
          </DialogContent>
        </Dialog>
  
              {/* Pending Approval Table */}
              {(fpaUserDetails)&&<PageLoader/>}
              <TabsContent value="pendingApproval">
                
                <Table className="w-full mt-4 border">
                  <TableHeader className="bg-violet-400">
                    <TableRow>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">User ID</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Account Name</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Role Name</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Action</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userPendingList.length>0 != null && userPendingList.map((user) => (
                      <TableRow key={user.userId}>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.userId}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.accountName}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.roleName}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">
                        
                            <Button
                              className="bg-green-400 hover:bg-green-500 text-white mx-1"
                              onClick={() => {
                                pendingDialogOpen(user,'Active')

                              }}
                            >
                              Accept
                            </Button>
                         
                        
                            <Button
                              className="bg-red-400 hover:bg-red-500 text-white mx-1"
                              onClick={() => {
                                pendingDialogOpen(user,'InActive')

                              }}
                            >
                              Reject
                            </Button>
                          
                      </TableCell>

                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.status}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
                   {/* Dialog Box for Accept/Reject Confirmation */}
      




              {/* User Details Table */}
              {(fpaActiveDetails)&&<PageLoader/>}
              <TabsContent value="userDetails">
                <Table className="w-full mt-4 border">
                  <TableHeader className="bg-violet-400">
                    <TableRow>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">User ID</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Account Name</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Role Name</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Action</TableHead>
                      <TableHead className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userActiveList.length>0 && userActiveList.map((user) => (
                      <TableRow key={user.userId}>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.userId}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.accountName}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.roleName}</TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">
                       
                        <Button
                              className="bg-red-400 hover:bg-red-500 text-white mx-1"
                              onClick={() => {
                                pendingDialogOpen(user,'InActive')

                              }}
                            >
                              Reject
                            </Button>
                      </TableCell>
                        <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white">{user.status}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          </TabsContent>
          


          {/* ACCOUNT MANAGEMENT PLACEHOLDER */}
          <TabsContent value="accountMgmt">
            <h2 className="text-lg font-bold mt-4 ml-2">Account Management </h2>
            
            <Table className="w-3/4 border-gray-500 dark:border-gray-700 ml-2 mt-6">
                        <TableHeader className="bg-violet-400">
                            <TableRow>
                                <TableHead className="text-center border border-gray-800 dark:border-gray-300  text-black dark:text-white px-4 py-2">Account Name</TableHead>
                                <TableHead className=" text-center border border-gray-800 dark:border-gray-300  px-4  text-black dark:text-white  py-2">Role Name</TableHead>
                                
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tableDataList.length>0?(tableDataList.map((item,index)=>(
                            <TableRow key={index}>
                              <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white py-3" >{item.accountName}</TableCell>
                              <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-black dark:text-white py-3">{item.roleName}</TableCell>
                              
                              <TableCell> <button className="ml-4 px-4 py-1 rounded-lg bg-blue-700 rounded hover:bg-blue-500  text-white"  onClick={()=>handleDeleteRow(index)} > Delete</button></TableCell>
                               </TableRow>))):(
                               <TableRow>
                                <TableCell className="text-center border border-gray-800 dark:border-gray-300 text-gray-600 dark:text-gray-400 py-3" colSpan={4}>
                                No items in the queue
                                </TableCell>
                                </TableRow>
                              )}
                              
                        </TableBody>
                     </Table> 
                      <div className="mt-8 ml-2 border border-gray-800 dark:border-gray-300 p-3 rounded-md w-3/4">
                            {/* {/* <div style={roleSelectionStyle} className="flex items-center space-x-2 mt-4">
                            <SingleSelectCombobox optionList={USER_LIST} field="Select User Role" placeholder="Select User Role" widthClass="w-full" value={undefined} setValue={undefined} />
                            </div>
                            <div className=" flex items-center space-x-2 relative mb-6 mt-2 w-1/4">
                            <Icon name="search" 
                            className="absolute left-3 top-2.5 size-5 text-neutral-500"></Icon>
                            <Input
                            placeholder="Application Search" className="rounded-3xl pl-10"
                          /></div></div> */}
                    
            
                     <h2 className="text-lg font-bold mb-6 text-muted-foreground uppercase ml-2 mt-4">Account Details</h2>
                        <div className="flex items-center gap-3 mb-4">
                            <label htmlFor="accountSelect" className="font-normal ml-4">Account Name</label>
                        <select id="accountSelect" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" value={selectedAccount} onChange={handleAccountChange}>
                            <option value="" disabled hidden>Select Account Name</option>
                        {accounts.map((account)=>(
                            <option key={account.value} value={account.value} className="text-gray-200">
                                {account.label}
                                </option>))}
                        </select>
                        <label htmlFor="roleSelect" className="font-normal ml-3">Role Name</label>
                        <select id="roleSelect" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" value={selectedRole} onChange={handleRoleChange}>
                            <option value="" disabled hidden>Select Role Name</option>
                        {roles.map((role)=>(
                            <option key={role.value} value={role.value} className="text-gray-200">
                                {role.label}
                                </option>))}
                        </select>
                        <button className="px-1 py-2 text-sm bg-blue-500 text-white rounded-md  ml-3 hover:bg-blue-800" onClick={toggleAddNewAccount}>
                            Add New Account
                        </button>
                        <button className="px-1 py-2 text-sm bg-blue-500 text-white rounded-md ml-3 hover:bg-blue-800" onClick={toggleAddNewRole}>
                            Add New Role
                        </button>
                        </div>
                        {/* Add New Account Section */}
                        {isAddingAccount && (
                            <div className="border-2 border p-4 rounded-md dark:border-gray-700 dark:bg-gray-900 mb-6 w-3/4 ml-4">
                                <h3 className="text-muted-foreground uppercase"> Add New Account</h3>
                                <div className="flex items-center gap-4 mb-4">
                                    <label htmlFor="newAccountName" className="font-semibold mt-2">Account Name:</label>
                                <input type="text" value={newAccountName} onChange={(e)=>setNewAccountName(e.target.value)} placeholder="Enter New Account Name" className="py-1 px-2 mt-2 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none"/>
                                </div>
                                <div className="flex space-x-6"><button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none" onClick={handleAddAccount}>Save Account</button>
                            <button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none " onClick={handleCancelAddAccount
                              }>Cancel</button>
                            </div></div>
                            )}
                            {isAddingRole && (
                            <div className="border-2 border p-4 rounded-md dark:border-gray-700 dark:bg-gray-900 mb-6 w-3/4 ml-4">
                                <h3 className="text-muted-foreground uppercase"> Add New Role</h3>
                                <div className="flex items-center gap-4 mb-4">
                                    <label htmlFor="newRoleName" className="font-semibold mt-2">Role Name:</label>
                                <input type="text" value={newRoleName} onChange={(e)=>setNewRoleName(e.target.value)} placeholder="Enter New Role Name" className="py-1 px-2 mt-2 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none"/>
                                </div>
                                <div className="flex space-x-6"><button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none" onClick={handleAddRole}>Save Role</button>
                            <button className="p-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-border-gray-600 focus outline-none " onClick={handleCancelAddRole}>Cancel</button>
                            </div></div>
                            )} 
                             
            
            
            
            
            
                            <button className="px-4 py-1 ml-2 mt-4 border rounded-md bg-blue-500 hover:bg-blue-800 text-black-400 dark:border-gray-600 border-border-gray-600" onClick={handleAddToTable} >SUBMIT</button>
                    </div>



            
          </TabsContent>
        </Tabs>
      </div>
    );
  };
  
  export default Administration;
  