// import { AlignCenter, SearchIcon } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLazyGetRoleDetailsByUserIdQuery, useSaveAcessRequestMutation } from "../slice/FPAUserRoleAPISlice";
import { updateFPARole } from "@/auth/slice/authSlice";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import ExcelUploads from "./Upload";
import { Dialog, DialogContent, DialogDescription } from "@/components/ui/dialog";

import { useToast } from "@/components/ui/use-toast";
import Administration from "./Administration";
import { Button } from "@/components/ui/button";
import { setSelectedRole, setSelectedAccount} from "../slice/NAOSlice";


const Onboard: React.FC = () => {

  const navigate = useNavigate();


  const selectedRoleName = useAppSelector((state:any) => state.nao.selectedRoleName);
  // const accountForAdmin= useAppSelector((state) => state.nao.accountForAdmin);

  // const [selectedRoleName, setSelectedRoleName] = useState<string>(''); 
  const [accountForAdmin, setAccountForAdmin] = useState<string>('');


  // const { applications } = useContext(AppContext);
  // const roleSelectionStyle = {
  //   marginBottom: '15px',
  //   color: "grey",
  // };

  // const [selectedTab, setSelectedTab] = useState("dashboard");
  // const USER_LIST = [
  //   { label: "Product Management", value: 'Product Management' },
  //   { label: "Development", value: 'Development' },
  // ]

  const userDetails = useAppSelector((state) => state.auth.rawUserDetails);

 // const [isLoading, setIsLoading] = useState(false);

  const [triggerGetFPAUserRoleDetails, fpaUserRoleDetails] = useLazyGetRoleDetailsByUserIdQuery()
  const dispatch = useAppDispatch();
  useEffect(() => {


    //console.log("userDetails-----",userDetails)
    triggerGetFPAUserRoleDetails({ userId: userDetails.empid })
    //triggerGetFPAUserRoleDetails({ userId: "12121212" })

  }, []);

  useEffect(() => {
    if (fpaUserRoleDetails.status == 'fulfilled') {


      if (fpaUserRoleDetails.data.length > 0) {
        let roleArray = [];
        for (let i = 0; i < fpaUserRoleDetails.data.length; i++) {
          if (fpaUserRoleDetails.data[i]["status"] == "Active") {
            roleArray.push(fpaUserRoleDetails.data[i])
          }
        }
        if (roleArray.length > 0) {
          dispatch(updateFPARole({ roleDetails: roleArray }))
        } else {
          setAlertMessage("Your request to access this module is currently pending. You will be notified once it has been approved.")
          setNavigateStatus(true)
          setIsAlertOpen(true);
        }

      } else {
        setIsDialogOpen(true);
      }
    }


  }, [fpaUserRoleDetails]);

  useEffect(() => {

    console.log("selectedRoleName----", selectedRoleName)

    console.log("accountForAdmin----", accountForAdmin)

  }, [selectedRoleName, accountForAdmin]);



  // const openDialog = () => {

  //   setIsDialogOpen(true);
  // };

  const closeDialog = () => {

    setIsDialogOpen(false);
    navigate("/");

  };

  const closeAlert = (naviStatus: any) => {

    setIsAlertOpen(false);

    if (naviStatus) {
      setIsDialogOpen(false)
      navigate("/");
    }

  };


  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAlertOpen, setIsAlertOpen] = useState(false);
  const [navigateStatus, setNavigateStatus] = useState(false);

  const [alertMessage, setAlertMessage] = useState("");

  const [accessDetails, setAccessDetails] = useState<any>([]);
  const [accounts] = useState([
    { label: "CITI", value: 'CITI' },
    { label: "MetLife", value: 'MetLife' },
  ]);

  const [roles] = useState([
    { label: "User", value: 'User' },
    { label: "DeliveryPartner", value: 'DeliveryPartner' },
    { label: "SuperAdmin", value: 'SuperAdmin' },
  ]);
  const { toast } = useToast();
  // const [selectedAccount,setSelectedAccount]=useState<string>('');
  // const [selectedRole,setSelectedRole]=useState<string>('');


  const selectedAccount = useAppSelector((state) => state.nao.selectedAccount);
  const selectedRole = useAppSelector((state) => state.nao.selectedRole);

  const handleAddAccessDetails = () => {


    if (!(accessDetails.some((item: any) => item.accountName == selectedAccount))) {
      const newAccessDetails = { accountName: selectedAccount, roleName: selectedRole, userId: userDetails.empid, createdBy: userDetails.empid, status: "Pending" };
      setAccessDetails([...accessDetails, newAccessDetails]);
    } else {
      setNavigateStatus(false)
      setAlertMessage("You can raise one access for one account");
      setIsAlertOpen(true);
    }
  };
  const removeSelectedRole = (item: any) => {
    console.log("removeSelectedRole----", item)
    setAccessDetails(accessDetails.filter((data: any) => data.accountName !== item.accountName))


  };

  const [triggerSaveAccessRequest, accessRequestResponse] = useSaveAcessRequestMutation();
  const handleSaveAccessDetails = () => {
    //console.log("accessDetails----",accessDetails)
    if (accessDetails.length > 0) {
      triggerSaveAccessRequest(accessDetails);
    } else {
      setAlertMessage("Please add atleast one role.")

      setIsAlertOpen(true);

    }

  };

  useEffect(() => {
    //console.log("accessRequestResponse-----",accessRequestResponse)
    if (accessRequestResponse.status == 'fulfilled') {
      toast({
        title: 'Request Sent successfully',
        description: ''
      })
      setNavigateStatus(true)
      setIsAlertOpen(true);
      setIsDialogOpen(false);
      setAlertMessage("Your request has been submitted successfully. You will receive a notification once it is approved.")


      // if(fpaUserRoleDetails.data.length > 0){

      //   dispatch(updateFPARole({ roleDetails: fpaUserRoleDetails.data }))

      // }else{
      //   setIsDialogOpen(true);
      // }
    }


  }, [accessRequestResponse]);

  const handleAccountChange = (event: React.ChangeEvent<HTMLSelectElement>) => {

    dispatch(setSelectedAccount(event.target.value));
  };

  const handleRoleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {

    dispatch(setSelectedRole(event.target.value));
  };



  return (
    <div >

      <Dialog open={isAlertOpen} onOpenChange={(open) => {
        if (!open) {
          return;
        }
        setIsAlertOpen(open)
      }}  >

        <DialogContent className="sm:max-w-[725px] rounded-2xl [&>button]:hidden "  >

          <DialogDescription>
            {alertMessage}
          </DialogDescription>
          <div className=" p-3 rounded-md w-1/1  ">
            <button className="pl-4 pt-2 pb-2 pr-4 text-sm bg-blue-300 text-white rounded-md dark:bg-blue-600 ml-72" onClick={() => closeAlert(navigateStatus)} >

              Ok
            </button>
          </div>

        </DialogContent>
      </Dialog>

      <Dialog open={isDialogOpen} onOpenChange={(open) => {
        if (!open) {
          return;
        }
        setIsDialogOpen(open)
      }}>

        <DialogContent className="sm:max-w-[725px] rounded-2xl [&>button]:hidden "  >

          <DialogDescription>
            You do not have any permission to access this module.Please raise a request to Admin for access.
          </DialogDescription>
          <div className=" border-2 border-black-800 p-3 rounded-md w-1/1  ">

            <div className="flex items-center gap-4 mb-4">
              <label htmlFor="accountSelect" className="font-normal ml-3">Account Name</label>
              <select id="accountSelect" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" onChange={handleAccountChange} value={selectedAccount} >
                <option value="" disabled hidden>Select Account</option>
                {accounts.map((account) => (
                  <option key={account.value} value={account.value} className="text-gray-200">
                    {account.label}
                  </option>))}
              </select>

              <label htmlFor="accountRole" className="font-normal ml-3">Role Name</label>
              <select id="accountRole" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" onChange={handleRoleChange} value={selectedRole} >
                <option value="" disabled hidden>Select Role</option>
                {roles.map((role) => (
                  <option key={role.value} value={role.value} className="text-gray-200">
                    {role.label}
                  </option>))}
              </select>

              <button className="p-2   text-sm  bg-blue-300 text-white rounded-md dark:bg-blue-600 " onClick={handleAddAccessDetails}>

                Add
              </button>

            </div>
            <table className="w-full border-gray-500 dark:border-gray-700 ">
              <thead>
                <tr>
                  <th className="border border-gray-500 bg-blue-600 dark:border-gray-700 text-gray-600 dark:text-gray-400 px-4 py-2 ">Account Name</th>
                  <th className="border border-gray-500 bg-blue-600 dark:border-gray-700 px-4 text-gray-600 dark:text-gray-400 py-2">Role Name</th>
                  <th className="border border-gray-500 bg-blue-600 dark:border-gray-700 px-4 text-gray-600 dark:text-gray-400 py-2">Action</th>

                </tr>
              </thead>
              <tbody>
                {accessDetails.length > 0 ? (accessDetails.map((item:any, index:any) => (
                  <tr key={index}>
                    <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3 h-2" >{item.accountName}</td>
                    <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3 h-2">{item.roleName}</td>
                    <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3 h-2"><Button
                      className="bg-red-400 hover:bg-red-500 text-white mx-1"
                      onClick={() => {
                        removeSelectedRole(item)

                      }}
                    >
                      Remove
                    </Button></td>

                  </tr>))) : (
                  <tr>
                    <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3" colSpan={3}>
                      No Details in the queue
                    </td>
                  </tr>
                )}

              </tbody>
            </table>
            <button className=" p-2 py-1 px-1 text-sm bg-blue-300 text-white rounded-md dark:bg-blue-600 mt-3 ml-60" onClick={handleSaveAccessDetails} >

              Submit Request
            </button>

            <button className="p-2 py-1 px-1 text-sm bg-blue-300 text-white rounded-md dark:bg-blue-600 mt-3 ml-2" onClick={closeDialog} >

              Close
            </button>
          </div>
        </DialogContent>
      </Dialog>


      <Tabs className="m-2" defaultValue="dashboard">
        <TabsList className="flex-x-4" >
          <TabsTrigger value="dashboard" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
            Dashboard
          </TabsTrigger>
          {(selectedRoleName == "SuperAdmin" || selectedRoleName == "AREAdmin") &&
            (<TabsTrigger value="administration" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
              Administration
            </TabsTrigger>)}

        </TabsList>

        {/* Master Data Tab */}
        <TabsContent value="dashboard">
 {fpaUserRoleDetails.status === 'fulfilled'&&(
          <ExcelUploads accountForAdmin={setAccountForAdmin} />)}

        </TabsContent>
        <TabsContent value="administration">
          <Administration selectedAccountName={accountForAdmin} />
        </TabsContent>
      </Tabs>


      {/* <div className="flex items-center justify-between w-3/4">
                <div style={roleSelectionStyle} className="flex items-center space-x-2 mt-4">
                <SingleSelectCombobox optionList={USER_LIST} field="Select User Role" placeholder="Select User Role" widthClass="w-full" value={undefined} setValue={undefined} />
                </div>
                <div className="flex items-center space-x-2 relative mb-6 mt-2 w-1/4">
                <Icon name="search" 
                className="absolute left-3 top-2.5 size-5 text-neutral-500"></Icon>
                <Input
                placeholder="Application Search" className="rounded-3xl pl-10"
              /></div></div> */}
      {/* <table className="w-3/4 border-gray-500 dark:border-gray-700 ml-4">
            <thead>
                <tr>
                    <th className="border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 px-4 py-2">Application ID</th>
                    <th className="border border-gray-500 dark:border-gray-700 px-4 text-gray-600 dark:text-gray-400 py-2">Application Name</th>
                    <th className="border border-gray-500 dark:border-gray-700 px-4 text-gray-600 dark:text-gray-400 py-2">PortFolio</th>
                    <th className="border border-gray-500 dark:border-gray-700 px-4 text-gray-600 dark:text-gray-400 py-2">Current Status</th>
                </tr>
            </thead>
            <tbody>
              {tableData.length>0?(tableData.map((item,index)=>(
                <tr key={index}>
                  <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3" >{item.applicationId}</td>
                  <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3">{item.applicationName}</td>
                  <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3">{item.portfolio}</td>
                  <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3">{item.currentStatus}</td>
                  <td> <button className="w-1/2 mb-3 ml-4 px-4  py-1 bg-tcs-primary rounded-lg bg-blue-500 rounded hover:bg-blue-600 dark:bg-blue-500 dark:hover:bg-blue-700 text-white"> View</button></td>
                   </tr>))):(
                   <tr>
                    <td className="text-center border border-gray-500 dark:border-gray-700 text-gray-600 dark:text-gray-400 py-3" colSpan={4}>
                    No items in the queue
                    </td>
                    </tr>
                  )}
                  
            </tbody>
         </table> */}
    </div>
  );
};
export default Onboard;




