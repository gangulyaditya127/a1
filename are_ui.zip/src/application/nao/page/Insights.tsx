import React,{useState} from "react";
import { Button } from "@/components/ui/button";
// import { useNavigate } from "react-router-dom";

interface Application {
  name: string;
  criticality: number;
  stability: number;
  complexity: number;
}

interface InsightsProps {
  applications: Application[];
}

const Insights: React.FC<InsightsProps> = ({ applications }) => {
  // Define Ranges
  const RANGES = {
    criticality: { low: [0, 100], medium: [101, 500], high: [501, Infinity] },
    stability: { low: [0, 100], medium: [101, 500], high: [501, Infinity] },
    complexity: { low: [0, 100], medium: [101, 500], high: [501, Infinity] },
  };

  // Classify Levels
  const classifyLevel = (value: number, ranges: any) => {
    if (value >= ranges.low[0] && value <= ranges.low[1]) return "low";
    if (value >= ranges.medium[0] && value <= ranges.medium[1]) return "medium";
    if (value >= ranges.high[0] && value <= ranges.high[1]) return "high";
    // throw new Error("Value does not fit into any range");
  };
  const [showInsights, setShowInsights]=useState(false);
  const handleToggleInsights=()=>{
    setShowInsights(!showInsights);
  };
 

  // const navigate = useNavigate();
  // const hardcodedData=[{accountid:"number", setnumber:"number"}];


  // const handleFPACalculate=()=>{
  // navigate("./application/nao/page/OnboardUpload/DDCube/FPACalculate",{state:{data:hardcodedData},})
  // };
  // Generate Insights
  const generateInsights = (applications: Application[]) => {
    const insights= {
      highRisk: [] as string[],
      lowRisk:[] as  string[],
    };
  
    applications.forEach((app) => {
      const criticality = classifyLevel(app.criticality, RANGES.criticality);
      const stability = classifyLevel(app.stability, RANGES.stability);
      const complexity = classifyLevel(app.complexity, RANGES.complexity);

      if (criticality === "high" && complexity === "high" && stability === "low") {
        insights.highRisk.push(app.name);
      }

      if (criticality === "low" && complexity === "low" && stability === "low") {
        insights.lowRisk.push(app.name);
      }
    });

    return insights;
  };

  const insights = generateInsights(applications);

  // Render Insights
  return (
    <div>

        <Button onClick={handleToggleInsights} className="mt-8 ml-10 mb-6 rounded-lg text white bg-green-500 hover:bg-green-700 text-center border border-gray-300">
            {showInsights?"Hide Insights":"Show Insights"}</Button>
            {/* <Button onClick={handleFPACalculate} className="mt-8 ml-10 mb-6 rounded-lg text white bg-green-500 hover:bg-green-700 text-center border border-gray-300">FPA Calculate</Button> */}
    {showInsights && (
        <><div style={{ marginTop: "40px", borderTop: "3px dashed #ccc", paddingTop: "40px", marginLeft: "40px", marginRight: "100px" }}>
                  <h2 className="mb-2 font-bold text-muted-foreground uppercase ">Analyzing all the application inputs, please find the INSIGHTS generated:</h2>

                  <ul className="font-bold mb-2 flex list-disc mt-4">
                      <li>High Criticality + High Complexity + Low Stability :-</li></ul>
                  <p className="mb-2">Below Application Falls in this category:</p>
                  <ul>
                      {insights.highRisk.length > 0 ? (
                          insights.highRisk.map((app, index) => (<li key={index} className="ml-2 list-disc font-bold ">{app}</li>
                          ))
                      ) : (
                          <li className="font-bold">No application fall in this category for this dataset.</li>)}
                  </ul>
                  <h3 className="mb-4 mt-2">Below are some generic recommendations :-</h3>
                  <ul className="list-decimal flex-col gap-1 pl-4">
                      <li>These applications represent significant business risks and require immediate stabilization efforts.</li>
                      <li> Disaster recovery plans, Proactive redesign or refactoring is essential to reduce operational risks.</li>
                  </ul>

                  <ul className="flex list-disc font-bold mb-2 mt-4 "><li>Low Criticality + Low Complexity + Low Stability :-</li></ul>
                  <p className="mb-2">Below Application Falls in this category:</p>
                  <ul>
                      {insights.lowRisk.length > 0 ? (
                          insights.lowRisk.map((app, index) => (<li key={index} className="ml-2 list-disc font-bold">{app}</li>))
                      ) : (
                          <li className="font-bold">No application fall in this category for this dataset.</li>
                      )}
          
                  </ul>
                  <h3 className="mb-4 mt-4">Below are some generic recommendations :-</h3>
                  <ul className="list-decimal flex-col gap-1 pl-4 mb-8">
                      <li>High-Criticality applications need robust monitoring and 24/7 support.</li>
                      <li>
                          High Complexity applications should simplify architecture to improve maintainability and scalability.
                      </li>
                      <li>
                          Allocate resources to improve stability through quick wins like bug fixes and optimizations.
                      </li>

                  </ul>
              </div><div style={{ height: "1rem" }}></div></>
    )}
    </div>
  );
};

export default Insights;
