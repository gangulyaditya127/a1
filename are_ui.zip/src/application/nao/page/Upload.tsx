import { useRef, useState } from "react";
import * as XLSX from "xlsx";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import PageLoader from "@/components/ui/page-loader";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/tailwind.utils";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { useUploadDDCubeDataMutation } from "../slice/DDCubeAPISlice";
import { useLazyGetFPADetailsDataQuery, useLazyGetMasterAndTransactDataQuery, useSaveMasterAndTransactDataMutation, useLazyGetAccountDetailsByAccountNameQuery, useSaveNewSetMutation } from "../slice/MasterAndTransactDataAPISlice";
import DataGrid from "@/components/ui/data-grid";
import myFPACss from "../style/onboard.module.css";
import useDerivedTheme from "@/lib/hooks/useDerivedTheme";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";

import { setlastSelectedAccountIndex } from "../slice/NAOSlice";
import { setFileUpload } from "../slice/NAOSlice";

import { setAccountList } from "../slice/NAOSlice";
import { setSelectedAccount } from "../slice/NAOSlice";
import { setShowAccountDetailsTable, setShowFileUploadSection } from "../slice/NAOSlice";
import { setRoleName } from "../slice/NAOSlice";
import { setSelectedRoleName } from "../slice/NAOSlice";
import { setGridHeight } from "../slice/NAOSlice";
import styles from "../style/onboard.module.css";

// import { useLazyGetMasterAndTransactDataQuery, useSaveMasterAndTransactDataMutation } from "../slice/MasterandTransactDataAPISlice";



type ExcelRow = Record<string, any>;
//  const selectedRoleName = useAppSelector((state) => state.nao.selectedRoleName);
//  const accountForAdmin= useAppSelector((state) => state.nao.accountForAdmin);


const ExcelUploads = ({ accountForAdmin }:any) => {
  // const [masterData, setMasterData] = useState<ExcelRow[]>([]);
  const lastSelectedAccountIndex = useAppSelector((state) => state.nao.lastSelectedAccountIndex);



  const [colDefs] = useState([

    { field: "account_NAME", headerName: "Account Name", headerClass: myFPACss['header-column-css'], minWidth: 50, maxWidth: 160},
    { field: "set_NO", headerName: "Set No", headerClass: myFPACss['header-column-css'], sortable: true, minWidth: 50, maxWidth: 120 },
    { field: "created_BY", headerName: "Created By", headerClass: myFPACss['header-column-css'], minWidth: 50, maxWidth: 150 },
    { field: "created_ON", headerName: "Created On", headerClass: myFPACss['header-column-css'], sortable: true, minWidth: 50, maxWidth: 150 },
    { field: "select", headerName: "Edit", headerClass: myFPACss['header-column-css'], checkboxSelection: true, headerCheckboxSelection: true, minWidth: 50, maxWidth: 120 },
    // { field: "action", headerName: "Action", headerClass: myFPACss['header-column-css'], cellRenderer:(params) =>(
    //   <button onClick={() =>handleAccountDetailChange(params.data)}>Edit</button>
    //       ),minWidth:50,maxWidth:150 }
  ])
  const theme = useDerivedTheme()
  const getRowClass = (params: any) => {
    if (theme == "dark") {
      if (params.node.rowIndex % 2 === 0) {
        return myFPACss['table-evenrow-css'];
      } else {
        return myFPACss['table-oddrow-css'];
      }
    } else {
      if (params.node.rowIndex % 2 === 0) {
        return myFPACss['table-evenrow-css-light'];
      } else {
        return myFPACss['table-oddrow-css-light'];
      }
    }

  };

  // const rowSelectionAccountDetails = useMemo(() => { 
  // 	return {

  //         mode: 'singleRow',
  //         checkboxes: true,
  //         enableClickSelection: true,
  //     };
  // }, []);

  // const rowSelectionAccountDetails = {
  //   mode: "singleRow",

  //   headerCheckbox: false,
  // };

  const onRowSelectAccountDetails = (event: any) => {

    console.log("onRowSelectAccountDetails----", event.data)
  }

  const getSelectedAccountIndex = (selectedRow: any) => {
    let matchId = null;
    if (!selectedRow) {
      return null;
    }
    for (let i = 0; i < accountList.length; i++) {
      if (accountList[i].id == selectedRow.id) {
        matchId = '' + i;
        return matchId;
      }
    }
    return matchId;
  }

  const onRowSelectionChangedAccountDetails = (event: any) => {

    // setEdit(true);

    const selectedRow = event.api.getSelectedRows();




    console.log("onRowSelectAccountDetails--selectedRow--", selectedRow)

    if (selectedRow.length > 0) {
      dispatch(setShowFileUploadSection(true));
      // setSelectedRadioBtn(value.set_NO)
      setSelectedSet(selectedRow[0].set_NO)

      searchDetailsByAccountAndSet(selectedRow[0].account_NAME, selectedRow[0].set_NO)
    } else {
      setSelectedSet("")
      searchDetailsByAccountAndSet(" ", "0")

    }

    dispatch(setlastSelectedAccountIndex(getSelectedAccountIndex(selectedRow?.[0])))

    // setShowFileUploadSection(true)
    //   setSelectedRadioBtn(value.set_NO)
    //   setSelectedSet(value.set_NO)
    //   searchDetailsByAccountAndSet(value.account_NAME, value.set_NO)

  }

  const pagination = true;
  const paginationPageSize = 5;
  const paginationPageSizeSelector = [5, 12, 20];

  //const [validatedMasterData, setValidatedMasterData] = useState<ExcelRow[]>([]);
  //const [validatedTransactData, setValidatedTransactData] = useState<ExcelRow[]>([]);
  const [validatedMasterTransactData, setValidatedMasterTransactData] = useState<ExcelRow[]>([]);
  const [setFileName] = useState<any>(null);
  //const [setFileSelected] = useState(false);
  const [masterAndTxnData, setMasterAndTxnData] = useState<any>([]);
  const [showData, setShowData] = useState(false);
  //const [showUserContent, setShowUserConsent] = useState(false);
  const [fpaCalculateLoder, setFpaCalculateLoder] = useState(false);
  const [searchLoder, setSearchLoder] = useState(false);
  const [saveLoder, setSaveLoder] = useState(false);
  const [editRowIndex, setEditRowIndex] = useState(null);
  const [editTransactRowIndex, setEditTransactRowIndex] = useState(null);
  const [accountsDetails, setaccountsDetails] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [account] = useState("");
  const [selectedSet, setSelectedSet] = useState("");


  const [trigger, { isError, isLoading, isSuccess, error, data }] = useUploadDDCubeDataMutation()

  const [triggerMasterTransact, dataMaster] = useSaveMasterAndTransactDataMutation()
  // const [trigger2, { isError2, isLoading2, isSuccess2, error2,data2 }] = useTestQuery()
  const [triggerGetMaster, result] = useLazyGetMasterAndTransactDataQuery()
  const [triggerGetFPADetails, fpaDetails] = useLazyGetFPADetailsDataQuery()
  const [triggerGetAccountDetailsByAccountName, accountDetails] = useLazyGetAccountDetailsByAccountNameQuery()
  //const [gettestTrigger] = useLazyTestQuery()
  //const [searchTerm, setSearchTerm] = useState('');
  const rowHeight= 30;
  const headerHeight = 65;
  // const [gridHeight, setGridHeight] = useState(1 * rowHeight + headerHeight);
  const gridHeight = useAppSelector((state) => state.nao.gridHeight);



  const [triggerNewSetSave, newSetResponse] = useSaveNewSetMutation()

  // const isAnyLoading:boolean=isUploading||isMasterLoading||isFPADetailsLoading;

  const [accounts, setAccounts] = useState([
    // { label: "CITI", value: 'CITI' },
    // { label: "MetLife", value: 'MetLife' },
  ]); //Start with account list

  //const gridHeight = 1 *rowHeight+headerHeight
  //Start with account list
  // const [setSelectedAccount] = useState<string>('');


  const dispatch = useAppDispatch();
  const selectedAccount = useAppSelector((state) => state.nao.selectedAccount);

  //const [selectedRadioBtn, setSelectedRadioBtn] = useState<string>('');
  //const [isAddingAccount, setIsAddingAccount] = useState<boolean>(false); // Add new account visibility
  //const [newAccountName, setNewAccountName] = useState<string>('');
  // const [ accountList, setAccountList] = useState<any>([]); //

  const accountList = useAppSelector((state) => state.nao.accountList);

  // const [showAccountDetailsTable, setShowAccountDetailsTable] = useState(false);

  // const [showFileUploadSection, setShowFileUploadSection] = useState(false);

  const showAccountDetailsTable = useAppSelector((state) => state.nao.showAccountDetailsTable);
  const showFileUploadSection = useAppSelector((state) => state.nao.showFileUploadSection);
  const [filters, setFilters] = useState({ portfolio: "", applicationCSI: "", language: "", criticality: "", stability: "", });

  const navigate = useNavigate();
  const { toast } = useToast();
  const roleDetails = useAppSelector((state) => state.auth.roleDetails)
  console.log(roleDetails)

  // const [roleName, setRoleName] = useState<string>(''); 

  const roleName = useAppSelector((state) => state.nao.roleName);
  useEffect(() => {

    console.log(selectedAccount, "----useEffect--190-roleDetails-----", roleDetails)
    if (roleDetails != undefined && roleDetails.length > 0) {

      let accountArray: any = []
      for (let i = 0; i < roleDetails.length; i++) {
        let accountJson = { label: roleDetails[i].accountName, value: roleDetails[i].accountName }
        accountArray.push(accountJson)
      }
      setAccounts(accountArray);
    }

  }, [roleDetails]);



  // useEffect(() => {
  //   console.log("roleDetails-----",roleDetails)
  //   const filterRoleDetail = roleDetails.filter(
  //     (roleDetails: any) => (selectedAccount === roleDetails["accountName"]));
  //     setRoleName(filterRoleDetail[0]["roleName"])


  // }, [selectedAccount]);

  const handleFilterChange = (e: any) => {

    const { name, value } = e.target;
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
    }))
  }



  const filteredMasterTransactData = validatedMasterTransactData.filter(item =>
    item.portfolio.toLowerCase().includes(filters.portfolio.toLowerCase()) &&
    item.applicationCSI.toLowerCase().includes(filters.applicationCSI.toLowerCase()) &&

    item.language.toLowerCase().includes(filters.language.toLowerCase()) &&
    item.criticality.toLowerCase().includes(filters.criticality.toLowerCase()) &&
    item.stability.toLowerCase().includes(filters.stability.toLowerCase())

  );

  const handleAccountChange = (event: React.ChangeEvent<HTMLSelectElement>) => {

    //console.log(event.target.value)
    dispatch(setSelectedAccount(event.target.value));
    accountForAdmin(event.target.value);

    const filterRoleDetail = roleDetails.filter(
      (roleDetail: any) => (event.target.value === roleDetail["accountName"]));

    dispatch(setRoleName(filterRoleDetail[0]["roleName"]));
    dispatch(setSelectedRoleName(filterRoleDetail[0]["roleName"]));
  };


  // const handleCancelAddAccount = () => {
  //   setIsAddingAccount(false);
  //   setNewAccountName('');
  // };
  // const accountDetails = useAppSelector((state) => state.nao.accountDetails);

  const searchAccountDetailsByName = () => {

    setaccountsDetails(true);

    const filterRoleDetail = roleDetails.filter(
      (roleDetails: any) => (selectedAccount === roleDetails["accountName"]));
    dispatch(setRoleName(filterRoleDetail[0]["roleName"]));
    dispatch(setSelectedRoleName(filterRoleDetail[0]["roleName"]));

    triggerGetAccountDetailsByAccountName({ accountName: selectedAccount })
    //setSelectedRadioBtn("")
    setSelectedSet("")
    dispatch(setShowFileUploadSection(false));
    setShowData(false)
  }

  useEffect(() => {

    if (accountDetails.status == 'fulfilled') {



      dispatch(setShowAccountDetailsTable(true));

      dispatch(setAccountList(accountDetails.data));
      dispatch(setGridHeight((accountDetails.data.length * rowHeight) + headerHeight))
      setaccountsDetails(false);
    }

  }, [accountDetails]);

  const searchDetailsByAccountAndSet = (selectedAccount: any, selectedSetNo: any) => {
    setSearchLoder(true);
    triggerGetMaster({ accountName: selectedAccount, setNo: selectedSetNo })

    setShowData(true);


  }

  useEffect(() => {
    console.log("triggerGetMaster-----", result)
    if (result.isSuccess) {

      let tempMasterTransactData: any = [];
      setShowData(true);
      //setValidatedMasterData(result.data.masterData);
      //setValidatedTransactData(result.data.transactData);
      for (let i = 0; i < result.data.masterData.length; i++) {
        let jsonObject: any = {}
        jsonObject["newService"] = result.data.masterData[i]["newService"]
        jsonObject["region"] = result.data.masterData[i]["region"]
        jsonObject["portfolio"] = result.data.masterData[i]["portfolio"]
        jsonObject["applicationCSI"] = result.data.masterData[i]["applicationCSI"]
        jsonObject["applicationName"] = result.data.masterData[i]["applicationName"]
        jsonObject["interfaces"] = result.data.masterData[i]["interfaces"]
        jsonObject["internalFiles"] = result.data.masterData[i]["internalFiles"]
        jsonObject["screens"] = result.data.masterData[i]["screens"]
        jsonObject["batchJobs"] = result.data.masterData[i]["batchJobs"]
        jsonObject["users"] = result.data.masterData[i]["users"]
        jsonObject["language"] = result.data.masterData[i]["language"]
        jsonObject["criticality"] = result.data.masterData[i]["criticality"]
        jsonObject["stability"] = result.data.masterData[i]["stability"]
        jsonObject["coverage"] = result.data.masterData[i]["coverage"]
        jsonObject["dup"] = result.data.masterData[i]["dup"]
        jsonObject["actCSI"] = result.data.masterData[i]["actCSI"]
        jsonObject["accountName"] = result.data.masterData[i]["accountName"]
        // jsonObject["accountId"] = result.data.masterData[i]["accountId"]
        jsonObject["setNo"] = result.data.masterData[i]["setNo"]


        const filterTransactData = result.data.transactData.filter(
          (transact: any) => (transact["applicationCSI"] === result.data.masterData[i]["applicationCSI"]) && (transact["portfolio"] === result.data.masterData[i]["portfolio"]));

        jsonObject["transactionDate"] = filterTransactData[0]["transactionDate"]
        jsonObject["majorIncident"] = filterTransactData[0]["majorIncident"]
        jsonObject["batchIncident"] = filterTransactData[0]["batchIncident"]
        jsonObject["userIncident"] = filterTransactData[0]["userIncident"]
        jsonObject["userQuery"] = filterTransactData[0]["userQuery"]
        jsonObject["problemTicket"] = filterTransactData[0]["problemTicket"]
        jsonObject["changeRequest"] = filterTransactData[0]["changeRequest"]
        jsonObject["serviceRequest"] = filterTransactData[0]["serviceRequest"]
        jsonObject["adhocRequest"] = filterTransactData[0]["adhocRequest"]
        jsonObject["alerts"] = filterTransactData[0]["alerts"]

        tempMasterTransactData.push(jsonObject)
      }
      setValidatedMasterTransactData(tempMasterTransactData)
      setSearchLoder(false);
    }

  }, [result]);



  useEffect(() => {
    if (isError) {
      setHasError(true);
      setErrorMessage("Failed to upload data.Please try again");
    } else if (isSuccess) {
      setHasError(false);
      setErrorMessage("");

      navigate("/nao/DDCube", { state: { data: data, masterAndTxnData, account, selectedSet } });
    }
  }, [isSuccess, isError, error]);
  console.log(isSuccess)

  //  const dispatch = useAppDispatch();

  const fileName = useAppSelector((state) => state.nao.fileName);
  const fileSelected = useAppSelector((state) => state.nao.fileSelected);


  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {

    setShowData(false);
    const file = e.target.files?.[0];

    if (file) {
      if (!file.name.endsWith(".xls") && !file.name.endsWith(".xlsx")) {
        alert("Please upload a valid Excel file (.xls or .xlsx)");
        e.target.value = "";
        return;
      }

      dispatch(setFileUpload({ fileName: file.name, fileSelected: true }));
      // setFileSelected(true);
      // setFileName(file.name);

      const reader = new FileReader();
      reader.onload = (event: ProgressEvent<FileReader>) => {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });

        // Process MasterData (Sheet 1)
        const sheetName1 = workbook.SheetNames[1];
        const worksheet1 = workbook.Sheets[sheetName1];
        const masterJsonData = XLSX.utils
          .sheet_to_json<ExcelRow>(worksheet1, { header: 1 })
          .slice(7) // Start from the 7th row
          .map((row: any) =>
            row.reduce(
              (acc: any, value: any, idx: number) => ({ ...acc, [`Column ${idx + 1}`]: value }),
              {}
            )
          );



        // Validation Logic For Master Data
        // validateMasterData(masterJsonData);

        // Process TransactData (Sheet 2)
        const sheetName2 = workbook.SheetNames[2];
        const worksheet2 = workbook.Sheets[sheetName2];
        const transactJsonData = XLSX.utils
          .sheet_to_json<ExcelRow>(worksheet2, { header: 1 })
          .slice(7) // Start from the 7th row
          .map((row: any) =>
            row.reduce(
              (acc: any, value: any, idx: number) => ({ ...acc, [`Column ${idx + 1}`]: value }),
              {}
            )
          );

        // validateTransactData(transactJsonData)

        validateMasterTransactData(masterJsonData, transactJsonData)

      };

      reader.readAsArrayBuffer(file);
      e.target.value = "";

    }
  };



  const handleEditClick = (index: any) => {

    setEditRowIndex(index)
  }

  const handleSaveClick = (data: any, index: any) => {

    validateMasterTransactDataSave(data, index)
    setEditRowIndex(null)

  }

  // Data Manipulation
  const handleSaveDDCube = () => {


    // const mergedArray = validatedMasterData.map(item1 => {
    //   const match = validatedTransactData.find(item2 => item2.applicationCSI === item1.applicationCSI);
    //   return match ? { ...item1, ...match } : { ...item1 }
    // });
    // validatedTransactData.forEach(item2 => {
    //   if (!mergedArray.some(item => item.applicationCSI === item2.applicationCSI)) {
    //     mergedArray.push(item2)
    //   }
    // })
    const mergedArray = [...validatedMasterTransactData]
    let arrPayload = [];
    setMasterAndTxnData(mergedArray)
    for (let i = 0; i < mergedArray.length; i++) {
      let payload: any = {};
      payload["newService"] = mergedArray[i].newService;
      payload["region"] = mergedArray[i].region;
      payload["portfolio"] = mergedArray[i].portfolio;
      payload["applicationName"] = mergedArray[i].applicationName;
      payload["interfaces"] = mergedArray[i].interfaces;
      payload["internalFiles"] = mergedArray[i].internalFiles;
      payload["screens"] = mergedArray[i].screens;
      payload["criticality"] = mergedArray[i].criticality;
      payload["stability"] = mergedArray[i].stability;
      payload["setNo"] = selectedSet;

      arrPayload.push(payload)

    }
    console.log("abc", selectedSet)
    //  console.log(arrPayload)
    trigger(arrPayload);  // need to call api

  }


  // Data Manipulation
  const handleSave = () => {
    setSaveLoder(true)
    const mergedArray = [...validatedMasterTransactData]
    mergedArray.forEach(obj => {
      if (!obj.hasOwnProperty('accountName')) {
        obj.accountName = selectedAccount
      }
      if (!obj.hasOwnProperty('setNo')) {
        obj.setNo = selectedSet
      }
    })

    let newSetJson: any = {}
    newSetJson["account_NAME"] = selectedAccount;
    newSetJson["set_NO"] = selectedSet;
    newSetJson["status"] = "APPROVED";
    newSetJson["file_NAME"] = "";
    newSetJson["created_BY"] = "2059225";
    triggerNewSetSave(newSetJson)
    triggerMasterTransact(mergedArray);  // need to call api

  }

  useEffect(() => {
    console.log("use effect-dataMaster---", dataMaster)

    if (dataMaster.isSuccess) {
      setSaveLoder(false)
      toast({
        title: 'Data Save successfully',
        description: ''
      })

      return;

    }

  }, [dataMaster]);

  const handleEditChange = (jsonObject: any, field: any, value: any) => {


    jsonObject[field] = value

    const updatedData = validatedMasterTransactData.map((item: any) =>
      item.applicationCSI === jsonObject.applicationCSI ? jsonObject : item
    )
    // const updatedData = validatedMasterTransactData.map((row: any, index) =>
    //   rowIndex === index ? { ...row, [field]: value } : row
    // )


    setValidatedMasterTransactData(updatedData)

  }

  const handleTransactEditClick = (index: any) => {

    setEditTransactRowIndex(index)
  }

  const handleTransactSaveClick = (data: any, index: any) => {

    validateMasterTransactDataSave(data, index)
    setEditTransactRowIndex(null)

  }

  const handleUploadClick = () => {

    setShowData(true);
  };

  const handleUserConsent = () => {
   // setShowUserConsent(true);
  };

  const fpaCalculate = () => {

    setFpaCalculateLoder(true)
    triggerGetFPADetails({ accountName: selectedAccount, setNo: selectedSet })
  }

  useEffect(() => {


    if (fpaDetails.status == 'fulfilled') {
      setFpaCalculateLoder(false)
      navigate("/nao/FPACalculate", { state: { data: fpaDetails, selectedAccount, selectedSet } });
    }

  }, [fpaDetails]);






  const handleKeyDownMasterData = (event: any, data: any, index: any) => {

    if (event.key === "Enter") {

      validateMasterTransactDataSave(data, index)
      setEditRowIndex(null)
    }
  }

  const handleKeyDownTransactData = (event: any, data: any, index: any) => {

    if (event.key === "Enter") {

      validateMasterTransactDataSave(data, index)
      setEditTransactRowIndex(null)
    }
  }

  // const handleAccountDetailChange = (value: any) => {
    
  //   dispatch(setShowFileUploadSection(true));
  //   setSelectedRadioBtn(value.set_NO)
  //   setSelectedSet(value.set_NO)
  //   searchDetailsByAccountAndSet(value.account_NAME, value.set_NO)
  // };
  const gridRef: any = useRef();
  const addNewSet = () => {

    // console.log("selectedAccount---",selectedAccount)
    // console.log("accountList---",accountList)
    let maxSetNo = 0;
    for (let i = 0; i < accountList.length; i++) {
      if (accountList[i].set_NO > maxSetNo) {
        maxSetNo = accountList[i].set_NO;
      }
    }
    let newAccountList = [...accountList]
    let newSetJson: any = {}
    newSetJson["account_NAME"] = selectedAccount;
    newSetJson["set_NO"] = maxSetNo + 1;
    newSetJson["status"] = "APPROVED";
    newSetJson["file_NAME"] = "";
    newSetJson["created_BY"] = "2059225";

    newAccountList.push(newSetJson)
    dispatch(setGridHeight(newAccountList.length * rowHeight + headerHeight))
    dispatch(setAccountList(newAccountList));
    setTimeout(() => {
      const selectedRowIndex = newAccountList.length - 1;
      gridRef.current.api.ensureIndexVisible(selectedRowIndex);
      gridRef.current.api.getDisplayedRowAtIndex(selectedRowIndex).setSelected(true);

    }, 0)



    //triggerNewSetSave(newSetJson)
  };

  useEffect(() => {

    if (newSetResponse.isSuccess) {
      dispatch(setShowFileUploadSection(true));
      triggerGetAccountDetailsByAccountName({ accountName: selectedAccount })
     // setSelectedRadioBtn(newSetResponse.data.set_NO)
      setSelectedSet(newSetResponse.data.set_NO)
      setShowData(false)
      // call fetch api
    }

  }, [newSetResponse]);


  const validateMasterTransactData = (masterData: any, transactData: any) => {
    setValidatedMasterTransactData([])
    let tempMasterTransactData: any = [];
    for (let i = 0; i < masterData.length; i++) {
      let masterTransactDataJson: any = {}

      if (masterData[i]["Column 1"] == "Y" || masterData[i]["Column 1"] == "N") {
        masterTransactDataJson["newService"] = masterData[i]["Column 1"]
        masterTransactDataJson["newServiceCssClass"] = " "
        masterTransactDataJson["newServiceStatus"] = false
      } else if (masterData[i]["Column 1"] == "" || masterData[i]["Column 1"] == " " || masterData[i]["Column 1"] == undefined) {
        masterTransactDataJson["newService"] = "N"
        masterTransactDataJson["newServiceCssClass"] = " "
        masterTransactDataJson["newServiceStatus"] = false
      } else {

        masterTransactDataJson["newServiceCssClass"] = "bg-red-500"
        masterTransactDataJson["newServiceStatus"] = true
      }

      masterTransactDataJson["region"] = masterData[i]["Column 2"]

      if (masterData[i]["Column 3"] == " " || masterData[i]["Column 3"] == "" || masterData[i]["Column 3"] == undefined) {
        masterTransactDataJson["portfolio"] = masterData[i]["Column 3"]
        masterTransactDataJson["portfolioCssClass"] = "bg-red-500"
        masterTransactDataJson["portfolioStatus"] = true
      } else {
        masterTransactDataJson["portfolio"] = masterData[i]["Column 3"]
        masterTransactDataJson["portfolioCssClass"] = " "
        masterTransactDataJson["portfolioStatus"] = false
      }

      if (masterData[i]["Column 4"] == " " || masterData[i]["Column 4"] == "" || masterData[i]["Column 4"] == undefined) {
        masterTransactDataJson["applicationCSI"] = masterData[i]["Column 4"]
        masterTransactDataJson["applicationCSIStatus"] = true
        masterTransactDataJson["applicationCSICssClass"] = "bg-red-500"
      } else {
        masterTransactDataJson["applicationCSI"] = masterData[i]["Column 4"]
        masterTransactDataJson["applicationCSICssClass"] = " "
        masterTransactDataJson["applicationCSIStatus"] = false
      }


      if (masterData[i]["Column 5"] == " " || masterData[i]["Column 5"] == undefined) {
        masterTransactDataJson["applicationName"] = masterData[i]["Column 5"]
        masterTransactDataJson["applicationNameCssClass"] = "bg-red-500"
        masterTransactDataJson["applicationNameStatus"] = true
      } else {
        masterTransactDataJson["applicationName"] = masterData[i]["Column 5"]
        masterTransactDataJson["applicationNameCssClass"] = " "
        masterTransactDataJson["applicationNameStatus"] = false
      }

      if (isNaN(masterData[i]["Column 6"]) && masterData[i]["Column 6"] != undefined) {
        masterTransactDataJson["interfaces"] = masterData[i]["Column 6"]
        masterTransactDataJson["interfacesCssClass"] = "bg-red-500"
        masterTransactDataJson["interfacesStatus"] = true
      } else if (masterData[i]["Column 6"] == " " || masterData[i]["Column 6"] == "" || masterData[i]["Column 6"] == undefined) {
        masterTransactDataJson["interfaces"] = 0
        masterTransactDataJson["interfacesCssClass"] = " "
        masterTransactDataJson["interfacesStatus"] = false
      } else {
        masterTransactDataJson["interfaces"] = masterData[i]["Column 6"]
        masterTransactDataJson["interfacesCssClass"] = " "
        masterTransactDataJson["interfacesStatus"] = false
      }

      if (isNaN(masterData[i]["Column 7"]) && masterData[i]["Column 7"] != undefined) {
        masterTransactDataJson["internalFiles"] = masterData[i]["Column 7"]
        masterTransactDataJson["internalFilesCssClass"] = "bg-red-500"
        masterTransactDataJson["internalFilesStatus"] = true
      } else if (masterData[i]["Column 7"] == " " || masterData[i]["Column 7"] == "" || masterData[i]["Column 7"] == undefined) {
        masterTransactDataJson["internalFiles"] = 0
        masterTransactDataJson["internalFilesCssClass"] = " "
        masterTransactDataJson["internalFilesStatus"] = false
      } else {
        masterTransactDataJson["internalFiles"] = masterData[i]["Column 7"]
        masterTransactDataJson["internalFilesCssClass"] = " "
        masterTransactDataJson["internalFilesStatus"] = false
      }

      if (isNaN(masterData[i]["Column 8"]) && masterData[i]["Column 8"] != undefined) {
        masterTransactDataJson["screens"] = masterData[i]["Column 8"]
        masterTransactDataJson["screensCssClass"] = "bg-red-500"
        masterTransactDataJson["screensStatus"] = true
      } else if (masterData[i]["Column 8"] == " " || masterData[i]["Column 8"] == "" || masterData[i]["Column 8"] == undefined) {
        masterTransactDataJson["screens"] = 0
        masterTransactDataJson["screensCssClass"] = " "
        masterTransactDataJson["screensStatus"] = false
      } else {
        masterTransactDataJson["screens"] = masterData[i]["Column 8"]
        masterTransactDataJson["screensCssClass"] = " "
        masterTransactDataJson["screensStatus"] = false
      }

      if (isNaN(masterData[i]["Column 9"]) && masterData[i]["Column 9"] != undefined) {
        masterTransactDataJson["batchJobs"] = masterData[i]["Column 9"]
        masterTransactDataJson["batchJobsStatus"] = true
        masterTransactDataJson["batchJobsCssClass"] = "bg-red-500"
      } else if (masterData[i]["Column 9"] == " " || masterData[i]["Column 9"] == "" || masterData[i]["Column 9"] == undefined) {
        masterTransactDataJson["batchJobs"] = 0
        masterTransactDataJson["batchJobsCssClass"] = " "
        masterTransactDataJson["batchJobsStatus"] = false
      } else {
        masterTransactDataJson["batchJobs"] = masterData[i]["Column 9"]
        masterTransactDataJson["batchJobsCssClass"] = " "
        masterTransactDataJson["batchJobsStatus"] = false
      }

      if (isNaN(masterData[i]["Column 10"]) && masterData[i]["Column 10"] != undefined) {
        masterTransactDataJson["users"] = masterData[i]["Column 10"]
        masterTransactDataJson["usersCssClass"] = "bg-red-500"
        masterTransactDataJson["usersStatus"] = true
      } else if (masterData[i]["Column 10"] == " " || masterData[i]["Column 10"] == "" || masterData[i]["Column 10"] == undefined) {
        masterTransactDataJson["users"] = 0
        masterTransactDataJson["usersCssClass"] = " "
        masterTransactDataJson["usersStatus"] = false
      } else {
        masterTransactDataJson["users"] = masterData[i]["Column 10"]
        masterTransactDataJson["usersCssClass"] = " "
        masterTransactDataJson["usersStatus"] = false
      }

      if (masterData[i]["Column 11"] == "High Level" || masterData[i]["Column 11"] == "Low Level" || masterData[i]["Column 11"] == "COTS" || masterData[i]["Column 11"] == "Niche" || masterData[i]["Column 11"] == " ") {
        masterTransactDataJson["language"] = masterData[i]["Column 11"]
        masterTransactDataJson["languageStatus"] = false
        masterTransactDataJson["languageCssClass"] = " "
      } else {
        masterTransactDataJson["language"] = masterData[i]["Column 11"]
        masterTransactDataJson["languageCssClass"] = "bg-red-500"
        masterTransactDataJson["languageStatus"] = true
      }

      if (masterData[i]["Column 12"] == "Tier 1" || masterData[i]["Column 12"] == "Tier 2" || masterData[i]["Column 12"] == "Tier 3" || masterData[i]["Column 12"] == "Tier 4") {
        masterTransactDataJson["criticality"] = masterData[i]["Column 12"]
        masterTransactDataJson["criticalityStatus"] = false
        masterTransactDataJson["criticalityCssClass"] = " "

      } else {
        masterTransactDataJson["criticality"] = masterData[i]["Column 12"]
        masterTransactDataJson["criticalityCssClass"] = "bg-red-500"
        masterTransactDataJson["criticalityStatus"] = true
      }

      if ((masterData[i]["Column 13"] == "10X5") || (masterData[i]["Column 13"] == "24X7")||(masterData[i]["Column 13"] == "8X5")) {
        masterTransactDataJson["coverage"] = masterData[i]["Column 13"]
        masterTransactDataJson["coverageStatus"] = false
        masterTransactDataJson["coverageCssClass"] = " "
      } else {
        masterTransactDataJson["coverage"] = masterData[i]["Column 13"]
        masterTransactDataJson["coverageCssClass"] = "bg-red-500"
        masterTransactDataJson["coverageStatus"] = true
      }

      if ((masterData[i]["Column 14"] == "Stable") || (masterData[i]["Column 14"] == "Unstable") || (masterData[i]["Column 14"] == "Moderate")) {
        masterTransactDataJson["stability"] = masterData[i]["Column 14"]
        masterTransactDataJson["stabilityStatus"] = false
        masterTransactDataJson["stabilityCssClass"] = " "
      } else {
        masterTransactDataJson["stability"] = masterData[i]["Column 14"]
        masterTransactDataJson["stabilityCssClass"] = "bg-red-500"
        masterTransactDataJson["stabilityStatus"] = true
      }

      masterTransactDataJson["actCSI"] = masterData[i]["Column 15"]
      masterTransactDataJson["dup"] = masterData[i]["Column 16"]

      const filterTransactData = transactData.filter(
        (transact: any) => (transact["Column 2"] === masterData[i]["Column 4"]) && (transact["Column 4"] === masterData[i]["Column 3"]));

      const transactionDate = filterTransactData[0]["Column 1"];
      const baseDate = new Date(1900, 0, 1);
      const convertedDate = new Date(baseDate.getTime() + (transactionDate - 1) * 24 * 60 * 60 * 1000);
      const dateString = convertedDate.toLocaleDateString("en-US", { month: "long", year: "numeric" });


      masterTransactDataJson["transactionDate"] = dateString

      if (isNaN(filterTransactData[0]["Column 5"]) && filterTransactData[0]["Column 5"] != undefined) {

        masterTransactDataJson["majorIncident"] = filterTransactData[0]["Column 5"]
        masterTransactDataJson["majorIncidentCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 5"] == " " || filterTransactData[0]["Column 5"] == "" || filterTransactData[0]["Column 5"] == undefined) {
        masterTransactDataJson["majorIncidentCssClass"] = " "
        masterTransactDataJson["majorIncident"] = 0
      } else {
        masterTransactDataJson["majorIncident"] = filterTransactData[0]["Column 5"].toFixed(2)
        masterTransactDataJson["majorIncidentCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 6"]) && filterTransactData[0]["Column 6"] != undefined) {
        masterTransactDataJson["batchIncident"] = filterTransactData[0]["Column 6"]
        masterTransactDataJson["batchIncidentCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 6"] == " " || filterTransactData[0]["Column 6"] == "" || filterTransactData[0]["Column 6"] == undefined) {
        masterTransactDataJson["batchIncident"] = 0
        masterTransactDataJson["batchIncidentCssClass"] = " "
      } else {
        masterTransactDataJson["batchIncident"] = filterTransactData[0]["Column 6"].toFixed(2)
        masterTransactDataJson["batchIncidentCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 7"]) && filterTransactData[0]["Column 7"] != undefined) {
        masterTransactDataJson["userIncident"] = filterTransactData[0]["Column 7"]
        masterTransactDataJson["userIncidentCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 7"] == " " || filterTransactData[0]["Column 7"] == "" || filterTransactData[0]["Column 7"] == undefined) {
        masterTransactDataJson["userIncident"] = 0
        masterTransactDataJson["userIncidentCssClass"] = " "
      } else {
        masterTransactDataJson["userIncident"] = filterTransactData[0]["Column 7"].toFixed(2)
        masterTransactDataJson["userIncidentCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 8"]) && filterTransactData[0]["Column 8"] != undefined) {
        masterTransactDataJson["userQuery"] = filterTransactData[0]["Column 8"]
        masterTransactDataJson["userQueryCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 8"] == " " || filterTransactData[0]["Column 8"] == "" || filterTransactData[0]["Column 8"] == undefined) {
        masterTransactDataJson["userQuery"] = 0
        masterTransactDataJson["userQueryCssClass"] = " "
      } else {
        masterTransactDataJson["userQuery"] = filterTransactData[0]["Column 8"].toFixed(2)
        masterTransactDataJson["userQueryCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 9"]) && filterTransactData[0]["Column 9"] != undefined) {
        masterTransactDataJson["problemTicket"] = filterTransactData[0]["Column 9"]
        masterTransactDataJson["problemTicketCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 9"] == " " || filterTransactData[0]["Column 9"] == "" || filterTransactData[0]["Column 9"] == undefined) {
        masterTransactDataJson["problemTicket"] = 0
        masterTransactDataJson["problemTicketCssClass"] = " "
      } else {
        masterTransactDataJson["problemTicket"] = filterTransactData[0]["Column 9"].toFixed(2)
        masterTransactDataJson["problemTicketCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 10"]) && filterTransactData[0]["Column 10"] != undefined) {
        masterTransactDataJson["changeRequest"] = filterTransactData[0]["Column 10"]
        masterTransactDataJson["changeRequestCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 10"] == " " || filterTransactData[0]["Column 10"] == "" || filterTransactData[0]["Column 10"] == undefined) {
        masterTransactDataJson["changeRequest"] = 0
        masterTransactDataJson["changeRequestCssClass"] = " "
      } else {
        masterTransactDataJson["changeRequest"] = filterTransactData[0]["Column 10"].toFixed(2)
        masterTransactDataJson["changeRequestCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 11"]) && filterTransactData[0]["Column 11"] != undefined) {
        masterTransactDataJson["serviceRequest"] = filterTransactData[0]["Column 11"]
        masterTransactDataJson["serviceRequestCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 11"] == " " || filterTransactData[0]["Column 11"] == "" || filterTransactData[0]["Column 11"] == undefined) {
        masterTransactDataJson["serviceRequest"] = 0
        masterTransactDataJson["serviceRequestCssClass"] = " "
      } else {
        masterTransactDataJson["serviceRequest"] = filterTransactData[0]["Column 11"].toFixed(2)
        masterTransactDataJson["serviceRequestCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 12"]) && filterTransactData[0]["Column 12"] != undefined) {
        masterTransactDataJson["adhocRequest"] = filterTransactData[0]["Column 12"]
        masterTransactDataJson["adhocRequestCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 12"] == " " || filterTransactData[0]["Column 12"] == "" || filterTransactData[0]["Column 12"] == undefined) {
        masterTransactDataJson["adhocRequest"] = 0
        masterTransactDataJson["adhocRequestCssClass"] = " "
      } else {
        masterTransactDataJson["adhocRequest"] = filterTransactData[0]["Column 12"].toFixed(2)
        masterTransactDataJson["adhocRequestCssClass"] = " "
      }

      if (isNaN(filterTransactData[0]["Column 13"]) && filterTransactData[0]["Column 13"] != undefined) {
        masterTransactDataJson["alerts"] = filterTransactData[0]["Column 13"]
        masterTransactDataJson["alertsCssClass"] = "bg-red-500"
      } else if (filterTransactData[0]["Column 13"] == " " || filterTransactData[0]["Column 13"] == "" || filterTransactData[0]["Column 13"] == undefined) {
        masterTransactDataJson["alerts"] = 0
        masterTransactDataJson["alertsCssClass"] = " "
      } else {
        masterTransactDataJson["alerts"] = filterTransactData[0]["Column 13"]
        masterTransactDataJson["alertsCssClass"] = " "
      }

      tempMasterTransactData.push(masterTransactDataJson)

    }

    let uniqueAPIFilterArray: any = []
    if (result.status == "fulfilled" && result.data.masterData.length > 0) {
      uniqueAPIFilterArray = result.data.masterData.filter((apiArray: any) => !tempMasterTransactData.some((excelArray: any) => (excelArray.applicationCSI === apiArray.applicationCSI) && (excelArray.portfolio === apiArray.portfolio)))
    }

    setValidatedMasterTransactData([...tempMasterTransactData, ...uniqueAPIFilterArray]);
    // setValidatedMasterTransactData(tempMasterTransactData)
  }


  const validateMasterTransactDataSave = (masterTransactData: any, index: any) => {

console.log(index)

    if (masterTransactData.newService == "Y" || masterTransactData.newService == "N") {

      masterTransactData["newService"] = masterTransactData.newService
      masterTransactData["newServiceStatus"] = false
      masterTransactData.newServiceCssClass = " "
    } else if (masterTransactData.newService == "" || masterTransactData.newService == " " || masterTransactData.newService == undefined) {

      masterTransactData["newService"] = "N"
      masterTransactData["newServiceCssClass"] = " "
      masterTransactData["newServiceStatus"] = false
    } else {

      masterTransactData["newServiceCssClass"] = "bg-red-500"
      masterTransactData["newServiceStatus"] = true
    }
    masterTransactData["region"] = masterTransactData.region
    if (masterTransactData.portfolio == " " || masterTransactData.portfolio == "" || masterTransactData.portfolio == undefined) {
      masterTransactData["portfolio"] = masterTransactData.portfolio
      masterTransactData["portfolioCssClass"] = "bg-red-500"
      masterTransactData["portfolioStatus"] = true
    } else {
      masterTransactData["portfolio"] = masterTransactData.portfolio
      masterTransactData["portfolioCssClass"] = " "
      masterTransactData["portfolioStatus"] = false
    }
    if (masterTransactData.applicationCSI == " " || masterTransactData.applicationCSI == "" || masterTransactData.applicationCSI == undefined) {
      masterTransactData["applicationCSI"] = masterTransactData.applicationCSI
      masterTransactData["applicationCSICssClass"] = "bg-red-500"
      masterTransactData["applicationCSIStatus"] = true
    } else {
      masterTransactData["applicationCSI"] = masterTransactData.applicationCSI
      masterTransactData["applicationCSICssClass"] = " "
      masterTransactData["applicationCSIStatus"] = false
    }

    if (masterTransactData.applicationName == " " || masterTransactData.applicationName == undefined) {
      masterTransactData["applicationName"] = masterTransactData.applicationName
      masterTransactData["applicationNameStatus"] = true
      masterTransactData["applicationNameCssClass"] = "bg-red-500"
    } else {
      masterTransactData["applicationName"] = masterTransactData.applicationName
      masterTransactData["applicationNameCssClass"] = " "
      masterTransactData["applicationNameStatus"] = false
    }

    if (isNaN(masterTransactData.interfaces) && masterTransactData.interfaces != undefined) {
      masterTransactData["interfaces"] = masterTransactData.interfaces
      masterTransactData["interfacesCssClass"] = "bg-red-500"
      masterTransactData["interfacesStatus"] = true
    } else if (masterTransactData.interfaces == " " || masterTransactData.interfaces == "" || masterTransactData.interfaces == undefined) {
      masterTransactData["interfaces"] = 0
      masterTransactData["interfacesCssClass"] = " "
      masterTransactData["interfacesStatus"] = false
    } else {
      masterTransactData["interfaces"] = masterTransactData.interfaces
      masterTransactData["interfacesCssClass"] = " "
      masterTransactData["interfacesStatus"] = false
    }

    if (isNaN(masterTransactData.internalFiles) && masterTransactData.internalFiles != undefined) {
      masterTransactData["internalFiles"] = masterTransactData.internalFiles
      masterTransactData["internalFilesStatus"] = true
      masterTransactData["internalFilesCssClass"] = "bg-red-500"
    } else if (masterTransactData.internalFiles == " " || masterTransactData.internalFiles == "" || masterTransactData.internalFiles == undefined) {
      masterTransactData["internalFiles"] = 0
      masterTransactData["internalFilesCssClass"] = " "
      masterTransactData["internalFilesStatus"] = false
    } else {
      masterTransactData["internalFiles"] = masterTransactData.internalFiles
      masterTransactData["internalFilesCssClass"] = " "
      masterTransactData["internalFilesStatus"] = false
    }

    if (isNaN(masterTransactData.screens) && masterTransactData.screens != undefined) {
      masterTransactData["screens"] = masterTransactData.screens
      masterTransactData["screensStatus"] = true
      masterTransactData["screensCssClass"] = "bg-red-500"
    } else if (masterTransactData.screens == " " || masterTransactData.screens == "" || masterTransactData.screens == undefined) {
      masterTransactData["screens"] = 0
      masterTransactData["screensCssClass"] = " "
      masterTransactData["screensStatus"] = false
    } else {
      masterTransactData["screens"] = masterTransactData.screens
      masterTransactData["screensCssClass"] = " "
      masterTransactData["screensStatus"] = false
    }

    if (isNaN(masterTransactData.batchJobs) && masterTransactData.batchJobs != undefined) {
      masterTransactData["batchJobs"] = masterTransactData.batchJobs
      masterTransactData["batchJobsStatus"] = true
      masterTransactData["batchJobsCssClass"] = "bg-red-500"
    } else if (masterTransactData.batchJobs == " " || masterTransactData.batchJobs == "" || masterTransactData.batchJobs == undefined) {
      masterTransactData["batchJobs"] = 0
      masterTransactData["batchJobsCssClass"] = " "
      masterTransactData["batchJobsStatus"] = false
    } else {
      masterTransactData["batchJobs"] = masterTransactData.batchJobs
      masterTransactData["batchJobsCssClass"] = " "
      masterTransactData["batchJobsStatus"] = false
    }
    if (isNaN(masterTransactData.users) && masterTransactData.users != undefined) {
      masterTransactData["users"] = masterTransactData.users
      masterTransactData["usersCssClass"] = "bg-red-500"
      masterTransactData["usersStatus"] = true
    } else if (masterTransactData.users == " " || masterTransactData.users == "" || masterTransactData.users == undefined) {
      masterTransactData["users"] = 0
      masterTransactData["usersCssClass"] = " "
      masterTransactData["usersStatus"] = false
    } else {
      masterTransactData["users"] = masterTransactData.users
      masterTransactData["usersCssClass"] = " "
      masterTransactData["usersStatus"] = false
    }

    if (masterTransactData.language == "High Level" || masterTransactData.language == "Low Level" || masterTransactData.language == "COTS" || masterTransactData.language == "Niche" || masterTransactData.language == " ") {
      masterTransactData["language"] = masterTransactData.language
      masterTransactData["languageCssClass"] = " "
      masterTransactData["languageStatus"] = false
    } else {
      masterTransactData["language"] = masterTransactData.language
      masterTransactData["languageCssClass"] = "bg-red-500"
      masterTransactData["languageStatus"] = true
    }

    if (masterTransactData.criticality == "Tier 1" || masterTransactData.criticality == "Tier 2" || masterTransactData.criticality == "Tier 3" || masterTransactData.criticality == "Tier 4") {
      masterTransactData["criticality"] = masterTransactData.criticality
      masterTransactData["criticalityStatus"] = false
      masterTransactData["criticalityCssClass"] = " "

    } else {
      masterTransactData["criticality"] = masterTransactData.criticality
      masterTransactData["criticalityCssClass"] = "bg-red-500"
      masterTransactData["criticalityStatus"] = true
    }

    if ((masterTransactData.coverage == "10X5") || (masterTransactData.coverage == "24X7")|| (masterTransactData.coverage == "8X5")) {
      masterTransactData["coverage"] = masterTransactData.coverage
      masterTransactData["coverageStatus"] = false
      masterTransactData["coverageCssClass"] = " "
    } else {
      masterTransactData["coverage"] = masterTransactData.coverage
      masterTransactData["coverageCssClass"] = "bg-red-500"
      masterTransactData["coverageStatus"] = true
    }

    if ((masterTransactData.stability == "Stable") || (masterTransactData.stability == "Unstable") || (masterTransactData.stability == "Moderate")) {
      masterTransactData["stability"] = masterTransactData.stability
      masterTransactData["stabilityCssClass"] = " "
      masterTransactData["stabilityStatus"] = false
    } else {
      masterTransactData["stability"] = masterTransactData.stability
      masterTransactData["stabilityCssClass"] = "bg-red-500"
      masterTransactData["stabilityStatus"] = true
    }

    masterTransactData["actCSI"] = masterTransactData.actCSI
    masterTransactData["dup"] = masterTransactData.dup
    //masterData["column1"] = masterData.column1
    masterTransactData["transactionDate"] = masterTransactData.transactionDate
    if (isNaN(masterTransactData.majorIncident) && masterTransactData.majorIncident != undefined) {

      masterTransactData["majorIncident"] = masterTransactData.majorIncident
      masterTransactData["majorIncidentCssClass"] = "bg-red-500"
    } else if (masterTransactData.majorIncident == " " || masterTransactData.majorIncident == "" || masterTransactData.majorIncident == undefined) {
      // majorIncidentCssClass
      masterTransactData["majorIncidentCssClass"] = " "
      masterTransactData["majorIncident"] = 0
    } else {

      masterTransactData["majorIncident"] = masterTransactData.majorIncident
      masterTransactData["majorIncidentCssClass"] = " "
    }

    if (isNaN(masterTransactData.batchIncident) && masterTransactData.batchIncident != undefined) {
      masterTransactData["batchIncident"] = masterTransactData.batchIncident
      masterTransactData["batchIncidentCssClass"] = "bg-red-500"
    } else if (masterTransactData.batchIncident == " " || masterTransactData.batchIncident == "" || masterTransactData.batchIncident == undefined) {
      masterTransactData["batchIncident"] = 0
      masterTransactData["batchIncidentCssClass"] = " "
    } else {
      masterTransactData["batchIncident"] = masterTransactData.batchIncident
      masterTransactData["batchIncidentCssClass"] = " "
    }

    if (isNaN(masterTransactData.userIncident) && masterTransactData.userIncident != undefined) {
      masterTransactData["userIncident"] = masterTransactData.userIncident
      masterTransactData["userIncidentCssClass"] = "bg-red-500"
    } else if (masterTransactData.userIncident == " " || masterTransactData.userIncident == "" || masterTransactData.userIncident == undefined) {
      masterTransactData["userIncident"] = 0
      masterTransactData["userIncidentCssClass"] = " "
    } else {
      masterTransactData["userIncident"] = masterTransactData.userIncident
      masterTransactData["userIncidentCssClass"] = " "
    }

    if (isNaN(masterTransactData.userQuery) && masterTransactData.userQuery != undefined) {
      masterTransactData["userQuery"] = masterTransactData.userQuery
      masterTransactData["userQueryCssClass"] = "bg-red-500"
    } else if (masterTransactData.userQuery == " " || masterTransactData.userQuery == "" || masterTransactData.userQuery == undefined) {
      masterTransactData["userQuery"] = 0
      masterTransactData["userQueryCssClass"] = " "
    } else {
      masterTransactData["userQuery"] = masterTransactData.userQuery
      masterTransactData["userQueryCssClass"] = " "
    }

    if (isNaN(masterTransactData.problemTicket) && masterTransactData.problemTicket != undefined) {
      masterTransactData["problemTicket"] = masterTransactData.problemTicket
      masterTransactData["problemTicketCssClass"] = "bg-red-500"
    } else if (masterTransactData.problemTicket == " " || masterTransactData.problemTicket == "" || masterTransactData.problemTicket == undefined) {
      masterTransactData["problemTicket"] = 0
      masterTransactData["problemTicketCssClass"] = " "
    } else {
      masterTransactData["problemTicket"] = masterTransactData.problemTicket
      masterTransactData["problemTicketCssClass"] = " "
    }


    if (isNaN(masterTransactData.changeRequest) && masterTransactData.changeRequest != undefined) {
      masterTransactData["changeRequest"] = masterTransactData.changeRequest
      masterTransactData["changeRequestCssClass"] = "bg-red-500"
    } else if (masterTransactData.changeRequest == " " || masterTransactData.changeRequest == "" || masterTransactData.changeRequest == undefined) {
      masterTransactData["changeRequest"] = 0
      masterTransactData["changeRequestCssClass"] = " "
    } else {
      masterTransactData["changeRequest"] = masterTransactData.changeRequest
      masterTransactData["changeRequestCssClass"] = " "
    }

    if (isNaN(masterTransactData.serviceRequest) && masterTransactData.serviceRequest != undefined) {
      masterTransactData["serviceRequest"] = masterTransactData.serviceRequest
      masterTransactData["serviceRequestCssClass"] = "bg-red-500"
    } else if (masterTransactData.serviceRequest == " " || masterTransactData.serviceRequest == "" || masterTransactData.serviceRequest == undefined) {
      masterTransactData["serviceRequest"] = 0
      masterTransactData["serviceRequestCssClass"] = " "
    } else {
      masterTransactData["serviceRequest"] = masterTransactData.serviceRequest
      masterTransactData["serviceRequestCssClass"] = " "
    }

    if (isNaN(masterTransactData.adhocRequest) && masterTransactData.adhocRequest != undefined) {
      masterTransactData["adhocRequest"] = masterTransactData.adhocRequest
      masterTransactData["adhocRequestCssClass"] = "bg-red-500"
    } else if (masterTransactData.adhocRequest == " " || masterTransactData.adhocRequest == "" || masterTransactData.adhocRequest == undefined) {
      masterTransactData["adhocRequest"] = 0
      masterTransactData["adhocRequestCssClass"] = " "
    } else {
      masterTransactData["adhocRequest"] = masterTransactData.adhocRequest
      masterTransactData["adhocRequestCssClass"] = " "
    }


    if (isNaN(masterTransactData.alerts) && masterTransactData.alerts != undefined) {
      masterTransactData["alerts"] = masterTransactData.alerts
      masterTransactData["alertsCssClass"] = "bg-red-500"
    } else if (masterTransactData.alerts == " " || masterTransactData.alerts == "" || masterTransactData.alerts == undefined) {
      masterTransactData["alerts"] = 0
      masterTransactData["alertsCssClass"] = " "
    } else {
      masterTransactData["alerts"] = masterTransactData.alerts
      masterTransactData["alertsCssClass"] = " "
    }


    //const updatedData = [...validatedMasterTransactData]

    const updatedData = validatedMasterTransactData.map((item: any) =>
      item.applicationCSI === masterTransactData.applicationCSI ? masterTransactData : item
    )

    // updatedData.splice(index, 1, masterTransactData);
    //setValidatedMasterData(updatedData);
    setValidatedMasterTransactData(updatedData)


  }


  const renderTable = (checkData: any) => (
    <div className="mt-4">

      <div className={`overflow-y-scroll overflow-x-scroll ${styles['scrollbar-custom']} h-80`} >

        <Table className="w-full" >
          <TableHeader className="sticky top-0 bg-violet-400">
            <TableRow>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">New Service</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Region</TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[150px] place-items-center  text-center">Portfolio
                <br></br>
                <input
                  type="text"

                  name="portfolio"
                  value={filters.portfolio}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "50%"
                  }}
                />
              </TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[160px] place-items-center  text-center">Application CSI
                <br></br>
                <input
                  type="text"

                  name="applicationCSI"
                  value={filters.applicationCSI}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "50%"
                  }}
                />
              </TableHead>
              {/* <TableHead style={{ color: "white" }} className="min-w-[185px] place-items-center  text-center">Application Name</TableHead> */}
              <TableHead style={{ color: "white" }} className="place-items-center  text-center z-[999]">Interfaces</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Internal Files</TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[70px] place-items-center  text-center">Screens</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Batch Jobs</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Users</TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[86px] place-items-center  text-center">Language
                <br></br>
                <input
                  type="text"
                  placeholder=" "
                  name="language"
                  value={filters.language}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "80%"
                  }}
                />
              </TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Criticality
                <br></br>
                <input
                  type="text"
                  placeholder=" "
                  name="criticality"
                  value={filters.criticality}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "80%"
                  }}
                />
              </TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Coverage</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Stability
                <br></br>
                <input
                  type="text"
                  placeholder=" "
                  name="stability"
                  value={filters.stability}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "80%"
                  }}
                />
              </TableHead>
              {/* <TableHead style={{ color: "white" }} className="place-items-center  text-center">Act CSI</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">DUP</TableHead> */}
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="border-0">
            {checkData.length > 0 ? (
              checkData.map((mData: any, i: any) => {
                return (
                  <TableRow
                    key={i}
                    className={cn(
                      "group/team-row border-0",
                      i % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                    )}
                    style={{
                      borderBottom: "0.5px solid grey"
                    }}>

                    <TableCell className={`place-items-center   text-center ${mData.newServiceCssClass}`}> {editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.newService} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "newService", e.target.value)} />) : (mData.newService)}
                      {editRowIndex === i && mData.newServiceStatus == true &&
                        <p className="text-xs ">* Value is undefined</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center `}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.region} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "region", e.target.value)} />) : (mData.region)}

                    </TableCell>
                    <TableCell className={`place-items-center  text-center border-slate-50 ${mData.portfolioCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.portfolio} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "portfolio", e.target.value)} />) : (mData.portfolio)}
                      {editRowIndex === i && mData.portfolioStatus == true &&
                        <p className="text-xs">* Value is undefined</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.applicationCSICssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.applicationCSI} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "applicationCSI", e.target.value)} />) : (mData.applicationCSI)}
                      {editRowIndex === i && mData.applicationCSIStatus == true &&
                        <p className="text-xs">* Value is undefined</p>}
                    </TableCell>
                    {/* <TableCell className={`place-items-center  text-center ${mData.applicationNameCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.applicationName} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "applicationName", e.target.value)} />) : (mData.applicationName)}
                      {editRowIndex === i && mData.applicationNameStatus == true &&
                        <p className="text-xs ">* Value is undefined</p>}
                    </TableCell> */}
                    {/* <TableCell  className={`place-items-center  text-center ${mData.newServiceCssClass}`}  >{mData.interfaces}</TableCell> */}
                    <TableCell className={`place-items-center  text-center relative bottom-px ${mData.interfacesCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.interfaces} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "interfaces", e.target.value)} />) : (mData.interfaces)
                    }
                      {editRowIndex === i && mData.interfacesStatus == true &&
                        <p className="text-xs ">* Value is not Numaric</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.internalFilesCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.internalFiles} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "internalFiles", e.target.value)} />) : (mData.internalFiles)}
                      {editRowIndex === i && mData.internalFilesStatus == true &&
                        <p className="text-xs ">*  Value is not Numaric</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.screensCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.screens} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "screens", e.target.value)} />) : (mData.screens)}
                      {editRowIndex === i && mData.screensStatus == true &&
                        <p className="text-xs ">* Value is not Numaric</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.batchJobsCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.batchJobs} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "batchJobs", e.target.value)} />) : (mData.batchJobs)}
                      {editRowIndex === i && mData.batchJobsStatus == true &&
                        <p className="text-xs ">* Value is not Numaric</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.usersCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.users} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "users", e.target.value)} />) : (mData.users)}
                      {editRowIndex === i && mData.usersStatus == true &&
                        <p className="text-xs ">* Value is not Numaric</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.languageCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.language} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "language", e.target.value)} />) : (mData.language)}
                      {editRowIndex === i && mData.languageStatus == true &&
                        <p className="text-xs">* Value did not contain string "High Level" ,"Low Level","COTS","Niche"</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.criticalityCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.criticality} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "criticality", e.target.value)} />) : (mData.criticality)}
                      {editRowIndex === i && mData.criticalityStatus == true &&
                        <p className="text-xs ">* Value did not contain string "Tier 1" or "Tier 2" or "Tier 3" or "Tier 4"</p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center  ${mData.coverageCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600 " type="text" value={mData.coverage} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "coverage", e.target.value)} />) : (mData.coverage)}
                      {editRowIndex === i && mData.coverageStatus == true &&
                        <p className="text-xs ">* Value did not contain  string "10X5" or "24X7" </p>}
                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.stabilityCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.stability} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "stability", e.target.value)} />) : (mData.stability)}
                      {editRowIndex === i && mData.stabilityStatus == true &&
                        <p className="text-xs">* Value did not contain string "Stable" or "Unstable" or "Moderate"  </p>

                      }
                    </TableCell>
                    {/* <TableCell className={`place-items-center  text-center ${mData.actCSICssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.actCSI} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "actCSI", e.target.value)} />) : (mData.actCSI)}

                    </TableCell>
                    <TableCell className={`place-items-center  text-center ${mData.dupCssClass}`}  >{editRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.dup} onKeyDown={(e) => handleKeyDownMasterData(e, mData, i)} onChange={(e) => handleEditChange(mData, "dup", e.target.value)} />) : (mData.dup)}

                    </TableCell> */}
                    <TableCell className={`place-items-center  text-center `}  >{editRowIndex === i ? (<button className="text-lime-600 hover:text-red-700" onClick={() => handleSaveClick(mData, i)}>Save</button>) : <button className="text-amber-300 hover:text-red-700" onClick={() => handleEditClick(i)}>Edit</button>}</TableCell>


                  </TableRow>
                );
              })) : (<TableRow><TableCell colSpan={12} className={`place-items-center  text-center `} >No Data Found</TableCell></TableRow>)
            }
          </TableBody>
        </Table>
      </div>

    </div>
  );

  const renderTransactTable = (checkData: any) => (
    <div className="mt-4">


      <div className={`overflow-y-scroll overflow-x-scroll ${styles['scrollbar-custom']} h-80`}>

        <Table className="w-full">
          <TableHeader className="sticky top-0 bg-violet-400">
            <TableRow>
              <TableHead style={{ color: "white" }} className="min-w-[94px] place-items-center   text-center">Transaction Date</TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[185px] place-items-center  text-center">Application CSI<br></br>
                <input
                  type="text"
                  placeholder=" "
                  name="applicationCSI"
                  value={filters.applicationCSI}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "50%"
                  }}
                />
              </TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Region</TableHead>
              <TableHead style={{ color: "white" }} className="min-w-[150px] place-items-center  text-center">Portfolio <br></br>
                <input
                  type="text"
                  placeholder=" "
                  name="portfolio"
                  value={filters.portfolio}
                  onChange={handleFilterChange}
                  className="mb-2 mt-1 p-1 border border-gray-300 rounded"
                  style={{
                    color: "#a855f7",
                    width: "50%"
                  }}
                />
              </TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Major Incident</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Batch Incident</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">User Incident</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">User Queries</TableHead>
              <TableHead style={{ color: "white" }} className="max-w-[60px] min-w-[50px] place-items-center  text-center">Problem Tickets</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Change Requests</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Service Requests</TableHead>
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">ADHOC Requests</TableHead>
              {/* <TableHead className="place-items-center  text-center">Alerts</TableHead> */}
              {/* <TableHead style={{ color: "white" }} className="place-items-center  text-center">DUP</TableHead> */}
              <TableHead style={{ color: "white" }} className="place-items-center  text-center">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="border-0">
            {checkData.length > 0 ? (
              checkData.map((mData: any, i: any) => {
                return (
                  <TableRow
                    key={i}
                    className={cn(
                      "group/team-row border-0",
                      i % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                    )}
                    style={{
                      borderBottom: "0.5px solid grey"
                    }}
                  >

                    <TableCell className=" place-items-center  text-center" > {editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.transactionDate} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "transactionDate", e.target.value)} />) : (mData.transactionDate)}</TableCell>
                    <TableCell className=" place-items-center  text-center"  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.applicationCSI} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "applicationCSI", e.target.value)} />) : (mData.applicationCSI)}</TableCell>
                    <TableCell className=" place-items-center  text-center"  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.region} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "region", e.target.value)} />) : (mData.region)}</TableCell>
                    <TableCell className=" place-items-center  text-center"  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.portfolio} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "portfolio", e.target.value)} />) : (mData.portfolio)}</TableCell>
                    <TableCell className={`place-items-center  text-center  ${mData.majorIncidentCssClass}`}   >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.majorIncident} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "majorIncident", e.target.value)} />) : (mData.majorIncident)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.batchIncidentCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.batchIncident} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "batchIncident", e.target.value)} />) : (mData.batchIncident)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.userIncidentCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.userIncident} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "userIncident", e.target.value)} />) : (mData.userIncident)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.userQueryCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.userQuery} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "userQuery", e.target.value)} />) : (mData.userQuery)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.problemTicketCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.problemTicket} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "problemTicket", e.target.value)} />) : (mData.problemTicket)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.changeRequestCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.changeRequest} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "changeRequest", e.target.value)} />) : (mData.changeRequest)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.serviceRequestCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.serviceRequest} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "serviceRequest", e.target.value)} />) : (mData.serviceRequest)}</TableCell>
                    <TableCell className={`place-items-center  text-center mb-2 ${mData.adhocRequestCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.adhocRequest} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "adhocRequest", e.target.value)} />) : (mData.adhocRequest)}</TableCell>
                    {/* <TableCell className={`place-items-center  text-center ${mData.alertsCssClass}`}  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.alerts} onChange={(e) => handleEditChange(mData, "alerts", e.target.value)} />) : (parseFloat(mData.alerts)).toFixed(2)}</TableCell> */}
                    {/* <TableCell className=" place-items-center  text-center"  >{editTransactRowIndex === i ? (<input className="text-gray-600" type="text" value={mData.dup} onKeyDown={(e) => handleKeyDownTransactData(e, mData, i)} onChange={(e) => handleEditChange(mData, "dup", e.target.value)} />) : (mData.dup)}</TableCell> */}
                    <TableCell className=" place-items-center  text-center "  >{editTransactRowIndex === i ? (<button className="text-lime-600 hover:text-red-700" onClick={() => handleTransactSaveClick(mData, i)}>Save</button>) : <button className="text-amber-300 hover:text-red-700" onClick={() => handleTransactEditClick(i)}>Edit</button>}</TableCell>


                  </TableRow>
                );
              })) : (<TableRow><TableCell colSpan={14} className={`place-items-center  text-center `} >No Data Found</TableCell></TableRow>)
            }
          </TableBody>
        </Table>
      </div>

    </div>
  );

  return (
    <>
      <div className="flex">



        <div className="flex-none  ">
          <div className="mt-5 ml-16 border-2 border-black-800 p-3 rounded-md w-1/1 ">
            {/* <h2 className="text-lg font-bold mb-6 text-muted-foreground uppercase ml-3">Account Details</h2> */}
            <div className="flex items-center gap-4 mb-4">
              <label htmlFor="accountSelect" className="font-normal ml-3">Account Name</label>
              <select onChange={handleAccountChange} id="accountSelect" className="p-2 py-1 border rounded-md dark:bg-gray-700 text-black-400 dark:border-gray-600 border-2-gray-600 focus outline-none" value={selectedAccount} >
                <option value="" disabled hidden>Select Account Name</option>
                {accounts.map((account:any) => (
                  <option key={account.label} value={account.value} className="text-gray-200">
                    {account.label}
                  </option>))}
              </select>

              {searchLoder && <PageLoader />}
              <button className="p-2 py-1 px-1 text-sm bg-blue-300 text-white rounded-md dark:bg-blue-600 ml-3" onClick={searchAccountDetailsByName}>

                Search
              </button>
              {accountsDetails && <PageLoader />}
            </div>

          </div>
        </div>
        <div className="flex-none">
          {/* <div className="mt-5 ml-16 border-2 border-black-800 p-3 rounded-md w-1/1 mr-36">
      
          <div className="flex-none">
          <div className={`p-1 bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-lg shadow-lg max-w-md mx-auto text-center cursor-pointer mb-6 border-2 border-dashed border-gray-800 hover:border-blue-600 transition`} onClick={handleUserConsent}>
          <input
            type="file"
            accept=".xls,.xlsx"
            onChange={handleFileUpload}
            className="hidden"
            id="upload-input" />
          <label htmlFor="upload-input" className="cursor-pointer text-gray-400">
            Drag 'n' drop Excel file here, or click to select files
          </label>
          <p className="text-sm text-gray-200">
            (Upload files only with specified template)
          </p>
          <UserConsent open={showUserContent} />
          {hasError && <p className="" text-red-500> {errorMessage}</p>}
        </div>
        {fileName && (
          <div className="max-w-sm mx-auto mb-4 ">
            <p className="text-black-700 font-semibold mb-2 mt-4">Uploaded Files</p>
            <div className="mt-4 bg-gray-200 p-2 rounded-lg flex justify-between items-center">
              <span className="text-gray-700">{fileName}</span>
              <button
                onClick={() => {
                  setFileName(null);
                  setValidatedMasterData([]);
                  setValidatedTransactData([]);
                  setFileSelected(false);
                  setShowData(false);
                } }
                className="text-red-500 hover:text-red-700"
              >
                &times;
              </button>
            </div>
          </div>
        )}
        </div>

         
          <div className="flex-none">
          <div>
          <button
            onClick={handleUploadClick}
            disabled={!fileSelected}
            className={` p-4 w-4/4  -ml-20 rounded-lg text-white ${fileSelected ? `bg-blue-400 hover:bg-blue-600 cursor-pointer` : `bg-gray-400 cursor-not-allowed`}`}
          >
            Upload
          </button>

        </div>
        </div>
    
  
      
       
           </div> */}
        </div>
      </div>



      <div className="mt-6 ml-16" style={{
        width: "100%",

      }}>
        {showAccountDetailsTable &&
          (<div 
            style={{
            width: "55%",
            height: `${gridHeight}px`,
            maxHeight: "200px",
            
          }}>


            <DataGrid
              initialState={{ rowSelection: lastSelectedAccountIndex ? [lastSelectedAccountIndex] : [] }}
              ref={gridRef}
              getRowClass={getRowClass}
              rowData={accountList}
              columnDefs={colDefs}
              pagination={pagination}
              paginationPageSize={paginationPageSize}
              paginationPageSizeSelector={paginationPageSizeSelector}
              // rowSelection={rowSelectionAccountDetails}
              onRowSelected={onRowSelectAccountDetails}
              onSelectionChanged={onRowSelectionChangedAccountDetails}
            />
          </div>)
        }

      </div>

      
      <div className="mt-6 ml-12">

        <div className="flex">

          <div className="flex-none">
            {showAccountDetailsTable && (
              <button className=" p-1.5 w-4/4  -ml-20 rounded-lg text-white bg-blue-400 hover:bg-blue-600 ml-3" onClick={addNewSet} >
                Add New Set
              </button>
            )}
          </div>
          {showFileUploadSection && (
            <div className="flex-none  ">
              <div className={`p-1 bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-lg shadow-lg max-w-md mx-auto text-center cursor-pointer mb-6 border-2 border-dashed border-gray-800 hover:border-blue-600 transition ml-2`} onClick={handleUserConsent}>
                <input
                  type="file"
                  accept=".xls,.xlsx"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="upload-input" />
                <label htmlFor="upload-input" className="cursor-pointer text-gray-200">
                  Upload File
                </label>
                {/* <p className="text-sm text-gray-200">
                   (Upload files only with specified template)
                 </p> */}
                {/* <UserConsent open={showUserContent} /> */}
                {hasError && <p className="" text-red-500> {errorMessage}</p>}
              </div>

            </div>
          )}


          {showFileUploadSection && (
            <div className="flex-none  ">
              <button
                onClick={handleUploadClick}
                disabled={!fileSelected}
                className={`ml-2 p-1.5 w-4/4  -ml-20 rounded-lg text-white ${fileSelected ? `bg-blue-400 hover:bg-blue-600 cursor-pointer` : `bg-gray-400 cursor-not-allowed`}`}
              >
                Upload
              </button>
            </div>
          )}

          <div className="flex-none  ">
            {fileName && (
              <div className="max-w-sm mx-auto mb-4 ">
                {/* <p className="text-black-700 font-semibold mb-2 mt-4">Uploaded Files</p> */}
                <div className=" bg-gray-200 p-1 ml-2 rounded-lg flex justify-between items-center">
                  <span className="text-gray-700">{fileName}</span>
                  <button
                    onClick={() => {

                      setFileName(null);
                      setValidatedMasterTransactData([]);

                      //setFileSelected(false);
                      setShowData(false);
                    }}
                    className="text-red-500 hover:text-red-700" >
                    &times;
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>



      <div className="mt-6 ml-16">

        {/* <h1 className="text-muted-foreground uppercase font-semibold text-gray-700 dark:text-gray-200 mb-4">
          Upload Your SLA Data
        </h1> */}
        {/* <div className="p-6 mt-6 bg-gray-100 dark:bg-gray-800 rounded-lg shadow-lg w-1/2 max-w-4xl mx-auto"> */}




        {/* Uploaded File Name */}


        {/* Render Tables Side by Side */}
        {showData && (
          <div className="mt-4 mr-3 justify-between ">
            <Tabs defaultValue="MasterData" className="">
              <TabsList className=" grid max-w-64 grid-cols-2 rounded-2xl dark:bg-violet-900/10">
                <TabsTrigger
                  value="MasterData"
                  className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal"
                >
                  Master Data
                </TabsTrigger>
                <TabsTrigger
                  value="TransactData"
                  className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-500 data-[state=active]:text-white"
                >
                  Transact Data
                </TabsTrigger>
              </TabsList>
              <TabsContent value="MasterData">
                {renderTable(filteredMasterTransactData)}
              </TabsContent>
              <TabsContent value="TransactData">
                {renderTransactTable(filteredMasterTransactData)}
              </TabsContent>
            </Tabs>


          </div>
        )}
        {showData && (
          <div className="flex">

            <div className="mt-8 flex-justfy-center">
              {(isLoading) && <PageLoader />}
              <Button onClick={handleSaveDDCube} className="-mt-4 ml-6 rounded-lg text white bg-green-500 hover:bg-green-700 text-center border border-gray-300">DD Cube</Button>
            </div>

            <div className="mt-8 flex-justfy-center">
              <Button onClick={handleSave} className="-mt-4 ml-6 rounded-lg text white bg-green-500 hover:bg-green-700 text-center border border-gray-300">

                Save {(saveLoder) && <PageLoader />} </Button>
            </div>
            {(roleName == "DeliveryPartner" || roleName == "SuperAdmin" || roleName == "AREAdmin") && (
              <div className="mt-8 flex-justfy-center">
                {(fpaCalculateLoder) && <PageLoader />}
                <Button onClick={fpaCalculate} className="-mt-4 ml-6 rounded-lg text white bg-green-500 hover:bg-green-700 text-center border border-gray-300">FPA Caculate
                  {/* {fpaCalculateLoder && <Loader className="animate-spin" />} */}
                </Button>

              </div>)}

            {/* <div className="mt-8 flex-justfy-center">
              <Link to="./application/nao/page/OnboardUpload/DDCube" className=" ml-6 px-2 py-2 mt-6 mb-6 rounded-lg text white bg-blue-500 hover:bg-blue-700 text-center border border-gray-300">DD Cube</Link>
            </div> */}
          </div>

        )}
      </div>
      <div className="m-10">
        {/* <RiskMatrix data={json}/> */}

      </div>

    </>
  );
};

export default ExcelUploads;

