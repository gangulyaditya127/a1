
import { JSXElementConstructor, Key, ReactElement, ReactNode, useEffect, useState } from "react";
import Insights from "./Insights";
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
import { useLocation } from "react-router-dom";
import {
  Table,
  TableCell,
  TableRow,
  TableBody,
} from "@/components/ui/table";
import React from 'react';
//import Plot from 'react-plotly.js';
// import Scatter from "./scatter";
// import Scatterr from "./scatter";
// import Scatter3DChart from "./scatter";
// import EChat3DScatter from "./scatter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// import { ScrollArea } from "@/components/ui/scroll-area";
// import { el } from "@vidstack/react/types/vidstack-react.js";


const DDCube: React.FC = () => {


  
  const [selectedTab, setSelectedTab] = useState("Excel");
  const location=useLocation();
   console.log(location.state)
    const {data:apps=[]}=location.state||{};
    if(!apps.length){
      return(
      <p className=" mt-4 text-center text-muted-foreground">No application data available</p>
  );
    }
      // Define ranges for criticality, stability, and complexity
      // const ranges = {
      //   high: [501, Infinity],
      //   medium: [201, 500],
      //   low: [0, 200],
      // };
    
      

      const data = apps
       // Convert strings to numbers
       const updatedData = data.map((item: { criticality: string; stability: string; complexity: string; name: any; }) => ({
        criticality: parseFloat(item.criticality),
        stability: parseFloat(item.stability),
        complexity: parseFloat(item.complexity),
        name: item.name
       }));

       useEffect(() => {
        console.log("updatedData--length--",updatedData.length);
       console.log("updatedData----",updatedData);
      }, [updatedData]);
       // Example function to return color based on risk
      //  const getRiskColor = (criticality: number, stability: number, complexity: number) => {
      //    return 'red'
         
      //   if (criticality >= 7 && stability <= 3 && complexity >= 5) {
      //     return 'red';
      //   } else if (criticality <= 3 && stability >= 4 && complexity <= 3) {
      //     return 'green';
      //   } else {
      //     return 'magenta';
      //   }
      //  };
       // Create plot trace

      //  const addRandomOffset = (value: number) => {
      //   return value + Math.random() * 2.1 ;  // Offset between -0.05 and 0.05
      //  };
      //  const trace = {
        
      //   x: updatedData.map((item: { criticality: number; }) => addRandomOffset(item.criticality)),
      //   y: updatedData.map((item: { stability: number; }) => addRandomOffset(item.stability)),
      //   z: updatedData.map((item: { complexity: number; }) => addRandomOffset(item.complexity)),
      //   mode: 'markers',
      //   type: 'scatter3d',
      //   marker: {
      //     size: 5,
      //     color: updatedData.map((item: { criticality: number; stability: number; complexity: number; }) => getRiskColor(item.criticality, item.stability, item.complexity)),
      //     opacity: 0.8,
      //   },
      //   text: updatedData.map((item: { name: any; }) => item.name),
      //   hoverinfo: 'text+x+y+z',
      //  };
       // Layout with transparent background
      //  const layout = {
      //   title: '3D Scatter Plot based on Risk',
      //   scene: {
      //     xaxis: { title: 'Criticality' },
      //     yaxis: { title: 'Stability' },
      //     zaxis: { title: 'Complexity' },
      //   },
      //   paper_bgcolor: 'rgba(0,0,0,0)',  // Transparent background
      //   plot_bgcolor: 'rgba(0,0,0,0)',
      //   autosize: true,
      //  };

     
      // Define static background colors for cells
      const cellColors :Record<string,Record<string,Record<string,string>>>= {
        high: {
          high: {
            high: 'bg-green-300 bg-opacity-70  ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-red-400 bg-opacity-75 ',
          },
          medium: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-red-400 bg-opacity-75',
          },
          low: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-amber-300 bg-opacity-75',
          },
        },
        medium: {
          high: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75 ',
            low: 'bg-red-400 bg-opacity-75',
          },
          medium: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-amber-300 bg-opacity-75',
          },
          low: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-amber-300 bg-opacity-75',
          },
        },
        low: {
          high: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-red-400 bg-opacity-75',
          },
          medium: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-amber-300 bg-opacity-75',
          },
          low: {
            high: 'bg-green-300 bg-opacity-70 ',
            medium: 'bg-amber-300 bg-opacity-75',
            low: 'bg-amber-300 bg-opacity-75',
          },
        },
      };
      
    
      // Static data for apps
      
      // Helper to determine range type
      const getRangeType = (value: number):string => {
       
        if (value > 500) return "high";
        if (value > 200 && value<=500) return "medium";
        return "low";
      };
    
      // const normalizePosition = (value: number, range: { low: number[]; medium: number[]; high: number[] }) => {
      //   if (value <= range.low[1]) return 25; // Low range
      //   if (value <= range.medium[1]) return 50; // Medium range
      //   return 75; // High range
      // };
      
      // const pointColorMapping = {
      //   low: "bg-blue-200 hover:bg-blue-300",
      //   medium: "bg-yellow-200 hover:bg-yellow-300",
      //   high: "bg-red-200 hover:bg-red-300",
      // };
      
      
      
      
      return (


<div className="items-center p-3 mt-4">
<NavigateBackButton/>
<Tabs  value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-64.5 grid-cols-2 rounded-2xl dark:bg-violet-900/10">
          <TabsTrigger value="Excel" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
          Excel View
          </TabsTrigger>
          {/* <TabsTrigger value="graph" className="rounded-3xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal">
          Graphical Representation
          </TabsTrigger> */}
        </TabsList>

        {/* Master Data Tab */}
        <TabsContent value="Excel">
          <h2 className="text-center text-lg uppercase font-bold mb-6">Criticality vs Stability vs Complexity</h2>
          {/* <ul className="list-disc list-inside mb-4 text-base font-semibold">For each Application,corresponding to parameters Criticality,Stability and Criticality ,Ranges are specified below:-
         <li className="font-semibold"><span>Low: 0-200</span></li>
         <li className="font-semibold"><span>Medium: 201-500</span></li>
         <li className="font-semibold"><span>High: 501+</span></li>
          </ul> */}
          <Table className="table-fixed border-collapse border border-gray-500">
              {/* Stability Header */}
              
              <TableRow>
                <TableCell className="border border-gray-500" colSpan={1}></TableCell>
                <TableCell className="border border-gray-500 text-center font-semibold text-base" colSpan={28} >
                  Stability
                </TableCell></TableRow>
                <TableRow >
                <TableCell className="border border-gray-500" colSpan={1}></TableCell>
                <TableCell className="border-l-2 border-r border-b-2 border-t-2 border-gray-500 dark:border-gray-200 " colSpan={1}></TableCell>
                {/* <TableCell>
                  {["High", "Medium", "Low","High", "Medium", "Low","High", "Medium", "Low"].map((label, index) => (
                  <TableCell key={index}>{label}</TableCell>))}
                  
                  </TableCell> */}
                <TableCell className="border-t-2 border-l-4 border-b-2  border-gray-500 dark:border-gray-200 text-center font-semibold " colSpan={3}>
                  High
                </TableCell>
                <TableCell className="border-l  border-t-2 border-b-2 text-center font-semibold border-gray-500 dark:border-gray-200" colSpan={3}>
                  Medium
                </TableCell>
                <TableCell className="border-gray-500 dark:border-gray-200 border-b-2 border-l text-center border-t-2 border-r-4 font-semibold" colSpan={3}>
                  Low
                </TableCell>
                
                <TableCell className="border-t-2 border-r   border-gray-500 dark:border-gray-200 border-b-2  text-center font-semibold" colSpan={3}>
                  High
                </TableCell>
                <TableCell className="border-t-2 border-r   border-gray-500 dark:border-gray-200 border-b-2 text-center font-semibold" colSpan={3}>
                  Medium
                </TableCell>
                <TableCell className="border-t-2 border-r-4   border-gray-500 dark:border-gray-200 border-b-2 text-center font-semibold" colSpan={3}>
                  Low
                </TableCell>
                <TableCell className="border-t-2 border-r   border-gray-500 dark:border-gray-200  border-b-2 text-center font-semibold" colSpan={3}>
                  High
                </TableCell>
                <TableCell className="border-t-2 border-r   border-gray-500 dark:border-gray-200  border-b-2 text-center font-semibold" colSpan={3}>
                  Medium
                </TableCell>
                <TableCell className=" border-r-4 border-t-2 border-gray-500 dark:border-gray-200  border-b-2 text-center font-semibold" colSpan={3}>
                  Low
                </TableCell>
                </TableRow>
              
              
           
            <TableBody>
              {/* Complexity Rows */}
              {["High", "Medium", "Low"].map((complexityLabel, complexityIndex) => (
                <TableRow key={complexityIndex}>
                  {/* Complexity Header */}
                  {complexityIndex === 0 && (
                    <TableCell
                      rowSpan={3}
                      className=" border border-gray-500 place-items-center font-semibold transform -rotate-90"
                    >
                      Size/Complexity
                    </TableCell>
                  )}
                  <TableCell
                    className="border-gray-500 dark:border-gray-200 border-l-2 border-r-4 border-t-2 border-b-2 text-center font-semibold transform -rotate-90"
                    colSpan={1}
                  >
                    {complexityLabel}
                  </TableCell>
                  {/* Cells with Background Colors */}
                  
                  {["Low", "Medium", "High"].map((criticalityLabel,critcalityIndex ) =>
                    ["High", "Medium", "Low"].map((stabilityLabel,stabilityIndex) => (
                      
                      <TableCell 
                        key={`${complexityIndex}-${critcalityIndex}-${stabilityIndex}`} colSpan={3}
                         className={`  h-36 w-28 border-gray-500 dark:border-gray-200  border-l border-t ${stabilityIndex===2?"border-r-4":""} ${
                          cellColors[complexityLabel.toLowerCase()][criticalityLabel.toLowerCase()][stabilityLabel.toLowerCase()]
                       }`}
                      >
                        
                        <div className="flex flex-wrap items-center gap-1">
                        {apps
                          .filter(
                            (app: { complexity: any; criticality: any; stability: any; }) =>
                              getRangeType(app.complexity) === complexityLabel.toLowerCase() &&
                              getRangeType(app.criticality) === criticalityLabel.toLowerCase() &&
                              getRangeType(app.stability) === stabilityLabel.toLowerCase()
                          )
                          .map((app: { name: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined; }, appIndex: Key | null | undefined) => {
                          
                            return (
                      
                            <>
                      
                            <div
                                key={appIndex}
                                className={` w-2 h-2 cursor-pointer  rounded-2xl ${cellColors[complexityLabel.toLowerCase()][criticalityLabel.toLowerCase()][stabilityLabel.toLowerCase()]}  text-black text-center text-xs shadow-lg hover:border hover:border-black  transition-transform transform hover:scale-150`}
                                title={` App Name: ${app.name}\nStability: ${stabilityLabel}\nCriticality: ${criticalityLabel}\nComplexity: ${complexityLabel}`}
                              >




                              </div><div className={`absolute bottom-[240px]  ml-16 text-[10px] text-gray-600  dark:text-gray-800 p-1 py-0.5 rounded-xl ${ cellColors[complexityLabel.toLowerCase()][criticalityLabel.toLowerCase()][stabilityLabel.toLowerCase()]} hover:border hover:border-gray-200 opacity-0 group-hover:opacity-100 transition`}>
                                  Count:
                                  {apps.filter(
                                    (app: { complexity: number; criticality: number; stability: number; }) => getRangeType(app.complexity) === complexityLabel.toLowerCase() &&
                                      getRangeType(app.criticality) === criticalityLabel.toLowerCase() &&
                                      getRangeType(app.stability) === stabilityLabel.toLowerCase()
                                  ).length}
                                </div></>
                          );
                        })}



                            </div>
                    </TableCell>
                    
                    
                    ))
                    
                  )}
              
                </TableRow>
              ))}
            </TableBody>
    
              {/* Criticality Header */}
              <TableRow>
                <TableCell className="border border-gray-500" rowSpan={1} colSpan={1}></TableCell>
                <TableCell className="border-l-2 border-r border-b-2 border-gray-500 dark:border-gray-200" rowSpan={1} colSpan={1}></TableCell>
                <TableCell className=" text-center font-semibold border-l-4 border-r-4 border-t-4 border-b-2 border-gray-500 dark:border-gray-200" colSpan={9}>
                  Low
                </TableCell>
                <TableCell className=" text-center font-semibold  border-r-4 border-b-2 border-t-4 border-gray-500 dark:border-gray-200" colSpan={9}>
                  Medium
                </TableCell>
                <TableCell className="text-center font-semibold  border-r-4 border-b-2 border-t-4 border-gray-500 dark:border-gray-200" colSpan={9}>
                  High
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  className="border border-gray-500 text-center font-semibold text-base"
                  colSpan={29}
                >
                  Criticality
                </TableCell>
              </TableRow>
          </Table>
          <Insights applications={apps}/>
        </TabsContent>
		   {/* <TabsContent value="graph">
         <div  className="m-30">
         <Plot
     data={[trace]}
     layout={layout}
     style={{ width: '100%', height: '800px' }}
   />
         </div>
      
       </TabsContent> */}
  </Tabs>



      
</div>
      );
    };
      
   
export default DDCube;
