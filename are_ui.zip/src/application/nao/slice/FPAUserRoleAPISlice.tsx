import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export const FPAUserRoleAPI = createApi({
    reducerPath: 'FPAUserRoleAPI',
    
     baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpaUserRole/` }),
    endpoints: ({ query,mutation}) => ({

        getRoleDetailsByUserId: query<any, any>({
            query: (queryParams) => ({ url: `getRoleDetailsByUserId`, params: queryParams }),
        }),
        saveAcessRequest: mutation({
            query: (body) => (
                {
                    url: 'saveAcessRequest',
                    body,
                    method: 'POST',

                }
            ),
        }),
        getFPAUserDetailsByAccount: query<any, any>({
            query: (queryParams) => ({ url: `getFPAUserDetailsByAccount`, params: queryParams }),
        }),
        getRoleDetailsByStatus: query<any, any>({
            query: (queryParams) => ({ url: `getRoleDetailsByStatus`, params: queryParams }),
        }),
        updateUserRole: mutation({
            query: (body) => (
                {
                    url: 'updateUserRole',
                    body,
                    method: 'POST',

                }
            ),
        }),
       
    }),
})


export const {
    useLazyGetRoleDetailsByUserIdQuery,
    useSaveAcessRequestMutation,
    useLazyGetFPAUserDetailsByAccountQuery,
    useLazyGetRoleDetailsByStatusQuery,
    useUpdateUserRoleMutation
} = FPAUserRoleAPI