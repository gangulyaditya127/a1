import { PayloadAction, createSlice } from "@reduxjs/toolkit";
// import {headerHeight} from "../page/Upload";
// import {rowHeight} from "../page/Upload";

interface NaoState {
  selectedAccount: string;
  fileName: string;
  fileSelected: boolean;
  accountDetails: any[];
  accountList: any[];
  showAccountDetailsTable: boolean;
  showFileUploadSection: boolean;
  roleName: string;
  userPendingList: any[];
  userActiveList: any[];
  accountForAdmin: string;
  selectedRole: string;
  selectedRoleName:string;
  lastSelectedAccountIndex:string|null,
  gridHeight:number;
  
}

const initialState: NaoState = {
  selectedAccount: "",
  selectedRole: "",
  accountForAdmin: "",
  fileName: "",
  fileSelected: false,
  accountDetails: [],
  showAccountDetailsTable: false,
  accountList: [],
  showFileUploadSection: false,
  roleName: "",
  userPendingList: [],
  userActiveList: [],
  selectedRoleName:'',
  lastSelectedAccountIndex:null,
  gridHeight:1*30+65,
  
};

const naoSlice = createSlice({
  name: "nao",
  initialState,
  reducers: {
    setSelectedAccount: (state, action: PayloadAction<string>) => {
      state.selectedAccount = action.payload;
    },
    setAccountDetails: (state, action: PayloadAction<any[]>) => {
      state.accountDetails = action.payload;
      state.showAccountDetailsTable = true;
    },
    resetAccountDetails: (state) => {
      state.accountDetails = [];
      state.showAccountDetailsTable = false;
    },

    setFileUpload: (state, action: PayloadAction<{ fileName: string; fileSelected: boolean }>) => {
      state.fileName = action.payload.fileName;
      state.fileSelected = action.payload.fileSelected;
    },
    setAccountList: (state, action: PayloadAction<any[]>) => {
      state.accountList = action.payload;
    },
    setShowAccountDetailsTable: (state, action: PayloadAction<boolean>) => {
      state.showAccountDetailsTable = action.payload;
    },
    setShowFileUploadSection: (state, action: PayloadAction<boolean>) => {
      state.showFileUploadSection = action.payload;
    },
    setRoleName: (state, action: PayloadAction<string>) => {
      state.roleName = action.payload;
    },
    setUserPendingList: (state, action: PayloadAction<any[]>) => {
      state.userPendingList = action.payload;
    },
    setUserActiveList: (state, action: PayloadAction<any[]>) => {
      state.userActiveList = action.payload;
    },
    setSelectedRole: (state, action: PayloadAction<string>) => {
      state.selectedRole = action.payload;
    },
    setAccountForAdmin: (state, action: PayloadAction<string>) => {
      state.accountForAdmin = action.payload;
    },
    setSelectedRoleName: (state, action: PayloadAction<string>) => {
      state.selectedRoleName = action.payload;
    },
    setlastSelectedAccountIndex: (state, action: PayloadAction<null|string>) => {
      state.lastSelectedAccountIndex = action.payload;
    },
    setGridHeight: (state, action: PayloadAction<number>) => {
      state.gridHeight = action.payload;
    },
   
  },
});

export const { setSelectedAccount, setAccountDetails, setAccountList, resetAccountDetails, setSelectedRole, setFileUpload, setShowAccountDetailsTable,
  setShowFileUploadSection, setRoleName,setSelectedRoleName,
  setUserPendingList, setUserActiveList, setAccountForAdmin,setlastSelectedAccountIndex,setGridHeight
} = naoSlice.actions;
export default naoSlice.reducer;
