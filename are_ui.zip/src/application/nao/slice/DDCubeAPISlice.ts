import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
// import { GetRawProjectDataProps, GetRawSLATableDataProps } from '../types/api.types'

export const DDCubeAPI = createApi({
    reducerPath: 'DDCubeAPI',
    // baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpa/` }),
     baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpa/` }),
    endpoints: ({ query,mutation}) => ({
        generateDqueue: query<any, any>({
            query: (queryParams) => ({ url: `generateDQueue`, params: queryParams }),
        }),
        uploadDDCubeData: mutation({
            query: (body) => (
                {
                    url: 'generateDqueue',
                    body,
                    method: 'POST',

                }
            ),
        }),
    }),
})


export const {
    useGenerateDqueueQuery,
    useUploadDDCubeDataMutation
} = DDCubeAPI