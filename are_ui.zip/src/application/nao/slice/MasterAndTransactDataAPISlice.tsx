import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export const MasterTransactAPI = createApi({
    reducerPath: 'MasterTransactAPI',
    
     baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpa/` }),
    endpoints: ({ query,mutation}) => ({

        getAccountDetailsByAccountName: query<any, any>({
            query: (queryParams) => ({ url: `getAccountDetailsByAccountName`, params: queryParams }),
        }),
        getMasterAndTransactData: query<any, any>({
            query: (queryParams) => ({ url: `get_master_transact`, params: queryParams }),
        }),
        getFPADetailsData: query<any, any>({
            query: (queryParams) => ({ url: `getFPADetailsWithLookUpTable`, params: queryParams }),
        }),
        saveMasterAndTransactData: mutation({
            query: (body) => (
                {
                    url: 'saveMasterTransactData',
                    body,
                    method: 'POST',

                }
            ),
        }),
        saveNewSet: mutation({
            query: (body) => (
                {
                    url: 'saveAccountRequest',
                    body,
                    method: 'POST',

                }
            ),
        }),
        getFPADetails: mutation({
            query: (body) => (
                {
                    url: 'getFPADetails',
                    body,
                    method: 'POST',

                }
            ),
        }),
        saveFPADetailsWithLookupData: mutation({
            query: (body) => (
                {
                    url: 'saveLookupFPAData',
                    body,
                    method: 'POST',

                }
            ),
        }),
    }),
})


export const {
    useLazyGetAccountDetailsByAccountNameQuery,
    useLazyGetMasterAndTransactDataQuery,
    useLazyGetFPADetailsDataQuery,
    useSaveMasterAndTransactDataMutation,
    useSaveNewSetMutation,
    useGetFPADetailsMutation,
    useSaveFPADetailsWithLookupDataMutation
} = MasterTransactAPI