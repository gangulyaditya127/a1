import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
// import { TestTubesIcon } from 'lucide-react'
// import { GetRawProjectDataProps, GetRawSLATableDataProps } from '../types/api.types'

export const FPACalculateAPI = createApi({
    reducerPath: 'FPACalculateAPI',
    // baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpa/` }),
     baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/fpa/` }),
    endpoints: ({ query}) => ({
           
            test: query<any, { empid: string }>({
                query: (queryParams) => ({ url: '/test', params: queryParams })
            }),
          
        }),
})


export const {
    useLazyTestQuery,
    
} = FPACalculateAPI