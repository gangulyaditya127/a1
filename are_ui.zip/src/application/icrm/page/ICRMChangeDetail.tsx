import Container from "@/components/ui/container";
import ICRMFilters from "../feature/ICRMFilters";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Outlet, useLocation } from "react-router-dom";


export default function ICRMChangeDetail() {
    const location = useLocation();
    const isDetailPage = location.pathname.includes("/icrm/change-details/");


    return (
        <Container className="mt-6">
            <NavigateBackButton className=""/>
            {!isDetailPage &&
                <ICRMFilters />}
            <Outlet />
        </Container>
    )
}