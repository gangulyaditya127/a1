import { useState, useMemo, useEffect } from 'react';
// import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList } from 'recharts';
import { CheckCircle, Clock, AlertTriangle, ChevronRight, Search, Calendar, Users, FileText } from 'lucide-react';
import ICRMFilters from '../feature/ICRMFilters';
import { useAppDispatch, useAppSelector } from '@/lib/redux/hooks';
import { fetchDashboardData } from '../feature/slice/dashboardSlice';
import { fetchConsoleList } from '../feature/slice/consoleSlice';
import axios from 'axios';
import Container from '@/components/ui/container';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/tailwind.utils';
import { Link } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';

// let transformedData = undefined;

const ICRMDashboard = () => {
  const [selectedChange, setSelectedChange] = useState<null | Record<string, any>>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const dispatch = useAppDispatch();
  const filters = useAppSelector(
    (state) => state.filters
  );
  useEffect(() => {
    dispatch(fetchDashboardData());
    dispatch(fetchConsoleList());
  }, [dispatch, filters]);
  // const { graphData } = useAppSelector((state) => state.dashboard);
  const { changeData, loading } = useAppSelector((state) => state.consoleList);

  // Filter changes
  // const transformedData = graphData?.map((item) => ({
  //   lob: item.lob,
  //   reviewed_application: item.reviewed.application,
  //   reviewed_approvalGrp: item.reviewed.approvalGrp,
  //   reviewed_changeTask: item.reviewed.changeTask,
  //   total_application: item.total.application,
  //   total_approvalGrp: item.total.approvalGrp,
  //   total_changeTask: item.total.changeTask,

  //   reviewedSum: item.reviewed.application + item.reviewed.approvalGrp + item.reviewed.changeTask,
  //   totalSum: item.total.application + item.total.approvalGrp + item.total.changeTask,
  // }));
  console.log('API items:', changeData.length, changeData);
  const filteredChanges = useMemo(() => {
    return changeData.filter(change =>
      searchTerm === '' ||
      change.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      change.change_number.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [changeData, searchTerm]);


  console.log('Filtered items:', filteredChanges.length, filteredChanges);

  // const riskData = useMemo(() => {
  //   const counts = filteredChanges.reduce((acc: any, change) => {
  //     acc[change.risk] = (acc[change.risk] || 0) + 1;
  //     return acc;
  //   }, {});
  //   return [
  //     { name: 'Low', value: counts['Low'] || 0, color: '#10b981' },
  //     { name: 'Medium', value: counts['Medium'] || 0, color: '#f59e0b' },
  //     { name: 'High', value: counts['High'] || 0, color: '#ef4444' }
  //   ];
  // }, [filteredChanges]);


  const getRiskColor = (score: number) => {
    
    if(score>=75){
      return 'bg-red-100 text-red-800 border-red-200';
    }else if(score>=50){
      return 'bg-amber-100 text-amber-800 border-amber-200';
    }else{
      return 'bg-green-100 text-green-800 border-green-200';
    }
    // switch (level) {
    //   case 'Low': return 'bg-green-100 text-green-800 border-green-200';
    //   case 'Medium': return 'bg-amber-100 text-amber-800 border-amber-200';
    //   case 'High': 'bg-red-100 text-red-800 border-red-200';
    //   default: return 'bg-gray-100 text-gray-800 border-gray-200';
    // }
  };
  const getRiskLabel = (score: number) => {
    
    if(score>=75){
      return 'High Risk';
    }else if(score>=50){
      return 'Medium Risk';
    }else{
      return 'Low Risk';
    }
    // switch (level) {
    //   case 'Low': return 'bg-green-100 text-green-800 border-green-200';
    //   case 'Medium': return 'bg-amber-100 text-amber-800 border-amber-200';
    //   case 'High': 'bg-red-100 text-red-800 border-red-200';
    //   default: return 'bg-gray-100 text-gray-800 border-gray-200';
    // }
  };

  if (selectedChange) {
    return <ChangeDetailView change={selectedChange} onBack={() => setSelectedChange(null)} />;
  }
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

  const pendingCount = changeData.filter(change => change.pass_percentage < 100).length;
  const highRiskCount = changeData.filter(change => +change.crm_score >= 75).length;
  const dueTodayCount = changeData.filter(change => change.start_date === today).length;

  if (loading) {
    return (
      <Container className='py-8 flex flex-col gap-6 '>
        <Skeleton className='h-12 rounded-lg'></Skeleton>
        <div className="grid grid-cols-[300px_auto] gap-6">
          <Skeleton className='h-[300px] rounded-xl'/>
          <div className="flex flex-col gap-6">
              <Skeleton className='h-12 rounded-lg'></Skeleton>
              <Skeleton className='h-[600px] rounded-xl'></Skeleton>
          </div>
        </div>
      </Container>
    )
  }

  return (
    <Container className="py-6">
      {/* Header */}
      {/* <header className="">
        <div className="">
          <div>
            <h1 className="text-2xl font-bold text-secondary-foreground">Intelligent Change Review Management Console</h1>
            <p className="text-sm text-secondary-foreground mt-1">Contextual intelligence for change decision support</p>
          </div>
        </div>
      </header> */}
      <ICRMFilters />
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-background  min-h-screen">
          <div className="pt-4">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase mb-3">Quick Stats</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex flex-col">
                <span className="text-muted-foreground">Pending</span>
                <span className="font-semibold text-xl text-foreground">{pendingCount}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">High Risk</span>
                <span className="font-semibold text-xl text-red-600">{highRiskCount}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Due Today</span>
                <span className="font-semibold text-xl text-amber-600">{dueTodayCount}</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="text"
                placeholder="Search by change ID or title..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Change List */}
          <div className="bg-card rounded-xl shadow-sm border">
            <div className="px-6 py-4 border-b">
              <h2 className="text-lg font-semibold text-foreground">Pending Change Reviews</h2>
              <p className="text-sm text-muted-foreground mt-1">Sorted by AI-recommended priority</p>
            </div>
            <div className="divide-y ">
              {filteredChanges.map((change) => (
                <Link
                  key={change.change_number}
                  to={`/icrm/dashboard/${change.change_number}`}
                  className="px-6 py-4 block hover:bg-secondary/80 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {change.PriorityRank && (
                          <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-semibold rounded-full">
                            AI Priority #{change.PriorityRank}
                          </span>
                        )}
                        <span className="text-xs font-mono text-muted-foreground">{change.change_number}</span>
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full border ${getRiskColor(+change.crm_score)}`}>
                          {getRiskLabel(+change.crm_score)}
                        </span>
                        <span className="text-xs text-muted-foreground">{change.model}</span>
                      </div>
                      <h3 className="text-sm font-semibold text-foreground mb-1">{change.title}</h3>
                      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{change.description}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {change.requestor}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Scheduled: {change.start_date}
                        </span>
                        <span className="flex items-center gap-1">
                          <FileText className="w-3 h-3" />
                          {change.lob_name}
                        </span>
                      </div>
                      {change.historical_context && (
                        <div className={cn("mt-3 px-3 py-2  border rounded-lg", (+change?.successprobability >= 70) ? "bg-green-50 text-green-800 border-green-100 dark:bg-green-800/40 dark:border-green-800/20 dark:text-green-100" : "bg-amber-50 border-amber-100 text-amber-800 dark:bg-amber-800/40 dark:text-amber-100 dark:border-amber-800/40")}>
                          <p className="text-xs">
                            <AlertTriangle className="w-3 h-3 inline mr-1" />
                            <strong>Historical Context:</strong> {change.successprobability}% similar changes were completed successfully
                          </p>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-2 ml-4">
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">Review Progress</div>
                          <div className="text-sm font-semibold text-foreground">{(change as any).review_progress}%</div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-slate-400" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </main>
      </div>


    </Container>
  );
};

const ChangeDetailView = ({ change, onBack }: any) => {


  // const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  // const handleToggle = (index: number) => {
  //   setExpandedIndex(expandedIndex === index ? null : index);
  // };

  const [details, setDetails] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);


  useEffect(() => {
    if (!change?.change_number) return;
    console.log({ loading, error })

    const fetchChangeDetails = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await axios.get(
          `https://ismartams.tcsapps.com/api/python_icrm/get-change-risk-factor?change_no=${change.change_number}`
        );

        setDetails(response.data);
      } catch (err) {
        setError("Failed to load change details");
      } finally {
        setLoading(false);
      }
    };

    fetchChangeDetails();
  }, [change.change_number]);
  console.log(details?.risk_assessment?.top_risk_factors);
  // const allMitigations = details?.risk_assessment?.top_risk_factors
  //   ?.flatMap(f => f.mitigation.actions) || [];
  // const [checklist, setChecklist] = useState([
  //   { id: 1, item: 'Rollback plan validated', status: 'completed', required: true },
  //   { id: 2, item: 'Stakeholder approval confirmed', status: 'completed', required: true },
  //   { id: 3, item: 'Test results documented', status: 'in-progress', required: true },
  //   { id: 4, item: 'Monitoring alerts configured', status: 'pending', required: true },
  //   { id: 5, item: 'Communication plan prepared', status: 'pending', required: true },
  //   { id: 6, item: 'Resource availability confirmed', status: 'completed', required: false },
  // ]);

  const [decision, setDecision] = useState('');
  //added by ali
  const [mitigationPlans, setMitigationPlans] = useState([]);

  useEffect(() => {
    if (details?.risk_assessment?.top_risk_factors) {
      const plans = details.risk_assessment.top_risk_factors
        .flatMap((factor: any, idx: number) =>
          factor.mitigation.actions.map((action: any) => ({
            id: `${idx}-${action.text}`,
            item: action.text,
            status: action.status,
            required: true
          }))
        );
      setMitigationPlans(plans);
    }
  }, [details]);
  const toggleMitigationItem = async (id: string) => {
    const item = mitigationPlans.find(item => (item as any).id === id);
    if (!item) return;

    // Compute new status
    const newStatus =
      (item as any).status === 'completed'
        ? 'pending'
        : (item as any).status === 'pending'
          ? 'in-progress'
          : 'completed';

    // Update UI
    setMitigationPlans((prev: any) =>
      prev.map((i: any) => (i.id === id ? { ...i, status: newStatus } : i))
    );

    // Call API with correct status
    try {
      await axios.post('https://ismartams.tcsapps.com/api/python_icrm/update-mitigation-status', {
        change_id: change.change_number,
        action_item: (item as any).item,
        portfolio: change.lob_name,
        region: change.region,    // replace dynamically
        status: newStatus, // ✅ correct status
        updated_by: 'md.islam'
      });
      console.log('Mitigation status updated successfully');
    } catch (error) {
      console.error('Failed to update mitigation status', error);
    }
  };


  const completedMitigations = mitigationPlans.filter(item => (item as any).status === 'completed').length;

  const mitigationProgress = mitigationPlans.length > 0
    ? Math.round((completedMitigations / mitigationPlans.length) * 100)
    : 0;
  const operationalReadiness = change.total_tasks > 0
    ? Math.round((change.accepted_tasks / change.total_tasks) * 100)
    : 0;
  const review_progress = Math.round((mitigationProgress + operationalReadiness + change.pass_percentage) / 3)
  // const toggleChecklistItem = (id) => {
  //   setChecklist(prev => prev.map(item => {
  //     if (item.id === id) {
  //       const newStatus = item.status === 'completed' ? 'pending' :
  //         item.status === 'pending' ? 'in-progress' : 'completed';
  //       return { ...item, status: newStatus };
  //     }
  //     return item;
  //   }));
  // };

  // const completedItems = checklist.filter(item => item.status === 'completed').length;
  // const progressPercent = Math.round((completedItems / checklist.length) * 100);

  const getStatusIcon = (status: any) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'in-progress': return <Clock className="w-5 h-5 text-amber-600" />;
      default: return <div className="w-5 h-5 rounded-full border-2 border-slate-300" />;
    }
  };
  const [comments, setComments] = useState('');
  useEffect(() => {
    if (change) {
      setDecision(change.review_decision || '');
      setComments(change.review_comment || '');
    }
  }, [change]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertType, setAlertType] = useState<'success' | 'error' | null>(null);

  const handleSubmit = async () => {
    if (!decision || !comments) {
      setAlertType('error');
      setAlertMessage('Please select a decision and provide comments.');
      return;
    }

    setIsSubmitting(true);
    setAlertMessage(null);

    try {
      const response = await axios.post('https://ismartams.tcsapps.com/api/python_icrm/save_portfolio_modal_data', {
        sector: change.sector || 'BFSI',
        region: change.region || 'SEAL',
        lob: change.lob_name || 'Digital',
        crNo: change.change_number,
        soeid: '1735400', // Replace dynamically if needed
        reviewDecision: decision,
        comments: comments,
        speakerName: '',
        speakerSoeid: '',
        owningTeam: '',
        rationale: '',
        timeZone: 'EST'
      });

      if (response.data.status === 'success') {
        setAlertType('success');
        setAlertMessage('Review submitted successfully!');
      } else {
        setAlertType('error');
        setAlertMessage(response.data.message || 'Failed to submit review.');
      }
    } catch (error: any) {
      setAlertType('error');
      setAlertMessage(error.response?.data?.message || 'An error occurred while submitting review.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="px-6 py-4">
          <button
            onClick={onBack}
            className="text-blue-600 hover:text-blue-700 font-medium mb-2 flex items-center gap-2"
          >
            ← Back to Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl font-bold text-foreground">{change.change_number}</h1>
                <span className={`px-3 py-1 text-sm font-semibold rounded-full border ${change.risk === 'High' ? 'bg-red-100 text-red-800 border-red-200' : change.risk === 'Medium' ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-green-100 text-green-800 border-green-200'}`}>
                  {change.risk} Risk
                </span>
                {change.PriorityRank <= 2 && (
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 text-sm font-semibold rounded-full">
                    AI Priority #{change.PriorityRank}
                  </span>
                )}
              </div>
              <h2 className="text-lg text-slate-700">{change.title}</h2>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-3 gap-6">
          {/* Main Content - Left Column */}
          <div className="col-span-2 space-y-6">
            {/* Change Summary */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Change Summary</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Submitted By</label>
                    <p className="text-sm text-foreground mt-1">{change.requestor}</p>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Type</label>
                    <p className="text-sm text-foreground mt-1">{change.model}</p>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Scheduled Date</label>
                    <p className="text-sm text-foreground mt-1">{change.start_date}</p>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Portfolio</label>
                    <p className="text-sm text-foreground mt-1">{change.lob_name}</p>
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Description</label>
                  <p className="text-sm text-slate-700 mt-1">{change.description}</p>
                </div>
                {/* <div className="flex items-center gap-4 pt-2">
                  <span className="text-sm text-muted-foreground">
                    <AlertCircle className="w-4 h-4 inline mr-1" />
                    {change.linkedIncidents} linked incidents
                  </span>
                </div> */}
              </div>
            </div>

            {/* Risk Summary */}
            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl shadow-sm border border-red-200 p-6">
              <h3 className="text-lg font-semibold text-red-900 mb-4">Risk Assessment (ICA Perspective)</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-white rounded-lg p-4">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">AI Risk</label>
                  <p className="text-3xl font-bold text-red-600 mt-1">{change.ai_risk}</p>
                  <p className="text-xs text-muted-foreground mt-1">Confidence: {change.ai_risk_confidence}%</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Historical Context</label>
                  <p className="text-sm text-slate-700 mt-2">{change.successprobability}% similar changes were completed successfully</p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-red-900 mb-2">Top Risk Factors</h4>
                <ul className="space-y-2">
                  {details?.risk_assessment?.top_risk_factors?.map((factor: any, idx: number) => (
                    <li
                      key={idx}
                      className="flex flex-col gap-2 text-sm text-red-800 border rounded p-2"
                    >
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>{factor.factor_name}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>


              {/* {change.suggestedMitigations.length > 0 && (
                <div className="mt-4 pt-4 border-t border-red-200">
                  <h4 className="text-sm font-semibold text-red-900 mb-2">Suggested Mitigations</h4>
                  <ul className="space-y-2">
                    {change.suggestedMitigations.map((mitigation, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-red-800">
                        <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        {mitigation}
                      </li>
                    ))}
                  </ul>
                </div>
              )} */}
            </div>

            {/* Mitigation Plan */}

            <div className="bg-white rounded-xl shadow-sm border p-6 mt-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Mitigation Plan</h3>
                {mitigationPlans.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No mitigation actions available.</p>
                ) : (
                  <>
                    <span className="text-sm text-muted-foreground">
                      {completedMitigations} of {mitigationPlans.length} completed
                    </span>
                    {/* Progress bar and list */}
                  </>
                )}
              </div>
              <div className="mb-4">
                <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-600 transition-all duration-300"
                    style={{ width: `${mitigationProgress}%` }}
                  ></div>
                </div>
              </div>
              <div className="space-y-3">
                {mitigationPlans.map(item => (
                  <div
                    key={(item as any).id}
                    onClick={() => toggleMitigationItem((item as any).id)}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    {getStatusIcon((item as any).status)}
                    <div className="flex-1">
                      <p
                        className={`text-sm font-medium ${(item as any).status === 'completed'
                          ? 'text-muted-foreground line-through'
                          : 'text-foreground'
                          }`}
                      >
                        {(item as any).item}
                        {(item as any).required && <span className="text-red-600 ml-1">*</span>}
                      </p>
                      {(item as any).status === 'in-progress' && (
                        <p className="text-xs text-amber-600 mt-1">In progress...</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>



            {/* Intelligent Checklist */}
            {/* <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Review Checklist</h3>
                <span className="text-sm text-muted-foreground">{completedItems} of {checklist.length} completed</span>
              </div>
              <div className="mb-4">
                <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
              </div>
              <div className="space-y-3">
                {checklist.map(item => (
                  <div
                    key={item.id}
                    onClick={() => toggleChecklistItem(item.id)}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    {getStatusIcon(item.status)}
                    <div className="flex-1">
                      <p className={`text-sm font-medium ${item.status === 'completed' ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
                        {item.item}
                        {item.required && <span className="text-red-600 ml-1">*</span>}
                      </p>
                      {item.status === 'in-progress' && (
                        <p className="text-xs text-amber-600 mt-1">In progress...</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div> */}
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Review Progress */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Review Status</h3>
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-100 mb-3">
                  <span className="text-2xl font-bold text-blue-600">{review_progress}%</span>
                </div>
                <p className="text-sm text-muted-foreground">Overall Progress</p>
              </div>
              <div className="space-y-3">
                {/* Decision Dropdown */}
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-2">Decision</label>
                  <select
                    value={decision}
                    onChange={(e) => setDecision(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select decision...</option>
                    <option value="Review Pending">Review Pending</option>
                    <option value="Approved Post Tier-0">Approved Post Tier-0</option>
                    <option value="Rejected Post Tier-0">Rejected Post Tier-0</option>
                    <option value="Rescheduled">Rescheduled</option>
                    <option value="Moved to Tier-1">Moved to Tier-1</option>
                    <option value="Approved Post Tier-1">Approved Post Tier-1</option>
                    <option value="Rejected Post Tier-1">Rejected Post Tier-1</option>
                    <option value="Moved to Tier-2">Moved to Tier-2</option>
                    <option value="Approved Post Tier-2">Approved Post Tier-2</option>
                    <option value="Rejected Post Tier-2">Rejected Post Tier-2</option>
                    <option value="Moved to Tier-3">Moved to Tier-3</option>
                    <option value="Approved Post Tier-3">Approved Post Tier-3</option>
                    <option value="Rejected Post Tier-3">Rejected Post Tier-3</option>
                    <option value="Need Further Details">Need Further Details</option>
                    <option value="Conditionally Approved">Conditionally Approved</option>
                  </select>
                </div>

                {/* Recommendation */}
                {decision && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-xs text-blue-900 mb-2"><strong>Recommendation:</strong></p>
                    <p className="text-xs text-blue-800">
                      {
                        decision.includes('Approve')
                          ? 'Ensure all risk mitigations are in place before approval. Validate compliance and readiness.'
                          : decision.includes('Reject')
                            ? 'Provide detailed reasons for rejection to help the submitter address gaps effectively.'
                            : decision.includes('Rescheduled')
                              ? 'Communicate the new target date and explain why rescheduling was necessary.'
                              : decision.includes('Moved to Tier-')
                                ? 'Escalation indicates complexity or risk. Ensure additional validations at the new tier.'
                                : decision.includes('Need Further Details')
                                  ? 'Request missing information clearly to avoid ambiguity and delays.'
                                  : decision.includes('Conditionally Approved')
                                    ? 'Specify conditions that must be met before final approval. Track compliance closely.'
                                    : 'Review pending. Ensure all prerequisites are met before proceeding.'
                      }
                    </p>
                  </div>
                )}

                {/* Comments Input */}
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-2">Comments</label>
                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    rows={4}
                    placeholder="Provide justification for your decision..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>

                {/* Submit Button */}
                <button
                  onClick={handleSubmit}
                  disabled={!decision || !comments || isSubmitting}
                  className={`w-full py-2 rounded-lg font-medium transition-colors ${!decision || !comments || isSubmitting
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Review'}
                </button>

                {/* Feedback */}
                {alertMessage && (
                  <div className={`mt-3 text-sm ${alertType === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                    {alertMessage}
                  </div>
                )}
              </div>
            </div>

            {/* Confidence Indicator */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl shadow-sm border border-green-200 p-6">
              <h3 className="text-sm font-semibold text-green-900 uppercase mb-3">Confidence to Proceed</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-green-800">Technical Readiness</span>
                    <span className="font-semibold text-green-900">{change.pass_percentage}%</span>
                  </div>
                  <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600" style={{ width: `${change.pass_percentage}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-green-800">Risk Mitigation</span>
                    <span className="font-semibold text-green-900">{mitigationProgress}%</span>
                  </div>
                  <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600" style={{ width: `${mitigationProgress}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-green-800">Operational Readiness</span>
                    <span className="font-semibold text-green-900">{operationalReadiness}%</span>
                  </div>
                  <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600" style={{ width: `${operationalReadiness}%` }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            {/* <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">Quick Actions</h3>
              <div className="space-y-2">
                <button className="w-full px-3 py-2 text-sm text-left text-slate-700 hover:bg-slate-50 rounded-lg transition-colors">
                  <FileText className="w-4 h-4 inline mr-2" />
                  View Full Documentation
                </button>
                <button className="w-full px-3 py-2 text-sm text-left text-slate-700 hover:bg-slate-50 rounded-lg transition-colors">
                  <Users className="w-4 h-4 inline mr-2" />
                  Request SME Review
                </button>
                <button className="w-full px-3 py-2 text-sm text-left text-slate-700 hover:bg-slate-50 rounded-lg transition-colors">
                  <Activity className="w-4 h-4 inline mr-2" />
                  View Similar Changes
                </button>
                <button className="w-full px-3 py-2 text-sm text-left text-slate-700 hover:bg-slate-50 rounded-lg transition-colors">
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Reschedule Change
                </button>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ICRMDashboard;