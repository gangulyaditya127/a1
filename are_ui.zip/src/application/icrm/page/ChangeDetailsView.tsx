import { useState, useEffect } from 'react';
// import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList } from 'recharts';
import { CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import axios from 'axios';
import { fetchConsoleList } from '../feature/slice/consoleSlice';
import { useAppDispatch, useAppSelector } from '@/lib/redux/hooks';
import { useParams } from 'react-router-dom';
import Container from '@/components/ui/container';
import { NavigateBackButton } from '@/components/ui/navigate-back-button';
import { cn } from '@/lib/tailwind.utils';
import { Select, SelectContent, SelectItem, SelectValue, SelectTrigger } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';



export default function ChangeDetailView() {
    const dispatch = useAppDispatch()
    const { changeNumber } = useParams();
    useEffect(() => {
        dispatch(fetchConsoleList());
    }, [dispatch]);
    const { changeData } = useAppSelector((state) => state.consoleList);
    const selectedChange = changeData.filter((el) => el.change_number == changeNumber);
    if (selectedChange?.length == 0) return "No data found"
    return <ChangeDetailViewHelper change={selectedChange[0]} />;
}

export const ChangeDetailViewHelper = ({ change }: any) => {


    // const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

    // const handleToggle = (index: number) => {
    //   setExpandedIndex(expandedIndex === index ? null : index);
    // };

    const [details, setDetails] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);


    useEffect(() => {
        if (!change?.change_number) return;
        console.log({ loading, error })

        const fetchChangeDetails = async () => {
            try {
                setLoading(true);
                setError(null);

                const response = await axios.get(
                    `https://ismartams.tcsapps.com/api/python_icrm/get-change-risk-factor?change_no=${change.change_number}`
                );

                setDetails(response.data);
            } catch (err) {
                setError("Failed to load change details");
            } finally {
                setLoading(false);
            }
        };

        fetchChangeDetails();
    }, [change.change_number]);
    console.log(details?.risk_assessment?.top_risk_factors);
    // const allMitigations = details?.risk_assessment?.top_risk_factors
    //   ?.flatMap(f => f.mitigation.actions) || [];
    // const [checklist, setChecklist] = useState([
    //   { id: 1, item: 'Rollback plan validated', status: 'completed', required: true },
    //   { id: 2, item: 'Stakeholder approval confirmed', status: 'completed', required: true },
    //   { id: 3, item: 'Test results documented', status: 'in-progress', required: true },
    //   { id: 4, item: 'Monitoring alerts configured', status: 'pending', required: true },
    //   { id: 5, item: 'Communication plan prepared', status: 'pending', required: true },
    //   { id: 6, item: 'Resource availability confirmed', status: 'completed', required: false },
    // ]);

    const [decision, setDecision] = useState('');
    //added by ali
    const [mitigationPlans, setMitigationPlans] = useState([]);

    useEffect(() => {
        if (details?.risk_assessment?.top_risk_factors) {
            const plans = details.risk_assessment.top_risk_factors
                .flatMap((factor: any, idx: number) =>
                    factor.mitigation.actions.map((action: any) => ({
                        id: `${idx}-${action.text}`,
                        item: action.text,
                        status: action.status,
                        required: true
                    }))
                );
            setMitigationPlans(plans);
        }
    }, [details]);
    const toggleMitigationItem = async (id: string) => {
        const item = mitigationPlans.find(item => (item as any).id === id);
        if (!item) return;

        // Compute new status
        const newStatus =
            (item as any).status === 'completed'
                ? 'pending'
                : (item as any).status === 'pending'
                    ? 'in-progress'
                    : 'completed';

        // Update UI
        setMitigationPlans((prev: any) =>
            prev.map((i: any) => (i.id === id ? { ...i, status: newStatus } : i))
        );

        // Call API with correct status
        try {
            await axios.post('https://ismartams.tcsapps.com/api/python_icrm/update-mitigation-status', {
                change_id: change.change_number,
                action_item: (item as any).item,
                portfolio: change.lob_name,
                region: change.region,    // replace dynamically
                status: newStatus, // ✅ correct status
                updated_by: 'md.islam'
            });
            console.log('Mitigation status updated successfully');
        } catch (error) {
            console.error('Failed to update mitigation status', error);
        }
    };


    const completedMitigations = mitigationPlans.filter(item => (item as any).status === 'completed').length;

    const mitigationProgress = mitigationPlans.length > 0
        ? Math.round((completedMitigations / mitigationPlans.length) * 100)
        : 0;
    const operationalReadiness = change.total_tasks > 0
        ? Math.round((change.accepted_tasks / change.total_tasks) * 100)
        : 0;
    const review_progress = Math.round((mitigationProgress + operationalReadiness + change.pass_percentage) / 3)
    // const toggleChecklistItem = (id) => {
    //   setChecklist(prev => prev.map(item => {
    //     if (item.id === id) {
    //       const newStatus = item.status === 'completed' ? 'pending' :
    //         item.status === 'pending' ? 'in-progress' : 'completed';
    //       return { ...item, status: newStatus };
    //     }
    //     return item;
    //   }));
    // };

    // const completedItems = checklist.filter(item => item.status === 'completed').length;
    // const progressPercent = Math.round((completedItems / checklist.length) * 100);

    const getStatusIcon = (status: any) => {
        switch (status) {
            case 'completed': return <CheckCircle className="w-5 h-5 text-green-600" />;
            case 'in-progress': return <Clock className="w-5 h-5 text-amber-600" />;
            default: return <div className="w-5 h-5 rounded-full border-2 border-slate-300" />;
        }
    };
    const [comments, setComments] = useState('');
    useEffect(() => {
        if (change) {
            setDecision(change.review_decision || '');
            setComments(change.review_comment || '');
        }
    }, [change]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [alertMessage, setAlertMessage] = useState<string | null>(null);
    const [alertType, setAlertType] = useState<'success' | 'error' | null>(null);

    const handleSubmit = async () => {
        if (!decision || !comments) {
            setAlertType('error');
            setAlertMessage('Please select a decision and provide comments.');
            return;
        }

        setIsSubmitting(true);
        setAlertMessage(null);

        try {
            const response = await axios.post('https://ismartams.tcsapps.com/api/python_icrm/save_portfolio_modal_data', {
                sector: change.sector || 'BFSI',
                region: change.region || 'SEAL',
                lob: change.lob_name || 'Digital',
                crNo: change.change_number,
                soeid: '1735400', // Replace dynamically if needed
                reviewDecision: decision,
                comments: comments,
                speakerName: '',
                speakerSoeid: '',
                owningTeam: '',
                rationale: '',
                timeZone: 'EST'
            });

            if (response.data.status === 'success') {
                setAlertType('success');
                setAlertMessage('Review submitted successfully!');
            } else {
                setAlertType('error');
                setAlertMessage(response.data.message || 'Failed to submit review.');
            }
        } catch (error: any) {
            setAlertType('error');
            setAlertMessage(error.response?.data?.message || 'An error occurred while submitting review.');
        } finally {
            setIsSubmitting(false);
        }
    };
    debugger;
    return (
        <Container className="py-6">
            {/* Header */}
            <NavigateBackButton className='' />
            <header className="">
                <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-xl font-semibold">{change.title}</h2>
                    <h1 className="text-md font-semibold text-muted-foreground">#{change.change_number}</h1>
                    <span className={cn(`px-3 py-1 text-xs font-semibold rounded-full border`, change.crm_score >= 75 ? 'bg-red-100 text-red-800 border-red-200' : change.crm_score >= 50 ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-green-100 text-green-800 border-green-200')}>
                        {change.crm_score >= 75?'High':change.crm_score >= 50?'Medium':'Low'} Risk
                    </span>
                    
                    {change.PriorityRank && (
                        <span className="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-semibold rounded-full">
                            AI Priority #{change.PriorityRank}
                        </span>
                    )}
                </div>

            </header>

            <div className="grid grid-cols-3 gap-6 mt-4">
                {/* Main Content - Left Column */}
                <div className="col-span-2 space-y-6">
                    {/* Change Summary */}
                    <div className="rounded-xl border p-4">
                        {/* <h3 className="text-sm font-semibold text-foreground mb-4">Change Summary</h3> */}
                        <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-semibold text-muted-foreground uppercase">Submitted By</label>
                                    <p className="text-sm text-foreground mt-1">{change.requestor}</p>
                                </div>
                                <div>
                                    <label className="text-xs font-semibold text-muted-foreground uppercase">Type</label>
                                    <p className="text-sm text-foreground mt-1">{change.model}</p>
                                </div>
                                <div>
                                    <label className="text-xs font-semibold text-muted-foreground uppercase">Scheduled Date</label>
                                    <p className="text-sm text-foreground mt-1">{change.start_date}</p>
                                </div>
                                <div>
                                    <label className="text-xs font-semibold text-muted-foreground uppercase">Portfolio</label>
                                    <p className="text-sm text-foreground mt-1">{change.lob_name}</p>
                                </div>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-muted-foreground uppercase">Description</label>
                                <p className="text-sm  mt-1">{change.description}</p>
                            </div>
                            {/* <div className="flex items-center gap-4 pt-2">
                  <span className="text-sm text-muted-foreground">
                    <AlertCircle className="w-4 h-4 inline mr-1" />
                    {change.linkedIncidents} linked incidents
                  </span>
                </div> */}
                        </div>
                    </div>

                    {/* Risk Summary */}
                    <div className="bg-red-50/90 dark:bg-red-800/20 dark:border-red-800/40 rounded-xl shadow-sm border border-red-200 p-6">
                        <h3 className="text-lg font-semibold  mb-4">Risk Assessment (ICA Perspective)</h3>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="border border-red-500/30 bg-background/20 rounded-lg p-4">
                                <label className="text-xs font-semibold text-muted-foreground uppercase">AI Risk</label>
                                <p className="text-3xl font-bold text-red-600 dark:text-red-100 mt-1">{change.ai_risk}</p>
                                <p className="text-xs mt-1">Confidence: {change.ai_risk_confidence}%</p>
                            </div>
                            <div className="border border-red-500/30 bg-background/20 rounded-lg p-4">
                                <label className="text-xs font-semibold text-muted-foreground uppercase">Historical Context</label>
                                <p className="text-sm  mt-2">{change.successprobability}% similar changes were completed successfully</p>
                            </div>
                        </div>

                        <div>
                            <h4 className="text-sm font-semibold mb-2 text-red-100">Top Risk Factors</h4>
                            <ul className="space-y-2">
                                {details?.risk_assessment?.top_risk_factors?.map((factor: any, idx: number) => (
                                    <li
                                        key={idx}
                                        className="flex flex-col gap-2 text-sm text-red-800 dark:text-red-100 rounded py-1"
                                    >
                                        <div className="flex items-start gap-2">
                                            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                            <span>{factor.factor_name}</span>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>


                        {/* {change.suggestedMitigations.length > 0 && (
                <div className="mt-4 pt-4 border-t border-red-200">
                  <h4 className="text-sm font-semibold text-red-900 mb-2">Suggested Mitigations</h4>
                  <ul className="space-y-2">
                    {change.suggestedMitigations.map((mitigation, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-red-800">
                        <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        {mitigation}
                      </li>
                    ))}
                  </ul>
                </div>
              )} */}
                    </div>

                    {/* Mitigation Plan */}

                    <div className=" rounded-xl shadow-sm border p-6 mt-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold text-foreground">Mitigation Plan</h3>
                            {mitigationPlans.length === 0 ? (
                                <p className="text-sm text-muted-foreground">No mitigation actions available.</p>
                            ) : (
                                <>
                                    <span className="text-sm text-muted-foreground">
                                        {completedMitigations} of {mitigationPlans.length} completed
                                    </span>
                                    {/* Progress bar and list */}
                                </>
                            )}
                        </div>
                        <div className="mb-4">
                            <div className="h-2 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-green-600 transition-all duration-300"
                                    style={{ width: `${mitigationProgress}%` }}
                                ></div>
                            </div>
                        </div>
                        <div className="space-y-3">
                            {mitigationPlans.map(item => (
                                <div
                                    key={(item as any).id}
                                    onClick={() => toggleMitigationItem((item as any).id)}
                                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-secondary/80 cursor-pointer transition-colors"
                                >
                                    {getStatusIcon((item as any).status)}
                                    <div className="flex-1">
                                        <p
                                            className={`text-sm font-medium ${(item as any).status === 'completed'
                                                ? 'text-muted-foreground line-through'
                                                : 'text-foreground'
                                                }`}
                                        >
                                            {(item as any).item}
                                            {(item as any).required && <span className="text-red-600 ml-1">*</span>}
                                        </p>
                                        {(item as any).status === 'in-progress' && (
                                            <p className="text-xs text-amber-600 mt-1">In progress...</p>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>



                    {/* Intelligent Checklist */}
                    {/* <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Review Checklist</h3>
                <span className="text-sm text-muted-foreground">{completedItems} of {checklist.length} completed</span>
              </div>
              <div className="mb-4">
                <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
              </div>
              <div className="space-y-3">
                {checklist.map(item => (
                  <div
                    key={item.id}
                    onClick={() => toggleChecklistItem(item.id)}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    {getStatusIcon(item.status)}
                    <div className="flex-1">
                      <p className={`text-sm font-medium ${item.status === 'completed' ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
                        {item.item}
                        {item.required && <span className="text-red-600 ml-1">*</span>}
                      </p>
                      {item.status === 'in-progress' && (
                        <p className="text-xs text-amber-600 mt-1">In progress...</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div> */}
                </div>

                {/* Right Sidebar */}
                <div className="space-y-6">
                    {/* Review Progress */}
                    <div className="rounded-xl shadow-sm border p-6">
                        <h3 className="text-lg font-semibold text-foreground mb-4">Review Status</h3>
                        <div className="text-center mb-6">
                            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-800/40 dark:border-blue-600 dark:border mb-3">
                                <span className="text-2xl font-bold text-blue-600">{review_progress}%</span>
                            </div>
                            <p className="text-sm text-muted-foreground">Overall Progress</p>
                        </div>
                        <div className="space-y-3">
                            {/* Decision Dropdown */}
                            <div>
                                <label className="block text-xs font-semibold text-muted-foreground uppercase mb-2">Decision</label>

                                <Select value={decision} onValueChange={(e)=>setDecision(e)}>
                                    <SelectTrigger className='border w-full text-sm'>
                                        <SelectValue placeholder="Select decision" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="light">Select decision</SelectItem>
                                        <SelectItem value="Review Pending">Review Pending</SelectItem>
                                        <SelectItem value="Approved Post Tier-0">Approved Post Tier-0</SelectItem>
                                        <SelectItem value="Rejected Post Tier-0">Rejected Post Tier-0</SelectItem>
                                        <SelectItem value="Rescheduled">Rescheduled</SelectItem>
                                        <SelectItem value="Moved to Tier-1">Moved to Tier-1</SelectItem>
                                        <SelectItem value="Approved Post Tier-1">Approved Post Tier-1</SelectItem>
                                        <SelectItem value="Rejected Post Tier-1">Rejected Post Tier-1</SelectItem>
                                        <SelectItem value="Moved to Tier-2">Moved to Tier-2</SelectItem>
                                        <SelectItem value="Approved Post Tier-2">Approved Post Tier-2</SelectItem>
                                        <SelectItem value="Rejected Post Tier-2">Rejected Post Tier-2</SelectItem>
                                        <SelectItem value="Moved to Tier-3">Moved to Tier-3</SelectItem>
                                        <SelectItem value="Approved Post Tier-3">Approved Post Tier-3</SelectItem>
                                        <SelectItem value="Rejected Post Tier-3">Rejected Post Tier-3</SelectItem>
                                        <SelectItem value="Need Further Details">Need Further Details</SelectItem>
                                        <SelectItem value="Conditionally Approved">Conditionally Approved</SelectItem>
                                    </SelectContent>
                                </Select>
                                {/* <select
                                    value={decision}
                                    onChange={(e) => setDecision(e.target.value)}
                                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">Select decision...</option>
                                    <option value="Review Pending">Review Pending</option>
                                    <option value="Approved Post Tier-0">Approved Post Tier-0</option>
                                    <option value="Rejected Post Tier-0">Rejected Post Tier-0</option>
                                    <option value="Rescheduled">Rescheduled</option>
                                    <option value="Moved to Tier-1">Moved to Tier-1</option>
                                    <option value="Approved Post Tier-1">Approved Post Tier-1</option>
                                    <option value="Rejected Post Tier-1">Rejected Post Tier-1</option>
                                    <option value="Moved to Tier-2">Moved to Tier-2</option>
                                    <option value="Approved Post Tier-2">Approved Post Tier-2</option>
                                    <option value="Rejected Post Tier-2">Rejected Post Tier-2</option>
                                    <option value="Moved to Tier-3">Moved to Tier-3</option>
                                    <option value="Approved Post Tier-3">Approved Post Tier-3</option>
                                    <option value="Rejected Post Tier-3">Rejected Post Tier-3</option>
                                    <option value="Need Further Details">Need Further Details</option>
                                    <option value="Conditionally Approved">Conditionally Approved</option>
                                </select> */}
                            </div>

                            {/* Recommendation */}
                            {decision && (
                                <div className="p-3 bg-blue-50 dark:bg-blue-800/40 dark:border-blue-800 dark:text-foreground border border-blue-200 rounded-lg">
                                    <p className="text-xs mb-2"><strong>Recommendation:</strong></p>
                                    <p className="text-xs">
                                        {
                                            decision.includes('Approve')
                                                ? 'Ensure all risk mitigations are in place before approval. Validate compliance and readiness.'
                                                : decision.includes('Reject')
                                                    ? 'Provide detailed reasons for rejection to help the submitter address gaps effectively.'
                                                    : decision.includes('Rescheduled')
                                                        ? 'Communicate the new target date and explain why rescheduling was necessary.'
                                                        : decision.includes('Moved to Tier-')
                                                            ? 'Escalation indicates complexity or risk. Ensure additional validations at the new tier.'
                                                            : decision.includes('Need Further Details')
                                                                ? 'Request missing information clearly to avoid ambiguity and delays.'
                                                                : decision.includes('Conditionally Approved')
                                                                    ? 'Specify conditions that must be met before final approval. Track compliance closely.'
                                                                    : 'Review pending. Ensure all prerequisites are met before proceeding.'
                                        }
                                    </p>
                                </div>
                            )}

                            {/* Comments Input */}
                            <div>
                                <label className="block text-xs font-semibold text-muted-foreground uppercase mb-2">Comments</label>
                                <Textarea
                                    value={comments}
                                    onChange={(e) => setComments(e.target.value)}
                                    rows={4}
                                    placeholder="Provide justification for your decision..."
                                    className="w-full px-3 py-2 border rounded-lg text-sm resize-none"
                                />
                            </div>

                            {/* Submit Button */}
                            <Button
                                onClick={handleSubmit}
                                disabled={!decision || !comments || isSubmitting}
                                className={`w-full text-xs ${!decision || !comments || isSubmitting
                                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                    : 'bg-blue-600 text-white hover:bg-blue-700'
                                    }`}
                            >
                                {isSubmitting ? 'Submitting...' : 'Submit Review'}
                            </Button>

                            {/* Feedback */}
                            {alertMessage && (
                                <div className={`mt-3 text-sm ${alertType === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                                    {alertMessage}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Confidence Indicator */}
                    <div className="bg-green-50 dark:bg-green-800/40 dark:border-green-800/50 text-foreground rounded-xl shadow-sm border border-green-200 p-6">
                        <h3 className="text-sm font-semibold uppercase mb-3">Confidence to Proceed</h3>
                        <div className="space-y-3">
                            <div>
                                <div className="flex justify-between text-sm mb-1">
                                    <span className="text-green-800 dark:text-foreground">Technical Readiness</span>
                                    <span className="font-semibold">{change.pass_percentage}%</span>
                                </div>
                                <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-600" style={{ width: `${change.pass_percentage}%` }}></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-sm mb-1">
                                    <span className="text-green-800 dark:text-foreground">Risk Mitigation</span>
                                    <span className="font-semibold">{mitigationProgress}%</span>
                                </div>
                                <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-600" style={{ width: `${mitigationProgress}%` }}></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-sm mb-1">
                                    <span className="text-green-800 dark:text-foreground">Operational Readiness</span>
                                    <span className="font-semibold">{operationalReadiness}%</span>
                                </div>
                                <div className="h-2 bg-green-200 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-600" style={{ width: `${operationalReadiness}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Quick Actions */}
                    {/* <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">Quick Actions</h3>
              <div className="space-y-2">
                <button className="w-full px-3 py-2 text-sm text-left  hover:bg-slate-50 rounded-lg transition-colors">
                  <FileText className="w-4 h-4 inline mr-2" />
                  View Full Documentation
                </button>
                <button className="w-full px-3 py-2 text-sm text-left  hover:bg-slate-50 rounded-lg transition-colors">
                  <Users className="w-4 h-4 inline mr-2" />
                  Request SME Review
                </button>
                <button className="w-full px-3 py-2 text-sm text-left  hover:bg-slate-50 rounded-lg transition-colors">
                  <Activity className="w-4 h-4 inline mr-2" />
                  View Similar Changes
                </button>
                <button className="w-full px-3 py-2 text-sm text-left  hover:bg-slate-50 rounded-lg transition-colors">
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Reschedule Change
                </button>
              </div>
            </div> */}
                </div>
            </div>
        </Container>
    );
};