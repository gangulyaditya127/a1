import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import journalData from "@/application/icrm/data/review_decision_journal.json";

interface JournalsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  crNumber: string;
}

const JournalsModal = ({ open, onOpenChange, crNumber }: JournalsModalProps) => {
  const crJournals = journalData.filter(journal => journal.crNo === crNumber);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            Review Decision Journals - {crNumber}
          </DialogTitle>
        </DialogHeader>

        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Action</TableHead>
                <TableHead>Review Decision</TableHead>
                <TableHead>Comments</TableHead>
                <TableHead>Updated By</TableHead>
                <TableHead>Updated On</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {crJournals.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No journal entries found for this change request
                  </TableCell>
                </TableRow>
              ) : (
                crJournals.map((journal) => (
                  <TableRow key={journal.id}>
                    <TableCell>{journal.action}</TableCell>
                    <TableCell>{journal.reviewDecision}</TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate" title={journal.comments}>
                        {journal.comments}
                      </div>
                    </TableCell>
                    <TableCell>{journal.updatedBy}</TableCell>
                    <TableCell>{new Date(journal.updatedOn).toLocaleString()}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default JournalsModal;