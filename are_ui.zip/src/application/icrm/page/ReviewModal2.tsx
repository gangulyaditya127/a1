// import { useState } from "react";
// import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
// import { Button } from "@/components/ui/button";
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { Textarea } from "@/components/ui/textarea";
// import { Badge } from "@/components/ui/badge";
// import { Checkbox } from "@/components/ui/checkbox";
// import { useToast } from "@/hooks/use-toast";
// import changeRequestsData from "@/data/change_requests_data.json";
// import checkPointData from "@/data/check_point_details.json";

// interface ReviewModal2Props {
//   open: boolean;
//   onOpenChange: (open: boolean) => void;
//   crNumber?: string;
// }

// interface CheckpointData {
//   id: string;
//   name: string;
//   relevantData: string;
//   analysis: string;
//   reviewStatusICRM: string;
//   reviewStatusManual: string;
//   comment: string;
//   psmStatus: string;
//   psmRemarks: string;
// }

// const ReviewModal2 = ({ open, onOpenChange, crNumber }: ReviewModal2Props) => {
//   const { toast } = useToast();
//   const [activeTab, setActiveTab] = useState('main-details');
//   const [isCritical, setIsCritical] = useState(false);
//   const [changeNutshell, setChangeNutshell] = useState("");
//   const [reviewDecision, setReviewDecision] = useState("review-pending");
//   const [comments, setComments] = useState("");
//   const [checkpointUpdates, setCheckpointUpdates] = useState<Record<string, any>>({});
  
//   const changeRequest = changeRequestsData.find(cr => cr.crNo === crNumber);
//   const checkPointDetails = checkPointData.find(cp => cp.crNo === crNumber);

//   // Get checkpoint data from JSON
//   const getCurrentTabCheckpoints = () => {
//     if (!checkPointDetails?.checkpoints) return [];
    
//     switch (activeTab) {
//       case 'main-details':
//         return checkPointDetails.checkpoints.mainDetails || [];
//       case 'precautionary-check':
//         return checkPointDetails.checkpoints.precautionaryCheck || [];
//       case 'approval-check':
//         return checkPointDetails.checkpoints.approvalCheck || [];
//       case 'change-task':
//         return checkPointDetails.checkpoints.changeTask || [];
//       default:
//         return [];
//     }
//   };

//   const updateCheckpointValue = (checkpointId: string, field: string, value: string) => {
//     setCheckpointUpdates(prev => ({
//       ...prev,
//       [`${activeTab}-${checkpointId}-${field}`]: value
//     }));
//   };

//   const handleUpdateCheckpointStatus = () => {
//     try {
//       // In a real application, this would make an API call to update the JSON file
//       // For now, we'll simulate the update and show a success message
//       toast({
//         title: "Checkpoint Status Updated",
//         description: "All checkpoint details have been successfully saved.",
//       });
//     } catch (error) {
//       toast({
//         title: "Error",
//         description: "Failed to update checkpoint status. Please try again.",
//         variant: "destructive",
//       });
//     }
//   };

//   const getStatusBadge = (status: string) => {
//     return status.toLowerCase() === 'pass' 
//       ? <Badge className="bg-status-green text-status-green-foreground">Pass</Badge>
//       : <Badge className="bg-status-high text-status-high-foreground">Fail</Badge>;
//   };

//   return (
//     <Dialog open={open} onOpenChange={onOpenChange}>
//       <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
//         <DialogHeader>
//           <div className="flex items-center justify-between">
//             <div className="space-y-1">
//               <DialogTitle className="text-lg font-semibold">
//                 Change No.: {crNumber || 'CHG000627267'}
//               </DialogTitle>
//               <div className="flex items-center gap-4 text-sm text-muted-foreground">
//                 <span>Sector: BFSI</span>
//                 <span>LOB: Digital</span>
//                 <span>Phase: assessment</span>
//                 <span>Phase State: pending</span>
//                 <span className="text-xs">[Timezone: EDT/EST]</span>
//               </div>
//             </div>
//             <Button 
//               className="bg-blue-500 text-white hover:bg-blue-600"
//               onClick={handleUpdateCheckpointStatus}
//             >
//               Update Checkpoint Status
//             </Button>
//           </div>
//         </DialogHeader>

//         <div className="py-4">
//           <div className="space-y-6 mb-6">
//             {/* First row: Is Critical and Change Nutshell */}
//             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
//               <div className="flex flex-col">
//                 <label className="text-sm font-medium mb-2">Is Critical:</label>
//                 <div className="flex items-center">
//                   <Checkbox 
//                     checked={isCritical}
//                     onCheckedChange={(checked) => setIsCritical(checked === true)}
//                   />
//                 </div>
//               </div>
//               <div className="flex flex-col">
//                 <label className="text-sm font-medium mb-2">Change Nutshell:</label>
//                 <Textarea 
//                   className="resize-none"
//                   rows={4}
//                   value={changeNutshell}
//                   onChange={(e) => setChangeNutshell(e.target.value)}
//                   placeholder="Enter change details..."
//                 />
//               </div>
//             </div>
            
//             {/* Second row: Review Decision and Comments */}
//             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
//               <div className="flex flex-col">
//                 <label className="text-sm font-medium mb-2">Review Decision:</label>
//                 <Select value={reviewDecision} onValueChange={setReviewDecision}>
//                   <SelectTrigger>
//                     <SelectValue />
//                   </SelectTrigger>
//                   <SelectContent>
//                     <SelectItem value="review-pending">Review Pending</SelectItem>
//                     <SelectItem value="approved">Approved</SelectItem>
//                     <SelectItem value="rejected">Rejected</SelectItem>
//                     <SelectItem value="conditionally-approved">Conditionally Approved</SelectItem>
//                   </SelectContent>
//                 </Select>
//               </div>
//               <div className="flex flex-col">
//                 <label className="text-sm font-medium mb-2">Comments:</label>
//                 <Textarea 
//                   className="resize-none" 
//                   rows={4}
//                   value={comments}
//                   onChange={(e) => setComments(e.target.value)}
//                   placeholder="Enter your comments..."
//                 />
//               </div>
//             </div>
//           </div>

//           <Tabs value={activeTab} onValueChange={setActiveTab}>
//             <TabsList className="grid w-full grid-cols-4">
//               <TabsTrigger value="main-details">Main Details</TabsTrigger>
//               <TabsTrigger value="precautionary-check">Precautionary Check</TabsTrigger>
//               <TabsTrigger value="approval-check">Approval Check</TabsTrigger>
//               <TabsTrigger value="change-task">Change Task</TabsTrigger>
//             </TabsList>

//             {/* Render table for all tabs */}
//             {['main-details', 'precautionary-check', 'approval-check', 'change-task'].map((tabValue) => (
//               <TabsContent key={tabValue} value={tabValue} className="mt-6">
//                 <div className="border rounded-lg overflow-hidden">
//                   <Table>
//                     <TableHeader>
//                       <TableRow className="bg-muted/50">
//                         <TableHead className="w-32">S#/Checkpoint Name</TableHead>
//                         <TableHead className="min-w-[200px]">Relevent Data</TableHead>
//                         <TableHead className="min-w-[200px]">Checkpoint Analysis</TableHead>
//                         <TableHead className="w-40">Review Status (ICRM)</TableHead>
//                         <TableHead className="w-40">Review Status (Manual)</TableHead>
//                         <TableHead className="w-48">Comment</TableHead>
//                         <TableHead className="w-32">PSM Status</TableHead>
//                         <TableHead className="w-48">PSM Remarks</TableHead>
//                       </TableRow>
//                     </TableHeader>
//                     <TableBody>
//                       {getCurrentTabCheckpoints().map((checkpoint, index) => (
//                         <TableRow key={checkpoint.id}>
//                           <TableCell className="font-medium">
//                             {index + 1}. {checkpoint.name}
//                           </TableCell>
//                           <TableCell className="text-xs">
//                             <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap">
//                               {checkpoint.relevantData}
//                             </div>
//                           </TableCell>
//                           <TableCell className="text-xs">
//                             <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap">
//                               {checkpoint.analysis}
//                             </div>
//                           </TableCell>
//                           <TableCell>
//                             {getStatusBadge(checkpoint.reviewStatusICRM)}
//                             <div className="mt-1">
//                               <Button variant="ghost" size="sm" className="p-1 h-auto">
//                                 ⬇️
//                               </Button>
//                             </div>
//                           </TableCell>
//                            <TableCell>
//                              <Select 
//                                defaultValue={checkpoint.reviewStatusManual.toLowerCase()}
//                                onValueChange={(value) => updateCheckpointValue(checkpoint.id, 'reviewStatusManual', value)}
//                              >
//                                <SelectTrigger className="w-full">
//                                  <SelectValue />
//                                </SelectTrigger>
//                                <SelectContent>
//                                  <SelectItem value="pass">Pass</SelectItem>
//                                  <SelectItem value="fail">Fail</SelectItem>
//                                  <SelectItem value="manual review">Manual Review</SelectItem>
//                                  <SelectItem value="na">NA</SelectItem>
//                                </SelectContent>
//                              </Select>
//                            </TableCell>
//                            <TableCell>
//                              <Textarea 
//                                placeholder={checkpoint.comment}
//                                className="min-h-[60px] text-xs"
//                                onChange={(e) => updateCheckpointValue(checkpoint.id, 'comment', e.target.value)}
//                              />
//                            </TableCell>
//                            <TableCell>
//                              <Select 
//                                defaultValue={checkpoint.psmStatus.toLowerCase()}
//                                onValueChange={(value) => updateCheckpointValue(checkpoint.id, 'psmStatus', value)}
//                              >
//                                <SelectTrigger className="w-full">
//                                  <SelectValue />
//                                </SelectTrigger>
//                                <SelectContent>
//                                  <SelectItem value="pass">Pass</SelectItem>
//                                  <SelectItem value="fail">Fail</SelectItem>
//                                  <SelectItem value="manual review">Manual Review</SelectItem>
//                                  <SelectItem value="na">NA</SelectItem>
//                                </SelectContent>
//                              </Select>
//                            </TableCell>
//                            <TableCell>
//                              <Textarea 
//                                placeholder={checkpoint.psmRemarks}
//                                className="min-h-[60px] text-xs"
//                                onChange={(e) => updateCheckpointValue(checkpoint.id, 'psmRemarks', e.target.value)}
//                              />
//                            </TableCell>
//                         </TableRow>
//                       ))}
//                     </TableBody>
//                   </Table>
//                 </div>
//               </TabsContent>
//             ))}
//           </Tabs>

//         </div>
//       </DialogContent>
//     </Dialog>
//   );
// };

// export default ReviewModal2;