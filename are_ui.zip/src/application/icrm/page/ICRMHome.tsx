import { useEffect } from 'react';

import Container from "@/components/ui/container";
import ErrorContainer from "@/components/ui/error-container";

import ICRMFilters from "../feature/ICRMFilters";
import ICRMHighlights from "../feature/ICRMHighlights";
import ICRMSummary from "../feature/ICRMSummary";

import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { fetchDashboardData } from "@/application/icrm/feature/slice/dashboardSlice";
import ICRMHomeShimmer from '../shimmer/ICRMHomeShimmer';
import { ICRMReviewGraph } from '../feature/ICRMReviewGraph';
import { Link } from 'react-router-dom';
import { PartyPopper } from 'lucide-react';

export default function ICRMHome() {
    const dispatch = useAppDispatch();
    const filters = useAppSelector(
        (state) => state.filters
    );
    const { dashboardCount, graphData, loading, error } = useAppSelector((state) => state.dashboard);
    // Fetch when any filter changes
    useEffect(() => {
        dispatch(fetchDashboardData());
    }, [dispatch, filters]);

    return (
        <Container className="mt-6">
            <ICRMFilters />

            <Link to="/doc/icrm-ica" className="px-4 mt-2 py-1 hover:underline bg-blue-500/40 flex gap-2 items-center border border-blue-500 rounded-lg text-sm">
                <p className="flex gap-1 ">
                    <PartyPopper className="h-4 w-4" />
                </p>
                <div className="">
                    Breaking New Ground: ICRM Becomes the First AMS Solution Powered by Powered by Intelligent Choice architecture (ICA) Framework!
                </div>
                <div className="text-xs">[view]</div>
            </Link>
            <div className="mt-2 grid gap-6 pb-12">


                {loading ? (
                    // <Loader className="justify-center m-24">
                    //     Loading data...
                    // </Loader>
                    <ICRMHomeShimmer />
                ) : error ? (
                    <ErrorContainer className="mt-6" />
                ) : (
                    <>
                        {dashboardCount && <ICRMHighlights dashboardCount={dashboardCount} />}

                        <div className="grid grid-cols-3 gap-6">
                            <div className="col-span-2">
                                {dashboardCount && <ICRMSummary dashboardCount={dashboardCount} />}

                            </div>
                            {graphData && <ICRMReviewGraph graphData={graphData} />}
                        </div>
                    </>
                )}
            </div>


        </Container>
    )
}