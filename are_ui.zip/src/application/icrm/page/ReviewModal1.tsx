// import { useState } from "react";
// import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Textarea } from "@/components/ui/textarea";
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { Label } from "@/components/ui/label";
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
// import JournalsModal from "@/application/icrm/page/JournalsModal";
// import changeRequestsData from "@/application/icrm/data/change_requests_data.json";
// import reviewDecisionData from "@/application/icrm/data/review_decision_data.json";

// interface ReviewModal1Props {
//   open: boolean;
//   onOpenChange: (open: boolean) => void;
//   crNumber?: string;
//   onShowDetailModal: () => void;
// }

// const ReviewModal1 = ({ open, onOpenChange, crNumber, onShowDetailModal }: ReviewModal1Props) => {
//   const [showJournals, setShowJournals] = useState(false);
//   const changeRequest = changeRequestsData.find(cr => cr.crNo === crNumber);
//   const reviewDecision = reviewDecisionData.find(rd => rd.crNo === crNumber);
  
//   const [formData, setFormData] = useState({
//     tierZeroName: changeRequest?.tierZeroName || "Others",
//     reviewDecision: reviewDecision?.portfolios?.Digital?.reviewDecision || "Review Pending",
//     changeNutshell: changeRequest?.title || "",
//     comments: reviewDecision?.portfolios?.Digital?.comments || "within greenzone and can be approved"
//   });

//   return (
//     <Dialog open={open} onOpenChange={onOpenChange}>
//       <DialogContent className="max-w-2xl">
//         <DialogHeader>
//           <DialogTitle className="text-lg font-semibold">
//             Review This CR at portfolio level
//           </DialogTitle>
//         </DialogHeader>

//         <div className="space-y-6 py-4">
//           <div className="grid grid-cols-2 gap-6">
//             <div className="space-y-2">
//               <Label htmlFor="tierZeroName">Tier Zero Name:</Label>
//               <Input
//                 id="tierZeroName"
//                 value={formData.tierZeroName}
//                 readOnly
//                 className="bg-muted"
//               />
//             </div>

//             <div className="space-y-2">
//               <Label htmlFor="changeNutshell">Change Nutshell:</Label>
//               <Input
//                 id="changeNutshell"
//                 value={formData.changeNutshell}
//                 readOnly
//                 className="bg-muted"
//               />
//             </div>
//           </div>

//           <Tabs defaultValue="digital" className="w-full">
//             <TabsList>
//               <TabsTrigger value="digital">Digital</TabsTrigger>
//             </TabsList>
            
//             <TabsContent value="digital" className="space-y-4">
//               <div className="grid grid-cols-2 gap-6">
//                 <div className="space-y-2">
//                   <Label htmlFor="reviewDecision">Review Decision:</Label>
//                   <Select value={formData.reviewDecision} onValueChange={(value) => setFormData(prev => ({ ...prev, reviewDecision: value }))}>
//                     <SelectTrigger>
//                       <SelectValue />
//                     </SelectTrigger>
//                     <SelectContent>
//                       <SelectItem value="Approved">Approved</SelectItem>
//                       <SelectItem value="Rejected">Rejected</SelectItem>
//                       <SelectItem value="Conditionally Approved">Conditionally Approved</SelectItem>
//                       <SelectItem value="Need Further Information">Need Further Information</SelectItem>
//                       <SelectItem value="On Hold">On Hold</SelectItem>
//                     </SelectContent>
//                   </Select>
//                 </div>
                
//                 <div className="space-y-2">
//                   <Label htmlFor="comments">Comments:</Label>
//                   <Textarea
//                     id="comments"
//                     value={formData.comments}
//                     onChange={(e) => setFormData(prev => ({ ...prev, comments: e.target.value }))}
//                     rows={3}
//                     className="resize-none"
//                   />
//                 </div>
//               </div>
//             </TabsContent>
//           </Tabs>
//         </div>

//         <div className="flex items-center justify-between pt-4 border-t">
//           <div className="flex gap-2">
//             <Button 
//               variant="outline"
//               onClick={onShowDetailModal}
//               className="bg-blue-500 text-white hover:bg-blue-600"
//             >
//               Show Review Modal
//             </Button>
            
//             <Button 
//               variant="outline"
//               onClick={() => setShowJournals(true)}
//             >
//               Journals
//             </Button>
//           </div>
          
//           <Button className="bg-blue-500 text-white hover:bg-blue-600">
//             Save
//           </Button>
//         </div>

//         <JournalsModal 
//           open={showJournals}
//           onOpenChange={setShowJournals}
//           crNumber={crNumber || ""}
//         />
//       </DialogContent>
//     </Dialog>
//   );
// };

// export default ReviewModal1;