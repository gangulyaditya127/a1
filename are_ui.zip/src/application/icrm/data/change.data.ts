import { getNthDate } from "@/lib/date.utils";

export const changeList=[
    {
        // checkbox:[],
        notes:[],
        crNo:'CHG0005774123',
        crmScore:'low',
        snowRisk:'medium',
        zone:'green',
        primaryApp:'Identity Management Systems',
        title:'Offcycle Realtime Payment Microservice deployment',
        startDate:getNthDate(-10),
        endDate:getNthDate(1),
        pastMIMID:'124242',
        coordinatingGrpManager:'Sudipta Maiti',
        phase:'assesment-pending',
        reviewDecision:'Approved post tier-0',
        crExaminer:'Sudhanshu Singh',
        assosiatedCR:'0',
    }
]


export const MainGraphData = [
  {"lob": "Digital", "request_type": "Reviewed Change Requests", "application": 30, "approval_groups": 15, "change_tasks": 20},
  {"lob": "Digital", "request_type": "All Change Requests", "application": 40, "approval_groups": 25, "change_tasks": 35},

  {"lob": "Payments", "request_type": "Reviewed Change Requests", "application": 35, "approval_groups": 20, "change_tasks": 10},
  {"lob": "Payments", "request_type": "All Change Requests", "application": 50, "approval_groups": 30, "change_tasks": 20},

  {"lob": "Data & Analytics", "request_type": "Reviewed Change Requests", "application": 28, "approval_groups": 15, "change_tasks": 12},
  {"lob": "Data & Analytics", "request_type": "All Change Requests", "application": 45, "approval_groups": 20, "change_tasks": 25},

  {"lob": "Finance", "request_type": "Reviewed Change Requests", "application": 38, "approval_groups": 18, "change_tasks": 15},
  {"lob": "Finance", "request_type": "All Change Requests", "application": 55, "approval_groups": 25, "change_tasks": 30},

  {"lob": "Cloud", "request_type": "Reviewed Change Requests", "application": 42, "approval_groups": 20, "change_tasks": 25},
  {"lob": "Cloud", "request_type": "All Change Requests", "application": 60, "approval_groups": 30, "change_tasks": 40}
]

