import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "Integrated Change Review Management​",
    route: "/icrm",
    key: "1",
  },
];
