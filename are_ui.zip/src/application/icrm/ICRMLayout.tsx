import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { TOP_NAV_LIST } from "./data/topnav.data.ts";
import { SIDEBAR_DATA } from "./data/sidebar.data.ts";

function ICRMLayout() {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(updateSideBarNavigation(SIDEBAR_DATA));
    dispatch(updateTopNavigation({ navList: TOP_NAV_LIST, isHome: false }));
    return () => {
      dispatch(
        updateSideBarNavigation({
          hasSideBar: false,
          sideBarNavList: [],
          bottomNavList: [],
        }),
      );
      dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
    }
  }, []);
  return <Outlet />;
}
export default ICRMLayout;
