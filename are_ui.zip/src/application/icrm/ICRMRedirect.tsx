import { useEffect } from "react"
import { Navigate } from "react-router-dom";

export default function ICRMRedirect() {
    useEffect(() => {
        window.open('https://ismartams.tcsapps.com/IADD/jsp/ChangeMgmtDashboard/init', '_black');
    }, [])
    return (
        <Navigate to="/"/>
    )
}