"use client";

import * as React from "react";
import { format, parse } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { DateRange } from "react-day-picker";

import { cn } from "@/lib/tailwind.utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { setDateRange } from "@/application/icrm/feature/slice/filterSlice";

export default function ICRMDateRange({
  className,
}: React.HTMLAttributes<HTMLDivElement>) {


  const dispatch = useAppDispatch();

  // 🔹 Get date range from Redux state
  const { startDate, endDate } = useAppSelector((state) => state.filters);
  // 🔹 Convert Redux strings into Date objects for Calendar
  const dateRange: DateRange | undefined =
    startDate && endDate
      ? {
        from: parse(startDate, "dd-MMM-yy HH:mm", new Date()),
        to: parse(endDate, "dd-MMM-yy HH:mm", new Date()),
      }
      : undefined;

  // 🔹 Handle user selection (dispatches directly to Redux)
  const handleSelect = (range: DateRange | undefined) => {
    if (range?.from && range?.to) {
      dispatch(
        setDateRange({
          startDate: format(range.from, "dd-MMM-yy HH:mm"),
          endDate: format(range.to, "dd-MMM-yy HH:mm"),
        })
      );
    }
  };

  return (
    <div className={cn(className)}>
      <Label>CR's timeline</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant="outline"
            className={cn(
              "w-[300px] justify-start text-left font-normal flex gap-2",
              !dateRange && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="h-4 w-4" />
            {dateRange?.from ? (
              dateRange.to ? (
                <>
                  {format(dateRange.from, "LLL dd, y")} -{" "}
                  {format(dateRange.to, "LLL dd, y")}
                </>
              ) : (
                format(dateRange.from, "LLL dd, y")
              )
            ) : (
              <span>Pick a date</span>
            )}
          </Button>
        </PopoverTrigger>

        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={dateRange?.from}
            selected={dateRange}
            onSelect={handleSelect}
            numberOfMonths={2}
            captionLayout="dropdown"
            showOutsideDays
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}