import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    Legend,
    LabelList,
    ResponsiveContainer,
} from "recharts";
import { GraphData } from "./slice/dashboardSlice";

interface TransformedDatum {
    lob: string;
    reviewed_application: number;
    reviewed_approvalGrp: number;
    reviewed_changeTask: number;
    total_application: number;
    total_approvalGrp: number;
    total_changeTask: number;
    reviewedSum: number;
    totalSum: number;
}
interface Props {
    graphData: GraphData[];
}
const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        const data = payload[0].payload;
        return (
            <div className="bg-white dark:bg-gray-800 p-3 rounded shadow-md text-sm">
                <p className="font-semibold text-gray-900 dark:text-gray-100">{label}</p>
                <p className="text-green-600 dark:text-green-400">
                    Total Reviewed: {data.reviewedSum}
                </p>
                <p className="text-blue-600 dark:text-blue-400">
                    Total: {data.totalSum}
                </p>
            </div>
        );
    }
    return null;
};
const StackedBarChart = ({ graphData }: Props) => {
    const transformedData: TransformedDatum[] = graphData.map((item) => ({
        lob: item.lob,
        reviewed_application: item.reviewed.application,
        reviewed_approvalGrp: item.reviewed.approvalGrp,
        reviewed_changeTask: item.reviewed.changeTask,
        total_application: item.total.application,
        total_approvalGrp: item.total.approvalGrp,
        total_changeTask: item.total.changeTask,
        reviewedSum:
            item.reviewed.application +
            item.reviewed.approvalGrp +
            item.reviewed.changeTask,
        totalSum:
            item.total.application +
            item.total.approvalGrp +
            item.total.changeTask,
    }));

    console.error({transformedData});
    // ✅ Custom Tooltip to show only Reviewed & Total

    return (
        <div className="w-full h-[600px] p-6 rounded-2xl shadow-md bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
            <h2 className="text-xl font-bold text-center mb-4 text-gray-900 dark:text-gray-100">
                Reviewed vs Total Change Requests by LOB
            </h2>

            <ResponsiveContainer width="100%" height={500}>
                <BarChart
                    data={transformedData}
                    margin={{ top: 20, right: 100, left: 50, bottom: 20 }}
                >
                    <XAxis
                        dataKey="lob"
                        label={{
                            value: "Line of Business (LOB)",
                            position: "bottom",
                            fill: "#6B7280",
                        }}
                        tick={{ fill: "#6B7280", fontSize: 14 }}
                    />
                    <YAxis
                        label={{
                            value: "Number of Changes",
                            angle: -90,
                            position: "insideLeft",
                            fill: "#6B7280",
                        }}
                        tick={{ fill: "#6B7280", fontSize: 14 }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                        wrapperStyle={{
                            marginTop: 10,
                            marginLeft: 35,
                            position: "relative",
                            color: "#6B7280",
                        }}
                    />

                    <Bar dataKey="reviewed_application" stackId="reviewed" fill="#4CAF50">
                        <LabelList dataKey="reviewed_application" position="center" fill="#fff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>
                    <Bar dataKey="reviewed_approvalGrp" stackId="reviewed" fill="#66BB6A">
                        <LabelList dataKey="reviewed_approvalGrp" position="center" fill="#fff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>
                    <Bar dataKey="reviewed_changeTask" stackId="reviewed" fill="#81C784">
                        <LabelList dataKey="reviewed_changeTask" position="center" fill="#fff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>


                    <Bar dataKey="total_application" stackId="total" fill="#2196F3">
                        <LabelList dataKey="total_application" position="center" fill="#090909ff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>
                    <Bar dataKey="total_approvalGrp" stackId="total" fill="#42A5F5">
                        <LabelList dataKey="total_approvalGrp" position="center" fill="#090909ff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>
                    <Bar dataKey="total_changeTask" stackId="total" fill="#64B5F6">
                        <LabelList dataKey="total_changeTask" position="center" fill="#090909ff" formatter={(val: number) => (val > 0 ? val : "")} />
                    </Bar>
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default StackedBarChart;