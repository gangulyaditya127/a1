

import { Bar, BarChart, CartesianGrid, XAxis } from "recharts";
import { format } from "date-fns";
import {
    Card,
    CardContent,
    CardDescription, CardHeader,
    CardTitle
} from "@/components/ui/card";
import {
    ChartConfig,
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
} from "@/components/ui/chart";

import { GraphData } from "./slice/dashboardSlice";
import { useAppSelector } from "@/lib/redux/hooks";


// const chartData = [
//     { month: "January", reviewedSum: 186, total_application: 80 },
//     { month: "February", reviewedSum: 305, total_application: 200 },
//     { month: "March", reviewedSum: 237, total_application: 120 },
//     { month: "April", reviewedSum: 73, total_application: 190 },
//     { month: "May", reviewedSum: 209, total_application: 130 },
//     { month: "June", reviewedSum: 214, total_application: 140 },
// ]

const chartConfig = {
    reviewedSum: {
        label: "Total Reviewed",
        color: "var(--chart-1)",
    },
    total_application: {
        label: "Total Application",
        color: "var(--chart-2)",
    },
} satisfies ChartConfig

interface TransformedDatum {
    lob: string;
    reviewed_application: number;
    reviewed_approvalGrp: number;
    reviewed_changeTask: number;
    total_application: number;
    total_approvalGrp: number;
    total_changeTask: number;
    reviewedSum: number;
    totalSum: number;
}
export function ICRMReviewGraph({ graphData }: { graphData: GraphData[] }) {
    const chartData: TransformedDatum[] = graphData.map((item) => ({
        lob: item.lob,
        reviewed_application: item.reviewed.application,
        reviewed_approvalGrp: item.reviewed.approvalGrp,
        reviewed_changeTask: item.reviewed.changeTask,
        total_application: item.total.application,
        total_approvalGrp: item.total.approvalGrp,
        total_changeTask: item.total.changeTask,
        reviewedSum:
            item.reviewed.application +
            item.reviewed.approvalGrp +
            item.reviewed.changeTask,
        totalSum:
            item.total.application +
            item.total.approvalGrp +
            item.total.changeTask,
    }));
    const { startDate, endDate } = useAppSelector((state) => state.filters);

    return (
        <Card className="rounded-xl">
            <CardHeader className="border-b">
                <CardTitle className="text-md">Reviewed vs Total Change Requests by LOB</CardTitle>
                <CardDescription className="text-sm">{format(startDate, "LLL dd, y")} - {format(endDate, "LLL dd, y")}</CardDescription>
            </CardHeader>
            <CardContent>
                <ChartContainer config={chartConfig} className="min-h-[200px] max-h-[200px]">
                    <BarChart accessibilityLayer data={chartData}>
                        <CartesianGrid vertical={false} />
                        <XAxis
                            dataKey="lob"
                            tickLine={false}
                            tickMargin={10}
                            axisLine={false}
                            tickFormatter={(value) => value}
                        />
                        <ChartTooltip
                            cursor={false}
                            content={<ChartTooltipContent indicator="dashed" />}
                        />
                        <Bar dataKey="reviewedSum" fill="hsl(var(--color-reviewedSum))" radius={4} />
                        <Bar dataKey="total_application" fill="hsl(var(--color-total_application))" radius={4} />
                    </BarChart>
                </ChartContainer>
            </CardContent>
        </Card>
    )
}
