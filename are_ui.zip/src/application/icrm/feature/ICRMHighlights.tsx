import { Separator } from "@/components/ui/seperator";
import {
    HoverCard,
    HoverCardContent,
    HoverCardTrigger,
} from "@/components/ui/hover-card"
import { Icon } from "@/components/ui/icon";
import { Link } from "react-router-dom";

import { DashboardCount } from "./slice/dashboardSlice";
interface Props {
    dashboardCount: DashboardCount;
}
export default function ICRMHighlights({ dashboardCount }: Props) {
    return (
        <div className="rounded-xl bg-blue-700 dark:blue-600  text-white ">
            <div className="flex justify-between px-8 py-10">
                <HoverCard >
                    <HoverCardTrigger asChild className="cursor-pointer group">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                Application Changes
                            </p>
                            <div className="flex items-baseline text-4xl font-medium">
                                {dashboardCount.application_changes}
                            </div>
                            <Link to={'/icrm/change-details'} className="flex items-center gap-1 text-sm mt-2 opacity-90 ">
                                <span>View More</span>
                                <Icon name='arrow-right' className="h-4 w-4 group-hover:translate-x-1" />
                            </Link>
                        </div>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-80">
                        <div className="grid grid-cols-2  gap-4">
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.tap_and_above_changes}</p>
                                <p className="text-sm text-muted-foreground">Task assesment & above</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.l2_review_completed}</p>
                                <p className="text-sm text-muted-foreground">Completed L2 review</p>
                            </div>

                        </div>
                    </HoverCardContent>
                </HoverCard>

                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] bg-white/30"
                />
                <HoverCard>
                    <HoverCardTrigger asChild className="cursor-pointer group">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                Critical Changes
                            </p>
                            <div className="flex items-baseline text-4xl font-medium">
                                {dashboardCount.critical_changes}
                            </div>
                            <p className="flex items-center gap-1 text-sm mt-2 opacity-90 ">
                                <span>View More</span>
                                <Icon name='arrow-right' className="h-4 w-4 group-hover:translate-x-1" />
                            </p>
                        </div>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-80">
                        <div className="grid grid-cols-2  gap-4">
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.tap_and_above_changes}</p>
                                <p className="text-sm text-muted-foreground">Task assesment & above</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.l2_review_completed}</p>
                                <p className="text-sm text-muted-foreground">Completed L2 review</p>
                            </div>
                        </div>
                    </HoverCardContent>
                </HoverCard>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] bg-white/30"
                />
                <HoverCard>
                    <HoverCardTrigger asChild className="cursor-pointer group">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                EMER Changes
                            </p>
                            <div className="flex items-baseline text-4xl font-medium">
                                {dashboardCount.emergency_changes}
                            </div>
                            <p className="flex items-center gap-1 text-sm mt-2 opacity-90 ">
                                <span>View More</span>
                                <Icon name='arrow-right' className="h-4 w-4 group-hover:translate-x-1" />
                            </p>
                        </div>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-80">
                        <div className="grid grid-cols-2  gap-4">
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.expedited_changes}</p>
                                <p className="text-sm text-muted-foreground">Expedite Changes</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.regular_changes}</p>
                                <p className="text-sm text-muted-foreground">Regular Changes</p>
                            </div>
                        </div>
                    </HoverCardContent>
                </HoverCard>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] bg-white/30"
                />
                <HoverCard>
                    <HoverCardTrigger asChild className="cursor-pointer group">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                Other Changes
                            </p>
                            <div className="flex items-baseline text-4xl font-medium">
                                {dashboardCount.others_changes}
                            </div>
                            <p className="flex items-center gap-1 text-sm mt-2 opacity-90 ">
                                <span>View More</span>
                                <Icon name='arrow-right' className="h-4 w-4 group-hover:translate-x-1" />
                            </p>
                        </div>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-96">
                        <div className="grid grid-cols-3  gap-4">
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.other_tap_and_above_changes}</p>
                                <p className="text-sm text-muted-foreground">Task Assessment & Above</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.others_l2_review_completed}</p>
                                <p className="text-sm text-muted-foreground">L2 Review Completed</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.others_approval_group}</p>
                                <p className="text-sm text-muted-foreground">GCG Approval Group</p>
                            </div>
                        </div>
                    </HoverCardContent>
                </HoverCard>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] bg-white/30"
                />
                <HoverCard>
                    <HoverCardTrigger asChild className="cursor-pointer group">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                Approved Changes but L2 review failed
                            </p>
                            <div className="flex items-baseline text-4xl font-medium">
                                {dashboardCount.ltwo_rev_failed_but_approved}
                            </div>
                            <p className="flex items-center gap-1 text-sm mt-2 opacity-90 ">
                                <span>View More</span>
                                <Icon name='arrow-right' className="h-4 w-4 group-hover:translate-x-1" />
                            </p>
                        </div>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-80">
                        <div className="grid grid-cols-2  gap-4">
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.expedited_changes}</p>
                                <p className="text-sm text-muted-foreground">Expedite Changes</p>
                            </div>
                            <div className="text-2xl">
                                <p className="font-medium">{dashboardCount.regular_changes}</p>
                                <p className="text-sm text-muted-foreground">Regular Changes</p>
                            </div>
                        </div>
                    </HoverCardContent>
                </HoverCard>
            </div>
        </div>
    )
}