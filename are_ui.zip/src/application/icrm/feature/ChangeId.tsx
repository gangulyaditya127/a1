import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { fetchChangeRequest } from "@/application/icrm/feature/slice/tierzeroSlice";
import { useLocation } from "react-router-dom";
import Loader from "@/components/ui/loader";
import ErrorContainer from "@/components/ui/error-container";
import ReviewChange from "./ReviewChange";
import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";
const ChangeID = () => {
    const location = useLocation();
    const changeData = location.state?.changeData;


    const dispatch = useAppDispatch();

    useEffect(() => {
        dispatch(fetchChangeRequest({
            crNo: changeData.change_number,
            sector: "BFSI",
            region: changeData.region,
            soeid: "1735400",
            lob: changeData.lob_name
        }));
    }, [dispatch]);

    // const [formData, setFormData] = useState({
    //     reviewDecision: "",
    //     comments: "",
    //     speakerName: "",
    //     speakerSoeid: "",
    //     owningTeam: "",
    //     rationale: "",
    //     timeZone: "EST",
    // });


    const { tierzeroData, loading, error } = useAppSelector(
        (state) => state.tierzero
    );

    // useEffect(() => {
    //     if (tierzeroData) {
    //         setFormData({
    //             reviewDecision: tierzeroData.reviewDecision ?? "",
    //             comments: tierzeroData.comments ?? "",
    //             speakerName: "",
    //             speakerSoeid: "",
    //             owningTeam: "",
    //             rationale: "",
    //             timeZone: "EST",
    //         })
    //     }
    // }, [tierzeroData])

    // const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    //     const { name, value } = e.target;
    //     console.log(formData)
    //     console.log(name)
    //     console.log(value)
    //     setFormData(prev => ({ ...prev, [name]: value }));
    // };


    // const handleSubmit = async () => {
    //     if (!formData.reviewDecision || !formData.comments.trim()) {
    //         setAlert({ type: "error", message: "Please fill in required fields before saving." });
    //         return;
    //     }

    //     setIsSaving(true);
    //     setAlert(null);

    //     try {
    //         const payload = {
    //             sector: "BFSI",
    //             region: "SEAL",
    //             lob: "Digital",
    //             crNo: changeData?.change_number,
    //             soeid: "1735400",
    //             ...formData,
    //         };

    //         const response = await axios.post(
    //             "https://ismartams.tcsapps.com/api/python_icrm/save_portfolio_modal_data",
    //             payload,
    //             { headers: { "Content-Type": "application/json" } }
    //         );

    //         if (response.status === 200) {
    //             setAlert({ type: "success", message: "✅ Data saved successfully!" });
    //             setFormData({
    //                 reviewDecision: "",
    //                 comments: "",
    //                 speakerName: "",
    //                 speakerSoeid: "",
    //                 owningTeam: "",
    //                 rationale: "",
    //                 timeZone: "EST",
    //             });
    //         } else {
    //             setAlert({ type: "error", message: "⚠️ Failed to save data." });
    //         }
    //     } catch (error) {
    //         console.error("Error saving data:", error);
    //         setAlert({ type: "error", message: "An error occurred while saving data." });
    //     } finally {
    //         setIsSaving(false);
    //         // Hide alert after 2 seconds
    //         setTimeout(() => setAlert(null), 5000);
    //     }
    // };
    if (loading) return (
        <Container className="flex flex-col gap-4">
            <Skeleton className="h-10 rounded-lg" />
            <Skeleton className="h-[200px] grid place-items-center rounded-lg ">
                <Loader className="justify-center m-24">

                </Loader>
            </Skeleton>
            <Skeleton className="h-[40px] grid place-items-center rounded-lg ">
                
            </Skeleton>
            <Skeleton className="h-[400px] grid place-items-center rounded-lg ">
                <Loader className="justify-center m-24">

                </Loader>
            </Skeleton>
        </Container>
    )
    if (error) return <ErrorContainer className="mt-6" />
    if (!tierzeroData) return null;

    console.log(alert);
    return (
        <div className="pb-12">
            {/* Alert Section */}
            {/* {alert && (
                <div className="fixed bottom-5 right-5 z-50 max-w-sm">
                    <Alert className={cn(
                        alert.type === "success"
                            ? "border-green-500 bg-green-100 text-green-700"
                            : "border-red-500 bg-red-100 text-red-700"
                    )}
                    >
                        <AlertTitle>{alert.type === "error" ? "Error" : "Success"}</AlertTitle>
                        <AlertDescription>{alert.message}</AlertDescription>
                    </Alert>
                </div>
            ) */}


            {/* Show loader overlay while saving */}
            {/* {
                isSaving && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/10 backdrop-blur-sm z-20">
                        <Loader className="text-gray-500">
                            <span className="ml-2">Saving...</span>
                        </Loader>
                    </div>
                )
            } */}


            <div className="flex items-center gap-2">
                <span className="font-medium">Change Number - {changeData.change_number} |</span>
                <span className="font-medium">Region - {changeData.region} |</span>
                <span className="font-medium">Portfolio - {changeData.lob_name}</span>
            </div>



            <ReviewChange
                open={true}
                crNumber={changeData.change_number}
                sector="BFSI"
                region={changeData.region}
                lob={changeData.lob_name}

            />



            {/* <div className="space-y-4 mt-4">
                <div className="flex-1 text-sm text-gray-500 ">
                    <label className="font-medium block mb-2">Review Decision</label>
                    <select
                        className="border rounded-md p-2 w-full"
                        name="reviewDecision"
                        value={formData.reviewDecision}
                        onChange={handleChange}
                    >
                        <option value="" disabled hidden>
                            Select an option
                        </option>
                        {(tierzeroData.reviewDecisions as any[])?.map((item, index) => (
                            <option key={index} value={item?.review_decision}>
                                {item?.review_decision}
                            </option>
                        ))}
                    </select>
                </div>


                <div className="flex-1 text-sm text-gray-500">
                    <label className="font-medium text-gray-500 block mb-2">Comments</label>
                    <textarea
                        name="comments"
                        value={formData.comments}
                        onChange={handleChange}
                        className="w-full border rounded-md p-2 "
                        placeholder="Review this CR at portfolio level2"
                    />
                </div>

                <div className="grid grid-rows-2 gap-4 hidden">
                    <div className="grid grid-cols-[1fr_1fr_1fr] gap-4">
                        <div className="text-sm text-gray-500">
                            <label className="font-medium text-gray-500 block mb-2">Speaker Name:</label>
                            <input className="border rounded-md p-2 w-full bg-gray-700/10"
                                name="speakerName"
                                value={formData.speakerName}
                                onChange={handleChange} />
                        </div>
                        <div className="text-sm text-gray-500">
                            <label className="font-medium text-gray-500 block mb-2">Speaker Soeid:</label>
                            <input className="border rounded-md p-2 w-full bg-gray-700/10"
                                name="speakerSoeid"
                                value={formData.speakerSoeid}
                                onChange={handleChange} />
                        </div>
                        <div className="text-sm text-gray-500">
                            <label className="font-medium text-gray-500 block mb-2">Owning Portfolio/Team:</label>
                            <select className="border rounded-md p-2 w-full bg-gray-700/10"
                                name="owningTeam"
                                value={formData.owningTeam}
                                onChange={handleChange}
                            >
                                <option value="" disabled hidden>
                                    -- Select an option --
                                </option>
                            </select>
                        </div>
                    </div>

                    <div className="text-sm text-gray-500">
                        <label className="font-medium text-gray-500 block mb-2">Rationale For Escalation:</label>
                        <textarea
                            className="w-full border text-white rounded-md p-2 bg-gray-700/10"
                            placeholder="Enter Your Rationale"
                        />
                    </div>
                </div>


                <div className="flex gap-6">
                    <Button
                        onClick={handleSubmit}
                        className="bg-blue-500 rounded-lg text-white hover:bg-blue-600"
                    >
                        Save
                    </Button>
                </div>
            </div> */}
            {/* <div className=" text-xs text-muted-foreground mt-4 mb-1 uppercase font-medium">
                Review this CR at portfolio level
            </div> */}

        </div >
    );
}

export default ChangeID