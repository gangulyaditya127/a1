import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectLabel,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/tailwind.utils";
import ICRMDateRange from "./ICRMDateRange";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { setSector, setRegion, setPortfolio } from "@/application/icrm/feature/slice/filterSlice";
export default function ICRMFilters({
    className
}: {
    className?: string
}) {
    const dispatch = useAppDispatch();
    const { sector, region, portfolio } = useAppSelector((state) => state.filters);


    return (
        <div className={cn("flex gap-4", className)}>
            <div className="">
                <Label>Sector</Label>
                <Select value={sector}
                    onValueChange={(value) => dispatch(setSector(value))}
                >
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select a sector" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectLabel>Sector</SelectLabel>
                            <SelectItem value="BFSI">BFSI</SelectItem>
                            <SelectItem value="HEALTHCARE">HEALTHCARE</SelectItem>
                            <SelectItem value="TECH">TECH</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </div>
            <div className="">
                <Label>Region</Label>
                <Select value={region}
                    onValueChange={(value) => dispatch(setRegion(value))}
                >
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select a region" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectLabel>Region</SelectLabel>
                            <SelectItem value="SEAL">SEAL</SelectItem>
                            <SelectItem value="NA">NA</SelectItem>
                            <SelectItem value="EU">EU</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </div>
            <div className="">
                <Label>Portfolio</Label>
                <Select value={portfolio}
                    onValueChange={(value) => dispatch(setPortfolio(value))}
                >
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select a region" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectLabel>Portfolio</SelectLabel>
                            <SelectItem value="DIGITAL">DIGITAL</SelectItem>
                            <SelectItem value="NA">NA</SelectItem>
                            <SelectItem value="EU">EU</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </div>
            <ICRMDateRange />

        </div>
    )
}