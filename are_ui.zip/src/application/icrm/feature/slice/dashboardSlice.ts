import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import type { RootState } from "@/lib/redux/store";

export interface DashboardCount {
  app_l2_review_completed: number;
  app_to_lob_mapped: number;
  application_changes: number;
  approver_to_lob_mapped: number;
  cc_changes: number;
  cml1: null | number;
  cml2: null | number;
  cml3: null | number;
  cml4: null | number;
  critical_application_changes: number;
  critical_changes: number;
  critical_others_changes: number;
  emergency_changes: number;
  expedited_changes: number;
  high_crm_score_c_rs: null | number;
  high_snow_risk_c_rs: null | number;
  impacted_app_to_lob_mapped: number;
  infra_changes: number;
  l2_review_approved: number;
  l2_review_completed: number;
  l2_review_pending: number;
  l2_review_rejected: number;
  ltwo_rev_failed_but_approved: number;
  manually_lob_mapped: number;
  multidaychanges: number;
  multidaychanges_app: number;
  multidaychanges_infra: number;
  only_l1_task: number;
  other_tap_and_above_changes: number;
  others_approval_group: number;
  others_changes: number;
  others_l2_review_completed: number;
  out_of_greenzone: number;
  out_of_greenzone_app: number;
  out_of_greenzone_infra: number;
  patch_count: number;
  pre_test_exempt: number;
  psm_appr_pending: number;
  regular_changes: number;
  reviewer_to_lob_mapped: number;
  senior_mgmt_cr: number;
  t2_changes: number;
  t3_changes: number;
  tap_and_above_changes: number;
  task_to_lob_mapped: number;
  total_changes: number;
}

export interface GraphData {
  lob: string;
  reviewed: { application: number; approvalGrp: number; changeTask: number };
  total: { application: number; approvalGrp: number; changeTask: number };
}

interface DashboardState {
  dashboardCount: DashboardCount | null;
  loading: boolean;
  error: string | null;
  graphData: GraphData[] | null;
}

const initialState: DashboardState = {
  dashboardCount: null,
  loading: false,
  error: null,
  graphData: null
};

// Async thunk — dynamically fetches based on filters
export const fetchDashboardData = createAsyncThunk<
  { dashboardCount: DashboardCount; graphData: GraphData[] },
  void,
  { state: RootState }
>("dashboard/fetchDashboardData", async (_, { getState }) => {
  const { sector, region, portfolio, startDate, endDate } = getState().filters;

  const [countRes, chartRes] = await Promise.all([
    axios.get(`https://ismartams.tcsapps.com/api/python_icrm/dashboardCount`, {
      params: { sector, region, portfolio, startDate, endDate },
    }),
    axios.get(`https://ismartams.tcsapps.com/api/python_icrm/dashboardChartData`, {
      params: { sector, region, portfolio, startDate, endDate },
    }),
  ]);

  return {
    dashboardCount: countRes.data.data,
    graphData: chartRes.data.data,
  };
});

// export const fetchDashboardData = createAsyncThunk<
//   DashboardCount,
//   void,
//   { state: RootState }
// >("dashboard/fetchDashboardCount", async (_, { getState }) => {
//   const { sector, region, startDate, endDate } = getState().filters;

//   const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/dashboardCount", {
//     params: { sector, region, startDate, endDate },
//   });

//   return response.data.data; // assuming your API returns { data: {...} }
// });

const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboardData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDashboardData.fulfilled, (state, action) => {
        state.loading = false;
        state.dashboardCount = action.payload.dashboardCount;
        state.graphData = action.payload.graphData;
      })
      .addCase(fetchDashboardData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? "Failed to fetch data";
      });
  },
});

export default dashboardSlice.reducer;