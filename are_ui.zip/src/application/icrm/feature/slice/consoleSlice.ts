import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import type { RootState } from "@/lib/redux/store";

// Utility function to format dates
function formatDate(date: string | Date | null): string {
    if (!date) return "";
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`
}

// Interfaces

export interface ChangeData {
    EstimatedImpact: string;
    PriorityRank: number;
    PriorityScore: number;
    Reasoning: string[];
    ReviewUrgency: string;
    ai_priority: number;
    app_infra: string;
    associated_cr_no: string | null;
    change_category: string;
    change_no: string | null;
    change_number: string;
    change_task_present: string;
    ci_criticality: string;
    color: string | null;
    consolidated_lob: string;
    coordinating_group: string;
    coordinating_grp_manager: string | null;
    countries: string | null;
    crm_score: string;
    description: string;
    downtime: string;
    duration: number;
    end_date: string;
    estimated_impact: string | null;
    explanation: string;
    historical_context: string;
    impacted_applications: string | null;
    l2_review_status: string | null;
    lob_name: string;
    lob_spoc: string | null;
    lobs: string | null;
    model: string;
    pass_percentage: number;
    phase: string;
    phase_state: string;
    prediction: string;
    primary_application: string;
    priority_score: number | null;
    reasoning: string | null;
    region: string;
    requestor: string;
    review_urgency: string | null;
    risk: string;
    risk_label: string;
    source: string;
    start_date: string;
    successprobability: string;
    sys_id: string;
    sys_number: string;
    tier_zero_name: string;
    title: string;
    topfactors: string; // Could be Record<string, number> if parsed
    zone: string;
}


export interface ConsoleResponse {
    data: ChangeData[];
    page: number;
    page_size: number;
    total_records: number;
}

// Slice state
interface ConsoleState {
    changeData: ChangeData[];
    page: number;
    page_size: number;
    total_records: number;
    loading: boolean;
    error: string | null;
}

const initialState: ConsoleState = {
    changeData: [],
    page: 1,
    page_size: 20,
    total_records: 0,
    loading: false,
    error: null,
};

// ✅ Async thunk (just like your fetchDashboardData)
export const fetchConsoleList = createAsyncThunk<
    ConsoleResponse, // return type
    void,               // no args passed directly
    { state: RootState } // to access filters from state
>(
    "consoleList/fetchConsoleList",
    async (_, { getState }) => {
        const { sector, region, portfolio, startDate, endDate } = getState().filters;

        const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/change_review_table_data", {
            params: {
                sector,
                region,
                portfolio,
                start_date: formatDate(startDate),
                end_date: formatDate(endDate),
            },
        });
        console.log({"api is calleed":Date.now()})

        return response.data; // API returns { data: [...], page, page_size, total_records }
    }
);

// Slice definition
const consoleListSlice = createSlice({
    name: "consoleList",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchConsoleList.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchConsoleList.fulfilled, (state, action) => {
                state.loading = false;
                state.changeData = action.payload.data;
                state.page = action.payload.page;
                state.page_size = action.payload.page_size;
                state.total_records = action.payload.total_records;
            })
            .addCase(fetchConsoleList.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || "Failed to fetch change list";
            });
    },
});

export default consoleListSlice.reducer;