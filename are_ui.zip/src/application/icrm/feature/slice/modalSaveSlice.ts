import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
export interface JournalEntry {
    id: number;
    cr_no: string;
    sector: string;
    region: string;
    lob: string;
    tier_zero_name: string;
    comments: string;
    updated_by: string;
    updated_on: string;
    updated_on_string: string | null;
}

export interface ModalSaveData {
    comments: string;
    consolidated_review_decision: string;
    cr_no: string;
    cr_nutshell: string;
    cr_nutshell_journal_list: JournalEntry[];
    l2_review_status: string;
    lob: string;
    psm_review_status: string;
    rd_journal_list: JournalEntry[];
    region: string;
    review_decision: string;
    status: string;
    trz_journal_map: Record<string, unknown>;
    trz_name: string;
    update_trz_qn_ans_status: string | null;
}

export interface ModalSaveResponse {
    data: ModalSaveData;
    message: string;
    status: string;
}

interface ModalSaveState {
    data: ModalSaveResponse | null;
    loading: boolean;
    error: string | null;
}

const initialState: ModalSaveState = {
    data: null,
    loading: false,
    error: null,
};

// ✅ Async thunk for saving modal data (POST)
export const saveModalData = createAsyncThunk<
    ModalSaveResponse,
    Record<string, any> // you can refine this to a strict type later
>("modalSave/saveModalData", async (formData, { rejectWithValue }) => {
    try {
        const response = await axios.post(
            "https://ismartams.tcsapps.com/api/python_icrm/savemodaldata",
            formData,
            {
                headers: {
                    "Content-Type": "application/json",
                },
            }
        );
        return response.data as ModalSaveResponse;
    } catch (error: any) {
        return rejectWithValue(error.response?.data?.message || error.message);
    }
});

const modalSaveSlice = createSlice({
    name: "modalSave",
    initialState,
    reducers: {
        clearModalSaveData(state) {
            state.data = null;
            state.error = null;
            state.loading = false;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(saveModalData.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(saveModalData.fulfilled, (state, action) => {
                state.loading = false;
                state.data = action.payload;
            })
            .addCase(saveModalData.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            });
    },
});
export const { clearModalSaveData } = modalSaveSlice.actions;
export default modalSaveSlice.reducer;