// src/redux/tierzeroSlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";

/** -------- Interfaces -------- */

export interface ReviewDecision {
  access: boolean;
  access_level?: string;
  priority?: number;
  region?: string;
  review_decision: string;
  sector?: string;
}

export interface TierzeroData {
  accessMap: Record<string, boolean> | null; // API uses numeric-string keys sometimes
  comments: string | null;
  coordinatorMLevel: number | null;
  crNo: string;
  cr_nutshell: string | null;
  region: string | null;
  reviewDecision: string | null;
  reviewDecisions: string[] | null;
  review_decision: ReviewDecision[]; // detailed objects
  sector: string | null;
  teamsReviewList: any[]; // refine when you know shape
}

interface TierzeroState {
  tierzeroData: TierzeroData | null;
  loading: boolean;
  error: string | null;
}

const initialState: TierzeroState = {
  tierzeroData: null,
  loading: false,
  error: null,
};

/** -------- Async thunk --------
 * Accepts an object with params and returns TierzeroData on success
 */
export const fetchChangeRequest = createAsyncThunk<
  TierzeroData, // return type
  { crNo: string; sector: string; region: string; soeid: string; lob: string }, // arg type
  { rejectValue: string }
>(
  "tierzero/fetchChangeRequest",
  async (params, { rejectWithValue }) => {
    try {
      const { crNo, sector, region, soeid, lob } = params;

      const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/gettierzeroandrd", {
        params: { crNo, sector, region, soeid, lob },
      });

      // defensive: ensure response.data.data exists
      if (!response?.data?.data) {
        return rejectWithValue("Invalid response from server");
      }

      return response.data.data as TierzeroData;
    } catch (err: any) {
      // try to return a useful error message
      const message =
        err?.response?.data?.message || err?.message || "Failed to fetch tierzero data";
      return rejectWithValue(message);
    }
  }
);

/** -------- Slice -------- */

const tierzeroSlice = createSlice({
  name: "tierzero",
  initialState,
  reducers: {
    clearTierzeroData(state) {
      state.tierzeroData = null;
      state.error = null;
      state.loading = false;
    },
    setTierzeroData(state, action: PayloadAction<TierzeroData>) {
      state.tierzeroData = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchChangeRequest.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchChangeRequest.fulfilled, (state, action) => {
        state.loading = false;
        state.tierzeroData = action.payload;
      })
      .addCase(fetchChangeRequest.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload ?? action.error.message ?? "Failed to fetch change request";
      });
  },
});

export const { clearTierzeroData, setTierzeroData } = tierzeroSlice.actions;
export default tierzeroSlice.reducer;