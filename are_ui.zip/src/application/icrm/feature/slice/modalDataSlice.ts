// redux/modalDataSlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
// types/modalData.ts
export interface ReviewItem {
  checklist_id: number;
  checklist_checkpoint: string;
  checklist_desc: string;
  cr_no: string;
  description: string;
  impacted_applications: string | null;
  lob: string;
  psm_remarks: string | null;
  psm_review_status: string | null;
  reason: string;
  region: string;
  remarks: string | null;
  review_status_user: string | null;           // user review status
  review_file: string | null;
  review_status_icrm: string;           // main review status
  rf_uploaded_by: string | null;
  user_remarks: string | null;
}

export interface AccessMap {
  [key: string]: boolean;
}

export interface ModalData {
  access_map: AccessMap;
  cause_of_rejection: string;
  comments: string;
  cr_nutshell: string;
  criticality: string;
  phase: string;
  phase_state: string;
  review_decision: string;
  reviews: ReviewItem[];
  zone: string;
}

export interface ModalApiResponse {
  data: ModalData;
  status: string;
}

interface ModalDataState {
  modalData: ModalData | null;
  loading: boolean;
  error: string | null;
}

const initialState: ModalDataState = {
  modalData: null,
  loading: false,
  error: null,
};

export const fetchModalData = createAsyncThunk<
  ModalData,
  { crNo: string; sector: string; region: string; lob: string; },
  { rejectValue: string }
>(
  "modal/fetchModalData",
  async (params, { rejectWithValue }) => {
    try {
      const { crNo, sector, region, lob } = params;

      const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/getmodaldata", {
        params: { crNo, sector, region, soeid:'1735400', lob, tierZeroName:'Others' },
      });

      if (!response?.data?.data) {
        return rejectWithValue("Invalid response from server");
      }

      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(error.message || "Failed to fetch modal data");
    }
  }
);


const modalDataSlice = createSlice({
  name: "modalData",
  initialState,
  reducers: {
    clearModalData: (state) => {
      state.modalData = null;
      state.error = null;
      state.loading = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchModalData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchModalData.fulfilled, (state, action: PayloadAction<ModalData>) => {
        state.loading = false;
        state.modalData = action.payload;
      })
      .addCase(fetchModalData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearModalData } = modalDataSlice.actions;
export default modalDataSlice.reducer;