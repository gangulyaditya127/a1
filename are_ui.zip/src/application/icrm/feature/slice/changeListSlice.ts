import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import type { RootState } from "@/lib/redux/store";

// Utility function to format dates
function formatDate(date: string | Date | null): string {
  if (!date) return "";
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`
}

// Interfaces
export interface ChangeRecord {
  ai_priority: number;
  app_infra: string | null;
  associated_cr_no: string | null;
  change_category: string | null;
  change_number: string;
  change_task_present: string | null;
  color: string | null;
  consolidated_lob: string | null;
  coordinating_group: string | null;
  coordinating_grp_manager: string | null;
  countries: string | null;
  crm_score: string | null;
  description: string | null;
  downtime: string | null;
  end_date: string | null;
  historical_context: string | null;
  impacted_applications: string | null;
  l2_review_status: string | null;
  lob_name: string | null;
  lob_spoc: string | null;
  lobs: string | null;
  model: string | null;
  pass_percentage: number;
  phase: string | null;
  phase_state: string | null;
  primary_application: string | null;
  region: string | null;
  requestor: string | null;
  risk: string | null;
  source: string | null;
  start_date: string | null;
  sys_id: string | null;
  sys_number: string | null;
  tier_zero_name: string | null;
  title: string | null;
  zone: string | null;
}

export interface ChangeListResponse {
  data: ChangeRecord[];
  page: number;
  page_size: number;
  total_records: number;
}

// Slice state
interface ChangeListState {
  changeData: ChangeRecord[];
  page: number;
  page_size: number;
  total_records: number;
  loading: boolean;
  error: string | null;
}

const initialState: ChangeListState = {
  changeData: [],
  page: 1,
  page_size: 20,
  total_records: 0,
  loading: false,
  error: null,
};

// ✅ Async thunk (just like your fetchDashboardData)
export const fetchChangeList = createAsyncThunk<
  ChangeListResponse, // return type
  void,               // no args passed directly
  { state: RootState } // to access filters from state
>(
  "changeList/fetchChangeList",
  async (_, { getState }) => {
    const { sector, region, portfolio, startDate, endDate } = getState().filters;

    const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/change_review_table_data", {
      params: {
        sector,
        region,
        portfolio,
        start_date: formatDate(startDate),
        end_date: formatDate(endDate),
      },
    });

    return response.data; // API returns { data: [...], page, page_size, total_records }
  }
);

// Slice definition
const changeListSlice = createSlice({
  name: "changeList",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchChangeList.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchChangeList.fulfilled, (state, action) => {
        state.loading = false;
        state.changeData = action.payload.data;
        state.page = action.payload.page;
        state.page_size = action.payload.page_size;
        state.total_records = action.payload.total_records;
      })
      .addCase(fetchChangeList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch change list";
      });
  },
});

export default changeListSlice.reducer;