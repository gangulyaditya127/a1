import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface FiltersState {
  sector: string;
  region: string;
  portfolio: string;
  startDate: string;
  endDate: string;
}

const initialState: FiltersState = {
  sector: "BFSI",
  region: "SEAL",
  portfolio: "DIGITAL",
  startDate: "01-OCT-25 00:00",
  endDate: "31-DEC-25 23:59",
};

const filtersSlice = createSlice({
  name: "filters",
  initialState,
  reducers: {
    setSector(state, action: PayloadAction<string>) {
      state.sector = action.payload;
    },
    setRegion(state, action: PayloadAction<string>) {
      state.region = action.payload;
    },
    setPortfolio(state, action: PayloadAction<string>){
      state.portfolio = action.payload;
    },
    setDateRange(
      state,
      action: PayloadAction<{ startDate: string; endDate: string }>
    ) {
      state.startDate = action.payload.startDate;
      state.endDate = action.payload.endDate;
    },
  },
});

export const { setSector, setRegion, setPortfolio, setDateRange } = filtersSlice.actions;
export default filtersSlice.reducer;