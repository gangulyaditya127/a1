import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { fetchModalData, ReviewItem } from "@/application/icrm/feature/slice/modalDataSlice";
import { saveModalData } from "@/application/icrm/feature/slice/modalSaveSlice";
import Loader from "@/components/ui/loader";
import { useToast } from "@/components/ui/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
interface ReviewModal2Props {
  open: boolean;
  onOpenChange?: (open: boolean) => void;
  crNumber: string;
  sector: string;
  region: string;
  lob: string;
}

// interface CheckpointData {
//   id: string;
//   name: string;
//   relevantData: string;
//   analysis: string;
//   review_status_icrm: string;
//   review_status_user: string;
//   comment: string;
//   psm_review_status: string;
//   psmRemarks: string;
// }

const ReviewChange = ({ open, crNumber, sector, region, lob, }: ReviewModal2Props) => {
  const [activeTab, setActiveTab] = useState("main-details");
  const [checkpointUpdates, setCheckpointUpdates] = useState<Record<string, any>>({});
  // const [alertMessage, setAlertMessage] = useState<string | null>(null);
  // const [alertType, setAlertType] = useState<"success" | "error" | null>(null);
  const [formData, setFormData] = useState({
    data: "",
    psmData: "",
    sector: sector,
    region: region,
    lob: lob,
    isCritical: "NO",
    crNutshell: "",
    reviewDecision: "",
    comments: "",
    timeZone: "EST",
    trzName: "Others",
    trzQnAns: "",
    trzAnsString: "",
    trzCommentsString: "",
    replicate: "Test Lobs",
    soeid: "1735400",
  });

  const dispatch = useAppDispatch();
  const { reviewModal, modalSave } = useAppSelector((state) => ({
    reviewModal: state.reviewModal,
    modalSave: state.modalSave,
  }));

  const { modalData, loading: reviewLoading, error: reviewError } = reviewModal;
  const { data, loading: saveLoading } = modalSave; //error: saveError

  useEffect(() => {
    if (open) {
      dispatch(fetchModalData({ crNo: crNumber, sector, region, lob }));
    }
  }, [dispatch, open]);

  // ✅ Initialize checkpoints when modalData is available
  useEffect(() => {
    if(reviewLoading) return;
    if (modalData?.reviews) {
      const initialState: Record<string, any> = {};
      modalData.reviews.forEach((cp) => {
        initialState[cp.checklist_id] = {
          review_status_user: cp.review_status_user||cp.review_status_icrm,
          psm_review_status: cp.psm_review_status||cp.review_status_icrm,
          user_remarks:cp.user_remarks,
          psm_remarks:cp.psm_remarks
        };
      });
      setCheckpointUpdates(initialState);
    }


    if (modalData) {
      setFormData((prev) => ({
        ...prev,
        comments: modalData.comments ?? prev.comments,
        isCritical: modalData.criticality ?? prev.isCritical,
        reviewDecision: modalData.review_decision ?? prev.reviewDecision,
        crNutshell: modalData.cr_nutshell ?? prev.crNutshell
      }));
    }

  }, [modalData]);

  const { toast } = useToast()

  useEffect(() => {
    if (data == null) return;
    // debugger;
    if (data?.status === "success") {
      toast({
        variant: "default",
        title: data?.message || "Notes saved successfully!"
      })
      // setAlertType("success");
      // setAlertMessage("Notes saved successfully!");
    } else {
      // setAlertType("error");
      // setAlertMessage(data?.message || "Failed to save notes.");

      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: data?.message || "Failed to save notes.",

      })
    }
    // setTimeout(() => {
    //   setAlertMessage(null);
    // }, 5000);
  }, [data]);

  useEffect(() => { }, [checkpointUpdates]);

  // ✅ Utility Functions
  const updateCheckpointValue = (checkpointId: number, field: string, value: string) => {
    console.log('checkpointId + field + value')
    console.log(checkpointId)
    console.log(field)
    console.log(value)
    setCheckpointUpdates((prev) => ({
      ...prev,
      [checkpointId]: {
        ...prev[checkpointId],
        [field]: value,
      },
    }));
  };

  const generateCheckpointDataString = (
    changeNumber: string,
    status_field: string,
    comment_field: string
  ) => {
    debugger;
    const rows = Object.entries(checkpointUpdates)
      .filter(([_, values]) => values[status_field])
      .map(([checkpointId, values]) => {
        const statusValue = values[status_field] || "";
        const commentValue = values[comment_field] || "";
        return `${checkpointId},,,${statusValue},,,${commentValue},,,`;
      });

    return `${changeNumber};;;${rows.join(";;;")};;;`;
  };

  const getStatusBadge = (status: string) => {
    const normalizedStatus = status.toLowerCase();

    switch (normalizedStatus) {
      case "pass":
        return (
          <Badge className="bg-status-green text-status-green-foreground">
            Pass
          </Badge>
        );
      case "fail":
        return (
          <Badge className="bg-status-red text-status-red-foreground">
            Fail
          </Badge>
        );
      case "manual review":
        return (
          <Badge className="bg-status-yellow text-status-yellow-foreground">
            Manual Review
          </Badge>
        );
      case "na":
        return (
          <Badge className="bg-status-gray text-status-gray-foreground">
            N/A
          </Badge>
        );
      default:
        return (
          <Badge className="bg-status-gray text-status-gray-foreground">
            Unknown
          </Badge>
        );
    }
  };


  const handleUpdateCheckpointStatus = () => {
    const review_status_userString = generateCheckpointDataString(crNumber, "review_status_user","user_remarks");
    const psm_review_statusString = generateCheckpointDataString(crNumber, "psm_review_status","psm_remarks");

    const updatedFormData = {
      ...formData,
      data: review_status_userString,
      psmData: psm_review_statusString,
    };

    setFormData(updatedFormData);
    dispatch(saveModalData(updatedFormData));
  };

  // ✅ Loading & Error States
  if (reviewLoading) {
    return (
      <div className="flex flex-col gap-4 mt-4">
        <Skeleton className="h-[200px] grid place-items-center rounded-lg ">
          <Loader className="justify-center m-24">

          </Loader>
        </Skeleton>
        <Skeleton className="h-[40px] grid place-items-center rounded-lg ">

        </Skeleton>
        <Skeleton className="h-[400px] grid place-items-center rounded-lg ">
          <Loader className="justify-center m-24">

          </Loader>
        </Skeleton>
      </div>
    );
  }

  if (reviewError) {
    return (
      "Error"
    );
  }

  if (!modalData) return null;

  // ✅ Categorize reviews
  const mainIds = [3, 4, 6, 7, 8, 9];
  const precautionIds = [1, 2, 5];
  const approvalIds = [10];
  const changeIds = [11];

  const mainReviews: ReviewItem[] = [];
  const precautionReviews: ReviewItem[] = [];
  const approvalReviews: ReviewItem[] = [];
  const changeReviews: ReviewItem[] = [];

  modalData.reviews.forEach((item) => {
    if (mainIds.includes(item.checklist_id)) mainReviews.push(item);
    else if (precautionIds.includes(item.checklist_id)) precautionReviews.push(item);
    else if (approvalIds.includes(item.checklist_id)) approvalReviews.push(item);
    else if (changeIds.includes(item.checklist_id)) changeReviews.push(item);
  });

  const getCurrentTabCheckpoints = () => {
    switch (activeTab) {
      case "main-details":
        return mainReviews;
      case "precautionary-check":
        return precautionReviews;
      case "approval-check":
        return approvalReviews;
      case "change-task":
        return changeReviews;
      default:
        return [];
    }
  };

  return (
    <div>
      
      <div className="">
        <div className="grid grid-cols-2 gap-y-4 gap-x-6 my-4">
          <div className="flex flex-col">
            <label className="text-sm font-medium mb-2">Review Decision</label>
            <Select
              value={formData.reviewDecision}
              onValueChange={
                (value) => {
                  setFormData((prev) => ({
                    ...prev,
                    reviewDecision: value, // update inside formData
                  }))
                  console.log('onChange={(e) => {setFormData((prev) => ({')
                  console.log(formData)
                }
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select review decision" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Review Pending">Review Pending</SelectItem>
                <SelectItem value="Approved Post Tier-0">Approved Post Tier-0</SelectItem>
                <SelectItem value="Rejected Post Tier-0">Rejected Post Tier-0</SelectItem>
                <SelectItem value="Rescheduled">Rescheduled</SelectItem>
                <SelectItem value="Moved to Tier-1">Moved to Tier-1</SelectItem>
                <SelectItem value="Approved Post Tier-1">Approved Post Tier-1</SelectItem>
                <SelectItem value="Rejected Post Tier-1">Rejected Post Tier-1</SelectItem>
                <SelectItem value="Moved to Tier-2">Moved to Tier-2</SelectItem>
                <SelectItem value="Approved Post Tier-2">Approved Post Tier-2</SelectItem>
                <SelectItem value="Rejected Post Tier-2">Rejected Post Tier-2</SelectItem>
                <SelectItem value="Moved to Tier-3">Moved to Tier-3</SelectItem>
                <SelectItem value="Approved Post Tier-3">Approved Post Tier-3</SelectItem>
                <SelectItem value="Rejected Post Tier-3">Rejected Post Tier-3</SelectItem>
                <SelectItem value="Need Further Details">Need Further Details</SelectItem>
                <SelectItem value="Conditionally Approved">Conditionally Approved</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 items-center">
            <label className="text-sm font-medium">Is Critical</label>
            <Checkbox
              checked={formData.isCritical === "YES"}
              onCheckedChange={(checked) => {
                setFormData((prev) => ({
                  ...prev,
                  isCritical: checked ? "YES" : "NO",
                }));
                console.log('onCheckedChange={(checked) ')
                console.log(formData)
              }
              }
            />
          </div>
          <div className="flex flex-col">
            <label className="text-sm font-medium mb-2">Comments:</label>
            <Textarea
              className="resize-none"
              rows={4}
              value={formData.comments}
              onChange={(e) => {
                setFormData((prev) => ({
                  ...prev,
                  comments: e.target.value,
                }))
                console.log('value={formData.comments}')
                console.log(formData)
              }
              }
              placeholder="Enter your comments..."
            />
          </div>

          <div className="flex flex-col">
            <label className="text-sm font-medium mb-2">Change Nutshell:</label>
            <Textarea
              className="resize-none"
              rows={4}
              value={formData.crNutshell}
              onChange={(e) => {
                setFormData((prev) => ({
                  ...prev,
                  crNutshell: e.target.value,
                }))
                console.log('onChange={(e) => {setFormData((prev) => ({')
                console.log(formData)
              }
              }
              placeholder="Enter change details..."
            />
          </div>
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="z-10">
          <TabsList className="sticky top-16 z-10 grid w-full grid-cols-4">
            <TabsTrigger value="main-details">Main Details</TabsTrigger>
            <TabsTrigger value="precautionary-check">Precautionary Check</TabsTrigger>
            <TabsTrigger value="approval-check">Approval Check</TabsTrigger>
            <TabsTrigger value="change-task">Change Task</TabsTrigger>
          </TabsList>
          {['main-details', 'precautionary-check', 'approval-check', 'change-task'].map((tabValue) => (
            <TabsContent key={tabValue} value={tabValue} className="mt-6">
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="w-32">S#/Checkpoint Name</TableHead>
                      <TableHead className="min-w-[200px]">Relevent Data</TableHead>
                      <TableHead className="min-w-[200px]">Checkpoint Analysis</TableHead>
                      <TableHead className="w-40">Review Status (ICRM)</TableHead>
                      <TableHead className="w-40">Review Status (L2 Reviewer)</TableHead>
                      <TableHead className="w-48">Comment</TableHead>
                      <TableHead className="w-32">PSM Status</TableHead>
                      <TableHead className="w-48">PSM Remarks</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getCurrentTabCheckpoints().map((checkpoint: { checklist_checkpoint: string; checklist_id: number; checklist_desc: string; review_status_icrm: string; reason: string; }, index: number) => (
                      <TableRow key={checkpoint.checklist_id}>
                        <TableCell className="font-medium">
                          {index + 1}. {checkpoint.checklist_checkpoint}
                        </TableCell>
                        <TableCell className="text-xs">
                          <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap line-clamp-3">
                            {(checkpoint as any)?.description}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap">
                            {checkpoint.reason}
                          </div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(checkpoint.review_status_icrm)}
                          
                        </TableCell>
                        <TableCell>
                          {/* <p className="h-[1px] overflow-hidden">
                            {JSON.stringify(checkpointUpdates[checkpoint.checklist_id]?.review_status_user)}
                          </p> */}
                          {/* {JSON.stringify(checkpointUpdates[checkpoint.checklist_id]?.review_status_user)} */}
                          <Select
                            // defaultValue={checkpoint.review_status_user.toLowerCase()}
                            defaultValue={checkpointUpdates[checkpoint.checklist_id]?.review_status_user}
                            onValueChange={(value) => updateCheckpointValue(checkpoint.checklist_id, 'review_status_user', value)}
                          >

                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="PASS">PASS</SelectItem>
                              <SelectItem value="FAIL">FAIL</SelectItem>
                              <SelectItem value="MANUAL_REVIEW">MANUAL REVIEW</SelectItem>
                              <SelectItem value="NA">NA</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Textarea
                            // placeholder={checkpoint.comment}
                            placeholder="Please mention your comment here"
                            className="min-h-[60px] text-xs"
                            onChange={(e) => updateCheckpointValue(checkpoint.checklist_id, 'user_remarks', e.target.value)}
                          />
                        </TableCell>
                        <TableCell>
                          <Select
                            // defaultValue={checkpoint.psm_review_status.toLowerCase()}
                            defaultValue={checkpointUpdates[checkpoint.checklist_id]?.psm_review_status}
                            onValueChange={(value) => updateCheckpointValue(checkpoint.checklist_id, 'psm_review_status', value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="PASS">PASS</SelectItem>
                              <SelectItem value="FAIL">FAIL</SelectItem>
                              <SelectItem value="MANUAL_REVIEW">MANUAL REVIEW</SelectItem>
                              <SelectItem value="NA">NA</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Textarea
                            // placeholder={checkpoint.psmRemarks}
                            placeholder="Please mention your remarks here"
                            className="min-h-[60px] text-xs"
                            onChange={(e) => updateCheckpointValue(checkpoint.checklist_id, 'psm_remarks', e.target.value)}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          ))}
        </Tabs>

      </div>
      <Button
        className="bg-blue-500 text-white hover:bg-blue-600 ml-auto mt-4"
        onClick={handleUpdateCheckpointStatus}
        disabled={saveLoading}
      >
        {saveLoading && <Loader />}
        Update
      </Button>
    </div>
  );
};

export default ReviewChange;

