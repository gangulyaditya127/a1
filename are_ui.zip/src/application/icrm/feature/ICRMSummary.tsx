import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardCount } from "./slice/dashboardSlice";
interface Props {
    dashboardCount: DashboardCount;
}
export default function ICRMSummary({ dashboardCount }: Props) {
    
    
    return (
        <Card className="h-full rounded-xl">
            <CardHeader className="flex flex-col items-stretch space-y-0 border-b p-0 sm:flex-row">
                <div className="flex flex-1 flex-col justify-center gap-1 px-6 py-5 sm:py-6">
                    <CardTitle className="text-xl">Summary</CardTitle>
                    <CardDescription>Over all summary for the changes logged in ICRM</CardDescription>
                </div>
                <div className="text-2xl border-l px-6 grid place-items-center">
                    <div className="">
                        <p className="font-medium">{dashboardCount.total_changes}</p>
                        <p className="text-sm text-muted-foreground">Total Changes</p>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="grid grid-cols-4 gap-6 p-4 px-7">
                <div className="text-2xl">
                    <p className="font-medium">{dashboardCount.l2_review_pending}</p>
                    <p className="text-sm text-muted-foreground">L2 review pending</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">0</p>
                    <p className="text-sm text-muted-foreground">Sev 2</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">{dashboardCount.l2_review_approved}</p>
                    <p className="text-sm text-muted-foreground">L2 review passed</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">{dashboardCount.l2_review_rejected}</p>
                    <p className="text-sm text-muted-foreground">L2 review failed</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">0</p>
                    <p className="text-sm text-muted-foreground">Total patches</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">{dashboardCount.infra_changes}</p>
                    <p className="text-sm text-muted-foreground">Infra changes</p>
                </div>
                <div className="text-2xl">
                    <p className="font-medium">0</p>
                    <p className="text-sm text-muted-foreground">Pre-exempt changes</p>
                </div>
            </CardContent>
        </Card>
    )
}