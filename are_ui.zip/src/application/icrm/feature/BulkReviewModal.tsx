import { useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import Loader from "@/components/ui/loader";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { cn } from "@/lib/tailwind.utils";

interface BulkReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedChanges: string[];
  onSave: (decision: string, comments: string) => void;
}

const BulkReviewModal = ({ open, onOpenChange, selectedChanges, onSave }: BulkReviewModalProps) => {
  const [reviewDecision, setReviewDecision] = useState("");
  const [comments, setComments] = useState("");
  const [saving, setSaving] = useState(false);
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const handleSave = async () => {
    if (!reviewDecision || !comments.trim()) {
      setAlert({ type: "error", message: "Please fill in required fields before saving." });
      return;
    }

    setSaving(true);
    setAlert(null);

    try {
      const body = {
        sector: "BFSI",
        region: "SEAL",
        lob: "Digital",
        crNo: selectedChanges,
        reviewDecision,
        comments,
        timeZone: "EST",
        speakerName: "John Doe",
        speakerSoeid: "JD12345",
        owningTeam: "Digital Ops",
        rationale: "Insufficient data",
        soeid: "1735400",
      };

      const response = await fetch("https://ismartams.tcsapps.com/api/python_icrm/saveBulkReviewModalData", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (response.status === 200) {
        setAlert({ type: "success", message: "Bulk review saved successfully!" });
        onSave(reviewDecision, comments);
        setReviewDecision("");
        setComments("");
      }
    } catch (error: any) {
      console.error("Save failed:", error);
      setAlert({ type: "error", message: "Failed to save bulk review. Please try again." });
    } finally {
      setSaving(false);
      setTimeout(() => setAlert(null), 3000);
      setTimeout(() => onOpenChange(false), 3200);
    }
  };

  const displayChanges = selectedChanges.length > 10
    ? [...selectedChanges.slice(0, 10), "..."]
    : selectedChanges;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="px-4">
          <DialogTitle className="text-lg font-semibold">
            Bulk Review - {selectedChanges.length} Changes Selected
          </DialogTitle>
        </DialogHeader>

        {/* ✅ Blur content while saving */}
        <div className={`space-y-4 px-4 transition duration-200 ${saving ? "pointer-events-none blur-sm opacity-60" : ""}`}>
          <div>
            <Label className="text-sm font-medium">Selected Changes</Label>
            <div className="mt-2 p-3 bg-muted rounded border max-h-32 overflow-y-auto">
              {displayChanges.map((change, index) => (
                <div key={index} className="text-sm py-1">
                  {change}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bulkReviewDecision">Review Decision:</Label>
            <Select value={reviewDecision} onValueChange={setReviewDecision}>
              <SelectTrigger>
                <SelectValue placeholder="Select review decision" />
              </SelectTrigger>
              <SelectContent className="max-h-64 overflow-y-auto">
                <SelectItem value="Review Pending">Review Pending</SelectItem>
                <SelectItem value="Approved Post Tier-0">Approved Post Tier-0</SelectItem>
                <SelectItem value="Rejected Post Tier-0">Rejected Post Tier-0</SelectItem>
                <SelectItem value="Rescheduled">Rescheduled</SelectItem>
                <SelectItem value="Moved to Tier-1">Moved to Tier-1</SelectItem>
                <SelectItem value="Approved Post Tier-1">Approved Post Tier-1</SelectItem>
                <SelectItem value="Rejected Post Tier-1">Rejected Post Tier-1</SelectItem>
                <SelectItem value="Moved to Tier-2">Moved to Tier-2</SelectItem>
                <SelectItem value="Approved Post Tier-2">Approved Post Tier-2</SelectItem>
                <SelectItem value="Rejected Post Tier-2">Rejected Post Tier-2</SelectItem>
                <SelectItem value="Moved to Tier-3">Moved to Tier-3</SelectItem>
                <SelectItem value="Approved Post Tier-3">Approved Post Tier-3</SelectItem>
                <SelectItem value="Rejected Post Tier-3">Rejected Post Tier-3</SelectItem>
                <SelectItem value="Need Further Details">Need Further Details</SelectItem>
                <SelectItem value="Conditionally Approved">Conditionally Approved</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bulkComments">Comments:</Label>
            <Textarea
              id="bulkComments"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              rows={4}
              placeholder="Enter comments for all selected changes..."
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="destructive" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!reviewDecision || !comments || saving} className=" bg-blue-600 text-white hover:bg-blue-500">
            {saving ? "Saving..." : "Save Bulk Review"}
          </Button>
        </DialogFooter>

        {/* ✅ Overlay loader when saving */}
        {saving && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
            <Loader>
              <span className="ml-2 text-gray-600">Saving...</span>
            </Loader>
          </div>
        )}

        {/* ✅ Custom Alert */}
        {alert && (
          <div className="fixed bottom-5 right-5 z-50 max-w-sm">
            <Alert className={cn(
              alert.type === "success"
                ? "border-green-500 bg-green-100 text-green-700"
                : "border-red-500 bg-red-100 text-red-700"
            )}
            >
              <AlertTitle>{alert.type === "error" ? "Error" : "Success"}</AlertTitle>
              <AlertDescription>{alert.message}</AlertDescription>
            </Alert>
          </div>
        )
        }
      </DialogContent>
    </Dialog>
  );
};

export default BulkReviewModal;