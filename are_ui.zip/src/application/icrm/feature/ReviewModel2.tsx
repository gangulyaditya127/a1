import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { fetchModalData, ReviewItem } from "@/application/icrm/feature/slice/modalDataSlice";
import { saveModalData } from "@/application/icrm/feature/slice/modalSaveSlice";
import Loader from "@/components/ui/loader";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { cn } from "@/lib/tailwind.utils";
interface ReviewModal2Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  crNumber: string;
  sector: string;
  region: string;
  lob: string;
}

// interface CheckpointData {
//   id: string;
//   name: string;
//   relevantData: string;
//   analysis: string;
//   review_status_icrm: string;
//   review_status_user: string;
//   comment: string;
//   psm_review_status: string;
//   psmRemarks: string;
// }

const ReviewModal2 = ({ open, onOpenChange, crNumber, sector, region, lob, }: ReviewModal2Props) => {
  const [activeTab, setActiveTab] = useState("main-details");
  const [checkpointUpdates, setCheckpointUpdates] = useState<Record<string, any>>({});
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertType, setAlertType] = useState<"success" | "error" | null>(null);
  const [formData, setFormData] = useState({
    data: "",
    psmData: "",
    sector: sector,
    region: region,
    lob: lob,
    isCritical: "NO",
    crNutshell: "",
    reviewDecision: "",
    comments: "",
    timeZone: "EST",
    trzName: "Others",
    trzQnAns: "",
    trzAnsString: "",
    trzCommentsString: "",
    replicate: "Test Lobs",
    soeid: "1735400",
  });

  const dispatch = useAppDispatch();
  const { reviewModal, modalSave } = useAppSelector((state) => ({
    reviewModal: state.reviewModal,
    modalSave: state.modalSave,
  }));

  const { modalData, loading: reviewLoading, error: reviewError } = reviewModal;
  const { data, loading: saveLoading } = modalSave; //error: saveError

  useEffect(() => {
    if (open) {
      dispatch(fetchModalData({ crNo: crNumber, sector, region, lob }));
    }
  }, [dispatch, open]);

  // ✅ Initialize checkpoints when modalData is available
  useEffect(() => {
    if (modalData?.reviews) {
      const initialState: Record<string, any> = {};
      modalData.reviews.forEach((cp) => {
        initialState[cp.checklist_id] = {
          review_status_user: "na",
          psm_review_status: "na",
        };
      });
      setCheckpointUpdates(initialState);
    }


    if (modalData) {
      setFormData((prev) => ({
        ...prev,
        comments: modalData.comments ?? prev.comments,
        isCritical: modalData.criticality ?? prev.isCritical,
        reviewDecision: modalData.review_decision ?? prev.reviewDecision
      }));
    }

  }, [modalData]);

  // ✅ Show success alert only once
  useEffect(() => {
    if (data?.status === "success") {
      setAlertType("success");
      setAlertMessage("Notes saved successfully!");
    } else {
      setAlertType("error");
      setAlertMessage(data?.message || "Failed to save notes.");
    }
    setTimeout(() => {
      setAlertMessage(null);
    }, 5000);
  }, [data]);

  useEffect(() => { }, [checkpointUpdates]);

  // ✅ Utility Functions
  const updateCheckpointValue = (checkpointId: number, field: string, value: string) => {
    console.log('checkpointId + field + value')
    console.log(checkpointId)
    console.log(field)
    console.log(value)
    setCheckpointUpdates((prev) => ({
      ...prev,
      [checkpointId]: {
        ...prev[checkpointId],
        [field]: value,
      },
    }));
  };

  const generateCheckpointDataString = (changeNumber: string, field: string) => {
    const rows = Object.entries(checkpointUpdates)
      .filter(([_, values]) => values[field])
      .map(([checkpointId, values]) => {
        const value = values[field] || "NA";
        return `${checkpointId},,,${value},,,`;
      });

    return `${changeNumber};;;${rows.join(";;;")};;;`;
  };

  const getStatusBadge = (status: string) => {
    const normalizedStatus = status.toLowerCase();

    switch (normalizedStatus) {
      case "pass":
        return (
          <Badge className="bg-status-green text-status-green-foreground">
            Pass
          </Badge>
        );
      case "fail":
        return (
          <Badge className="bg-status-red text-status-red-foreground">
            Fail
          </Badge>
        );
      case "manual review":
        return (
          <Badge className="bg-status-yellow text-status-yellow-foreground">
            Manual Review
          </Badge>
        );
      case "na":
        return (
          <Badge className="bg-status-gray text-status-gray-foreground">
            N/A
          </Badge>
        );
      default:
        return (
          <Badge className="bg-status-gray text-status-gray-foreground">
            Unknown
          </Badge>
        );
    }
  };


  const handleUpdateCheckpointStatus = () => {
    const review_status_userString = generateCheckpointDataString(crNumber, "review_status_user");
    const psm_review_statusString = generateCheckpointDataString(crNumber, "psm_review_status");

    const updatedFormData = {
      ...formData,
      data: review_status_userString,
      psmData: psm_review_statusString,
    };

    setFormData(updatedFormData);
    console.log('updatedFormData')
    console.log(formData)
    dispatch(saveModalData(updatedFormData));
  };

  // ✅ Loading & Error States
  if (reviewLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <p>Loading...</p>
        </DialogContent>
      </Dialog>
    );
  }

  if (reviewError) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <p className="text-red-500">{reviewError}</p>
        </DialogContent>
      </Dialog>
    );
  }

  if (!modalData) return null;

  // ✅ Categorize reviews
  const mainIds = [3, 4, 6, 7, 8, 9];
  const precautionIds = [1, 2, 5];
  const approvalIds = [10];
  const changeIds = [11];

  const mainReviews: ReviewItem[] = [];
  const precautionReviews: ReviewItem[] = [];
  const approvalReviews: ReviewItem[] = [];
  const changeReviews: ReviewItem[] = [];

  modalData.reviews.forEach((item) => {
    if (mainIds.includes(item.checklist_id)) mainReviews.push(item);
    else if (precautionIds.includes(item.checklist_id)) precautionReviews.push(item);
    else if (approvalIds.includes(item.checklist_id)) approvalReviews.push(item);
    else if (changeIds.includes(item.checklist_id)) changeReviews.push(item);
  });

  const getCurrentTabCheckpoints = () => {
    switch (activeTab) {
      case "main-details":
        return mainReviews;
      case "precautionary-check":
        return precautionReviews;
      case "approval-check":
        return approvalReviews;
      case "change-task":
        return changeReviews;
      default:
        return [];
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`max-w-7xl max-h-[90vh] ${saveLoading ? "overflow-y-hidden" : "overflow-y-auto"}`}>
        {
          saveLoading && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/10 backdrop-blur-sm">
              <Loader>
                <span className="ml-2 text-gray-600">Saving...</span>
              </Loader>
            </div>
          )
        }
        {alertMessage && (
          <div className="mt-4">
            <Alert
              className={cn(
                alertType === "success"
                  ? "border-green-500 bg-green-100 text-green-700"
                  : "border-red-500 bg-red-100 text-red-700"
              )}
            >
              <AlertTitle>
                {alertType === "success" ? "Success" : "Error"}
              </AlertTitle>
              <AlertDescription>{alertMessage}</AlertDescription>
            </Alert>
          </div>
        )}
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            Change No.: {crNumber}
          </DialogTitle>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Sector: BFSI</span>
            <span>LOB: Digital</span>
            <span>Phase: {modalData.phase}</span>
            <span>Phase State: {modalData.phase_state}</span>
            {/* <span className="text-xs">[Timezone: EDT/EST]</span> */}
          </div>
        </DialogHeader>
        <div className="py-4 p-4">
          <div className="space-y-6 mb-6">
            {/* First row: Is Critical */}
            <div className="flex flex-col">
              <label className="text-sm font-medium mb-2">Is Critical:</label>
              <div className="flex items-center">
                <Checkbox
                  checked={formData.isCritical === "YES"}
                  onCheckedChange={(checked) => {
                    setFormData((prev) => ({
                      ...prev,
                      isCritical: checked ? "YES" : "NO",
                    }));
                    console.log('onCheckedChange={(checked) ')
                    console.log(formData)
                  }
                  }
                />
              </div>
            </div>

            {/* Change Nutshell */}
            <div className="flex flex-col">
              <label className="text-sm font-medium mb-2">Change Nutshell:</label>
              <Textarea
                className="resize-none"
                rows={4}
                value={formData.crNutshell}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    crNutshell: e.target.value,
                  }))
                  console.log('onChange={(e) => {setFormData((prev) => ({')
                  console.log(formData)
                }
                }
                placeholder="Enter change details..."
              />
            </div>

            {/* Review Decision */}
            <div className="flex flex-col">
              <label className="text-sm font-medium mb-2">Review Decision:</label>
              <Select
                value={formData.reviewDecision}
                onValueChange={
                  (value) => {
                    setFormData((prev) => ({
                      ...prev,
                      reviewDecision: value, // update inside formData
                    }))
                    console.log('onChange={(e) => {setFormData((prev) => ({')
                    console.log(formData)
                  }
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select review decision" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Review Pending">Review Pending</SelectItem>
                  <SelectItem value="Approved Post Tier-0">Approved Post Tier-0</SelectItem>
                  <SelectItem value="Rejected Post Tier-0">Rejected Post Tier-0</SelectItem>
                  <SelectItem value="Rescheduled">Rescheduled</SelectItem>
                  <SelectItem value="Moved to Tier-1">Moved to Tier-1</SelectItem>
                  <SelectItem value="Approved Post Tier-1">Approved Post Tier-1</SelectItem>
                  <SelectItem value="Rejected Post Tier-1">Rejected Post Tier-1</SelectItem>
                  <SelectItem value="Moved to Tier-2">Moved to Tier-2</SelectItem>
                  <SelectItem value="Approved Post Tier-2">Approved Post Tier-2</SelectItem>
                  <SelectItem value="Rejected Post Tier-2">Rejected Post Tier-2</SelectItem>
                  <SelectItem value="Moved to Tier-3">Moved to Tier-3</SelectItem>
                  <SelectItem value="Approved Post Tier-3">Approved Post Tier-3</SelectItem>
                  <SelectItem value="Rejected Post Tier-3">Rejected Post Tier-3</SelectItem>
                  <SelectItem value="Need Further Details">Need Further Details</SelectItem>
                  <SelectItem value="Conditionally Approved">Conditionally Approved</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Comments */}
            <div className="flex flex-col">
              <label className="text-sm font-medium mb-2">Comments:</label>
              <Textarea
                className="resize-none"
                rows={4}
                value={formData.comments}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    comments: e.target.value,
                  }))
                  console.log('value={formData.comments}')
                  console.log(formData)
                }
                }
                placeholder="Enter your comments..."
              />
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="z-10">
            <TabsList className="sticky top-20 z-10 grid w-full grid-cols-4">
              <TabsTrigger value="main-details">Main Details</TabsTrigger>
              <TabsTrigger value="precautionary-check">Precautionary Check</TabsTrigger>
              <TabsTrigger value="approval-check">Approval Check</TabsTrigger>
              <TabsTrigger value="change-task">Change Task</TabsTrigger>
            </TabsList>

            {/* Render table for all tabs */}
            {['main-details', 'precautionary-check', 'approval-check', 'change-task'].map((tabValue) => (
              <TabsContent key={tabValue} value={tabValue} className="mt-6">
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="w-32">S#/Checkpoint Name</TableHead>
                        <TableHead className="min-w-[200px]">Relevent Data</TableHead>
                        <TableHead className="min-w-[200px]">Checkpoint Analysis</TableHead>
                        <TableHead className="w-40">Review Status (ICRM)</TableHead>
                        <TableHead className="w-40">Review Status (L2 Reviewer)</TableHead>
                        <TableHead className="w-48">Comment</TableHead>
                        <TableHead className="w-32">PSM Status</TableHead>
                        <TableHead className="w-48">PSM Remarks</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getCurrentTabCheckpoints().map((checkpoint: { checklist_checkpoint: string; checklist_id: number; checklist_desc: string; review_status_icrm: string; reason: string; }, index: number) => (
                        <TableRow key={checkpoint.checklist_id}>
                          <TableCell className="font-medium">
                            {index + 1}. {checkpoint.checklist_checkpoint}
                          </TableCell>
                          <TableCell className="text-xs">
                            <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap">
                              {(checkpoint as any)?.description}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs">
                            <div className="max-w-[200px] overflow-hidden whitespace-pre-wrap">
                              {checkpoint.reason}
                            </div>
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(checkpoint.review_status_icrm)}
                            {/* <div className="mt-1">
                              <Button variant="ghost" size="sm" className="p-1 h-auto">
                                ⬇️
                              </Button>
                            </div> */}
                          </TableCell>
                          <TableCell>
                            <Select
                              // defaultValue={checkpoint.review_status_user.toLowerCase()}
                              defaultValue={checkpointUpdates[checkpoint.checklist_id]?.review_status_user}
                              onValueChange={(value) => updateCheckpointValue(checkpoint.checklist_id, 'review_status_user', value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="PASS">PASS</SelectItem>
                                <SelectItem value="FAIL">FAIL</SelectItem>
                                <SelectItem value="Manual Review">Manual Review</SelectItem>
                                <SelectItem value="NA">NA</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <Textarea
                              // placeholder={checkpoint.comment}
                              placeholder="Please mention your comment here"
                              className="min-h-[60px] text-xs"
                              onChange={(e) => updateCheckpointValue(checkpoint.checklist_id, 'comment', e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            <Select
                              // defaultValue={checkpoint.psm_review_status.toLowerCase()}
                              defaultValue={checkpointUpdates[checkpoint.checklist_id]?.psm_review_status}
                              onValueChange={(value) => updateCheckpointValue(checkpoint.checklist_id, 'psm_review_status', value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="PASS">PASS</SelectItem>
                                <SelectItem value="FAIL">FAIL</SelectItem>
                                <SelectItem value="Manual Review">Manual Review</SelectItem>
                                <SelectItem value="NA">NA</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <Textarea
                              // placeholder={checkpoint.psmRemarks}
                              placeholder="Please mention your remarks here"
                              className="min-h-[60px] text-xs"
                              onChange={(e) => updateCheckpointValue(checkpoint.checklist_id, 'psmRemarks', e.target.value)}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            ))}
          </Tabs>

        </div>
        <DialogFooter>
          <Button
            className="bg-blue-500 text-white hover:bg-blue-600"
            onClick={handleUpdateCheckpointStatus}
          >
            Update Checkpoint Status
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ReviewModal2;

// function setAlertType(arg0: string) {
//   throw new Error("Function not implemented.");
// }
