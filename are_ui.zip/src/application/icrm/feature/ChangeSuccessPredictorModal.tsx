import { cn } from "@/lib/tailwind.utils";

// interface Props {
//     data: ChangeRecord;
// }
export default function ChangeSuccessPredictorModal({ data }: any) {
    return (
        <div className="px-4 pt-4">
            <div className="grid grid-cols-3 gap-3 text-sm text-muted-foreground">

                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Change No</p>
                    <p className="text-primary">{data.change_number}</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Title</p>
                    <p className="text-primary">{data.title}</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Description</p>
                    <p className="text-primary">{data.description}</p>
                </div>
                {/* <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Impacted Sector</p>
                    <p className="text-primary">BFSI</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Impacted Region</p>
                    <p className="text-primary">SEAL</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Impacted Environment</p>
                    <p className="text-primary">Prod, COB</p>
                </div> */}
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Risk</p>
                    <p className={cn(
                        "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700 capitalize",
                        data?.risk == "high"
                            ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
                            : data?.risk == 'Medium' ? "bg-yellow-400 dark:bg-yellow-800" : 'bg-green-400 dark:bg-green-800 dark:text-white',
                    )}>{data.risk}</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Primary Application</p>
                    <p className="text-primary">{data.primary_application}</p>
                </div>
                {/* <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">ESR Reason</p>
                    <p className="text-primary">NA</p>
                </div> */}
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Change Category</p>
                    <p className="text-primary"> {data.change_category}</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Conflict Status</p>
                    <p className="text-primary">Conflict</p>
                </div>
                {/* <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Certificate Change</p>
                    <p className="text-primary">NA</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Customer Live</p>
                    <p className="text-primary">NA</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Customer Live</p>
                    <p className="text-primary">NA</p>
                </div>
                <div className="flex flex-col gap-1 px-2">
                    <p className="font-medium text-xs">Change Duration</p>
                    <p className="text-primary">NA</p>
                </div> */}
                <div className="flex flex-col gap-1 py-4 px-2">
                    <p className="font-medium text-xs">Success Probablity</p>
                    <p className={cn(
                        "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700 capitalize",
                        data.successprobability < 50
                            ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
                            : data.successprobability < 80? "bg-yellow-400 dark:bg-yellow-800" : 'bg-green-400 dark:bg-green-800 dark:text-white',
                    )}>{data.successprobability} %</p>
                </div>
            </div>
        </div>
    )
}