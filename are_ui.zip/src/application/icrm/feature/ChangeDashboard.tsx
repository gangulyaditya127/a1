import DataGrid from "@/components/ui/data-grid";
import { ColDef } from "ag-grid-charts-enterprise";
import React, { useMemo, useState } from "react";
// import { changeList } from "../data/change.data";
import { CustomCellRendererProps } from "ag-grid-react";
import { cn } from "@/lib/tailwind.utils";
import { Icon } from "@/components/ui/icon";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
// import Editor from "@/components/ui/editor";
import ChangeSuccessPredictorModal from "./ChangeSuccessPredictorModal";
import { Button } from "@/components/ui/button";
// import ReviewModal2 from "./ReviewModel2";
import BulkReviewModal from "./BulkReviewModal";
// import JournalsModal from "./JournalsModal";

import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { useEffect } from 'react';
import { ChangeRecord, fetchChangeList } from "@/application/icrm/feature/slice/changeListSlice";
export default function ChangeDashboard() {
    // const theme = useDerivedTheme()
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const columnDefs = useMemo<ColDef[]>(() => [
        {
            headerCheckboxSelection: true,   // checkbox in header
            checkboxSelection: true,         // checkbox in rows
            headerCheckboxSelectionFilteredOnly: true, // optional: select only filtered rows
            width: 50,
        },
        {
            field: 'notes',
            initialWidth: 50,
            cellRenderer: NotesRenderer
        },
        {
            field: 'change_number',
            headerName: 'CR Number',
            cellRenderer: ChangeNumberRenderer
        },
        {
            field: 'crm_score',
            headerName: 'CR Score',
            cellRenderer: CRMScoreRenderer,
            filter: "agSetColumnFilter",
            width: 110
        },
        {
            field: 'risk',
            headerName: 'SNOW Risk',
            cellRenderer: SNOWRiskRenderer,
            filter: "agSetColumnFilter",
            width: 120
        },
        {
            field: 'zone',
            cellRenderer: ZoneRenderer,
            filter: "agSetColumnFilter",
            width: 90
        },
        {
            field: 'primary_application',
            headerName: 'Primary Application',
            filter: "agSetColumnFilter",
        },
        {
            field: 'title',
        },
        {
            field: 'start_date',
            width: 140
        },
        {
            field: 'end_date',
            width: 140
        },
        {
            field: 'incident_count',
            headerName: 'Past MIM/P1 Incident'
        },
        {
            field: 'coordinating_grp_manager',
            headerName: 'Coordinating Group Manager',
            filter: "agSetColumnFilter",
        },
        {
            field: 'phase'
        },
        {
            field: 'review_decision'
        },
        {
            field: 'coordinator',
            headerName: 'CR Examiner',
        },
        {
            field: "assosiatedCR",
            headerName: 'Assosiated CR'
        }
    ], []);


    const [selectionModel, setSelectionModel] = useState<any[]>([]);
    const [isOpen, setIsOpen] = useState(false);

    const onSelectionChanged = (event: any) => {
        const selectedRows = event.api.getSelectedRows();
        setSelectionModel(selectedRows);
    };


    const handleBulkReview = () => {
        if (selectionModel.length >= 2) {
            setIsOpen(true);
        }
    };

    const dispatch = useAppDispatch();
    const filters = useAppSelector(
        (state) => state.filters
    );
    // Fetch when any filter changes
    useEffect(() => {
        dispatch(fetchChangeList());
    }, [dispatch, filters]);
    const { changeData, page_size, loading, error } = useAppSelector((state) => state.changeList);

    console.log(changeData);

    if (loading) return (
        <Skeleton className="h-[400px] mt-6 rounded-xl border grid place-items-center">
            <Loader className="justify-center m-24">

            </Loader>
        </Skeleton>
    )
    if (error) return <ErrorContainer className="mt-6" />
    if (!changeData) return null;
    return (
        <div className="relative mt-4">
            <div className="h-[20px]">
                <Button className={cn(`absolute right-0 text-sm top-0 z-[1] rounded text-white h-fit`, selectionModel.length >= 2
                    ? "bg-blue-600 hover:bg-blue-700"
                    : "bg-gray-400 cursor-not-allowed hidden")}
                    disabled={selectionModel.length < 2}
                    onClick={handleBulkReview}
                    size={"sm"}

                >
                    Bulk Review
                </Button>
            </div>

            <div className="h-[400px] mb-8 ">
                <div
                    style={gridStyle}
                >
                    <DataGrid
                        rowData={changeData}
                        columnDefs={columnDefs}
                        masterDetail={true}
                        rowSelection="multiple"
                        suppressRowClickSelection={true}
                        onSelectionChanged={onSelectionChanged}

                        pagination
                        paginationPageSize={page_size}
                        sideBar={"filters"}
                    />
                </div>
            </div>
            <BulkReviewModal
                open={isOpen}
                onOpenChange={setIsOpen}
                selectedChanges={selectionModel.map((row) => row.change_number)}
                onSave={(decision: string, comments: string) => {
                    console.log("Saving bulk review:", {
                        changes: selectionModel.map((r) => r.change_number),
                        decision,
                        comments,
                    });

                }}
            />
        </div >
    );
}

const CRMScoreRenderer = ({ data }: CustomCellRendererProps) => {
    const score = Number(data?.crm_score); // Convert string to number

    // Define thresholds
    const isHigh = score >= 80;
    const isMedium = score >= 50 && score < 80;

    return (
        <div className="grid h-full items-center">
            <div
                className={cn(
                    "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700 capitalize",
                    isHigh
                        ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
                        : isMedium
                            ? "bg-yellow-400 dark:bg-yellow-800"
                            : "bg-green-400 dark:bg-green-800"
                )}
            >
                {isHigh ? "Red": isMedium?"Amber":"Green"}
            </div>
        </div>
    );
};

const SNOWRiskRenderer = ({ data }: CustomCellRendererProps) => {
    return (
        <div className="grid h-full items-center">
            <div
                className={cn(
                    "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700 capitalize",
                    data?.risk == "high"
                        ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
                        : data?.risk == 'Medium' ? "bg-yellow-400 dark:bg-yellow-800" : 'bg-green-400 dark:bg-green-800 dark:text-white',
                )}
            >
                {data.risk}
            </div>
        </div>
    )
}

const ZoneRenderer = ({ data }: CustomCellRendererProps) => {
    return (
        <div className="grid h-full items-center">
            <div
                className={cn(
                    "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700 capitalize",
                    data?.zone == "RED" || data?.zone == "Red"
                        ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
                        : data?.zone == 'amber' ? "bg-yellow-400 dark:bg-yellow-800" : 'bg-green-400 dark:bg-green-800',
                )}
            >
                {data.zone}
            </div>
        </div>
    )
}


import axios from "axios";
import { Textarea } from "@/components/ui/textarea";
const NotesRenderer = React.memo(({ data }: CustomCellRendererProps) => {
    const [notes, setNotes] = useState("");
    const [isOpen, setIsOpen] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [alertMessage, setAlertMessage] = useState<string | null>(null);
    const [alertType, setAlertType] = useState<"success" | "error" | null>(null);

    // Fetch notes when modal opens
    const fetchNotes = async () => {
        setIsLoading(true);
        setAlertMessage(null);
        try {
            const response = await axios.get("https://ismartams.tcsapps.com/api/python_icrm/getNotes", {
                params: {
                    refNo: data.change_number,
                    sector: "Finance",
                    region: "USA",
                    module: "MODULE1",
                },
            });

            setNotes(response.data[0]?.notes || "");
        } catch (error) {
            console.error("Error fetching notes:", error);
            setAlertType("error");
            setAlertMessage("Failed to load notes from backend.");
        } finally {
            setIsLoading(false);
        }
    };

    // Save notes to backend
    const handleSave = async () => {
        if (!notes.trim()) {
            setAlertType("error");
            setAlertMessage("Please enter some notes before saving.");
            return;
        }

        setIsSaving(true);
        setAlertMessage(null);

        try {
            const response = await axios.post("https://ismartams.tcsapps.com/api/python_icrm/saveNotes", {
                refNo: data.change_number,
                sector: "Finance",
                region: "USA",
                module: "Module1",
                notes,
                soeId: "SOE123",
            });

            if (response.data.status === "Success") {
                setAlertType("success");
                setAlertMessage("Notes saved successfully!");
                setTimeout(() => {
                    setIsOpen(false);
                    setAlertMessage(null);
                }, 5000);
            } else {
                setAlertType("error");
                setAlertMessage(response.data.message || "Failed to save notes.");
            }
        } catch (error: any) {
            console.error("Error saving notes:", error);
            setAlertType("error");
            setAlertMessage(
                error.response?.data?.message || "An error occurred while saving notes."
            );
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Dialog
            open={isOpen}
            onOpenChange={(open) => {
                setIsOpen(open);
                if (open) fetchNotes();
            }}
        >
            <DialogTrigger asChild>
                <div className="grid h-full items-center cursor-pointer">
                    <Icon name="notebook-pen" className="h-4 w-4 text-muted-foreground" />
                </div>
            </DialogTrigger>

            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>Add Notes</DialogTitle>
                    <DialogDescription>
                        Add notes for the change review. Click save when you're done.
                    </DialogDescription>
                </DialogHeader>

                {/* ✅ Show loader while fetching */}
                {isLoading ? (
                    <div className="flex justify-center items-center min-h-[100px]">
                        <Loader>Loding Note...</Loader>
                    </div>
                ) : (
                    <div className="mt-2 px-4">
                        <Textarea
                            value={notes}
                            rows={10}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Write your notes here..."
                            className="resize-none"
                        />
                    </div>
                )}

                {/* ✅ Alert Section */}
                {alertMessage && (
                    <div className="mt-4">
                        <Alert
                            className={cn(
                                alertType === "success"
                                    ? "border-green-500 bg-green-100 text-green-700"
                                    : "border-red-500 bg-red-100 text-red-700"
                            )}
                        >
                            <AlertTitle>
                                {alertType === "success" ? "Success" : "Error"}
                            </AlertTitle>
                            <AlertDescription>{alertMessage}</AlertDescription>
                        </Alert>
                    </div>
                )}

                {/* ✅ Save Button */}
                <div className="mt-4 flex">
                    <button
                        onClick={handleSave}
                        disabled={isSaving || isLoading}
                        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                    >
                        {isSaving ? "Saving..." : "Save"}
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
});


interface Props {
    data: ChangeRecord;
}
const ChangeSuceessRenderer = ({ data }: Props) => {
    return (
        <Dialog>
            <DialogTrigger asChild>
                <Icon name="sparkles" className="h-4 w-4 text-muted-foreground cursor-pointer" />
            </DialogTrigger>
            <DialogContent className="sm:max-w-[80vw]">
                <DialogHeader className="px-4">
                    <DialogTitle>Change Success Predictor</DialogTitle>
                    <DialogDescription>
                        Know your change suceess probablity beforehand to avoid last time hassle
                    </DialogDescription>
                </DialogHeader>
                <ChangeSuccessPredictorModal data={data} />
            </DialogContent>
        </Dialog>
    )
}

import { Link } from "react-router-dom";
import Loader from "@/components/ui/loader";
import ErrorContainer from "@/components/ui/error-container";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
const ChangeNumberRenderer = ({ data }: CustomCellRendererProps) => {
    return (
        <>
            <div className="flex gap-2 items-center h-full w-full">
                <ChangeSuceessRenderer data={data} />
                <Link to={data.change_number}
                    className="flex items-center gap-1 text-sm mt-2 opacity-90 "
                    state={{ changeData: data }}
                >
                    {data.change_number}
                </Link>
            </div>
        </>
    );
};