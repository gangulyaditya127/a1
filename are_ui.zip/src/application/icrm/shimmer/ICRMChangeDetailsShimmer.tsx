import Container from "@/components/ui/container";
import Loader from "@/components/ui/loader";
import { Skeleton } from "@/components/ui/skeleton";

export default function ICRMChangeDetailsShimmer() {
    return (
        <Container className="flex flex-col gap-4 py-6">
            <Skeleton className="h-10 rounded-lg" />
            <Skeleton className="h-[200px] grid place-items-center rounded-lg ">
                <Loader className="justify-center m-24">

                </Loader>
            </Skeleton>
            <Skeleton className="h-[40px] grid place-items-center rounded-lg ">

            </Skeleton>
            <Skeleton className="h-[400px] grid place-items-center rounded-lg ">
                <Loader className="justify-center m-24">

                </Loader>
            </Skeleton>
        </Container>
    )
}