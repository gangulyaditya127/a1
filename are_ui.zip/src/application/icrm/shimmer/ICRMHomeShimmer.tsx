import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function ICRMHomeShimmer(){
    return (
        <Container className="flex flex-col gap-4 py-6">
            <Skeleton className="h-[150px] w-full rounded-xl"/>
            <div className="grid grid-cols-3 gap-6">
                <Skeleton className="col-span-2 h-[300px] rounded-xl"/>
                <Skeleton className="h-[300px] rounded-xl"/>
            </div>
        </Container>
    )
}