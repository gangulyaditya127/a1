import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function ICPAChangeShimmer() {
    return (
        <Container className="flex flex-col gap-6 py-6">
            <Skeleton className="h-10 rounded-lg" />
            <div className="grid grid-cols-[auto_300px] gap-6">
                <div className="flex flex-col gap-6">
                    <Skeleton className="h-[300px] rounded-xl" />
                    <Skeleton className="h-[400px] rounded-xl" />
                </div>
                <div className="flex flex-col gap-6">
                    <Skeleton className="h-[450px] rounded-xl"/>
                    <Skeleton className="h-[250px] rounded-xl" />
                </div>
            </div>
        </Container>
    )
}