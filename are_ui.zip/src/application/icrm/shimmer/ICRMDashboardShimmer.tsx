import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function ICRMDashboardShimmer() {
    return (
        <Container className="flex flex-col gap-6 py-6">
            <Skeleton className="h-[150px] w-full rounded-xl" />
            <Skeleton className="col-span-2 h-[300px] rounded-xl" />
        </Container>
    )
}

export function ICRMDashboardTableShimmer(){
    return (
        <div className="pt-8">
            <Skeleton className="h-[300px] rounded-xl py-6 pt-6"/>
        </div>
    )
}