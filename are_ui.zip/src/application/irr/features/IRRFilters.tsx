const IRRFilters = () => {
  return <div className="flex items-center"></div>;
};

export default IRRFilters;
