import {
  useMemo,
  useState,
} from "react";
import {CustomCellRendererProps } from "ag-grid-react";
import {
  ColDef,
} from "ag-grid-community";
// import "ag-grid-charts-enterprise";
import { Link } from "react-router-dom";
// import useDerivedTheme from "@/lib/hooks/useDerivedTheme";
import { cn } from "@/lib/tailwind.utils"
// import { IncidentProps } from "../slice/iRRDataSlice";
import { useMockTableData } from "../hooks/useMockTableData";
import DataGrid from "@/components/ui/data-grid";

const IRRDashboardTable = () => {
  const { data: rowData, ready } = useMockTableData()
  // const theme = useDerivedTheme()
  const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);

  const [columnDefs] = useState<ColDef[]>([
    { field: "incidentNumber", maxWidth: 200, filter: 'agTextColumnFilter', headerName: "Incident Number", cellRenderer: IncidentRender },
    { field: "incidentTitle", filter: 'agSetColumnFilter' },
    { field: "priority", filter: 'agSetColumnFilter', maxWidth: 150, cellRenderer: TicketPriorityRender },
    { field: "category", filter: 'agSetColumnFilter', },
    { field: "createdAt" }
  ]);
  const defaultColDef = useMemo<ColDef>(() => {
    return {
      flex: 1,
    };
  }, []);
  if(!ready){
    return 'Loading...'
  }
  return (
    <div className="h-[400px] mt-6 mb-8">
      <div
        style={gridStyle}
      >
        <DataGrid
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          masterDetail={true}
        />
      </div>
    </div>
  );
};
const TicketPriorityRender = ({ data }: CustomCellRendererProps) => {
  return (
    <div className="grid h-full items-center">
      <div
        className={cn(
          "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700",
          data?.priority == "High"
            ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
            : "bg-yellow-400 dark:bg-yellow-800",
        )}
      >
        {data.priority}
      </div>
    </div>
  )
}
const IncidentRender = ({ data }: CustomCellRendererProps) => {
  return (
    <div className="h-full flex items-center gap-2">
      <Link
        to={`/irr/${data.incidentNumber}`}
        className="h-full hover:underline"
      >
        {data?.incidentNumber}
      </Link>
      <div
        className={cn(
          "w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700",
          data?.match < 50
            ? "bg-red-600 text-white dark:bg-red-600 dark:text-foreground"
            : data?.match < 70 ? 'bg-yellow-400 dark:bg-yellow-800' : "bg-green-400 dark:bg-green-800",
        )}
      >
        {data?.match} %
      </div>
    </div>
  )
}
export default IRRDashboardTable;
