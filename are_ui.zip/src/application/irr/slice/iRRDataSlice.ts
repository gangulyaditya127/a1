import { createSlice } from "@reduxjs/toolkit";
import { getIncidents } from "../data/mockup.data";
// PayloadAction
export type IncidentProps = {
  incidentNumber: string;
  incidentTitle: string;
  priority: string;
  resolutionFound: boolean;
  resolution?: string;
  createdAt?:string,
  category?:string,
  subCategory?:string,
  match?:number
};

type IRRSliceDataProp = {
  incidentList: IncidentProps[];
};

const initialState: IRRSliceDataProp = {
  incidentList: getIncidents(),
};

const iRRDataSlice = createSlice({
  name: "irrDataSlice",
  initialState,
  reducers: {},
});

export const {} = iRRDataSlice.actions;

export default iRRDataSlice.reducer;
