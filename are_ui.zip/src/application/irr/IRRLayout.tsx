import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import SIDEBAR_DATA from "./data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
// import { TOP_NAV_LIST } from "./data/topnav.data";
import { useTranslation } from "react-i18next";

function IRRLayout() {
  const dispatch = useAppDispatch();
  const { t, ready ,i18n} = useTranslation('/irr/appDetails')
  useEffect(() => {
    if (ready) {
      dispatch(updateSideBarNavigation(SIDEBAR_DATA));
      dispatch(
        updateTopNavigation({
          navList: [
            {
              content: t('name'),
              route: "/irr",
              key: "1",
            },
          ],
          isHome: false,
          isAMS: false,
        }),
      );
    }
  }, [i18n.language]);
  return <Outlet />;
}
export default IRRLayout;
