import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "Intelligent Resolution Recommender",
    route: "/irr",
    key: "1",
  },
];
