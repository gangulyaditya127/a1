import { getNthHourNumericFormat } from "@/lib/date.utils";
import { IncidentProps } from "../slice/iRRDataSlice";

export const MOCK_DATA: IncidentProps[] = [
  {
    incidentNumber: "INC76497584",
    incidentTitle: "cdcgsker34: ITM_K_20 ATM Withdrawal Server Failure",
    priority: "Medium",
    resolutionFound: true,
    createdAt:getNthHourNumericFormat(-2),
    match:91,
    category:'Infra/Server Issue',
    resolution:
      "ATM withdrawal transactions were failing due to a network connectivity issue. **Resolution Steps**: \n1. **Identify the issue**: Checked the ATM server `cdcgsker34` logs and found network timeout errors. Command used: `tail -f /var/log/cdcgsker34_at_23/itm_k_cdcgsker34.log`. \n2. **Check network connectivity**: Verified the network connection between the ATM and the server. Command used: `ping server_ip`. \n3. **Restart ATM service**: Restarted the ATM service to establish a fresh connection. Command used: `systemctl restart cdcgsker_ser_it_3456`. \n5. **Monitor the system**: Used network monitoring tools to ensure stable connectivity. Tools used: `Wireshark`, `Nagios`. ATM withdrawals were successful, and no further failures were reported.",
  },
  {
    incidentNumber: "INC76493982",
    incidentTitle: "cdcgskdr34: ITM_K_140 Online Account Registration Error",
    priority: "Low",
    category:'Application/Software Bug',
    resolutionFound: true,
    match:76,
    createdAt:getNthHourNumericFormat(-3),
    resolution:
      "Customers were unable to register for online accounts due to a validation error. **Resolution Steps**: \n1. **Identify the issue**: Checked the application logs and found registration validation errors. Command used: `tail -f /var/log/cdcgskdr34/item/140/error.log`. \n2. **Review the validation logic**: Reviewed the application code and identified a bug in the email validation. File: `/var/www/cdcgskdr34/item/html/register.php`. \n3. **Fix the bug**: Corrected the email validation logic to allow special characters. Code change: `filter_var($email, FILTER_VALIDATE_EMAIL)`. \n4. **Deploy the fix**: Deployed the updated code to the production server. Command used: `scp register.php <<user@cdcgskdr34>>:/var/www/html/`. \n5. **Test the registration**: Registered multiple test accounts to ensure the issue was resolved. \n6. **Monitor the system**: Used application monitoring tools to ensure no further registration errors occurred. Tools used: `New Relic`, `Splunk`. Online account registrations were successful, and no further errors were reported.",
  },
  {
    incidentNumber: "INC76497599",
    incidentTitle: "APAC_APP_2096_USER_SS9798_Card Payment Declined",
    priority: "High",
    category:'Transation Issue',
    resolutionFound: true,
    match:87,
    createdAt:getNthHourNumericFormat(-2),
    resolution:
      "Card payments were being declined due to an issue with the payment gateway. **Resolution Steps**: \n1. **Identify the issue**: Checked the payment gateway logs and found error responses. Command used: `tail -f /var/log/apac/app/2096/payment_gateway/payment.log`. \n2. **Investigate the gateway response**: Analyzed the error codes and messages returned by the payment gateway. \n3. **Contact payment gateway provider**: Reached out to the payment gateway provider's support team to investigate the issue. \n4. **Implement temporary workaround**: Implemented a temporary solution to route payments through an alternative gateway. \n5. **Monitor the system**: Used payment gateway monitoring tools to ensure successful transactions. Tools used: `Stripe Dashboard`, `PayPal Developer Console`. Card payments were processed successfully, and no further declines were reported.",
  },
  {
    incidentNumber: "INC76493988",
    incidentTitle: "NAM_APP_2450: Mobile App Login Failure",
    priority: "Medium",
    category:'Auth/Access Control Issue',
    resolutionFound: true,
    createdAt:getNthHourNumericFormat(-3),
    match:64,
    resolution:
      'Users were unable to log in to the mobile app due to an authentication error. **Resolution Steps**: \n1. **Identify the issue**: Checked the mobile app logs and found authentication failure messages. Command used: `adb logcat -v time | grep "AuthenticationError"`. \n2. **Review authentication process**: Reviewed the mobile app code and identified a bug in the authentication logic. File: `2450_LoginActivity.java`. \n3. **Fix the bug**: Corrected the authentication logic to handle special characters in passwords. Code change: `TextUtils.equals(inputPassword, storedPassword)`. \n4. **Deploy the fix**: Rebuilt the app and deployed the updated version to the app store. Commands used: `./gradlew assembleRelease`, `fastlane supply --track production --json_key api-key.json`. \n5. **Test the app**: Logged in with multiple test accounts to ensure the issue was resolved. \n6. **Monitor the app**: Used app performance monitoring tools to ensure no further login failures occurred. Tools used: `Firebase Crashlytics`, `New Relic Mobile`. The app login functionality was restored, and no further failures were reported.',
  },
  {
    incidentNumber: "INC76497605",
    category:'Performance/Load Issue',
    incidentTitle: "APP_2645_ARE_INTRO Website Slow Performance",
    priority: "High",
    resolutionFound: true,
    createdAt:getNthHourNumericFormat(-3),
    match:53,
    resolution:
      "The website was experiencing slow performance due to high server load. **Resolution Steps**: \n1. **Identify the issue**: Monitored the server performance and found high CPU and memory usage. Command used: `top`. \n2. **Optimize server configuration**: Adjusted the server configuration to handle increased traffic. File: `/etc/nginx/nginx.conf`. \n3. **Implement caching**: Configured caching mechanisms to reduce server load. File: `/etc/nginx/sites-available/website.conf`. \n4. **Monitor server performance**: Used server monitoring tools to ensure improved performance. Tools used: `Grafana`, `Prometheus`. The website performance improved, and no further slowdowns were reported.",
  },
  {
    incidentNumber: "INC76493992",
    category:'Integration Failure',
    incidentTitle: "SG_NAM_APP_2560_USER_AF4523: Email Notifications Not Sent",
    priority: "Medium",
    resolutionFound: true,
    createdAt:getNthHourNumericFormat(-2),
    match:43,
    resolution:
      "Email notifications were not being sent to customers due to a misconfiguration in the email server. **Resolution Steps**: \n1. **Identify the issue**: Checked the email server logs and found connection errors. Command used: `tail -f /var/log/mail.log`. \n2. **Check email server configuration**: Verified the email server configuration settings. File: `/etc/postfix/main.cf`. \n3. **Restart email server**: Restarted the email server to apply the configuration changes. Command used: `systemctl restart postfix`. \n4. **Test email notifications**: Sent test emails to ensure they were delivered successfully. \n5. **Monitor the system**: Used email server monitoring tools to ensure all notifications were sent. Tools used: `Mailgun Logs`, `Postfix Admin`. Email notifications were sent successfully, and no further issues were reported.",
  },
];
export const getIncidents = () => {
  return MOCK_DATA.map((el) => ({ ...el, resolution: undefined }));
};
export const getResolution = (incidentNumber: string) => {
  return (
    MOCK_DATA.filter((el) => el.incidentNumber === incidentNumber)?.[0]
      ?.resolution ?? "Not found"
  );
};
