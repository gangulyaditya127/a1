import Container from "@/components/ui/container";
import { useParams, Link } from "react-router-dom";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Separator } from "@/components/ui/seperator";
import ReactMarkDown from "react-markdown";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Icon } from "@/components/ui/icon";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetResolutionRecommendation } from "../hooks/useGetResolution";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
export default function IRRecommendation() {
  const { incidentNumber } = useParams();
  const { t, ready } = useTranslation('/irr/appDetails')
  const { data, ready: isDataLoaded } = useGetResolutionRecommendation(incidentNumber ?? "")
  return (
    <section>
      <Container className="relative mt-9 max-w-4xl pb-56">
        <Button
          variant="link"
          className="p-0 text-muted-foreground hover:text-foreground"
        >
          <NavigateBackButton fallbackUrl="/irr" />
        </Button>
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/irr">IRR</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{incidentNumber}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <h1 className="mb-3 mt-6 text-3xl">
          {ready ? t('incidentRecommendationTitle') : <Skeleton className="h-8 w-30" />} {incidentNumber}
        </h1>
        <Separator />
        <div className="mt-2">
          {
            isDataLoaded &&
            <ReactMarkDown
              className="prose prose-stone max-w-none dark:prose-invert prose-code:inline-block prose-code:rounded-lg prose-code:px-2 prose-code:dark:bg-neutral-700  prose-code:bg-neutral-200 prose-ul:list-disc prose-ol:list-decimal"
              children={((data as string) ?? "")?.replace?.(
                /\n/gi,
                "&nbsp; \n",
              )}
            />
          }
        </div>
      </Container>
      <div className="fixed bottom-0 left-[40px] flex w-full items-center justify-center">
        <form
          className="w-full max-w-4xl overflow-hidden rounded-lg border bg-background focus-within:ring-1 focus-within:ring-ring"
          x-chunk="dashboard-03-chunk-1"
        >
          <Label htmlFor="message" className="sr-only">
            {t('followup')}
          </Label>
          <Textarea
            id="message"
            placeholder={t('followup')}
            className="min-h-12 resize-none border-0 p-3 shadow-none focus-visible:ring-0"
          />
          <div className="flex items-center p-3 pt-0">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Icon name="paperclip" className="size-4" />
                    <span className="sr-only">Attach file</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top">Attach File</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Icon name="mic" className="size-4" />
                    <span className="sr-only">Use Microphone</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top">Use Microphone</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button type="submit" size="sm" className="ml-auto gap-1.5">
              {/* Send Message */}
              <Icon name="corner-down-left" className="size-3.5" />
            </Button>
          </div>
        </form>
      </div>
    </section>
  );
}
