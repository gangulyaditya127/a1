import Container from "@/components/ui/container";
import { cn } from "@/lib/tailwind.utils";
import BG from "@/assets/3D illus/Saly-38.png";
import { lazy, Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { useTranslation } from "react-i18next";
const IRRDashboardTable = lazy(() => import('../features/IRRDashboardTable'))
function IRRHome() {
  const { t, ready } = useTranslation('irr/appDetails')
  return (
    <section className="p-2">
      <Container>
        <p
          className={cn(
            "relative mb-6 mt-2 text-3xl font-medium",
          )}
        >
          {ready ? t('homeTitle') : <Skeleton className="h-14" />}
        </p>
        <Suspense fallback={<Skeleton className="w-full h-[400px] rounded-lg" />}>
          <IRRDashboardTable />
        </Suspense>
      </Container>
      <img src={BG} alt="" className="fixed right-0 w-96" />
    </section>
  );
}
export default IRRHome;
