import DatePicker from "@/components/ui/date-picker";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { getNthDateNumericFormat } from "@/lib/date.utils";
import { useTranslation } from "react-i18next";
const formSchema = z.object({
  roomName: z.string().min(4).max(50),
  description: z.string().min(10).max(800),
  rules: z.string().min(10).max(400),
  startDate: z.date(),
  endDate: z.date(),
  prizePool: z.coerce.number().min(100).max(1000),
});
type WarRoomFormProps = {
  defaultValues?: number,
}
const WarRoomForm = (
  { defaultValues }: WarRoomFormProps
) => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });
  useEffect(() => {
    if (defaultValues) {
      form.setValue("roomName", "Wealth Mangement knowledge base war");
      form.setValue("description", "We have to increase our knowledge base by 100%. The top 3 user with highest contribution to the knowlede articles will get rewards worth 500 points");
      form.setValue("rules", `All contrbutions must be original and relevant to wealth management.
Each Knowledge article will be approved by team lead before it counts toward contribution.
Palagrism is strictly prohibited and will result in disqalification.
Team collaboration is encouraged, buts points will be awarded to individual contributors.
All articles must be submitted by the end date to be considered.`);
      form.setValue("prizePool", 1000);
      form.setValue("startDate", new Date(getNthDateNumericFormat(-4)));
      form.setValue("endDate", new Date(getNthDateNumericFormat(2)));
    }
  }, []);

  function onSubmit() {
  }
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminWarRoomConfig')
  if(!ready){
      return null;
  }
  return (
    <>
      <h1 className="px-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
        {
          defaultValues ?
            <span>Edit {form.getValues().roomName ?? "Wealth Mangement knowledge base war"}</span>
            :
            <span>{t('WarRoomForm.createAWarRoom')}</span>
        }
      </h1>

      <ScrollArea className="h-[75vh]">
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col gap-4 px-4"
          >
            <FormField
              control={form.control}
              name="roomName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('WarRoomForm.roomName')}</FormLabel>
                  <FormControl>
                    <Input
                      id="war_room_name"
                      placeholder={t('WarRoomForm.enterTheNameOfTheWarRoom')}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('WarRoomForm.description')}</FormLabel>
                  <FormControl>
                    <Textarea
                      id="description"
                      placeholder={t('WarRoomForm.provideADetailedDescriptionOfTheWarRoom')}
                      {...field}
                    ></Textarea>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="rules"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('WarRoomForm.rulesAndGuidelines')}</FormLabel>
                  <FormControl>
                    <Textarea
                      id="rules_and_guidelines"
                      placeholder={t('WarRoomForm.outlineTheRulesAndGuidelinesForParticipationInTheWarRoom')}
                      {...field}
                    ></Textarea>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid w-full grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('WarRoomForm.startDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('WarRoomForm.pickAStartDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('WarRoomForm.endDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('WarRoomForm.pickAEndDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="prizePool"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('WarRoomForm.prizePool')}</FormLabel>
                  <FormControl>
                    <Input
                      id="prizePool"
                      placeholder={t('WarRoomForm.enterPrizePool')}
                      value={+field.value}
                      onChange={field.onChange}
                      type="number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit">{t('WarRoomForm.submit')}</Button>
          </form>
        </Form>
      </ScrollArea>
    </>
  );
};
export default WarRoomForm;
