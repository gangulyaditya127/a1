import { PolarAngleAxis, PolarGrid, Radar, RadarChart } from "recharts"
import { useTranslation } from "react-i18next";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
const chartData = [
  { kpi: "War Room", participation: 80 },
  { kpi: "Innovation Lab", participation: 60 },
  { kpi: "Learning Odysyss", participation: 97 },
]

const chartConfig = {
  participation: {
    label: "Participation % ",
    color: "hsl(var(--chart-5))",
  },
} satisfies ChartConfig

export function ActivityParticipationTrend() {
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
  if (!ready) {
    return null;
  }
  return (
    <Card className="rounded-xl">
      <CardHeader className="items-center pb-4">
        <CardTitle className="text-xl">{t('ActivityParticipationTrend.offeringsParticipation')}</CardTitle>
        <CardDescription>
          {t('ActivityParticipationTrend.showingParticipationOfTeamAcrossDifferentGamificationKPIs')}
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-0">
        <ChartContainer
          config={chartConfig}
          className="mx-auto aspect-square max-h-[250px]"
        >
          <RadarChart data={chartData}>
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent />}
            />
            <PolarGrid gridType="circle" />
            <PolarAngleAxis dataKey="kpi" />
            <Radar
              dataKey="participation"
              fill="var(--color-participation)"
              fillOpacity={0.6}
              dot={{
                r: 3,
                fillOpacity: 1,
              }}
            />
          </RadarChart>
        </ChartContainer>
        <div className="flex flex-col gap-2 text-sm items-center justify-center w-full">
          <div className="flex items-center gap-2 leading-none text-muted-foreground">
            January - June 2024
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex-col gap-2 text-sm items-start mt-4 border-t py-4">
        <p>{t('ActivityParticipationTrend.content.0')}</p>
        <p className="text-muted-foreground">
          {t('ActivityParticipationTrend.content.1')}<KBDTag text={t('ActivityParticipationTrend.content.2')} /> {t('ActivityParticipationTrend.content.3')}
        </p>
      </CardFooter>
    </Card>
  )
}
const KBDTag = ({ text }: {
  text: string
}) => {
  return (
    <kbd className="pointer-events-none mx-0 inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
      <span className="text-xs">{text}</span>
    </kbd>
  )
}