import ReactEcharts from "echarts-for-react";
function KeyTrendsBarChart() {
  const option = {
    legend: { textStyle: { color: "white" } },
    tooltip: {},
    dataset: {
      dimensions: ["product", "Compliance", "Finance", "HR", "Risk"],
      source: [
        {
          product: "JustifyIT",
          Compliance: 43.3,
          Finance: 85.8,
          HR: 93.7,
          Risk: 43.7,
        },
        {
          product: "RLM Deployment",
          Compliance: 43.3,
          Finance: 85.8,
          HR: 93.7,
          Risk: 63.7,
        },
        {
          product: "SLA",
          Compliance: 43.3,
          Finance: 85.8,
          HR: 93.7,
          Risk: 73.7,
        },
        {
          product: "DQ Score",
          Compliance: 43.3,
          Finance: 85.8,
          HR: 93.7,
          Risk: 90.7,
        },
      ],
    },
    xAxis: { type: "category", axisLabel: { color: "white" } },
    yAxis: {},
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
      { type: "bar" },
      { type: "bar" },
      { type: "bar" },
      { type: "bar" },
    ],
  };
  return <ReactEcharts option={option} />;
}
export default KeyTrendsBarChart;
