import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import podimStyles from "./styles/podium.module.css";
import { cn } from "@/lib/tailwind.utils";
import { Icon } from "@/components/ui/icon";
const Podium = ({
  className,
  podiumSize,
}: {
  className?: string;
  podiumSize?: number;
}) => {
  const style = {
    "--_podium-size": podiumSize ? `${podiumSize}px` : "3px",
  } as React.CSSProperties;
  return (
    <>
      <div
        className={cn(`${podimStyles["podium-container"]} relative`, className)}
        style={style}
      >
        <div className={podimStyles["podium"]}>
          <div
            className={`${podimStyles["podium__front"]} ${podimStyles["podium__left"]} group/podium`}
          >
            <div className="text-white">2</div>
            <div className={`${podimStyles["podium__image"]} relative z-[5]`}>
              <div className="relative flex flex-col items-center gap-1 text-xs font-medium">
                <div
                  className={`${podimStyles["podium__crown"]} group-hover/podium:rotate-vertical-axis`}
                >
                  <Icon
                    name="crown"
                    className={`size-[14px] fill-white text-white`}
                  />
                </div>
                <Avatar>
                  <AvatarFallback className="border-4 border-white bg-neutral-800">
                    SU
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
          </div>
          <div
            className={`${podimStyles["podium__front"]} ${podimStyles["podium__center"]}`}
          >
            <div className="">1</div>
            <div className={`${podimStyles["podium__image"]} relative z-[5]`}>
              <div className="relative flex flex-col items-center gap-1 text-xs font-medium">
                <Icon
                  name="crown"
                  className={`size-[14px] fill-yellow-200 text-yellow-200`}
                />
                <Avatar>
                  <AvatarFallback className="border-4 border-yellow-200 bg-neutral-800">
                    AK
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
          </div>
          <div
            className={`${podimStyles["podium__front"]} ${podimStyles["podium__right"]} relative`}
          >
            <div className="">3</div>
            <div
              className={`${`${podimStyles["podium__image"]} relative z-[5]`} absolute`}
            >
              <div className="relative flex flex-col items-center gap-1 text-xs font-medium">
                <Icon
                  name="crown"
                  className={`size-[14px] fill-amber-400 text-amber-400`}
                />
                <Avatar>
                  <AvatarFallback className="border-4 border-amber-600 bg-neutral-800">
                    PA
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Podium;
