
import { Icon } from "@/components/ui/icon";
import NumberTicker from "@/components/ui/number-ticker";
import { Separator } from "@/components/ui/seperator";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog"
import GamificationKPIPeerComparision from "./GamificationKPIPeerComparision";
import { useTranslation } from "react-i18next";
const AdminDashboardHeader = () => {
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
  if(!ready){
      return null;
  }
  return (
    <div className="flex items-baseline justify-between">
      <div>
        <h4 className="text-sm font-medium uppercase text-muted-foreground">
          {t('AdminDashboardHeader.financeTeam')}
        </h4>
        <h3 className="text-2xl font-medium">{t('AdminDashboardHeader.performanceDashboard')}</h3>
      </div>
      <div className="flex items-center gap-4">
        <div>

          <Dialog>
            <DialogTrigger asChild>
              <div className="cursor-pointer">
                <div className="flex gap-1">
                  <p className="text-muted-foreground">{t('AdminDashboardHeader.overallTeamRank')}</p>
                  <div className="flex -space-x-1">
                    <Icon
                      name="bar-chart-2"
                      className="size-5 p-0 text-green-400 dark:text-green-600"
                    />
                    <Icon
                      name="bar-chart"
                      className="size-5 p-0 text-green-400 dark:text-green-600"
                    />
                  </div>
                </div>
                <p className="text-2xl">
                  <NumberTicker value={2} />
                  <span className="text-sm font-normal text-muted-foreground">
                    /6
                  </span>
                </p>
              </div>
            </DialogTrigger>
            <DialogContent className="sm:max-w-4xl rounded-xl">
              <GamificationKPIPeerComparision/>
            </DialogContent>
          </Dialog>

        </div>
        <Separator orientation="vertical" className="h-12" />
        <div>
          <div className="flex gap-1">
            <p className="text-muted-foreground">{t('AdminDashboardHeader.memberCount')}</p>
            <div className="flex -space-x-1">
              <Icon
                name="bar-chart-2"
                className="size-5 p-0 text-green-400 dark:text-green-600"
              />
              <Icon
                name="bar-chart"
                className="size-5 p-0 text-green-400 dark:text-green-600"
              />
            </div>
          </div>
          <p className="text-2xl">
            <NumberTicker value={245} />
          </p>
        </div>
        <Separator orientation="vertical" className="h-12" />
        <div>
          <div className="flex gap-1">
            <p className="text-muted-foreground">{t('AdminDashboardHeader.avgTimeSpent')}</p>
            <div className="flex -space-x-1">
              <Icon
                name="bar-chart-2"
                className="size-5 p-0 text-yellow-400 dark:text-yellow-500"
              />
              <Icon
                name="bar-chart"
                className="size-5 p-0 text-yellow-400 dark:text-yellow-500"
              />
            </div>
          </div>
          <p className="flex items-baseline gap-1">
            <span className="text-2xl">
              <NumberTicker value={60} />
            </span>
            <span className="text-xs text-muted-foreground">{t('AdminDashboardHeader.min')}</span>
          </p>
        </div>
      </div>
    </div>
  )
}
export default AdminDashboardHeader;