import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useTranslation } from "react-i18next";

const TopPerformer = () => {
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
    if(!ready){
        return null;
    }
    return (
        <Card className="rounded-xl  bg-gradient-to-tr from-purple-700 dark:from-purple-700 dark:to-purple-500 to-purple-500 text-white">
            <CardHeader className="items-center pb-4">
                <CardTitle className="text-xl">{t('TopPerformer.topAchievers')}</CardTitle>
                <CardDescription className="text-neutral-200">
                    {t('TopPerformer.showingTop5PerformerOfYourTeam')}
                </CardDescription>
            </CardHeader>
            <CardContent className="p-6 pb-12">
                <div className="flex flex-wrap gap-6 justify-center">
                    <TopUserProfile name="Sudhanshu Singh" rank={1} emoji="👑" />
                    <TopUserProfile name="Shushant Mohan" rank={2} emoji="🥇" />
                    <TopUserProfile name="Vishal Sinha" rank={3} emoji="🎖️" />
                    <TopUserProfile name="Sumanta Desayi" rank={4} emoji="🌟" />
                    <TopUserProfile name="Abhishek Kumar" rank={5} emoji="🌟" />
                </div>
            </CardContent>
        </Card>
    )
}
// 🌟 (Star)
// 👑 (Crown)
// 🏆 (Trophy)
// 🥇 (Gold Medal)
// 🎖️ (Medal)
type UserProfileProps = {
    name: string,
    rank: string | number,
    emoji?: string
}
const TopUserProfile = (
    {
        name,
        rank,
        emoji
    }: UserProfileProps
) => {
    return (
        <div className="relative flex justify-center">
            <div className="space-y-2 flex flex-col items-center z-[1] relative">
                <div className="relative size-16 grid text-xl uppercase place-items-center rounded-full bg-neutral-200/40 border border-neutral-200 border-2">
                    <p>{name.substring(0, 2)}</p>
                    <p className="absolute -right-2 -bottom-2">{emoji}</p>
                </div>
                <p className="text-sm text-neutral-200">{name}</p>
            </div>

            <div className="text-7xl font-bold opacity-30 absolute -top-2 left-0 text-neutral-200">{rank}</div>
        </div>
    )
}
export default TopPerformer