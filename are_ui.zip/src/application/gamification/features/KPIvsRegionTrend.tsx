import ReactEcharts, { EChartsOption } from "echarts-for-react";
import { useState } from "react";
import colors from "tailwindcss/colors";
// import * as echarts from 'echarts';
const KPIvsRegionTrend = () => {
  const [option] = useState<EChartsOption>({
    legend: {
      itemGap: 25,
      textStyle: {
        color: colors.neutral[200],
      },
      left: 0,
      padding: 0,
      // show:false
    },
    grid: {
      left: "0%",
      right: "0%",
      bottom: "0%",
      containLabel: true,
    },
    tooltip: {},
    textStyle: {
      fontFamily: `ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"`,
    },
    dataset: {
      dimensions: [
        "product",
        "Retail Banking",
        "Corporate Banking",
        "Wealth Management",
        "Insurance",
      ],
      source: [
        {
          product: "SLA",
          "Retail Banking": 43.3,
          "Corporate Banking": 85.8,
          "Wealth Management": 93.7,
          Insurance: 60,
        },
        // { product: 'Ticket volume reduction', 'Retail Banking': 83.1, 'Corporate Banking': 73.4, 'Wealth Management': 55.1, 'Insurance': 20 },
        {
          product: "COB Complaince",
          "Retail Banking": 86.4,
          "Corporate Banking": 65.2,
          "Wealth Management": 82.5,
          Insurance: 80,
        },
        {
          product: "Automation",
          "Retail Banking": 72.4,
          "Corporate Banking": 53.9,
          "Wealth Management": 39.1,
          Insurance: 70,
        },
        {
          product: "MTP Reduction",
          "Retail Banking": 32.4,
          "Corporate Banking": 23.9,
          "Wealth Management": 39.1,
          Insurance: 10,
        },
        {
          product: "DQ Score",
          "Retail Banking": 62.4,
          "Corporate Banking": 43.9,
          "Wealth Management": 79.1,
          Insurance: 60.5,
        },
      ],
    },
    xAxis: {
      type: "category",
      axisLabel: {
        color: colors.neutral[200],
      },
    },
    yAxis: {
      axisLabel: {
        color: "white",
        formatter: "{value}%",
      },
      axisLine: {
        show: true,
      },
      splitLine: {
        show: false,
        lineStyle: {
          color: colors.neutral[600],
        },
      },
    },
    series: [
      {
        type: "bar",
        itemStyle: {
          borderRadius: 5,
          borderWidth: 4,
          borderColor: "transparent",
          borderJoin: "round",
        },
        color: colors.purple[400],
        // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //     {
        //       offset: 1,
        //       color: '#ffffff00'
        //     },
        //     {
        //       offset: 0,
        //       color: colors.purple[700]
        //     }
        // ]),
        showBackground: true,
        backgroundStyle: {
          color: "transparent",
        },
        label: {
          show: true,
        },
      },
      {
        type: "bar",
        itemStyle: {
          borderRadius: 5,
          borderWidth: 4,
          borderColor: "transparent",
          borderJoin: "round",
        },
        color: colors.sky[200],
        // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //     {
        //       offset: 1,
        //       color: '#ffffff00'
        //     },
        //     {
        //       offset: 0,
        //       color: colors.sky[300]
        //     }
        // ]),
        showBackground: true,
        backgroundStyle: {
          color: "transparent",
        },
        label: {
          show: true,
        },
      },
      {
        type: "bar",
        itemStyle: {
          borderRadius: 5,
          borderWidth: 4,
          borderColor: "transparent",
          borderJoin: "round",
        },
        color: colors.pink[200],
        // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //     {
        //       offset: 1,
        //       color: '#ffffff00'
        //     },
        //     {
        //       offset: 0,
        //       color: colors.pink[400]
        //     }
        // ]),
        showBackground: true,
        backgroundStyle: {
          color: "transparent",
        },
        label: {
          show: true,
        },
      },
    ],
  });

  return (
    <div className="rounded-xl border border-[rgba(255,255,255,0.10)] bg-secondary/80 p-6 tracking-wider shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] dark:bg-[rgba(40,40,40,0.70)]">
      <ReactEcharts option={option} />
    </div>
  );
};
export default KPIvsRegionTrend;
