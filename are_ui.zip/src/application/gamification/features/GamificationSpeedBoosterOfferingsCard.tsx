import { WobbleCard } from "@/components/ui/wobble-card";
import { IconNameProp } from "@/components/ui/icon";
import { Icon } from "@/components/ui/icon";
import { Link } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
import COIN from '@/assets/3D illus/coin.png'
import { useTranslation } from "react-i18next";
type GamificationSpeedBoosterOfferingsCardProps = {
  className?: string;
  title: string;
  description: string;
  icon?: IconNameProp;
  coins?: number;
  route?: string;
  imageClassName?: string;
  desClassName?: string;
  points?: number
};
const GamificationSpeedBoosterOfferingsCard = ({
  title,
  description,
  icon,
  route,
  className,
  desClassName,
  points
}: GamificationSpeedBoosterOfferingsCardProps) => {
  const { t, ready } = useTranslation('/gamification/common')
  return (
    <Link to={route ? route : ""}>
      <WobbleCard
        containerClassName={cn(
          "rounded-xl h-[12rem] cursor-pointer relative overflow-hidden",
          className
        )}
        showNoise={true}
        showRadialGradient={true}
        className="p-6 text-sm"
      >
        <div className="relative z-[2] flex flex-col h-full">
          <div className="flex gap-1">
            {icon && (
              <Icon
                name={icon}
                className="relative z-[1] size-4"
              />
            )}
            <p className="font-medium">{title}</p>
          </div>
          <p className={cn("mt-1 text-neutral-400", desClassName)}>
            {description}
          </p>
          <div className="flex gap-1 items-center mt-auto">
            <img src={COIN} alt="" className="size-5" />
            <p>+{points} <span>{ready && t('points')}</span></p>
          </div>
        </div>
      </WobbleCard>
    </Link>
  );
};
export default GamificationSpeedBoosterOfferingsCard;
