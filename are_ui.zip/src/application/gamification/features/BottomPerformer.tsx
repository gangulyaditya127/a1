import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useTranslation } from "react-i18next";

import {
    HoverCard,
    HoverCardContent,
    HoverCardTrigger,
  } from "@/components/ui/hover-card"
const BottomPerformer = () => {
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
    if(!ready){
        return null;
    }
    return (
        <Card className="rounded-xl bg-gradient-to-tr from-rose-700 dark:from-rose-700 dark:to-rose-500 to-rose-500 text-white">
            <CardHeader className="items-center pb-4">
                <CardTitle className="text-xl">{t('BottomPerformer.strugglingPerformers')}</CardTitle>
                <CardDescription className="text-neutral-200">
                    {t('BottomPerformer.showingBottom5PerformersOfYourTeam')}
                </CardDescription>
            </CardHeader>
            <CardContent className="p-6 pb-12">
                <div className="flex flex-wrap gap-6 justify-center">
                    <BottomUserProfile name="Amit Kumar Das" rank={110} emoji="😔" suggestion="Need to participate regularly in speed duals and war room"/>
                    <BottomUserProfile name="Shayam Kumar Bera" rank={123} emoji="😔" suggestion="Need to complete assigned training from Learning Odysyss"/>
                    <BottomUserProfile name="Mrinal D. Karak" rank={132} emoji="😔" suggestion="Need to improve ticket resolution speed, participating in speed dual might improve the overall performance"/>
                    <BottomUserProfile name="Debashish Das" rank={143} emoji="😔" suggestion="Need to actively participate in all offerings. Current Participation is too low"/>
                    <BottomUserProfile name="Akash K. Roy" rank={154} emoji="😔" suggestion="Need to fous more on innovation labs"/>
                </div>
            </CardContent>
        </Card>
    )
}
type UserProfileProps = {
    name: string,
    rank: string | number,
    emoji?: string,
    suggestion?:string
}
const BottomUserProfile = (
    {
        name,
        rank,
        emoji,
        suggestion
    }: UserProfileProps
) => {
    return (
        <HoverCard>
            <HoverCardTrigger asChild>
                <div className="relative flex justify-center">
                    <div className="space-y-2 flex flex-col items-center z-[1] relative">
                        <div className="relative size-16 grid text-xl uppercase place-items-center rounded-full bg-neutral-200/40 border border-neutral-200 border-2">
                            <p>{name.substring(0, 2)}</p>
                            <p className="absolute -right-2 -bottom-2">{emoji}</p>
                        </div>
                        <p className="text-sm text-neutral-200">{name}</p>
                    </div>

                    {/* <div className="text-7xl font-bold opacity-10 absolute -top-2 left-0">{rank}</div> */}
                </div>
            </HoverCardTrigger>
            <HoverCardContent className="w-80 rounded-lg">
                <div className="flex justify-between space-x-4">
                    <Avatar>
                        <AvatarFallback className="uppercase">{name.substring(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                        <h4 className="text-sm font-semibold">{name}</h4>
                        <p className="text-sm">
                            Rank # {rank}
                        </p>
                        <p className="text-xs text-muted-foreground">
                            {suggestion}
                        </p>
                    </div>
                </div>
            </HoverCardContent>
        </HoverCard>

    )
}
export default BottomPerformer