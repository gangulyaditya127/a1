import { Icon } from "@/components/ui/icon";
import { Separator } from "@/components/ui/seperator";
import { cn } from "@/lib/tailwind.utils";
import { WobbleCard } from "@/components/ui/wobble-card";
import COIN from "@/assets/3D illus/coin.png";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
const ProfileCard = ({ className }: { className?: string }) => {
  const { t, ready } = useTranslation('/gamification/user/home')

  if (!ready) {
    <Skeleton className="h-64 rounded-xl col-span-3 md:col-span-2 lg:col-span-3">
    </Skeleton>
  }

  return (
    <WobbleCard
      containerClassName={cn(
        "rounded-xl cursor-pointer bg-gradient-to-tr from-purple-700 dark:from-purple-600 dark:to-purple-400 to-purple-500 text-white ",
        className,
      )}
      showNoise={true}
    >
      <Link to="/gamification/profile" className="flex h-full flex-col justify-center">
        <div className={"relative flex flex-col gap-4 overflow-hidden p-7"}>
          <div>
            <p className="text-sm uppercase text-neutral-200">{t('profile.globalRank.displayText')}</p>
            <div className="ml-auto flex items-baseline gap-1">
              <div className="text-7xl font-semibold">5</div>
              <div className="text-4xl font-medium text-neutral-200">/ 243</div>
            </div>
          </div>
          <Separator orientation="horizontal" className="bg-neutral-300" />
          <div className="z-[1] flex items-center gap-4">
            <div>
              <div className="text-2xl">2</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
                {t('profile.teamRank.displayText')}
              </p>
            </div>
            <Separator orientation="vertical" className="h-10 bg-neutral-300" />
            <div>
              <div className="text-2xl">20</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
                {t('profile.courseCount.displayText')}
              </p>
            </div>
            <Separator orientation="vertical" className="h-10 bg-neutral-300" />
            <div>
              <div className="text-2xl">400</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
                {t('profile.ticketCount.displayText')}
              </p>
            </div>
          </div>
        </div>
        <div className="absolute -right-5 top-9 z-[1] flex w-fit items-center gap-2 rounded-full bg-black/60 p-1 pl-3 pr-8">
          {/* <Icon name="badge-cent" className="size-6 fill-white text-black/50"></Icon> */}
          <img src={COIN} alt="" className="size-6" />
          <p className="flex items-center gap-1 text-lg">
            <span className="font-medium">1000</span>
            <span className="text-sm">{t('profile.points.displayText')}</span>
          </p>
        </div>
        <Icon
          name="gem"
          className="absolute -right-20 -top-20 -z-[0] size-96 text-black opacity-10"
        ></Icon>
      </Link>
    </WobbleCard>
  );
};
export default ProfileCard;
