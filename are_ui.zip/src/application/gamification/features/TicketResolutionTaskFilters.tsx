import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { MultiSelectCombobox } from "@/components/ui/multi-select-combobox";

const TicketResolutionTaskFilters = () => {
  return (
    <div className="flex gap-4">
      <MultiSelectCombobox
        value={undefined}
        setValueOnClose={true}
        setValue={() => {}}
        optionList={[]}
        placeholder="Status"
      />
      <MultiSelectCombobox
        value={undefined}
        setValueOnClose={true}
        setValue={() => {}}
        optionList={[]}
        placeholder="Priority"
      />
      <div className="relative w-full">
        <Icon
          name="search"
          className="absolute left-3 top-2.5 size-5 text-neutral-500"
        ></Icon>
        <Input placeholder="Search for Incident" className="pl-10" />
      </div>
    </div>
  );
};
export default TicketResolutionTaskFilters;
