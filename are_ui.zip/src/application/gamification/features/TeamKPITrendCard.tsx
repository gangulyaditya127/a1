import { Area, AreaChart, CartesianGrid, XAxis } from "recharts"
import { useTranslation } from "react-i18next";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import TeamKPITrendFilters, { durationList, kpiList } from "./TeamKPITrendFilters"
import { useAppSelector } from "@/lib/redux/hooks"
import { useEffect, useState } from "react"

const generateData = (low: number, high: number) => {
  let res = [];
  let now = new Date()
  for (let i = 0; i < 180; i++) {
    const date=new Date(now);
    date.setDate(now.getDate()-i);
    const year=date.getFullYear();
    const month=String(date.getMonth()+1).padStart(2,'0')
    const day=String(date.getDate()).padStart(2,'0')
    res.push({
      date: `${year}-${month}-${day}`,
      data: Math.floor(Math.random() * (high - low + 1)) + low
    })
  }
  return res.reverse()
}

const filterChartData = (chartData: { data: number, date: string }[], timeRange: string) => {
  return chartData.filter((item) => {
    const date = new Date(item.date)
    const now = new Date()
    let daysToSubtract = +timeRange
    now.setDate(now.getDate() - daysToSubtract)
    return date >= now
  })
}

const ticketResolutionData = generateData(74, 175);
const pointsData = generateData(875, 3742);
const trainingCompletionRateData = generateData(30, 100);
const getKPILabel = (kpiVal: string) => (kpiList.filter(el => el.value == kpiVal)?.[0]?.label)


export default function TeamKPITrendCard() {
  const { kpi, duration } = useAppSelector((state) => state.gamificationAdmin.gamificationTeamKPITrendFilterData);
  const [chartConfig, setChartConfig] = useState<ChartConfig>({
    data: {
      label: "#",
      color: "hsl(var(--chart-5))",
    },
  })
  const [chartData, setChartData] = useState<{ date: string, data: number }[]>([])
  useEffect(() => {
    setChartConfig(
      {
        date: {
          label: 'Date'
        },
        data: {
          label: `${getKPILabel(kpi)}`,
          color: "hsl(var(--chart-5))",
        }
      }
    )
    switch (kpi) {
      case "ticket": {
        setChartData(filterChartData(ticketResolutionData, duration))
        break;
      }
      case "points": {
        setChartData(filterChartData(pointsData, duration))
        break;
      }
      case "training": {
        setChartData(filterChartData(trainingCompletionRateData, duration))
        break;
      }
    }
  }, [kpi, duration])
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
  if(!ready){
      return null;
  }
  return (
    <Card className="rounded-xl">
      <CardHeader className="border-b flex-row justify-between items-center">
        <div className="space-y-1.5">
          <CardTitle className="text-xl">{getKPILabel(kpi)} Trend</CardTitle>
          <CardDescription>
            {t("TeamKPITrendCard.showingTotalTicketResolvedForThe")} <span className="lowercase">{durationList.filter(el => el.value == duration)?.[0]?.label}</span>
          </CardDescription>
        </div>
        <div className="">
          <TeamKPITrendFilters />
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <ChartContainer config={chartConfig} className="h-[300px] aspect-auto">
          <AreaChart
            accessibilityLayer
            data={chartData}
            margin={{
              left: 12,
              right: 12,
              top: 10
            }}
          >
            <defs>
              <linearGradient id="fillKPIs" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor="var(--color-data)"
                  stopOpacity={0.8}
                />
                <stop
                  offset="95%"
                  stopColor="var(--color-data)"
                  stopOpacity={0.1}
                />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              minTickGap={32}
              tickFormatter={(value) => {
                const date = new Date(value)
                return date.toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                })
              }}
            />
            <ChartTooltip
              cursor={false}
              content={
                <ChartTooltipContent
                  labelFormatter={(value) => {
                    return new Date(value).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                    })
                  }}
                />
              }
            />
            <Area
              dataKey="data"
              type="natural"
              fill="url(#fillKPIs)"
              fillOpacity={0.4}
              stroke="var(--color-data)"
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
      <CardFooter>
        {/* <div className="flex w-full items-start gap-2 text-sm">
          <div className="grid gap-2">
            <div className="flex items-center gap-2 font-medium leading-none">
              Trending up by 5.2% this month <TrendingUp className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-2 leading-none text-muted-foreground">
              January - June 2024
            </div>
          </div>
        </div> */}
      </CardFooter>
    </Card>
  )
}
