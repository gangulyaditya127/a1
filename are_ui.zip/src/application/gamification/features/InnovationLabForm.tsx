import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/seperator";
import { useTranslation } from "react-i18next";
const formSchema = z.object({
  title: z.string().min(4).max(50),
  typeOfImprovement: z.string().min(4).max(50),
  expectedSavings: z.string().min(10).max(800),
  idea: z.string().min(10).max(400),
  benefits: z.string().min(10).max(400),
});

type improvementTypeList={
label:string;
value:string;
}[];

// const improvementTypeList: SelectOption[] = [
//   {
//     label: "Simplification",
//     value: "Simplification"
//   },
//   {
//     label: "Elimination",
//     value: "Elimination"
//   },
//   {
//     label: "Automation",
//     value: "Automation"
//   },
//   {
//     label: "Optimization",
//     value: "Optimization"
//   },
// ]
const InnovationLabForm = () => {
  const { t, ready } = useTranslation('/gamification/user/InnovationLabForm')
  if(!ready){
    return null;
  }
  const improvementTypeList = t("improvementTypeList", { returnObjects: true }) as improvementTypeList
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });
  useEffect(() => {
  }, [form]);

  function onSubmit() {
  }
  return (
    <>
      <h1 className="px-4 text-4xl text-muted-foreground mb-2">
      {t('title')}
        <Separator className="my-4" />
      </h1>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-4 px-4"
        >
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('id')}</FormLabel>
                <FormControl>
                  <Input
                    id={t('id')}
                    placeholder={t('Provide Title')}
                    {...field}
                  ></Input>
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
          <FormField
            control={form.control}
            name="typeOfImprovement"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('Improvement Type')}</FormLabel>
                <FormControl>
                  <SingleSelectCombobox optionList={improvementTypeList} setValue={field.onChange} value={field.value} placeholder={t('Select improvement type')} field={t('improvement type')} widthClass="w-full" placeholderClass="text-muted-forground fone-normal" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="expectedSavings"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('Expected Savings')}</FormLabel>
                <FormControl>
                  <Input
                    id={t('Expected Savings')}
                    placeholder={t('Provide Expected Savings')}
                    {...field}
                  ></Input>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="idea"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('Idea')}</FormLabel>
                <FormControl>
                  <Textarea
                    id="idea_and_guidelines"
                    placeholder={t('Outline the idea in details')}
                    {...field}
                  ></Textarea>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="benefits"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('Benefits/Savings')}</FormLabel>
                <FormControl>
                  <Textarea
                    id="benefits"
                    placeholder={t('Benefits/Savings')}
                    {...field}
                  ></Textarea>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="grid gap-4">
            {/* <Button variant="ghost">
              Discard
            </Button> */}
            <Button type="submit" className="bg-gradient-to-r from-purple-700 dark:from-purple-600 dark:to-purple-400 to-purple-500 text-white ">{t('submit')}</Button>
          </div>
        </form>
      </Form>
    </>
  );
};
export default InnovationLabForm;