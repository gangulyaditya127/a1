import { Separator } from "@/components/ui/seperator";
import { getNthDate } from "@/lib/date.utils";
import { cn } from "@/lib/tailwind.utils";

export default function GamificationWarRoomLog({ className }: { className?: string }) {
    return (
        <section className={cn("border w-full  max-h-screen rounded-xl py-6 flex flex-col justify-between ", className)}>
            <div className="grid gap-4">
                <Update content={`Sudhanshu Singh (2096742) joined the war room on 4:08PM IST, ${getNthDate(-4)}`} />
                <Update content={`Debashis Das (183642) joined the war room on 5:08PM IST, ${getNthDate(-3)}`} />
                <Update content={`Sumanta desai (2096742) joined the war room on 6:08PM IST, ${getNthDate(-3)}`} />
                <Update content={`Sudhanshu Singh (2096742) submitted for evaluation on 7:08PM IST, ${getNthDate(-1)}`} />
                <Update content={`Abhinav Kumar (2096742) joined the war room on 7:08PM IST, ${getNthDate(-1)}`} />
            </div>
        </section>
    )
}

const Update = ({
    content
}: { content: string }) => {
    return (
        <div className="flex-2 flex items-center gap-2 text-muted-foreground text-xs pl-8">
            {/* <Separator className="shrink" /> */}
            <p className="shrink-0">{content}</p>
            <Separator className="shrink" />
        </div>
    )
}

