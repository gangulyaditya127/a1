import { WobbleCard } from "@/components/ui/wobble-card";
import { IconNameProp } from "@/components/ui/icon";
import { Icon } from "@/components/ui/icon";
import { Link } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
type GamificationOfferingsCardProps = {
  className?: string;
  img: any;
  title: string;
  description: string;
  icon?: IconNameProp;
  coins?: number;
  route?: string;
  imageClassName?: string;
  desClassName?: string;
};
const GamificationOfferingsCard = ({
  img,
  title,
  description,
  icon,
  route,
  imageClassName,
  className,
  desClassName,
}: GamificationOfferingsCardProps) => {
  return (
    <Link to={route ? route : ""}>
      <WobbleCard
        containerClassName={cn(
          "rounded-xl h-[22rem] cursor-pointer relative overflow-hidden border border-[rgba(255,255,255,0.10)] dark:bg-[rgba(40,40,40,0.70)] bg-gray-100 shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset]",
          className,
        )}
        className="p-6 text-sm"
      >
        <div className="relative z-[2]">
          <div className="flex gap-1">
            {icon && (
              <Icon
                name={icon}
                className="relative z-[1] size-4 text-black dark:text-white"
              />
            )}
            <p className="font-medium">{title}</p>
          </div>
          <p className={cn("mt-1 text-neutral-400", desClassName)}>
            {description}
          </p>
        </div>
        <img
          src={img}
          alt=""
          className={cn("absolute bottom-0 z-[1] w-full", imageClassName)}
        />
        <div className="absolute bottom-1 left-[50%] h-10 w-1/2 -translate-x-[50%] rounded-2xl bg-purple-400 blur-xl"></div>
        <div className="absolute inset-0 backdrop-blur-[50px]"></div>
      </WobbleCard>
    </Link>
  );
};
export default GamificationOfferingsCard;
