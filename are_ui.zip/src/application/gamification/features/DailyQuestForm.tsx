import DatePicker from "@/components/ui/date-picker";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useTranslation } from "react-i18next";
const formSchema = z.object({
  offering: z.string(),
  startDate: z.date(),
  endDate: z.date(),
  extraPoints: z.coerce.number().min(100).max(1000),
});

type offering_list={
  label: string;
  value: string;
}[];

// const OFFERING_LIST: SelectOption[] = [
//   {
//     label: "Bucket Clearance",
//     value: "Bucket Clearance"
//   },
//   {
//     label: "Quality Quest",
//     value: "Quality Quest"
//   },
//   {
//     label: "Knowledge Sharer",
//     value: "Knowledge Sharer"
//   },
//   {
//     label: "Feedback Gatherer",
//     value: "Feedback Gatherer"
//   },
// ]
const DailyQuestForm = () => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });
  useEffect(() => {
  }, [form]);

  function onSubmit() {
  }
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDailyQuestConfig')
  if(!ready){
      return null;
  }
  const OFFERING_LIST = t("DailyQuestForm.offeringList", { returnObjects: true }) as offering_list
  return (
    <>
      <h1 className="px-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
        {t('DailyQuestForm.createNewDailyQuest')}
      </h1>

      <ScrollArea className="h-[50vh]">
        <Form {...form} >
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col gap-4 px-4 h-full"
          >
            <FormField
              control={form.control}
              name="offering"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('DailyQuestForm.questType')}</FormLabel>
                  <FormControl>
                    <SingleSelectCombobox optionList={OFFERING_LIST} setValue={field.onChange} value={field.value} placeholder={t('DailyQuestForm.selectQuestType')} field={t('DailyQuestForm.selectQuestType')} widthClass="w-full" placeholderClass="text-muted-forground fone-normal" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid w-full grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('DailyQuestForm.startDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('DailyQuestForm.pickAStartDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('DailyQuestForm.endDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('DailyQuestForm.pickAEndDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="extraPoints"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('DailyQuestForm.questPoints')}</FormLabel>
                  <FormControl>
                    <Input
                      id="prizePool"
                      placeholder={t('DailyQuestForm.enterPointsToBeAllocatedForTheQuest')}
                      value={+field.value}
                      onChange={field.onChange}
                      type="number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="mt-auto">{t('DailyQuestForm.submit')}</Button>
          </form>
        </Form>
      </ScrollArea>
    </>
  );
};
export default DailyQuestForm;
