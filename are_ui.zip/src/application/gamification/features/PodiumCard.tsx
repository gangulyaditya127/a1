import Podium from "./Podium";
import { buttonVariants } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { Link } from "react-router-dom";
import { WobbleCard } from "@/components/ui/wobble-card";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
const PodiumCard = ({
  className
}: {
  className: string
}) => {

  const { t, ready } = useTranslation('/gamification/common')

  if (!ready) {
    return <Skeleton className="h-60 rounded-xl">
    </Skeleton>
  }

  return (
    <WobbleCard
      containerClassName={cn("bg-gradient-to-br from-purple-700 dark:from-purple-600 dark:to-purple-400 to-purple-500 rounded-xl", className)}
      className="group/podium-card flex flex-col justify-center p-4 px-6 pb-6 text-white"
      showNoise={true}
    >
      <div className="flex items-center justify-between">
        <p className="text-lg font-medium">{t('leaderboard')}</p>
        <Link
          className={cn(
            buttonVariants({
              variant: "link",
              className: "font-baseline flex gap-1 p-0 text-xs text-white",
            }),
          )}
          to="/gamification/leaderboard"
        >
          <span>{t('viewAll')}</span>
          <Icon name="move-right" className="w-4"></Icon>
        </Link>
      </div>
      <Tabs defaultValue="Global" className="">
        <TabsContent value="Global">
          <div className="pb-6">
            <Podium rankList={[
              {
                name: "Sudhanshu Singh",
                rank: 1
              },
              {
                name: "Abhinav Jha",
                rank: 2
              },
              {
                name: "Shushant Mohan",
                rank: 3
              }
            ]} />
          </div>
        </TabsContent>
        <TabsContent value="Team">
          <div className="pb-6">
            <Podium rankList={[
              {
                name: "Sumanta Desayi",
                rank: 1
              },
              {
                name: "Debashis Das",
                rank: 2
              },
              {
                name: "Mohit Jha",
                rank: 3
              }
            ]} />
          </div>
        </TabsContent>
        <TabsList className="mx-auto grid max-w-64 grid-cols-2 rounded-2xl dark:bg-violet-900/50 text-xs font-normal">
          <TabsTrigger
            value="Global"
            className="rounded-2xl font-normal text-white data-[state=active]:bg-purple-400 data-[state=active]:text-black data-[state=active]:font-medium"
          >
            {t('global')}
          </TabsTrigger>
          <TabsTrigger
            value="Team"
            className="rounded-2xl font-normal text-white data-[state=active]:bg-purple-400 data-[state=active]:text-black data-[state=active]:font-medium"
          >
            {t('team')}
          </TabsTrigger>
        </TabsList>

      </Tabs>

    </WobbleCard>
  );
};
export default PodiumCard;
//  bg-gradient-to-br from-purple-700 dark:from-purple-600 dark:to-purple-400 to-purple-500
