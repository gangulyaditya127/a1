import { Icon } from "@/components/ui/icon"
import NumberTicker from "@/components/ui/number-ticker"
import { Separator } from "@/components/ui/seperator"
import { useTranslation } from "react-i18next";

const AdminMetricsSummary = () => {
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
  if(!ready){
      return null;
  }
  return (
    <div className="dark:purple-600 rounded-xl bg-purple-700 text-white">
      <div className="flex justify-between px-8 py-14">
        <div className="flex flex-col">
          <p className="text-xs font-medium uppercase tracking-wider">
            {t('AdminMetricsSummary.totalTicketsResolved')} 
          </p>
          <p className="flex items-baseline gap-1">
            <span className="text-4xl font-medium">
              <NumberTicker className="text-white" value={864} />
            </span>
          </p>
          <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
            <p className="">
              <span>
                <NumberTicker className="text-white" value={8} />
              </span>
              <span className="text-xs">%</span>
            </p>
            <Icon name="arrow-down-right" className="size-4" />
            <p>{t('AdminMetricsSummary.thisMonthRunningMonthlyAvg')}</p>
          </div>
        </div>
        <Separator
          orientation="vertical"
          className="h-[5.2rem] bg-white/30"
        />
        <div className="flex flex-col">
          <p className="text-xs font-medium uppercase tracking-wider">
            {t('AdminMetricsSummary.avgTicketResolutionTime')}
          </p>
          <p className="flex items-baseline gap-1">
            <span className="text-4xl font-medium">
              <NumberTicker className="text-white" value={30} />
            </span>
            <span className="text-purple-200">{t('AdminMetricsSummary.minutes')}</span>
          </p>
          
        </div>
        <Separator
          orientation="vertical"
          className="h-[5.2rem] bg-white/30"
        />
        <div className="flex flex-col">
          <p className="text-xs font-medium uppercase tracking-wider">
            {t('AdminMetricsSummary.trainingCompletionRate')}
          </p>
          <p className="flex items-baseline gap-1">
            <span className="text-4xl font-medium">
              <NumberTicker className="text-white" value={87} />
            </span>
            <span className="text-purple-200">%</span>
          </p>
          <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
            <p className="">
              <span>
                <NumberTicker className="text-white" value={2} />
              </span>
              <span className="text-xs">%</span>
            </p>
            <Icon name="arrow-up-right" className="size-4" />
            <p>{t('AdminMetricsSummary.thisMonth')}</p>
          </div>
        </div>
        <Separator
          orientation="vertical"
          className="h-[5.2rem] bg-white/30"
        />
        
        <div className="flex flex-col">
          <p className="text-xs font-medium uppercase tracking-wider">
            {t('AdminMetricsSummary.activeWarRoomCount')}
          </p>
          <p className="flex items-baseline gap-1">
            <span className="text-4xl font-medium">
              <NumberTicker className="text-white" value={6} />
            </span>
          </p>
        </div>
      </div>
    </div>
  )
}
export default AdminMetricsSummary