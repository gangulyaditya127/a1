import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/seperator"
import { useTranslation } from "react-i18next";

export default function GamificationWarRoomParticipantsChart() {
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminWar')
  if(!ready){
      return null;
  }
  return (
    <Card className="flex flex-col rounded-xl h-fit">
      <CardHeader className="items-center pb-0">
        <CardTitle>{t('GamificationWarRoomParticipantsChart.warRoomStats')}</CardTitle>
        <CardDescription className="text-center">{t('GamificationWarRoomParticipantsChart.showsFewStasticalDataForTheWarRoom')}</CardDescription>
      </CardHeader>
      <CardContent className="flex gap-6 mt-4 flex-wrap">
        <div className="">
          <div className="text-4xl font-bold">70</div>
          <div className="text-muted-foreground text-xs">{t('GamificationWarRoomParticipantsChart.participants')}</div>
        </div>
        <div className="">
          <div className="text-4xl font-bold">10</div>
          <div className="text-muted-foreground text-xs">{t('GamificationWarRoomParticipantsChart.submissions')}</div>
        </div>
        
        <div className="text-muted-foreground w-full">
          <h5 className="text-xs uppercase tracking-wider">{t('GamificationWarRoomParticipantsChart.participants')}</h5>
          <Separator/>
          <div className="flex gap-2 mt-4 flex-wrap items-center">
            {
              new Array("AK","SK","AU","PK","JK","FZ","FA","KS","LV").map((el)=>(
                <Avatar>
                  <AvatarFallback>{el}</AvatarFallback>
                </Avatar>
              ))
            }
            <p>+61</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
