import DatePicker from "@/components/ui/date-picker";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useTranslation } from "react-i18next";
const formSchema = z.object({
  title: z.string().min(4).max(50),
  description: z.string().min(10).max(800),
  offering: z.string(),
  startDate: z.date(),
  endDate: z.date(),
  extraPoints: z.coerce.number().min(100).max(1000),
});

type offering_list={
  label: string;
  value: string;
}[];


// const OFFERING_LIST: SelectOption[] = [
//   {
//     label: "War Room",
//     value: "WarRoom"
//   },
//   {
//     label: "Innovation Lab",
//     value: "InnovationLab"
//   },
//   {
//     label: "Learning Odysyss",
//     value: "LearningOdysyss"
//   },
// ]
const PerformanceBoosterForm = () => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });
  useEffect(() => {
  }, [form]);

  function onSubmit() {
  }
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminPerformanceBoosterConfig')
  if(!ready){
      return null;
  }
  const OFFERING_LIST = t("PerformaceBoosterForm.offeringList", { returnObjects: true }) as offering_list
  return (
    <>
      <h1 className="px-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
        Create New Performance Booster
      </h1>

      <ScrollArea className="h-[75vh]">
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col gap-4 px-4"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('PerformaceBoosterForm.title')}</FormLabel>
                  <FormControl>
                    <Input
                      id="war_room_name"
                      placeholder={t('PerformaceBoosterForm.enterTheTitleForThePerformaceBooster')}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="offering"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('PerformaceBoosterForm.offering')}</FormLabel>
                  <FormControl>
                    <SingleSelectCombobox optionList={OFFERING_LIST} setValue={field.onChange} value={field.value} placeholder={t('PerformaceBoosterForm.selectOffering')} field={t('PerformaceBoosterForm.selectOffering')} widthClass="w-full" placeholderClass="text-muted-forground fone-normal" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('PerformaceBoosterForm.description')}</FormLabel>
                  <FormControl>
                    <Textarea
                      id="description"
                      placeholder={t('PerformaceBoosterForm.provideADetailedDescriptionOfThePerformaceBooster')}
                      {...field}
                    ></Textarea>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid w-full grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('PerformaceBoosterForm.startDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('PerformaceBoosterForm.pickAStartDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>{t('PerformaceBoosterForm.endDate')}</FormLabel>
                    <DatePicker
                      placeholder={t('PerformaceBoosterForm.pickAEndDate')}
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="extraPoints"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('PerformaceBoosterForm.extraPoints')}</FormLabel>
                  <FormControl>
                    <Input
                      id="prizePool"
                      placeholder={t('PerformaceBoosterForm.enterExtraPointsToBeAllocated')}
                      value={+field.value}
                      onChange={field.onChange}
                      type="number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit">{t('PerformaceBoosterForm.submit')}</Button>
          </form>
        </Form>
      </ScrollArea>
    </>
  );
};
export default PerformanceBoosterForm;
