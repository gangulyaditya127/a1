import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/tailwind.utils";
import { Icon } from "@/components/ui/icon";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card"
const Podium = ({
  className,
  rankList
}: {
  className?: string;
  rankList: {
    name: string,
    rank: number
  }[]
}) => {
  return (
    <div className={(cn("flex justify-center", className))}>
      <HoverCard>
        <HoverCardTrigger asChild>
          <div className="flex flex-col items-center gap-2">
            <div className="mt-auto ">
              <div className="relative">
                <div className="grid place-items-center gap-1">
                  <Icon name="crown" className="h-4 w-4 fill-white" />
                  <Avatar className="">
                    <AvatarFallback className="uppercase bg-black/20  font-semibold text-white text-md border border-white border-4">{rankList?.[1]?.name?.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -bottom-3 -left-3 text-7xl font-bold -z-[1] opacity-40">2</div>
              </div>
            </div>
            <div className="w-20 h-12 bg-gradient-to-t from-transparent to-neutral-100 rounded"></div>
          </div>
        </HoverCardTrigger>
        <HoverCardContent className="w-50 z-[10]">
          <UserDetails name={rankList[1]?.name} rank={rankList[1]?.rank} />
        </HoverCardContent>
      </HoverCard>
      <HoverCard>
        <HoverCardTrigger asChild>
          <div className="flex flex-col items-center gap-2">
            <div className="mt-auto ">
              <div className="relative">
                <div className="grid place-items-center gap-1">
                  <Icon name="crown" className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <Avatar className="">
                    <AvatarFallback className="uppercase bg-black/20  font-semibold text-md border border-yellow-400 border-4 text-yellow-200">{rankList?.[0]?.name?.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -bottom-3 -left-1 text-7xl font-bold -z-[1] opacity-40">1</div>
              </div>
              <div className="w-20 h-16 bg-gradient-to-t from-transparent to-neutral-100 rounded z-[1]"></div>
            </div>
          </div>
        </HoverCardTrigger>
        <HoverCardContent className="w-50 z-[10]">
          <UserDetails name={rankList[0]?.name} rank={rankList[0]?.rank} />
        </HoverCardContent>
      </HoverCard>
      <HoverCard>
        <HoverCardTrigger asChild>
          <div className="flex flex-col items-center gap-2">
            <div className="mt-auto ">
              <div className="relative">
                <div className="grid place-items-center gap-1">
                  <Icon name="crown" className="h-4 w-4 fill-white fill-white" />
                  <Avatar className="">
                    <AvatarFallback className="uppercase bg-black/20  font-semibold text-md border border-white border-4 text-white">{rankList?.[2]?.name?.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -bottom-3 right-4 text-7xl font-bold -z-[1] opacity-40">3</div>
              </div>
            </div>
            <div className="w-20 h-8 bg-gradient-to-t from-transparent to-neutral-100 rounded"></div>
          </div>
        </HoverCardTrigger>
        <HoverCardContent className="w-50 z-[10]">
          <UserDetails name={rankList[2]?.name} rank={rankList[2]?.rank} />
        </HoverCardContent>
      </HoverCard>



    </div>
  );
};

export default Podium;
function UserDetails({
  name,
  rank
}: {
  name: string;
  rank: number
}) {
  return (
    <div className="flex justify-between space-x-4 z-[10]">
      <div className="space-y-1">
        <h4 className="text-sm font-semibold">{name}</h4>
        <p className="text-sm">
          Rank - {rank}
        </p>
      </div>
    </div>
  )
}

{/* <HoverCard>
  <HoverCardTrigger asChild>
    <Button variant="link">@nextjs</Button>
  </HoverCardTrigger>
  <HoverCardContent className="w-50">

  </HoverCardContent>
</HoverCard> */}