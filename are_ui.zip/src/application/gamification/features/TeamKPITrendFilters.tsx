import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";

import { updateGamificationTeamKPITrendFilterDuration, updateGamificationTeamKPITrendFilterKPI } from "../slice/GamificationAdminSlice";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";

type Option = {
    value: string;
    label: string;
};

export const kpiList: Option[] = [
    {
        value: "ticket",
        label: "Ticket Resolution Count"
    },
    {
        value: "points",
        label: "Total Team Points"
    },
    {
        value: "training",
        label: "Training Completion Rate"
    },
]

export const durationList: Option[] = [
    {
        value: "30",
        label: "Last 30 days"
    },
    {
        value: "90",
        label: "Last 3 Months"
    },
    {
        value: "180",
        label: "Last 6 Months"
    },
]

const TeamKPITrendFilters = () => {
    const kpi = useAppSelector((state) => state.gamificationAdmin.gamificationTeamKPITrendFilterData.kpi);
    const duration = useAppSelector((state) => state.gamificationAdmin.gamificationTeamKPITrendFilterData.duration);


    const dispatch = useAppDispatch();
    const setKPIs = (kpi: string) => {
        dispatch(updateGamificationTeamKPITrendFilterKPI(kpi))
    }
    const setDuration = (duration: string) => {
        dispatch(updateGamificationTeamKPITrendFilterDuration(duration))
    }

    return (
        <div className="flex items-center">
            <div className="flex gap-6">
                <div className="flex flex-col gap-2">
                    {/* <Label className="text-xs text-muted-foreground">KPI</Label> */}
                    <SingleSelectCombobox
                        value={kpi}
                        optionList={kpiList}
                        placeholder="Select KPIs"
                        setValue={setKPIs}
                        field="kpi"
                    />
                </div>
                <div className="flex flex-col gap-2">
                    {/* <Label className="text-xs text-muted-foreground">Duration</Label> */}
                    <SingleSelectCombobox
                        value={duration}
                        optionList={durationList}
                        placeholder="Select Teams"
                        setValue={setDuration}
                        field="duration"
                    />
                </div>
            </div>
        </div>
    );
};

export default TeamKPITrendFilters;
