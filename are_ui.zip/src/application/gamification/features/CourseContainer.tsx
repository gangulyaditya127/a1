import CourseCard from "./CourseCard";
import { useTranslation } from "react-i18next";
// import { Icon, IconNameProp } from "@/components/ui/icon";
import {IconNameProp } from "@/components/ui/icon";
type CourseList={
  key:number;
  name:string;
  description:string;
  icon:IconNameProp;
  route:string;
}[];

const CourseContainer = () => {
  const { t, ready } = useTranslation('/gamification/user/learning')
  if(!ready){
    return null;
  }
  
  const COURSE_LIST = t("courseList", { returnObjects: true }) as CourseList
  return (
    <div className="pb-12">
      <h1 className="mt-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
      {t('courses')}
      </h1>
      <div className="mt-4 grid grid-cols-3 gap-6">
        {COURSE_LIST.map((el, i) => (
          <CourseCard
            key={i}
            name={el.name}
            description={el.description}
            icon={el.icon}
            route={el.route}
          />
        ))}
      </div>
    </div>
  );
};
export default CourseContainer;
