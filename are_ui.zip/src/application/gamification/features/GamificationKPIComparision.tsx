import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useEffect, useState } from "react";
import GamificationKPIComparisionFilter from "./GamificationKPIComparisionFilter";
import { useAppSelector } from "@/lib/redux/hooks";
import EChartsReact from "echarts-for-react";
import colors from "tailwindcss/colors";
import { useTranslation } from "react-i18next";

type Option = {
  value: string;
  label: string;
};
const kpiList: Option[] = [
  {
    value: "WarRoom",
    label: "War Room"
  },
  {
    value: "InnovationLab",
    label: "Innovation Lab"
  },
  {
    value: "LearningOdysyss",
    label: "Learning Odysyss"
  },
]

const generateMockChartData = (kpis: string[], teams: string[]) => {
  let high = 100, low = 40
  return kpis.map((kpi: String) => {
    let res: any = {};
    let kpiVal = kpiList.filter(el => el.value == kpi)?.[0]?.label ?? kpi
    res["kpi"] = kpiVal
    teams.forEach(el => {
      res[el] = Math.floor(Math.random() * (high - low + 1)) + low;
    })

    return res;
  })

};
export default function GamificationKPIComparision() {

  const kpi = useAppSelector((state) => state.gamificationAdmin.gamificationKPIComparisionFilterData.kpi);
  const team = useAppSelector((state) => state.gamificationAdmin.gamificationKPIComparisionFilterData.team);
  const [isChartValsNull, setIsChartValsNull] = useState(true)
  const [chartOptions, setChartOptions] = useState<any>(
    {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        backgroundColor:colors.neutral[950],
        textStyle:{
          color:colors.neutral[400],
          fontFamily:'inherit',
          fontSize:12,
        },
        borderColor:colors.neutral[800]
      },
      color: [
        colors.blue[600],
        colors.green[600],
        colors.amber[600],
        colors.purple[600],
        colors.pink[500],
        colors.lime[500]
      ],
      legend: {
        show: true,
        type: 'scroll',
        textStyle: {
          color: colors.neutral[400]
        },
        // bottom:0
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '10%',
        top: '10%'
      },
      toolbox: {
        show: false,
        orient: 'vertical',
        left: 'right',
        top: 'center',
        feature: {
          saveAsImage: { show: true }
        }
      },
      xAxis: [
        {
          type: 'category',
          axisTick: { show: false },
          axisLine: {
            show: false,
          },
        }
      ],
      yAxis: {
        axisLabel: {
          show: false
        },
        axisLine: {
          show: false,
        },
        splitLine: {
          show: false,
        },
      },
      media: [{
        query: {
          minHeight: 100
        }
      }],
      series: [
      ]
    }
  )
  useEffect(() => {
    if (kpi?.length && team?.length) {
      let data = generateMockChartData(kpi, team)
      let series = [];
      for (let i = 0; i < Object.keys(data?.[0]).length - 1; i++) {
        series.push({
          type: 'bar',
          itemStyle: {
            borderRadius: 5,
            borderWidth: 4,
            borderColor: "transparent",
            borderJoin: "round",
          },
        })
      }
      setIsChartValsNull(false)
      setChartOptions((prev: any) => ({
        ...prev,
        dataset: {
          dimensions: Object.keys(data?.[0]),
          source: data
        },
        series
      }))
    } else {
      setChartOptions((prev: any) => {
        return ({
          ...prev,
          series: []
        })
      })
      setIsChartValsNull(true)
    }
  }, [kpi, team])
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminDashboard')
  if(!ready){
      return null;
  }
  return (
    <Card className="rounded-xl">
      <CardHeader className="flex flex-col items-stretch space-y-0 border-b p-0 sm:flex-row">
        <div className="flex flex-1 flex-col justify-center gap-1 px-6 py-5 sm:py-6">
          <CardTitle className="text-xl">{t('GamificationKPIComparision.gamificationKPIscomparisionacrossTeams')}</CardTitle>
          <CardDescription>{t('GamificationKPIComparision.showingKPIscomparisionforthelast3months')}</CardDescription>
        </div>
      </CardHeader>
      <div className="border-b space-y-1.5 p-6">
        {<GamificationKPIComparisionFilter />}
      </div>
      <CardContent className="py-6">
        {!isChartValsNull && <EChartsReact option={chartOptions} className="mt-auto" notMerge={true} />}
      </CardContent>
    </Card>
  );
}
