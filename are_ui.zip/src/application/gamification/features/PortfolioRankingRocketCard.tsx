import EChartsReact from "echarts-for-react";
import { useState } from "react";
import * as echarts from "echarts";
const pathSymbols = {
  rocket:
    "path://M11.41,2.87c0.35-0.26,0.82-0.26,1.18,0C13.81,3.75,16.5,6.46,16.5,13c0,2.16-0.78,4.76-1.36,6.35 C15,19.74,14.63,20,14.21,20l-4.41,0c-0.42,0-0.8-0.26-0.94-0.65C8.28,17.76,7.5,15.16,7.5,13C7.5,6.46,10.19,3.75,11.41,2.87z M14,11c0-1.1-0.9-2-2-2s-2,0.9-2,2s0.9,2,2,2S14,12.1,14,11z M7.69,20.52c-0.48-1.23-1.52-4.17-1.67-6.87l-1.13,0.75 C4.33,14.78,4,15.4,4,16.07v4.45c0,0.71,0.71,1.19,1.37,0.93L7.69,20.52z M20,20.52v-4.45c0-0.67-0.33-1.29-0.89-1.66l-1.13-0.75 c-0.15,2.69-1.2,5.64-1.67,6.87l2.32,0.93C19.29,21.71,20,21.23,20,20.52z",
};
import { cn } from "@/lib/tailwind.utils";
// import SpaceStars from "@/application/ismart/features/SpaceStars";
const PortfolioRankingRocketCard = ({ className }: { className?: string }) => {
  const [option] = useState({
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "none",
      },
      formatter: function (params: any) {
        let { name } = params[0];
        switch (name) {
          case "WM":
            name = "Wealth Management - Rank 1";
            break;
          case "RB":
            name = "Retail Banking - Rank 3";
            break;
          case "CB":
            name = "Corporate Banking- Rank 2";
            break;
        }
        return name;
      },
    },
    grid: {
      left: "10%",
      right: "10%",
      bottom: "0%",
      containLabel: true,
    },
    xAxis: {
      data: ["WM", "RB", "CB"],
      axisTick: { show: false },
      axisLine: { show: false },
      axisLabel: {
        color: "#e5e5e5",
      },
    },
    yAxis: {
      splitLine: { show: false },
      axisTick: { show: false },
      axisLine: { show: false },
      axisLabel: { show: false },
    },
    color: ["#fff"],
    series: [
      {
        name: "hill",
        type: "pictorialBar",
        barCategoryGap: "-130%",
        // symbol: 'path://M0,10 L10,10 L5,0 L0,10 z',
        symbol: "path://M0,10 L10,10 C5.5,10 5.5,5 5,0 C4.5,5 4.5,10 0,10 z",
        itemStyle: {
          opacity: 0.5,
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            {
              offset: 1,
              color: "#ffffff00",
            },
            {
              offset: 0,
              color: "#fff",
            },
          ]),
        },
        emphasis: {
          itemStyle: {
            opacity: 1,
          },
        },
        data: [123, 60, 80],
        z: 10,
      },
      {
        name: "glyph",
        type: "pictorialBar",
        barGap: "-100%",
        symbolPosition: "end",
        symbolSize: 50,
        symbolOffset: [0, "-120%"],
        data: [
          {
            value: 123,
            symbol: pathSymbols.rocket,
            symbolSize: [20, 30],
            itemStyle: {
              color: "#fff",
            },
          },
          {
            value: 60,
            symbol: pathSymbols.rocket,
            symbolSize: [20, 30],
            itemStyle: {
              color: "#fff",
            },
          },
          {
            value: 80,
            symbol: pathSymbols.rocket,
            symbolSize: [20, 30],
            itemStyle: {
              color: "#fff",
            },
          },
        ],
      },
    ],
  });
  return (
    <div
      className={cn(
        "relative flex flex-col rounded-xl border border-[rgba(255,255,255,0.10)] bg-secondary/80 p-6 shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] dark:bg-[rgba(40,40,40,0.70)]",
        className,
      )}
    >
      <EChartsReact option={option} className="mt-auto" />
      {/* <SpaceStars/> */}
    </div>
  );
};
export default PortfolioRankingRocketCard;
