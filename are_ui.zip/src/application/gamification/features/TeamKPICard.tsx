import { cn } from "@/lib/tailwind.utils";
import ReactEcharts, { EChartsOption } from "echarts-for-react";
import { useState } from "react";
import colors from "tailwindcss/colors";
const TeamKPICard = ({ className }: { className?: string }) => {
  const [option] = useState<EChartsOption>({
    tooltip: {
      trigger: "axis",
    },
    radar: {
      // shape: 'circle',
      indicator: [
        { name: "Training", max: 6500 },
        { name: "SLA", max: 30000 },
        { name: "Automation", max: 32000 },
        { name: "MTP R.", max: 38000 },
      ],
    },
    textStyle: {
      fontFamily: `ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"`,
    },
    series: [
      {
        type: "radar",
        tooltip: {
          trigger: "item",
        },
        data: [
          {
            value: [4200, 30000, 20000, 35000],
            name: "Team KPI Performance",
          },
        ],
        itemStyle: {
          color: colors.purple[600],
        },
        areaStyle: {
          color: colors.purple[500],
        },
      },
    ],
  });
  return (
    <div
      className={cn(
        "rounded-xl border border-[rgba(255,255,255,0.10)] bg-gray-100 p-6 shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] dark:bg-[rgba(40,40,40,0.70)]",
        className,
      )}
    >
      <ReactEcharts option={option} className="mt-4" />
    </div>
  );
};
export default TeamKPICard;
