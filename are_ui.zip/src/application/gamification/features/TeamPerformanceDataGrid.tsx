import {
  useMemo,
  useState,
} from "react";
import {
  ColDef,
  IDetailCellRendererParams,
} from "ag-grid-community";
import { TEAM_PERFORMACE_DATA } from "../data/team-performace-data-grid-dump";
import DataGrid from "@/components/ui/data-grid";
export type ICallRecord = {
  name: string;
  points: number;
  teamRank: number;
  globalRank: number;
  ticketCount: number;
  employeeID: string;
}

export type IAccount = {
  teamname: string;
  points: number;
  rank: number;
  ticketCount: number;
  suborinates: ICallRecord[];
}

const TeamPerformanceDataGrid = () => {
  const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
  const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
  const [rowData] = useState<IAccount[]>(TEAM_PERFORMACE_DATA);
  const [columnDefs] = useState<ColDef[]>([
    // group cell renderer needed for expand / collapse icons
    { field: "teamname", cellRenderer: "agGroupCellRenderer", sortable: false },
    { field: "points" },
    { field: "rank" },
    { field: "ticketCount" },
  ]);
  const defaultColDef = useMemo<ColDef>(() => {
    return {
      flex: 1,
    };
  }, []);
  const detailCellRendererParams = useMemo(() => {
    return {
      detailGridOptions: {
        columnDefs: [
          { field: "name" },
          // { field: "employeeID", minWidth: 150 },
          { field: "points" },
          { field: "teamRank", minWidth: 150 },
          { field: "globalRank", },
          { field: "ticketCount", minWidth: 150 },
        ],
        defaultColDef: {
          flex: 1,
        },
      },
      getDetailRowData: (params) => {
        params.successCallback(params.data.suborinates);
      },
    } as IDetailCellRendererParams<IAccount, ICallRecord>;
  }, []);
  return (
    <div style={containerStyle}>
      <div
        style={gridStyle}
      >
        <DataGrid
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          masterDetail={true}
          detailCellRendererParams={detailCellRendererParams}
        // onFirstDataRendered={onFirstDataRendered}
        />
      </div>
    </div>
  );
}
export default TeamPerformanceDataGrid