import EChartsReact from "echarts-for-react";
import { useState } from "react";

import colors from "tailwindcss/colors";

const GamificationKPIPeerComparision = () => {
    const [chartOptions] = useState<any>({
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            },
            backgroundColor: colors.neutral[950],
            textStyle: {
                color: colors.neutral[400],
                fontFamily: 'inherit',
                fontSize: 12,
            },
            borderColor: colors.neutral[800]
        },
        color: [
            colors.blue[600],
            colors.green[600],
            colors.amber[600],
            colors.purple[600],
            colors.pink[500],
            colors.lime[500]
        ],
        legend: {
            show: true,
            type: 'scroll',
            textStyle: {
                color: colors.neutral[400]
            },
            // bottom:0
        },
        grid: {
            left: '0%',
            right: '0%',
            bottom: '10%',
            top: '10%'
        },
        toolbox: {
            show: false,
            orient: 'vertical',
            left: 'right',
            top: 'center',
            feature: {
                saveAsImage: { show: true }
            }
        },
        xAxis: [
            {
                type: 'category',
                axisTick: { show: false },
                axisLine: {
                    show: false,
                },
            }
        ],
        yAxis: {
            axisLabel: {
                show: false
            },
            axisLine: {
                show: false,
            },
            splitLine: {
                show: false,
            },
        },
        media: [{
            query: {
                minHeight: 100
            }
        }],
        dataset: {
            dimensions: [
                "kpi",
                "CitiKYC",
                "Finance",
                "Genesis",
                "HR",
                "Compliance",
                "Risk"
            ],
            source: [
                {
                    "kpi": "War Room",
                    "CitiKYC": 63,
                    "Finance": 56,
                    "Genesis": 87,
                    "HR": 57,
                    "Compliance": 68,
                    "Risk": 56
                },
                {
                    "kpi": "Innovation Lab",
                    "CitiKYC": 81,
                    "Finance": 91,
                    "Genesis": 100,
                    "HR": 54,
                    "Compliance": 65,
                    "Risk": 75
                },
                {
                    "kpi": "Learning Odysyss",
                    "CitiKYC": 58,
                    "Finance": 76,
                    "Genesis": 59,
                    "HR": 54,
                    "Compliance": 91,
                    "Risk": 65
                }
            ]
        },
        series:[
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            },
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            },
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            },
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            },
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            },
            {
                "type": "bar",
                "itemStyle": {
                    "borderRadius": 5,
                    "borderWidth": 4,
                    "borderColor": "transparent",
                    "borderJoin": "round"
                }
            }
        ]
    })
    return (
        <div className="">
            <h1 className="text-sm tracking-wider mb-4 text-muted-foreground uppercase">Comarision with peer teams</h1>
            <EChartsReact option={chartOptions} className="mt-auto" notMerge={true} />
        </div>
    )
}
export default GamificationKPIPeerComparision;