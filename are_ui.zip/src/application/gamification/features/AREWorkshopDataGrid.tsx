import DataGrid from "@/components/ui/data-grid";
import { useMemo, useState } from "react";
import { ARE_WORKSHOP_DATA } from "../data/are-gamification-workshop.data";
import { ColDef } from "ag-grid-charts-enterprise";

const AREWorkshopDataGrid = () => {
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);

    const [rowData] = useState(() => {
        const updatedTeams = ARE_WORKSHOP_DATA.teams.map((team: any) => {
            const total = [
                team.round_1,
                team.round_2,
                team.round_3,
                team.round_4,
                team.round_5,
                team.round_6,
                team.round_7,
                team.round_8,
                team.round_9,
                team.round_10,
            ].reduce((acc, value) => (acc ?? 0) + (value ?? 0), 0);
            return { ...team, total };
        });
        updatedTeams.sort((a: any, b: any) => b.total - a.total);
        let currentRank = 0;
        let teamsProcessed = 0;

        for (let i = 0; i < updatedTeams.length; i++) {
            if (i === 0 || updatedTeams[i].total !== updatedTeams[i - 1].total) {
                currentRank += 1;
            }
            updatedTeams[i].rank = currentRank;
            teamsProcessed++;
            if (i < updatedTeams.length - 1 && updatedTeams[i].total === updatedTeams[i + 1].total) {
                continue;
            }
        }
        return updatedTeams;
    });

    const columnDefs = [
        { field: 'team_name', headerName: 'Team Name', sortable: true, cellRenderer: "agGroupCellRenderer" },
        {
            field: 'rank',
            headerName: 'Rank',
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'total',
            headerName: 'Total',
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },

        {
            field: 'round_1',
            headerName: 'Round 1',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_2',
            headerName: 'Round 2',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_3',
            headerName: 'Round 3',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_4',
            headerName: 'Round 4',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_5',
            headerName: 'Round 5',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_6',
            headerName: 'Round 6',
            hide: false,
            headerTooltip: "Ideas submission (points= #of ideas * 3)",
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_7',
            headerName: 'Round 7',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_8',
            headerName: 'Round 8',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_9',
            headerName: 'Round 9',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },
        {
            field: 'round_10',
            headerName: 'Round 10',
            hide: false,
            valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
        },

    ];

    const detailCellRendererParams = useMemo(() => {
        return {
            detailGridOptions: {
                columnDefs: [
                    { field: 'name', headerName: 'Name', sortable: true, filter: true },
                    { field: 'id', headerName: 'ID', sortable: true, filter: true },
                    {
                        field: 'email',
                        headerName: 'Email',
                        sortable: true,
                        filter: true,
                        valueFormatter: (params: any) => (params.value === null || params.value === undefined ? 'NA' : params.value),
                    },
                    { field: 'location', headerName: 'Location', sortable: true, filter: true },
                ],
                defaultColDef: {
                    flex: 1,
                },
            },
            getDetailRowData: (params: any) => {
                params.successCallback(params.data.members);
            },
        };
    }, []);

    return (
        <div style={{ height: '600px', width: '100%' }}>
            <div className="ag-theme-alpine" style={{ height: '100%', width: '100%' }}>
                <DataGrid
                    rowData={rowData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    masterDetail={true}
                    detailCellRendererParams={detailCellRendererParams}
                />
            </div>
        </div>
    );
};

export default AREWorkshopDataGrid;