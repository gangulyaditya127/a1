
import { Bar, BarChart, LabelList, XAxis, YAxis } from "recharts"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ChartContainer } from "@/components/ui/chart"
import { Separator } from "@/components/ui/seperator"
import { useTranslation } from "react-i18next";
export default function UserPersonalStats() {
  const { t, ready } = useTranslation('/gamification/user/Profile')
  if(!ready){
      return null;
  }
  return (
    <Card className="rounded-xl col-span-2">
      <CardContent className="flex gap-4 p-4 pb-2">
        <ChartContainer
          config={{
            move: {
              label: "Move",
            },
            stand: {
              label: "Stand",
            },
            exercise: {
              label: "Exercise",
            },
          }}
          className="h-[150px] w-full"
        >
          <BarChart
            margin={{
              left: 10,
              right: 0,
              top: 0,
              bottom: 10,
            }}
            data={[
              {
                activity: "Learning Odysyss",
                value: (4/16) * 100,
                label: "4/16",
                fill: "hsl(var(--chart-2))",
              },
              {
                activity: "War Room",
                value: (1 / 2) * 100,
                label: "1/2",
                fill: "hsl(var(--chart-1))",
              },
              {
                activity: "Innovation Lab",
                value: (4 / 6) * 100,
                label: "4/6",
                fill: "hsl(var(--chart-5))",
              },
            ]}
            layout="vertical"
            barSize={32}
            barGap={2}
          >
            <XAxis type="number" dataKey="value" hide />
            <YAxis
              dataKey="activity"
              type="category"
              tickLine={false}
              tickMargin={4}
              axisLine={false}
              className="capitalize"
            />
            <Bar dataKey="value" radius={5}>
              <LabelList
                position="insideLeft"
                dataKey="label"
                fill="white"
                offset={8}
                fontSize={12}
              />
            </Bar>
          </BarChart>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex flex-row border-t p-4">
        <div className="flex w-full items-center gap-2">
          <div className="grid flex-1 auto-rows-min gap-0.5">
            <div className="text-xs text-muted-foreground">{t('Learning Odysyss')}</div>
            <div className="flex items-baseline gap-1 text-2xl font-bold tabular-nums leading-none">
              4 <span className="text-sm font-normal text-muted-foreground">
              /16
              </span>
            </div>
          </div>
          <Separator orientation="vertical" className="mx-2 h-10 w-px" />
          <div className="grid flex-1 auto-rows-min gap-0.5">
            <div className="text-xs text-muted-foreground">{t('War Room')}</div>
            <div className="flex items-baseline gap-1 text-2xl font-bold tabular-nums leading-none">
              1
              <span className="text-sm font-normal text-muted-foreground">
              /2
              </span>
            </div>
          </div>
          <Separator orientation="vertical" className="mx-2 h-10 w-px" />
          <div className="grid flex-1 auto-rows-min gap-0.5">
            <div className="text-xs text-muted-foreground">{t('Innovation Lab')}</div>
            <div className="flex items-baseline gap-1 text-2xl font-bold tabular-nums leading-none">
               4
              <span className="text-sm font-normal text-muted-foreground">
                /16
              </span>
            </div>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
