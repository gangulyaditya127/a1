import { Icon } from "@/components/ui/icon";
import { Progress } from "@/components/ui/progress";
import dynamicIconImports from "lucide-react/dynamicIconImports";
import { Link } from "react-router-dom";
import COIN_ICO from '@/assets/3D illus/coin.png'
type TaskFeatureCardProps = {
  title: string;
  desc?: string;
  iconName: keyof typeof dynamicIconImports;
  route?: string;
  points?:number
};
const TaskFeatureCard = ({
  title,
  desc,
  iconName,
  route,
  points
}: TaskFeatureCardProps) => {
  return (
    <Link
      to={route ?? ""}
      className={`group/task grid cursor-pointer grid-cols-[auto_1fr] gap-4 rounded-xl border border-[rgba(255,255,255,0.10)] bg-gray-100 bg-secondary/80 p-4 text-sm shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] transition-all duration-500 ease-in-out hover:-translate-y-1 hover:scale-[1.005] dark:bg-[rgba(40,40,40,0.70)] overflow-hidden relative`}
    >
      <div className="grid size-12 place-items-center rounded-xl bg-gradient-to-br from-purple-700 to-purple-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-purple-600 dark:to-purple-400">
        <Icon name={iconName} className="size-5 fill-white text-white/80" />
      </div>
      <div className="flex flex-col gap-1">
        <div className="flex justify-between items-center">
          <div className="font-medium">{title}</div>

        </div>
        <div className="max-w-[31rem] overflow-hidden truncate text-ellipsis text-neutral-400">
          {desc}
        </div>
        <div className="mt-1">
          <Progress
            value={Math.random() * 100}
            className="h-[5px]"
            indicatorClassName="bg-purple-500"
          />
        </div>
        <div className="text-muted-foreground flex items-center gap-1 absolute right-4 top-3">
          <img src={COIN_ICO} alt="" className="size-4" />
          <p><span className="text-foreground">{points}</span> Points</p>
        </div>
      </div>
    </Link>
  );
};
export default TaskFeatureCard;
