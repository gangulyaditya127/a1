import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/tailwind.utils";
import { TEAMPERFORMACEDATA } from "../data/teamPerformaceData";
import { Icon } from "@/components/ui/icon";

const TicketResolutionTaskTable = () => {
  return (
    <div className="mt-4">
      <Table className="">
        <TableHeader className="">
          <TableRow>
            <TableHead className="">Trend</TableHead>
            <TableHead className="w-[300px]">Name</TableHead>
            <TableHead className="">Emp.Id</TableHead>
            <TableHead>Global Rank</TableHead>
            <TableHead className="">Team Rank</TableHead>
            <TableHead className="">Points</TableHead>
            <TableHead className="">Training Completion %</TableHead>
            <TableHead className="">Ticket Resolved / Month</TableHead>
            <TableHead className="">Avg. Resolution Time</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="border-0">
          {TEAMPERFORMACEDATA.map((teamMember, i) => {
            return (
              <TableRow
                key={i}
                className={cn(
                  "group/team-row border-0",
                  i % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                )}
              >
                <TableCell className="px-4 py-4 text-white">
                  {teamMember.trend == "down" ? (
                    <div className="grid size-8 place-items-center rounded-full bg-red-500/90">
                      <Icon name="move-down-left" className="size-4"></Icon>
                    </div>
                  ) : (
                    <div className="grid size-8 place-items-center rounded-full bg-green-500/90">
                      <Icon name="move-up-right" className="size-4"></Icon>
                    </div>
                  )}
                </TableCell>
                <TableCell className="py-4">{teamMember.name}</TableCell>
                <TableCell>{teamMember.empid}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <p>{teamMember.globalRank.value}</p>
                    {teamMember.globalRank.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <p>{teamMember.teamRank.value}</p>
                    {teamMember.teamRank.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
                <TableCell className="">
                  <div className="flex items-center gap-2">
                    <p>{teamMember.points.value}</p>
                    {teamMember.points.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
                <TableCell className="">
                  <div className="flex items-center gap-2">
                    <p>{teamMember.trainingCompletion.value}</p>
                    {teamMember.trainingCompletion.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
                <TableCell className="">
                  <div className="flex items-center gap-2">
                    <p>{teamMember.ticketsResolved.value}</p>
                    {teamMember.ticketsResolved.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
                <TableCell className="">
                  <div className="flex items-center gap-2">
                    <p>{teamMember.avgResolutionTime.value}</p>
                    {teamMember.avgResolutionTime.trend == "up" ? (
                      <Icon
                        name="trending-up"
                        className="size-4 text-green-600 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    ) : (
                      <Icon
                        name="trending-down"
                        className="size-4 text-red-500 opacity-0 transition-all group-hover/team-row:opacity-100"
                      ></Icon>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};
export default TicketResolutionTaskTable;

/**
 * <div className="grid place-items-center">
                                            <Icon name="circle-check-big" className="size-4 text-green-600 dark:text-green-400"></Icon>
                                        </div>
 */
