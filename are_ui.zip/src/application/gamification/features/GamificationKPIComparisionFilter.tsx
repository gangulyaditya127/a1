import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";

import { MultiSelectCombobox } from "@/components/ui/multi-select-combobox";
import { updateGamificationKPIComparisionFilterKPI, updateGamificationKPIComparisionFilterTeam } from "../slice/GamificationAdminSlice";

type Option = {
    value: string;
    label: string;
};

const kpiList: Option[] = [
    {
        value: "WarRoom",
        label: "War Room"
    },
    {
        value:"InnovationLab",
        label:"Innovation Lab"
    },
    {
        value:"LearningOdysyss",
        label:"Learning Odysyss"
    },
]

const teamList:Option[]=[
    "APAC Finance",
    "EMEA Finance",
    "Automation & Supply Chain",
    "Regulatory Reporting",
    "Taxation & Product Control",
    "Treasury & Allocation",
  ].map(el=>({value:el.split(" ").join(""),label:el}))

const GamificationKPIComparisionFilter = () => {
    const kpi = useAppSelector((state) => state.gamificationAdmin.gamificationKPIComparisionFilterData.kpi);
    const team = useAppSelector((state) => state.gamificationAdmin.gamificationKPIComparisionFilterData.team);


    const dispatch = useAppDispatch();
    const setKPIs = (kpis: string[]) => {
        dispatch(updateGamificationKPIComparisionFilterKPI(kpis))
    }
    const setTeams=(teams:string[])=>{
        dispatch(updateGamificationKPIComparisionFilterTeam(teams))
    }

    return (
        <div className="flex items-center">
            <div className="flex gap-6">
                <MultiSelectCombobox
                    value={kpi}
                    optionList={kpiList}
                    placeholder="Select KPIs"
                    setValue={setKPIs}
                    setValueOnClose={false}
                    label="KPIs"
                />
                <MultiSelectCombobox
                    value={team}
                    optionList={teamList}
                    placeholder="Select Teams"
                    setValue={setTeams}
                    setValueOnClose={false}
                    label="Teams"
                />
            </div>
        </div>
    );
};

export default GamificationKPIComparisionFilter;
