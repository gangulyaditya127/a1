import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Podium from "./Podium";

const Leaderbord = () => {
  return (
    <>
      <div className="relative min-h-60 w-full rounded-xl bg-gradient-to-tr from-purple-700 to-purple-500 text-white dark:from-purple-600 dark:to-purple-400">
        <Podium
          className="absolute left-1/2 top-14 -translate-x-1/2 scale-150"
          rankList={[
            {
              name:"Sudhanshu Singh",
              rank:1
            },
            {
              name:"Abhinav Jha",
              rank:2
            },
            {
              name:"Shushant Mohan",
              rank:3
            }
          ]} 
        />
      </div>
      <div className="mt-4 grid gap-4">
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                SU
              </AvatarFallback>
            </Avatar>
            <p>Sudhanshu Singh</p>
          </div>
          <p>1424</p>
          <p>Wealth Management</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#01</p>
        </div>
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                AK
              </AvatarFallback>
            </Avatar>
            <p>Akriti Sengupta</p>
          </div>
          <p>1345</p>
          <p>Wealth Management</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#02</p>
        </div>
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                PA
              </AvatarFallback>
            </Avatar>
            <p>Pankaj Kumar</p>
          </div>
          <p>1200</p>
          <p>Wealth Management</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#03</p>
        </div>
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                SU
              </AvatarFallback>
            </Avatar>
            <p>Sumanta Desayi</p>
          </div>
          <p>1024</p>
          <p>Retail Banking</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#04</p>
        </div>
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-gradient-to-br from-purple-700 to-purple-500 p-4 dark:from-purple-600 dark:to-purple-400">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                SU
              </AvatarFallback>
            </Avatar>
            <p>You</p>
          </div>
          <p>1000</p>
          <p>Wealth Management</p>
          <p className="text-2xl font-medium dark:text-neutral-200">#05</p>
        </div>

        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                SU
              </AvatarFallback>
            </Avatar>
            <p>Debashish Das</p>
          </div>
          <p>986</p>
          <p>Corporate Banking</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#06</p>
        </div>
        <div className="border-1 grid grid-cols-[auto_200px_400px_50px] items-center rounded-xl border bg-purple-800/10 bg-secondary/80 p-4">
          <div className="flex items-center gap-2">
            <Avatar className="size-8">
              <AvatarFallback className="border-1 border-white bg-neutral-800 text-xs">
                SU
              </AvatarFallback>
            </Avatar>
            <p>Akash Gupta</p>
          </div>
          <p>807</p>
          <p>Retail Banking</p>
          <p className="text-2xl font-medium dark:text-neutral-400">#07</p>
        </div>
      </div>
    </>
  );
};
export default Leaderbord;
