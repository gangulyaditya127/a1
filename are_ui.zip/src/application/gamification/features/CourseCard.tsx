import { buttonVariants } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import dynamicIconImports from "lucide-react/dynamicIconImports";
import { Link } from "react-router-dom";
import COIN_IMG from '@/assets/3D illus/coin.png'
import { useTranslation } from "react-i18next";
const CourseCard = ({
  name,
  description,
  icon,
  route,
}: {
  name: string;
  description: string;
  icon: keyof typeof dynamicIconImports;
  route?: string;
}) => {
  const { t, ready } = useTranslation('/gamification/user/learning')
  if(!ready){
    return null;
  }
  return (
    <div className="group/course-card w-full cursor-pointer overflow-hidden rounded-xl border border-[rgba(255,255,255,0.10)] bg-gray-100 p-6 text-sm shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] transition-all duration-500 ease-in-out hover:-translate-y-1 hover:scale-[1.005] dark:bg-[rgba(40,40,40,0.70)]">
      <div className="grid h-full grid-cols-[auto_1fr] gap-4">
        <div className="grid size-14 place-items-center rounded-full bg-gradient-to-br from-purple-700 to-purple-500 group-hover/course-card:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-purple-600 dark:to-purple-400">
          <Icon name={icon} className="text-white"></Icon>
        </div>
        <div className="flex flex-col relative">
          <h4 className="text-lg font-medium">{name}</h4>
          <p className="text-muted-foreground">{description}</p>
          <Link
            to={route ?? ""}
            target="_blank"
            className={cn(
              buttonVariants({
                variant: "link",
                className: "mr-auto mt-auto flex gap-2 p-0",
              }),
            )}
          >
            <span>{t('Explore')}</span>
            <Icon
              name="move-right"
              className="w-5 text-muted-foreground"
            ></Icon>
          </Link>
          <div className="flex gap-1 items-center bg-black/40 pl-2 pr-6 absolute py-[2px] rounded-xl w-fit -right-8 bottom-0" >
            <img src={COIN_IMG} alt="" className="size-4"/>
            <p>x{Math.floor([1,2,3][Math.floor(Math.random()*3)]*20)}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CourseCard;
