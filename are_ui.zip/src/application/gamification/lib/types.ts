export type DQScoreDataType = {
  title: string;
  dqPercent: string;
  dqIncrementPercent: string;
  userINCPercent: string;
  userINCIncrementPercent: string;
  icon: string;
  batchINCPercent: string;
  batchINCIncrementPercent: string;
};
