import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PerformanceBoosterForm from "../../features/PerformaceBoosterForm";
import {
    useMemo,
    useState,
} from "react";
import {
    ColDef,
} from "ag-grid-community";
import { PERFORMACE_BOOSTER_DATA } from '../../data/performance-booster-data'
import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import NumberTicker from "@/components/ui/number-ticker";
import { Separator } from "@/components/ui/seperator";
import { useTranslation } from "react-i18next";
import DataGrid from "@/components/ui/data-grid";
export type SpeedBoosterProps = {
    title: string;
    description: string;
    points: number;
    startDate: string;
    endDate: string;
    status: string;
    questType: string;
}

const GaificationAdminPerformaceBoosterConfig = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData] = useState<SpeedBoosterProps[]>(PERFORMACE_BOOSTER_DATA);
    const [columnDefs] = useState<ColDef[]>([
        { field: "title", minWidth: 300, filter: 'agTextColumnFilter' },
        { field: "description", filter: 'agSetColumnFilter' },
        { field: "points", headerName: "Extra Points", filter: 'agNumberColumnFilter' },
        { field: "startDate", filter: 'agSetColumnFilter', },
        { field: "endDate", filter: 'agSetColumnFilter', },
        { field: "status", filter: 'agSetColumnFilter', },
        { field: "questType", headerName: "Offering", filter: 'agSetColumnFilter', },
    ]);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminPerformanceBoosterConfig')
    if (!ready) {
        return null;
    }
    return (
        <section className="mt-4 pb-8">
            <Container>
                <NavigateBackButton />
                <div className="dark:purple-600 rounded-xl bg-purple-700 text-white">
                    <div className="flex justify-between px-20 py-14">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('activeSpeedBoosters')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={2} />
                                </span>
                            </p>
                            <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                <p className="">
                                    <span>
                                        <NumberTicker className="text-white" value={8} />
                                    </span>
                                    <span className="text-xs">%</span>
                                </p>
                                <Icon name="arrow-down-right" className="size-4" />
                                <p>{t('thisMonth')}</p>
                            </div>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('participation')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={86} />
                                </span>
                                <span className="text-md">%</span>
                            </p>
                            <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                <p className="">
                                    <span>
                                        <NumberTicker className="text-white" value={13} />
                                    </span>
                                    <span className="text-xs">%</span>
                                </p>
                                <Icon name="arrow-up-right" className="size-4" />
                                <p>{t('thisMonth')}</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="flex gap-2 items-center mt-4 mb-2">
                    <h2 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">{t('ongoingPerformaceBooster')}</h2>
                    <Dialog>
                        <DialogTrigger asChild>
                            <Button variant="link" className="mr-auto gap-1 p-0">
                                <Icon name="plus" className="size-4" />
                                <span>{t('addNewBooster')}</span>
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl">
                            <PerformanceBoosterForm />
                        </DialogContent>
                    </Dialog>
                </div>
                <div className="h-[400px]">
                    <div
                        style={gridStyle}
                    >
                        <DataGrid
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            masterDetail={true}
                        />
                    </div>
                </div>
            </Container>
        </section>
    )
}
export default GaificationAdminPerformaceBoosterConfig