import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import COIN from "@/assets/3D illus/coin.png";
import WAR_ROOM from "@/assets/3D illus/war_room.png";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import WarRoomForm from "../../features/WarRoomForm";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";

type data={
  id: number;
  description: string;
  participants: any[];
  prizePool: string;
  title: string;
  totalParticipants: number;
}[];

const GamificationAdminWarRoomConfig = () => {
  const { t, ready } = useTranslation('/gamification/admin/GamificationAdminWarRoomConfig')
  if(!ready){
      return null;
  }
  const DATA = t("data", { returnObjects: true }) as data
  return (
    <section className="mt-6">
      <Container>
        <NavigateBackButton/>
        <div className="grid grid-cols-4 gap-6">
          <div className="col-span-3 flex flex-col">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="link" className="mr-auto gap-1 p-0">
                  <Icon name="plus" className="size-4" />
                  <span>{t('createNewWarRoom')}</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <WarRoomForm />
              </DialogContent>
            </Dialog>
            <div className="relative mb-6 mt-2 w-full">
              <Icon
                name="search"
                className="absolute left-3 top-2.5 size-5 text-neutral-500"
              ></Icon>
              <Input
                placeholder={t('searchForWarRoom')}
                className="rounded-lg pl-10"
              />
            </div>
            <div className="flex flex-col gap-6">
              {DATA.map(
                ({
                  id,
                  description,
                  participants,
                  prizePool,
                  title,
                  totalParticipants,
                }) => (
                  <Link
                    to={id+""}
                    key={id}
                    className="group/war-room flex items-start gap-4 rounded-xl border border-[rgba(255,255,255,0.10)] bg-gray-100 p-2 px-4 text-sm shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] transition-all duration-500 ease-in-out hover:-translate-y-1 hover:scale-[1.005] dark:bg-[rgba(40,40,40,0.70)]"
                  >
                    <div className="flex w-fit items-center gap-2 rounded-3xl bg-gradient-to-tr from-neutral-400 to-neutral-500 p-2 pr-3 text-white group-hover/war-room:from-purple-600 group-hover/war-room:to-purple-400 dark:from-neutral-600 dark:to-neutral-400">
                      <div className="flex -space-x-4">
                        {participants.map((participant) => (
                          <Avatar>
                            <AvatarFallback
                              key={participant}
                              className="dark border-2 border-white text-white dark:border-gray-600"
                            >
                              {participant}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                      </div>
                      <p>+{totalParticipants}</p>
                    </div>
                    <div className="">
                      <p className="font-medium">{title}</p>
                      <p className="text-neutral-400">{description}</p>
                      <div className="mt-2 flex w-fit items-center gap-1 rounded-2xl bg-black/60 px-3 py-[4px] pl-2 text-xs text-white">
                        <img src={COIN} alt="" className="size-4" />
                        <p>x{prizePool}</p>
                      </div>
                    </div>
                  </Link>
                ),
              )}
            </div>
          </div>
        </div>
        <img
          src={WAR_ROOM}
          alt=""
          className="fixed -bottom-[10rem] right-0 -z-[1] h-auto w-[30rem] -scale-x-100"
        />
      </Container>
    </section>
  );
};
// const DATA = [
//   {
//     id: 1,
//     participants: ["AK", "SU"],
//     totalParticipants: 54,
//     title: "Wealth Mangement knowledge base war",
//     description:
//       "We have to increase our knowledge base by 100%. The top 3 user with highest contribution to the knowlede articles will get rewards worth 500 points",
//     prizePool: 500,
//   },
  
// ];
export default GamificationAdminWarRoomConfig;
