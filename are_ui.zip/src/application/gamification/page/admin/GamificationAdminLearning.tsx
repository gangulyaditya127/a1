import Container from "@/components/ui/container";
import { Icon, IconNameProp } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import NumberTicker from "@/components/ui/number-ticker";
import { Separator } from "@/components/ui/seperator";
import {
    useMemo,
    useState,
} from "react";
import {
    ColDef,
} from "ag-grid-community";
import { GAMIFICATION_LEARNING_DATA } from '../../data/gamification-learning-data'
import { useTranslation } from "react-i18next";
import DataGrid from "@/components/ui/data-grid";
export type GamificationLearningDataGridProps = {
    empId: string;
    name: string;
    noOfPendingCourse: number;
    noOfCompletedCourse: number;
    noOfAssignedCourse: number;
    completionPercentage: number;
    role: string
}

type roles = {
    role: number;
    icon: IconNameProp;
}[];

const GamificationAdminLearning = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData] = useState<GamificationLearningDataGridProps[]>(GAMIFICATION_LEARNING_DATA);
    const [columnDefs] = useState<ColDef[]>([
        { field: "name", minWidth: 300, filter: 'agTextColumnFilter', headerName: "Employee Name" },
        { field: "empId", minWidth: 300, filter: 'agSetColumnFilter', headerName: "Employee ID" },
        { field: "role", minWidth: 300, filter: 'agSetColumnFilter', },
        { field: "noOfAssignedCourse", minWidth: 200, filter: 'agSetColumnFilter', },
        { field: "noOfCompletedCourse", minWidth: 200, filter: 'agSetColumnFilter', },
        { field: "noOfPendingCourse", minWidth: 200, filter: 'agSetColumnFilter', },
        { field: "completionPercentage", minWidth: 200, filter: 'agSetColumnFilter', },
    ]);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminLearning')
    if (!ready) {
        return null;
    }
    const ROLES = t("roles", { returnObjects: true }) as roles
    return (
        <section className="pt-4">
            <Container>
                <NavigateBackButton fallbackUrl="/gamification" />
                <div className="dark:purple-600 rounded-xl bg-purple-700 text-white">
                    <div className="flex justify-between px-20 py-14">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('pendingCount')}
                            </p>
                            <div className="flex items-center text-xs opacity-90">
                                <p>{t('assosiatesWithPendingCourses')}</p>
                            </div>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={15} />
                                </span>
                            </p>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('completedCount')}
                            </p>
                            <div className="flex items-center text-xs opacity-90">
                                <p>{t('assosiatesWithCompletedCourses')}</p>
                            </div>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={101} />
                                </span>
                            </p>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />

                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('trainingCompletionRate')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={86} />
                                </span>
                                <span className="text-md">%</span>
                            </p>
                            <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                <p className="">
                                    <span>
                                        <NumberTicker className="text-white" value={13} />
                                    </span>
                                    <span className="text-xs">%</span>
                                </p>
                                <Icon name="arrow-up-right" className="size-4" />
                                <p>{t('thisMonth')}</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="mt-6">
                    <h2 className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">{t('courseBuckets')}</h2>
                    <div className="grid grid-cols-4 gap-4">
                        {
                            ROLES.map((el, i) => (
                                <div key={i} className="rounded-xl min-h-24 cursor-pointer relative overflow-hidden border border-[rgba(255,255,255,0.10)] dark:bg-[rgba(40,40,40,0.70)] bg-gray-100 shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] p-4">
                                    <div className="relative z-[2]">
                                        <div className="grid size-8 place-items-center rounded-lg bg-gradient-to-br from-purple-700 to-purple-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-purple-600 dark:to-purple-400">
                                            <Icon name={el.icon} className="size-4 text-white/80" />
                                        </div>
                                        <div className="flex gap-3 items-center mt-2">
                                            <p className="font-medium text-sm">{el.role}</p>
                                            <Icon name="move-right" className="h-4 w-4 text-neutral-400"></Icon>
                                        </div>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                </div>
                <div className="h-[400px] mt-6">
                    <div
                        style={gridStyle}
                    >
                        <DataGrid
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            masterDetail={true}
                        />
                    </div>
                </div>
            </Container>
        </section>
    )
}
// const ROLES: {
//     role: string;
//     icon: IconNameProp
// }[] = [
//         {
//             role: "Support Engineer",
//             icon: "message-square-code"
//         },
//         {
//             role: "Application Support Analyst",
//             icon: "app-window"
//         },
//         {
//             role: "Database Administrator",
//             icon: "database-zap"
//         },
//         {
//             role: "System Administrator",
//             icon: "monitor-check"
//         },
//     ]
export default GamificationAdminLearning;