import Container from "@/components/ui/container";
import TeamKPITrendCard from "../../features/TeamKPITrendCard";
import { ActivityParticipationTrend } from "../../features/ActivityParticipationTrend";
import AdminDashboardHeader from "../../features/AdminDashboardHeader";
import AdminMetricsSummary from "../../features/AdminMetricsSummary";
import TopPerformer from "../../features/TopPerformer";
import BottomPerformer from "../../features/BottomPerformer";
import { lazy, Suspense } from 'react';
import { Skeleton } from "@/components/ui/skeleton";
const TeamPerformanceDataGrid = lazy(() => import("../../features/TeamPerformanceDataGrid"))
const GamificationKPIComparision = lazy(() => import("../../features/GamificationKPIComparision"))
const GamificationAdminDashboard = () => {
  return (
    <section className="mt-6 pb-12">
      <Container className="grid gap-6">
        <AdminDashboardHeader />
        <AdminMetricsSummary />
        <div className="grid grid-cols-4 gap-4">
          <div className="col-span-3">
            <Suspense fallback={
              <Skeleton className="h-full w-full">
              </Skeleton>
            }>
              <GamificationKPIComparision />
            </Suspense>
          </div>
          <ActivityParticipationTrend />
        </div>
        <div className="grid">
          <div className="col-span-4">
            <TeamKPITrendCard />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <TopPerformer />
          <BottomPerformer />
        </div>
        <div className="grid h-[400px] rounded-xl">
          <Suspense fallback={
            <Skeleton className="h-full w-full rounded-xl">
            </Skeleton>
          }>
            <TeamPerformanceDataGrid />
          </Suspense>
        </div>
      </Container>
    </section>
  );
};
export default GamificationAdminDashboard;
