import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import GamificationWarRoomParticipantsChart from "../../features/GamificationWarRoomParticipantsChart";
import CountDown from "@/components/ui/countdown";
import { getNthDateNumericFormat } from "@/lib/date.utils";
import { Icon } from "@/components/ui/icon";
import {
    Dialog,
    DialogContent,
    DialogTrigger,
  } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button";
import WarRoomForm from "../../features/WarRoomForm";
import { useTranslation } from "react-i18next";
const GamificationAdminWar = () => {
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminWar')
    if(!ready){
        return null;
    }
    return (
        <section className="pt-4">
            <Container>
                <NavigateBackButton fallbackUrl="/gamification" />
                <Breadcrumb className="mb-4">
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/gamification">{t('gamification')}</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/gamification/war-room-control">{t('warRoom')}</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{t('wealthMangementKnowledgeBaseWar')}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <h2 className="text-foreground font-medium text-2xl col-span-4 mb-4 flex items-center gap-4">
                    <span>{t('wealthMangementKnowledgeBaseWar')}</span>
                    <Dialog>
                        <DialogTrigger asChild>
                            <Button variant="ghost" className="mr-auto gap-1 p-0">
                                <Icon name="pencil" className="h-3 w-3 fill-foreground cursor-pointer" />
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl">
                            <WarRoomForm defaultValues={1}/>
                        </DialogContent>
                    </Dialog>
                </h2>
                <div className="grid grid-cols-4 gap-6">
                    <div className="text-muted-foreground col-span-3">
                        <div className="bg-purple-500 bg-gradient from-purple-600 to-purple-500 rounded-xl py-6 text-white mb-4">
                            <CountDown countDownFrom={getNthDateNumericFormat(2)} countDownItemCounterClassName="text-3xl font-semibold" countDownItemLabelClassName="text-sm" />
                        </div>
                        <p className="mb-2">{t('content.0')}</p>
                        <p className="mb-2">{t('content.1')}</p>
                        <ul className="list-disc pl-4 space-y-1.5">
                            <li>{t('content.2')}</li>
                            <li>{t('content.3')}</li>
                            <li>{t('content.4')}</li>
                            <li>{t('content.5')}</li>
                            <li>{t('content.6')}</li>
                        </ul>

                    </div>
                    <GamificationWarRoomParticipantsChart />
                </div>
            </Container>
        </section>
    )
}
export default GamificationAdminWar;