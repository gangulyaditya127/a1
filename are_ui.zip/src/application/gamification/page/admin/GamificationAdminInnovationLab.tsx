import Container from "@/components/ui/container"
import { Icon } from "@/components/ui/icon"
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
import NumberTicker from "@/components/ui/number-ticker"
import { Separator } from "@/components/ui/seperator"
import {
    useMemo,
    useState,
} from "react";
import { CustomCellRendererProps } from "ag-grid-react";
import {
    ColDef,
} from "ag-grid-community";
import { INNOVATION_LAB_DATA } from '../../data/innovation-lab-data'
import { cn } from "@/lib/tailwind.utils";
import { useTranslation } from "react-i18next";
import DataGrid from "@/components/ui/data-grid"
export type InnovationSubmissionProps = {
    id: string,
    title: string,
    improvementType: string,
    expectedSavings: string | number,
    approvalStatus: string,
    points: number,
    assosiateName: string,
    empID: string,
    submittedOn: string
}
const GamificationAdminInnovationLab = () => {
    const { t, ready } = useTranslation('/gamification/admin/GamificationAdminInnovationLab')
    if (!ready) {
        return null;
    }
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData] = useState<InnovationSubmissionProps[]>(INNOVATION_LAB_DATA);
    const [columnDefs] = useState<ColDef[]>([
        { field: "title", minWidth: 300, filter: 'agTextColumnFilter', headerName: "Idea Title" },
        { field: "improvementType", filter: 'agSetColumnFilter' },
        { field: "expectedSavings", filter: 'agTextColumnFilter' },
        { field: "points", headerName: "Points Assigned", filter: 'agNumberColumnFilter' },
        { field: "submittedOn", filter: 'agDateColumnFilter', },
        { field: "assosiateName", filter: 'agTextColumnFilter', },
        { field: "empID", filter: 'agSetColumnFilter', },
        { field: "approvalStatus", filter: 'agSetColumnFilter', cellRenderer: ApprovalStatus },
    ]);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);
    return (
        <section className="pt-4">
            <Container>
                <NavigateBackButton fallbackUrl="/gamification" />
                <div className="dark:purple-600 rounded-xl bg-purple-700 text-white">
                    <div className="flex justify-between px-20 py-14">
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('pendingIdeaCount')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={3} />
                                </span>
                            </p>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('approvedIdeaCount')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={3} />
                                </span>
                            </p>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />
                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('rejectedIdeaCount')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={2} />
                                </span>
                            </p>
                        </div>
                        <Separator
                            orientation="vertical"
                            className="h-[5.2rem] bg-white/30"
                        />

                        <div className="flex flex-col">
                            <p className="text-xs font-medium uppercase tracking-wider">
                                {t('participation')}
                            </p>
                            <p className="flex items-baseline gap-1">
                                <span className="text-4xl font-medium">
                                    <NumberTicker className="text-white" value={86} />
                                </span>
                                <span className="text-md">%</span>
                            </p>
                            <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                <p className="">
                                    <span>
                                        <NumberTicker className="text-white" value={13} />
                                    </span>
                                    <span className="text-xs">%</span>
                                </p>
                                <Icon name="arrow-up-right" className="size-4" />
                                <p>{t('thisMonth')}</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="h-[400px] mt-6 mb-8">
                    <div
                        style={gridStyle}
                    >
                        <DataGrid
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            masterDetail={true}
                        />
                    </div>
                </div>
            </Container>
        </section>
    )
}
export default GamificationAdminInnovationLab
const ApprovalStatus = ({ data }: CustomCellRendererProps) => {
    return (
        <div className="capitalize text-xs grid place-items-center h-full w-full">
            <div className={
                cn(
                    "rounded-xl px-2 py-[1px]",
                    data?.approvalStatus == "pending" ? "dark:bg-yellow-700 bg-yellow-300" :
                        data?.approvalStatus == "rejected" ? "dark:bg-red-700 bg-red-300" :
                            "dark:bg-green-700 bg-green-300"
                )
            }>
                {data?.approvalStatus}
            </div>
        </div>
    )
}