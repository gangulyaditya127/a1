import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import confetti from "canvas-confetti";
import { lazy, Suspense, useEffect } from "react";
const AREWorkshopDataGrid = lazy(() => import("../../features/AREWorkshopDataGrid"))
export default function AREWorkshop() {
    const sideCanonConfetti = () => {
        const end = Date.now() + 1 * 1000; // 3 seconds
        const colors = ["#a786ff", "#fd8bbc", "#eca184", "#f8deb1"];
        const frame = () => {
            if (Date.now() > end) return;
            confetti({
                particleCount: 2,
                angle: 60,
                spread: 55,
                startVelocity: 60,
                origin: { x: 0, y: 0.5 },
                colors: colors,
            });
            confetti({
                particleCount: 2,
                angle: 120,
                spread: 55,
                startVelocity: 60,
                origin: { x: 1, y: 0.5 },
                colors: colors,
            });

            requestAnimationFrame(frame);
        };

        frame();
    };
    useEffect(() => {
        sideCanonConfetti();
    }, []);
    return (
        <Container className="mt-4">
            <NavigateBackButton fallbackUrl="/gamification" />
            <div className="mb-6 grid place-items-center">
                <div className="">
                    <Icon name="trophy" className="size-10" />
                </div>
                <div className="mt-2 text-xl font-medium">Leaderboard
                </div>
            </div>
            <div className="rounded-xl bg-secondary/90 mt-2">
                <div className="w-full h-10 bg-secondary rounded-lg flex items-center px-4 justify-between">
                    <p className="font-medium text-sm">ARE Gamified Workshop - Kolkata</p>
                    <div className="flex gap-1 items-center text-xs">
                        {/* <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                        </span> */}
                        <p className="font-medium ">17/03/2025-19/03/2025</p>
                    </div>
                </div>
                <Suspense fallback={null}>
                    <AREWorkshopDataGrid />
                </Suspense>
            </div>
        </Container>
    )
}

