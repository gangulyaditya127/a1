import Container from "@/components/ui/container";
import InnovationLabForm from "../../features/InnovationLabForm";
import { Link } from "react-router-dom";
import { Icon } from "@/components/ui/icon";
import BG_IMG from '@/assets/3D illus/Saly-25.png'
import { cn } from "@/lib/tailwind.utils";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useTranslation } from "react-i18next";
const GamificationInnovationLab = () => {
  const { t, ready } = useTranslation('/gamification/user/InnovationLab')
  if(!ready){
    return null;
  }
  return (
    <section className="mt-4">
      <Container className="grid grid-cols-4 gap-6">
        <Link to="/gamification" className="text-xs py-0 px-4 col-span-4 flex gap-1 text-muted-foreground hover:text-foreground">
          <Icon name="move-left" className="size-4" />
          <span>{t('back')}</span>
        </Link >
        <div className="col-span-3 pb-6">
          <InnovationLabForm />
        </div>
        <div className="bg-gradient-to-tr from-purple-700 dark:from-purple-600 dark:to-purple-400 to-purple-500 text-white h-fit min-h-[250px] pb-6 p-4 rounded-xl text-white">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium">{t('Recent Submissions')}</p>
            <Link
              className={cn(
                buttonVariants({
                  variant: "link",
                  className: "font-baseline flex gap-1 p-0 text-xs text-white",
                }),
              )}
              to="submission"
            >
              <span>{t('view')}</span>
              <Icon name="move-right" className="w-4"></Icon>
            </Link>
          </div>
          <div className="grid gap-4">
            {
              new Array(1).fill(0)
                .map((_) => (<Link
                  to={"submission"}
                  className={`group/task grid cursor-pointer grid-cols-[auto_1fr] gap-4 rounded-lg border border-[rgba(255,255,255,0.10)] bg-black/40 p-2 text-sm shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] transition-all duration-500 ease-in-out hover:-translate-y-1 hover:scale-[1.005] text-xs`}
                >
                  <div className="grid size-8 place-items-center rounded-lg bg-gradient-to-br from-purple-700 to-purple-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-purple-600 dark:to-purple-400">
                    <Icon name="lightbulb" className="size-5 fill-white text-white/80" />
                  </div>
                  <div className="flex flex-col gap-1 ">
                    <div className="font-medium">{t('tag')}</div>
                    <Badge variant="default" className="ml-auto">{t('pending')}</Badge>
                  </div>
                </Link>))
            }
          </div>
        </div>
        <img src={BG_IMG} alt="" className="fixed bottom-8 right-0 w-80" />
      </Container>
    </section>
  );
};
export default GamificationInnovationLab;
