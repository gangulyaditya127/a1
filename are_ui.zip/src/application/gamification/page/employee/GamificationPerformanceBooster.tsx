import Container from "@/components/ui/container";
import GamificationSpeedBoosterOfferingsCard from "../../features/GamificationSpeedBoosterOfferingsCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { getNthDate } from "@/lib/date.utils";
import IMG_BG from '@/assets/3D illus/Saly-2.png'
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
const GamificationPerformanceBooster = () => {
  const { t, ready } = useTranslation('/gamification/user/performanceBooster')
  return (
    <section className="mt-4">
      <Container>
        <NavigateBackButton fallbackUrl="/gamification" />
        <h2 className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">{t('performanceBooster')}</h2>

        {
          !ready ? <div className="grid h-full grid-cols-3 gap-4">
            <Skeleton />
            <Skeleton />
          </div>
            :
            <div className="grid h-full grid-cols-3 gap-4">
              <GamificationSpeedBoosterOfferingsCard
                title={t('offeringList.0.title')}
                icon="graduation-cap"
                route="/gamification/course"
                points={20}
                className="bg-pink-800 text-white"
                desClassName="text-neutral-200"
                description={t('offeringList.0.description',{date:getNthDate(3)})}
              />
              <GamificationSpeedBoosterOfferingsCard
                title={t('offeringList.1.title')}
                icon="flask-conical"
                points={50}
                route="/gamification/innovation"
                className="text-white"
                desClassName="text-neutral-200"
                description={t('offeringList.1.description',{date:getNthDate(5)})}
              />
            </div>
        }


        <img src={IMG_BG} alt="Background Image" className="fixed top-0 -z-[1] -right-12 w-[40rem]" />
      </Container>
    </section>
  );
};
export default GamificationPerformanceBooster;
