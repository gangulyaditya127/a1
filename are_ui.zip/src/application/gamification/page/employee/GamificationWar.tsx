import Container from "@/components/ui/container";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { SlashIcon } from "lucide-react";
import GamificationWarRoomParticipantsChart from "../../features/GamificationWarRoomParticipantsChart";
import GamificationWarRoomLog from "../../features/GamificationWarRoomLog";
import { useRef } from "react";
import type { ConfettiRef } from "@/components/ui/confetti";
import Confetti from "@/components/ui/confetti";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import CountDown from "@/components/ui/countdown";
import { getNthDateNumericFormat } from "@/lib/date.utils";
import { useTranslation } from "react-i18next";
const GamificationWar = () => {
  const { t, ready } = useTranslation('gamification/user/War')
  if(!ready){
    return null;
  }
  const [isJoinedWar, setIsJoinedWar] = useState(false)
  return (
    <section className="mt-4 pb-6">
      <Container>

        <NavigateBackButton fallbackUrl="/gamification" />
        <Breadcrumb className="mb-4">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/gamification">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/gamification/war-room">{t('app')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <h2 className="text-foreground font-medium text-2xl col-span-4 mb-4">{t('title')}</h2>
        <div className="grid grid-cols-4 gap-6">
          <div className="text-muted-foreground col-span-3">
            <div className="bg-purple-500 bg-gradient from-purple-600 to-purple-500 rounded-xl py-6 text-white mb-4">
              <CountDown countDownFrom={getNthDateNumericFormat(2)} countDownItemCounterClassName="text-3xl font-semibold" countDownItemLabelClassName="text-sm" />
            </div>
            <p className="mb-2">{t('content.0')}</p>
            <p className="mb-2">{t('content.1')}</p>
            <ul className="list-disc pl-4 space-y-1.5">
              <li>{t('content.2')}</li>
              <li>{t('content.3')}</li>
              <li>{t('content.4')}</li>
              <li>{t('content.5')}</li>
              <li>{t('content.6')}</li>
            </ul>
            <div className="my-4 mt-6">
              {
                !isJoinedWar ?
                  <JoinTheWar setIsJoinedWar={setIsJoinedWar} /> :
                  <SubmitForEvaluation />
              }
            </div>

          </div>
          <GamificationWarRoomParticipantsChart />
        </div>

        <div className="">
          <h4 className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">{t('content.8')}</h4>
          <div className="grid grid-cols-4 gap-6">
            <GamificationWarRoomLog className="col-span-4" />
          </div>
        </div>
      </Container>
    </section>
  );
};


export default GamificationWar;
const JoinTheWar = ({
  setIsJoinedWar
}: {
  setIsJoinedWar: any
}) => {
  const confettiRef = useRef<ConfettiRef>(null);
  const { t, ready } = useTranslation('gamification/user/War')
  if(!ready){
    return null;
  }
  const [isOpen, setIsOpen] = useState(false)
  return (
    <Dialog open={isOpen} >
      <DialogTrigger asChild>
        <Button onClick={() => {
          setIsOpen(true)
        }} className="rounded-3xl bg-purple-600 text-white hover:bg-purple-700">
          {t('content.7')}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] rounded-2xl">
        <h4 className="text-2xl">{t('content.9')}</h4>
        <DialogFooter>
          <Button type="submit" variant="ghost" onClick={() => {
            setIsOpen(false)
            setIsJoinedWar(true)
          }}>Okay</Button>
        </DialogFooter>
        <Confetti
          ref={confettiRef}
          className="absolute inset-0 -z-[1] size-full"
          onMouseEnter={() => {
            confettiRef.current?.fire({});
          }}
        />
      </DialogContent>
    </Dialog>
  )
}
const SubmitForEvaluation = () => {
  const { t, ready } = useTranslation('gamification/user/War')
  if(!ready){
    return null;
  }
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="rounded-3xl bg-rose-600 text-white hover:bg-rose-700">
        {t('content.10')}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <div className="">
          <h4 className="text-xl font-medium">{t('content.11')}</h4>
          <p className="text-sm text-muted-foreground">{t('content.12')}</p>
        </div>
        <div className="flex flex-col gap-1">
          <Label>
          {t('content.13')}
          </Label>
          <Textarea placeholder={t('content.15')}></Textarea>
        </div>
        <DialogTrigger asChild>
          <Button className="rounded-3xl" >{t('content.15')}</Button>
        </DialogTrigger>

      </DialogContent>
    </Dialog>

  )
}