import Container from "@/components/ui/container";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Icon } from "@/components/ui/icon";
import Leaderbord from "../../features/LeaderBoard";
import confetti from "canvas-confetti";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
const GamificationLeaderboard = () => {
  const { t, ready } = useTranslation('/gamification/user/Leaderboard')
  if(!ready){
      return null;
  }
  const sideCanonConfetti = () => {
    const end = Date.now() + 1 * 1000; // 3 seconds
    const colors = ["#a786ff", "#fd8bbc", "#eca184", "#f8deb1"];

    const frame = () => {
      if (Date.now() > end) return;
      confetti({
        particleCount: 2,
        angle: 60,
        spread: 55,
        startVelocity: 60,
        origin: { x: 0, y: 0.5 },
        colors: colors,
      });
      confetti({
        particleCount: 2,
        angle: 120,
        spread: 55,
        startVelocity: 60,
        origin: { x: 1, y: 0.5 },
        colors: colors,
      });

      requestAnimationFrame(frame);
    };

    frame();
  };
  useEffect(() => {
    sideCanonConfetti();
  }, []);

  return (
    <section className="mt-6 pb-6">
      <Container>
        <Link to="/gamification" className="text-xs py-0 mb-4 col-span-4 flex gap-1 text-muted-foreground hover:text-foreground">
          <Icon name="move-left" className="size-4" />
          <span>{t('goback')}</span>
        </Link >
        <div className="mb-6 grid place-items-center">
          <div className="">
            <Icon name="trophy" className="size-10" />
          </div>
          <div className="mt-2 text-xl font-medium">{t('Leaderboards')}</div>
        </div>
        <Tabs defaultValue="Global" className="">
          <TabsList className="mx-auto grid max-w-64 grid-cols-2 rounded-2xl dark:bg-violet-900/10">
            <TabsTrigger
              value="Global"
              className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal"
            >
              {t('Global')}
            </TabsTrigger>
            <TabsTrigger
              value="Team"
              className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              {t('Team')}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="Global">
            <Leaderbord />
          </TabsContent>
          <TabsContent value="Team">
            <Leaderbord />
          </TabsContent>
        </Tabs>
      </Container>
    </section>
  );
};
export default GamificationLeaderboard;
