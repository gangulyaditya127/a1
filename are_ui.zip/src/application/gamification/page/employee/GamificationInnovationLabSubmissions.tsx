import {
    useMemo,
    useState,
} from "react";
import { CustomCellRendererProps } from 'ag-grid-react';
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import {
    ColDef,
} from "ag-grid-community";
import { IDEA_SUBMISSION_DATA } from "../../data/innovation-submissions.data";
import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { Separator } from "@/components/ui/seperator";
import NumberTicker from "@/components/ui/number-ticker";
import { useTranslation } from "react-i18next";
import DataGrid from "@/components/ui/data-grid";
export type InnovationLabSubmissionProp = {
    title: string;
    improvementType: string;
    expectedSavings: string | number;
    approvalStatus: string;
    points: number;
    id: number | string
}

const GamificationInnovationLabSubmissions = () => {
    const { t, ready } = useTranslation('/gamification/user/InnovationLabSubmissions')
    if(!ready){
        return null;
    }
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData] = useState<InnovationLabSubmissionProp[]>(IDEA_SUBMISSION_DATA);
    const [columnDefs] = useState<ColDef[]>([
        { field: "title", minWidth: 300, filter: 'agTextColumnFilter' },
        { field: "improvementType", filter: 'agSetColumnFilter' },
        { field: "expectedSavings", filter: 'agNumberColumnFilter' },
        { field: "points", headerName: "Points Earned", filter: 'agNumberColumnFilter' },
        { field: "approvalStatus", filter: 'agSetColumnFilter', cellRenderer: ApprovalStatus },
    ]);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);

    return (
        <section>
            <Container className="mt-4">
                <Link to="/gamification/innovation" className="text-xs py-2 flex gap-1 text-muted-foreground hover:text-foreground">
                    <Icon name="move-left" className="size-4" />
                    <span>{t('Go Back')}</span>
                </Link >
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/">{t('Gamification')}</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/doc/operate">{t('app')}</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{t('title')}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <div className="mt-4">
                    <div className="dark:purple-600 rounded-xl bg-purple-700 text-white">
                        <div className="flex justify-between px-8 py-14">
                            <div className="flex flex-col">
                                <p className="text-xs font-medium uppercase tracking-wider">
                                {t('Total Ideas Submitted')}
                                </p>
                                <p className="flex items-baseline gap-1">
                                    <span className="text-4xl font-medium">
                                        <NumberTicker className="text-white" value={9} />
                                    </span>
                                </p>
                                <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                    <p className="">
                                        <span>
                                            <NumberTicker className="text-white" value={8} />
                                        </span>
                                        <span className="text-xs">%</span>
                                    </p>
                                    <Icon name="arrow-down-right" className="size-4" />
                                    <p>{t('thisMonth')}</p>
                                </div>
                            </div>
                            <Separator
                                orientation="vertical"
                                className="h-[5.2rem] bg-white/30"
                            />
                            <div className="flex flex-col">
                                <p className="text-xs font-medium uppercase tracking-wider">
                                {t('ApprovedIdeaCount')}
                                </p>
                                <p className="flex items-baseline gap-1">
                                    <span className="text-4xl font-medium">
                                        <NumberTicker className="text-white" value={5} />
                                    </span>
                                </p>
                                <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                    <p className="">
                                        <span>
                                            <NumberTicker className="text-white" value={13} />
                                        </span>
                                        <span className="text-xs">%</span>
                                    </p>
                                    <Icon name="arrow-up-right" className="size-4" />
                                    <p>{t('thisMonth')}</p>
                                </div>
                            </div>
                            <Separator
                                orientation="vertical"
                                className="h-[5.2rem] bg-white/30"
                            />
                            <div className="flex flex-col">
                                <p className="text-xs font-medium uppercase tracking-wider">
                                {t('ApprovalPendingCount')}
                                </p>
                                <p className="flex items-baseline gap-1">
                                    <span className="text-4xl font-medium">
                                        <NumberTicker className="text-white" value={2} />
                                    </span>
                                </p>
                                <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                    <p className="">
                                        <span>
                                            <NumberTicker className="text-white" value={2} />
                                        </span>
                                        <span className="text-xs">%</span>
                                    </p>
                                    <Icon name="arrow-up-right" className="size-4" />
                                    <p>{t('thisMonth')}</p>
                                </div>
                            </div>
                            <Separator
                                orientation="vertical"
                                className="h-[5.2rem] bg-white/30"
                            />
                            <div className="flex flex-col">
                                <p className="text-xs font-medium uppercase tracking-wider">
                                {t('PointsEarnedfromsubmission')}
                                </p>
                                <p className="flex items-baseline gap-1">
                                    <span className="text-4xl font-medium">
                                        <NumberTicker className="text-white" value={215} />
                                    </span>
                                </p>
                                <div className="mt-auto flex items-center gap-2 text-sm opacity-90">
                                    <p className="">
                                        <span>
                                            <NumberTicker className="text-white" value={5} />
                                        </span>
                                        <span className="text-xs">%</span>
                                    </p>
                                    <Icon name="arrow-up-right" className="size-4" />
                                    <p>{t('thisMonth')}</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">{t('Your Submissions')}</h2>
                    <div className="h-[400px]">
                        <div
                            style={gridStyle}
                        >
                            <DataGrid
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                masterDetail={true}
                            />
                        </div>
                    </div>
                </div>
            </Container>
        </section>
    );
}
export default GamificationInnovationLabSubmissions
const ApprovalStatus = ({ data }: CustomCellRendererProps) => {
    return (
        <div className="capitalize text-xs grid place-items-center h-full w-full">
            <div className={
                cn(
                    "rounded-xl px-2 py-[1px]",
                    data?.approvalStatus == "pending" ? "dark:bg-yellow-700 bg-yellow-300" :
                        data?.approvalStatus == "rejected" ? "dark:bg-red-700 bg-red-300" :
                            "dark:bg-green-700 bg-green-300"
                )
            }>
                {data?.approvalStatus}
            </div>
        </div>
    )
}