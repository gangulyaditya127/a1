import Container from "@/components/ui/container";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CourseContainer from "../../features/CourseContainer";
import { Icon } from "@/components/ui/icon";
import { Separator } from "@/components/ui/seperator";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
const GamificationLearning = () => {
  const { t, ready } = useTranslation('gamification/user/learning')
  if(!ready){
    return null;
  }
  return (
    <section className="mt-6">
      <Container>
        <Link to="/gamification" className="text-xs py-0 mb-4 col-span-4 flex gap-1 text-muted-foreground hover:text-foreground">
          <Icon name="move-left" className="size-4" />
          <span>{t('back')}</span>
        </Link >
        <div className="py-18 relative mb-4 overflow-hidden rounded-xl bg-gradient-to-tr from-purple-700 to-purple-500 p-8 text-white dark:from-purple-600 dark:to-purple-400">
          <h1 className="mb-4 text-7xl">
            {" "}
            <span className="font-thin">{t('title.0')}</span>{" "}
            <span className="font-medium">{t('title.1')}</span>
          </h1>
          <div className="z-[1] mt-8 flex items-center gap-4">
            <div className="">
              <div className="text-2xl">5</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
              {t('pending')}
              </p>
            </div>
            <Separator orientation="vertical" className="h-10 bg-neutral-300" />
            <div className="">
              <div className="text-2xl">15</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
              {t('inProgre')}
              </p>
            </div>
            <Separator orientation="vertical" className="h-10 bg-neutral-300" />
            <div className="">
              <div className="text-2xl">3</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
              {t('completed')}
              </p>
            </div>
            <Separator orientation="vertical" className="h-10 bg-neutral-300" />
            <div className="">
              <div className="text-2xl">680</div>
              <p className="text-xs uppercase tracking-wider text-neutral-200">
              {t('pointsEarned')}
              </p>
            </div>
          </div>
          <Icon
            name="graduation-cap"
            className="absolute -top-20 right-0 size-96 text-black opacity-10"
          ></Icon>
        </div>
        <Tabs defaultValue={t('pending')} className="">
          <TabsList className="grid grid-cols-3 p-0 rounded-2xl border border-[rgba(255,255,255,0.10)] bg-gray-100 shadow-[2px_4px_16px_0px_rgba(248,248,248,0.06)_inset] dark:bg-[rgba(40,40,40,0.70)]">
            <TabsTrigger
              value={t('pending')}
              className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal"
            >
              {t('pending')}
            </TabsTrigger>
            <TabsTrigger
              value= {t('inProgre')}
              className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
           {t('inProgre')}
            </TabsTrigger>
            <TabsTrigger
              value= {t('completed')}
              className="rounded-2xl font-normal uppercase tracking-wider data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
               {t('completed')}
            </TabsTrigger>
          </TabsList>
          <TabsContent value={t('pending')}>
            <CourseContainer />
          </TabsContent>
        </Tabs>
      </Container>
    </section>
  );
};
export default GamificationLearning;
