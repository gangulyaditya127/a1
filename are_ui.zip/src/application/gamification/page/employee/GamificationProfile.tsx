import Container from "@/components/ui/container";
import myProfileCss from "../../style/myprofile.module.css";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import UserPersonalStats from "../../features/UserPersonalStats";
import GamificationUserStreak from "../../features/GamificationUserStreak";
import { useTranslation } from "react-i18next";
const GamificationProfile = () => {
  const { t, ready } = useTranslation('/gamification/user/Profile')
  if(!ready){
      return null;
  }
  return (
    <section className="p-2 mt-2">
      <Container>
        <NavigateBackButton fallbackUrl="/gamification" className="pl-2" />
        <div className={myProfileCss["user-profile-page__wrapper"]}>
          <div
            className={`${myProfileCss["user-profile-page"]}`}
          >
            <div className={` `}>
              <div className={`${myProfileCss["profile__card__wrapper"]}  text-white mb-16`}>
                <div className={myProfileCss["profile__card"]}>
                  <div
                    className={`flex gap-3 items-center`}
                  >
                    <div className={`bg-purple-600 size-12 grid place-items-center rounded-full`}>
                      <Icon name="user" className="h-6 w-6" />
                    </div>
                    <div className={``}>
                      <p className={`flex items-baseline`}>
                        <sub>#</sub>
                        <span id="rank" className="text-4xl font-bold">
                          5
                        </span>
                        /<span id="total">243</span>
                      </p>
                      <div className={myProfileCss["profile__sub-info--key"]}>
                        {t('Global Rank')}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["profile__info"]}>
                    <p className={myProfileCss["profile__info--user-name"]}>
                      <span id="name">Sudipta</span>
                    </p>
                    <p className={`dark:text-muted-foreground text-sm`}>
                      @<span id="soeid">109625</span>
                    </p>
                  </div>
                  <br />
                  <div className={myProfileCss["user__stat__wrapper"]}>
                    <div className={myProfileCss["user__stat-val"]}>
                      <div className={myProfileCss["profile__sub-info--key"]}>
                      {t('TeamRank')}
                      </div>
                      <div className={myProfileCss["user__stat--val"]}>
                        <span id="portfolioRank">2</span>
                      </div>
                    </div>

                    <div className={myProfileCss["user__stat-val"]}>
                      <div className={myProfileCss["profile__sub-info--key"]}>
                        {" "}
                        {t('Points')}
                      </div>
                      <div className={myProfileCss["user__stat--val"]}>
                        <span id="score">1000</span>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["profile__sub-info__wrapper"]}>
                    <div className={myProfileCss["profile__sub-info"]}>
                      <p className={myProfileCss["profile__sub-info--key"]}>
                      {t('Portfolio')}
                      </p>
                      <p className={myProfileCss["profile__sub-info--val"]}>
                        <span id="portfolio"> {t('BFSI')}</span>
                      </p>
                    </div>
                    <div className={myProfileCss["profile__sub-info"]}>
                      <p className={myProfileCss["profile__sub-info--key"]}>
                      {t('Team')}
                      </p>
                      <p className={myProfileCss["profile__sub-info--val"]}>
                        <span id="subportfolio">{t('Automation')}</span>
                      </p>
                    </div>
                  </div>
                </div>
                <div className={myProfileCss["profile__card__bg"]}></div>
              </div>


            </div>
            <main
              className={`flex flex-col gap-6`}
            >
              <div className="grid grid-cols-3 gap-6">
                <GamificationUserStreak/>
                <UserPersonalStats />
              </div>
              <div className={``}>
                <h2 className={`mb-6 uppercase tracking-wider text-muted-foreground`}>
                {t('Performance Matrix')}
                </h2>
                <div className={myProfileCss["user__stat__board"]}>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="ticket-check" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('Total Tickets Resolved')}:{" "}
                        <strong>
                          <span id="totalCount">400</span>
                        </strong>
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('OverallRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="gpaScore">30</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('TeamRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="portfolioScore">5</span>
                          </div>
                        </div>
                        {/* <div className={myProfileCss["user__stat-val"]}>
                                                        <div className={myProfileCss["user__stat--param"]}>Sub-portfolio</div>
                                                        <div className={myProfileCss["user__stat--val"]}><span id="subPortfolioScore">25</span></div>
                                                    </div> */}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                        {t('Incidents')}:{" "}
                        <strong>
                          <span id="totalCount">267</span>
                        </strong>
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('OverallRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="gpaScore">30</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('TeamRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="portfolioScore">3</span>
                          </div>
                        </div>
                        {/* <div className={myProfileCss["user__stat-val"]}>
                                                        <div className={myProfileCss["user__stat--param"]}>Sub-portfolio</div>
                                                        <div className={myProfileCss["user__stat--val"]}><span id="subPortfolioScore">24</span></div>
                                                    </div> */}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('Requests')}:{" "}
                        <strong>
                          <span id="totalCount">20</span>
                        </strong>
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('OverallRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="gpaScore">31</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('TeamRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="portfolioScore">25</span>
                          </div>
                        </div>
                        {/* <div className={myProfileCss["user__stat-val"]}>
                                                        <div className={myProfileCss["user__stat--param"]}>Sub-portfolio</div>
                                                        <div className={myProfileCss["user__stat--val"]}><span id="subPortfolioScore">11</span></div>
                                                    </div> */}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('Auto Tickets')}:{" "}
                        <strong>
                          <span id="totalCount"></span>40
                        </strong>
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('OverallRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="gpaScore">77</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('TeamRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="portfolioScore">52</span>
                          </div>
                        </div>
                        {/* <div className={myProfileCss["user__stat-val"]}>
                                                        <div className={myProfileCss["user__stat--param"]}>Sub-portfolio</div>
                                                        <div className={myProfileCss["user__stat--val"]}><span id="subPortfolioScore">14</span></div>
                                                    </div> */}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('User Tickets')}:{" "}
                        <strong>
                          <span id="totalCount">18</span>
                        </strong>
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('OverallRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="gpaScore">56</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('TeamRank')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="portfolioScore">34</span>
                          </div>
                        </div>
                        {/* <div className={myProfileCss["user__stat-val"]}>
                                                        <div className={myProfileCss["user__stat--param"]}>Sub-portfolio</div>
                                                        <div className={myProfileCss["user__stat--val"]}><span id="subPortfolioScore">21</span></div>
                                                    </div> */}
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="thumbs-up" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('Data Quality Score')}:{" "}
                        <span id="DqScorePercentage">0</span>%
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('DQ Missed')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="DqMissedCount">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                        {t('Priority 1 Tickets')}
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                            {t('Count')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1TicketCount">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                            {t('SLA Met')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMet">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                            {t('SLA Missed')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMissed">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                       {t('Priority 2 Tickets')}
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('Count')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1TicketCount">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Met')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMet">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Missed')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMissed">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                      {t('Priority 3 Tickets')}
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('Count')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1TicketCount">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Met')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMet">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Missed')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMissed">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="newspaper" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                        {t('Priority 4 Tickets')}
                      </div>
                      <div className={myProfileCss["user__stat__wrapper"]}>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('Count')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1TicketCount">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Met')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMet">0</span>
                          </div>
                        </div>
                        <div className={myProfileCss["user__stat-val"]}>
                          <div className={myProfileCss["user__stat--param"]}>
                          {t('SLA Missed')}
                          </div>
                          <div className={myProfileCss["user__stat--val"]}>
                            <span id="P1SLAMissed">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={myProfileCss["user__stat__card"]}>
                    <div className={myProfileCss["user__stat__icon"]}>
                      <Icon name="folders" />
                    </div>
                    <div className={myProfileCss["user__stat"]}>
                      <div className={myProfileCss["user__stat--key"]}>
                        {t('# of Course Not Completed')}
                      </div>
                      <div className={myProfileCss["user__stat--val"]}>
                        <span id="course">0</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </main>
          </div>
        </div>
      </Container>
    </section>
  );
};
export default GamificationProfile;
