import Container from "@/components/ui/container";
import TaskFeatureCard from "../../features/TaskFeatureCard";
import SPEED_QUEST from "@/assets/3D illus/Saly-1.png";
import LEARNING_QUEST from "@/assets/3D illus/Saly-10.png";
import INNOVATION_QUEST from "@/assets/3D illus/Saly-19.png";
import WAR_ROOM from "@/assets/3D illus/Saly-31.png";
import { lazy, Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { useTranslation } from "react-i18next";
const GamificationOfferingsCard = lazy(
  () => import("../../features/GamificationOfferingsCard"),
);
const ProfileCard = lazy(() => import("../../features/ProfileCard"));
const PodiumCard = lazy(() => import("../../features/PodiumCard"));
const GamificationEmployeeHome = () => {
  const { t: common, ready: commonReady } = useTranslation('/gamification/common')
  const { t, ready } = useTranslation('/gamification/user/home')
  console.log({ t, ready })
  return (
    <section className="relative w-full pb-8 pt-8">
      <Container className="grid gap-6">
        <div className="grid grid-cols-4 gap-4 md:grid-cols-3 lg:grid-cols-4 lg:gap-6">
          <h1 className="col-span-4 text-2xl">
            <span>{commonReady && common('greeting')}, </span>
            <span className="font-medium">Sudipta</span>
          </h1>
          <Suspense fallback={
            <Skeleton className="h-60 rounded-xl col-span-3 md:col-span-2 lg:col-span-3">
            </Skeleton>
          }>
            <ProfileCard className="col-span-3 md:col-span-2 lg:col-span-3" />
          </Suspense>
          <Suspense fallback={
            <Skeleton className="h-60 rounded-xl">
            </Skeleton>
          }>
            <PodiumCard className="" />
          </Suspense>
        </div>
        <div className="flex flex-col">
          <p className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
            {t('offerings')}
          </p>
          <Suspense fallback="">
            {
              !ready ?
                <div className="grid h-full grid-cols-4 gap-6">
                  <Skeleton className="h-60 rounded-xl" />
                  <Skeleton className="h-60 rounded-xl" />
                  <Skeleton className="h-60 rounded-xl" />
                  <Skeleton className="h-60 rounded-xl" />
                </div> :

                <div className="grid h-full grid-cols-4 gap-6">
                  <GamificationOfferingsCard
                    title={t('offeringList.0.title')}
                    icon="rocket"
                    route="/gamification/performace-booster"
                    img={SPEED_QUEST}
                    description={t('offeringList.0.description')}
                  />
                  <GamificationOfferingsCard
                    title={t('offeringList.1.title')}
                    icon="graduation-cap"
                    img={LEARNING_QUEST}
                    route="/gamification/course"
                    description={t('offeringList.1.description')}
                  />
                  <GamificationOfferingsCard
                    title={t('offeringList.2.title')}
                    icon="flask-conical"
                    img={INNOVATION_QUEST}
                    route="/gamification/innovation"
                    description={t('offeringList.2.description')}
                  />
                  <GamificationOfferingsCard
                    title={t('offeringList.3.title')}
                    icon="swords"
                    img={WAR_ROOM}
                    route="/gamification/war-room"
                    description={t('offeringList.3.description')}
                  />
                </div>
            }
          </Suspense>
        </div>
        <div className="mb-4">
          <p className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
            {t('dailyQuest')}
          </p>
          <div className="grid grid-cols-2 gap-4 lg:gap-6">
            <TaskFeatureCard
              title={t('dailyQuestList.0.title')}
              route=""
              iconName="ticket-check"
              desc={t('dailyQuestList.0.description')}
              points={20}
            />
            <TaskFeatureCard
              title={t('dailyQuestList.1.title')}
              iconName="sparkles"
              points={40}
              desc={t('dailyQuestList.1.description')}
            />
            <TaskFeatureCard
              title={t('dailyQuestList.2.title')}
              route=""
              iconName="book-open-check"
              points={40}
              desc={t('dailyQuestList.2.description')}
            />
            <TaskFeatureCard
              title={t('dailyQuestList.3.title')}
              iconName="messages-square"
              points={20}
              desc={t('dailyQuestList.3.description')}
            />
          </div>
        </div>
      </Container>
    </section>
  );
};
export default GamificationEmployeeHome;
