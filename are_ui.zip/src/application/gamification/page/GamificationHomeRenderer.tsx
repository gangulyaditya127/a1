import { useAppSelector } from "@/lib/redux/hooks"
import { lazy, Suspense } from 'react'
const GamificationAdminDashboard = lazy(() => import('./admin/GamificationAdminDashboard'))
const GamificationEmployeeHome = lazy(() => import('./employee/GamificationEmployeeHome'))
const GamificationHomeRenderer = () => {
    const { role } = useAppSelector((state) => state.auth)
    console.log(role)
    if (role == "manager_2") {
        return <Suspense fallback="">
            <GamificationAdminDashboard />
        </Suspense>
    }
    if (role == "employee") {
        return <Suspense fallback="">
            <GamificationEmployeeHome />
        </Suspense>
    }
    return <>
        Un-Authorized to access the module
    </>
}
export default GamificationHomeRenderer