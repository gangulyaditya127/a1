import { getNthDateNumericFormat } from "@/lib/date.utils";
import { DailyQuestProp } from "../page/admin/GamificationAdminDailyQuestConfig";

export const DAILY_QUEST_DATA:DailyQuestProp[] = [
    {
        status: "active",
        startDate: getNthDateNumericFormat(-4),
        endDate: getNthDateNumericFormat(30),
        points: 20,
        questType: "Bucket Clearance"
    },
    {
        status: "active",
        startDate: getNthDateNumericFormat(-4),
        endDate: getNthDateNumericFormat(30),
        points: 40,
        questType: "Quality Quest"
    },
    {
        status: "active",
        startDate: getNthDateNumericFormat(-4),
        endDate: getNthDateNumericFormat(30),
        points: 40,
        questType: "Knowledge Sharer"
    },
    {
        status: "active",
        startDate: getNthDateNumericFormat(-4),
        endDate: getNthDateNumericFormat(30),
        points: 20,
        questType: "Feedback Gatherer"
    },
]