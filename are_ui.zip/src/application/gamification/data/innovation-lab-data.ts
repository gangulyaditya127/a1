import { getNthDateNumericFormat } from "@/lib/date.utils";

export const INNOVATION_LAB_DATA = [
    {
        "id": "0011",
        "title": "Automated Invoice Processing",
        "improvementType": "Automation",
        "expectedSavings": 50000,
        "approvalStatus": "pending",
        "points": 0,
        "assosiateName": "Sudhanshu Singh",
        "empID": "2096742",
        submittedOn:getNthDateNumericFormat(-1)
    },
    {
        "id": "0012",
        "title": "Simplified User Onboarding",
        "improvementType": "Simplification",
        "expectedSavings": 20000,
        "approvalStatus": "pending",
        "points": 0,
        "assosiateName": "Sudhanshu Singh",
        "empID": "2096742",
        submittedOn:getNthDateNumericFormat(-2)
    },
    {
        "id": "0013",
        "title": "Elimination of Redundant Data Entry",
        "improvementType": "Elimination",
        "expectedSavings": 30000,
        "approvalStatus": "rejected",
        "points": 0,
        "assosiateName": "Sumanta Deyasi",
        "empID": "1859343",
        submittedOn:getNthDateNumericFormat(-5)
    },
    {
        "id": "0014",
        "title": "Optimization of Supply Chain Management",
        "improvementType": "Optimization",
        "expectedSavings": 45000,
        "approvalStatus": "approved",
        "points": 75,
        "assosiateName": "Sumanta Deyasi",
        "empID": "1859343",
        submittedOn:getNthDateNumericFormat(-10)
    },
    {
        "id": "0015",
        "title": "Automated Customer Support Chatbots",
        "improvementType": "Automation",
        "expectedSavings": 60000,
        "approvalStatus": "pending",
        "points": 0,
        "assosiateName": "Sumanta Deyasi",
        "empID": "1859343",
        submittedOn:getNthDateNumericFormat(-2)
    },
    {
        "id": "0016",
        "title": "Simplification of Report Generation",
        "improvementType": "Simplification",
        "expectedSavings": 15000,
        "approvalStatus": "approved",
        "points": 30,
        "assosiateName": "Debashis Das",
        "empID": "2057483",
        submittedOn:getNthDateNumericFormat(-4)
    },
    {
        "id": "0017",
        "title": "Elimination of Manual Approval Processes",
        "improvementType": "Elimination",
        "expectedSavings": 25000,
        "approvalStatus": "rejected",
        "points": 0,
        "assosiateName": "Debashis Das",
        "empID": "2057483",
        submittedOn:getNthDateNumericFormat(-6)
    },
    {
        "id": "0018",
        "title": "Optimization of Resource Allocation",
        "improvementType": "Optimization",
        "expectedSavings": 35000,
        "approvalStatus": "approved",
        "points": 60,
        "assosiateName": "Debashis Das",
        "empID": "2057483",
        submittedOn:getNthDateNumericFormat(-12)
    }
]