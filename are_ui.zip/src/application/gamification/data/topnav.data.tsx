import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "Gamification",
    route: "/gamification",
    key: "1",
  },
];
