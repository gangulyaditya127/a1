import { IAccount } from "../features/TeamPerformanceDataGrid";

export const TEAM_PERFORMACE_DATA:IAccount[]=[
    {
      "teamname": "Finance",
      "points": 177000,
      "rank": 4,
      "ticketCount": 2000,
      "suborinates": [
        {
          "name": "APAC Finance",
          "points": 3000,
          "teamRank": 1,
          "globalRank":10,
          "ticketCount": 400,
          "employeeID": "2096742"
        },
        {
          "name": "EMEA Finance",
          "points": 2700,
          "teamRank": 2,
          "globalRank":15,
          "ticketCount": 300,
          "employeeID": "1247353"
        },
        {
          "name": "Automation & Supply Chain",
          "points": 1853,
          "teamRank": 3,
          "globalRank":25,
          "ticketCount": 100,
          "employeeID": "1247353"
        },
        {
          "name": "Regulatory Reporting",
          "points": 1774,
          "teamRank": 3,
          "globalRank":35,
          "ticketCount": 87,
          "employeeID": "43223432"
        },
        {
          "name": "Taxation & Product Control",
          "points": 1774,
          "teamRank": 4,
          "globalRank":36,
          "ticketCount": 86,
          "employeeID": "43222452"
        },
        {
          "name": "Treasury & Allocations",
          "points": 1774,
          "teamRank": 5,
          "globalRank":46,
          "ticketCount": 126,
          "employeeID": "43222452"
        },
      ]
    },
    {
        "teamname": "Citi KYC",
        "points": 467000,
        "rank": 1,
        "ticketCount": 4000,
        "suborinates":[],
    },
    {
        "teamname": "Genesis",
        "points": 377000,
        "rank": 2,
        "ticketCount": 3500,
        "suborinates":[],
    },
    {
        "teamname": "Hr",
        "points": 277000,
        "rank": 3,
        "ticketCount": 3000,
        "suborinates":[],
    },
    {
        "teamname": "Compliance",
        "points": 157000,
        "rank": 5,
        "ticketCount": 1400,
        "suborinates":[],
    },
    {
        "teamname": "Risk",
        "points": 143000,
        "rank": 6,
        "ticketCount": 1200,
        "suborinates":[],
    },
  ]