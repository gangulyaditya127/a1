export const TEAMPERFORMACEDATA = [
  {
    trend: "up",
    globalRank: {
      value: 4,
      trend: "up",
    },
    teamRank: {
      value: 1,
      trend: "up",
    },
    name: "Sudhanshu Singh",
    empid: 2096742,
    points: {
      value: 1000,
      trend: "up",
    },
    trainingCompletion: {
      value: 100,
      trend: "up",
    },
    ticketsResolved: {
      value: 150,
      trend: "down",
    },
    avgResolutionTime: {
      value: 2.1,
      trend: "up",
    },
  },
  {
    trend: "down",
    globalRank: {
      value: 7,
      trend: "down",
    },
    teamRank: {
      value: 2,
      trend: "down",
    },
    name: "Shushant Mohan",
    empid: 1097532,
    points: {
      value: 950,
      trend: "up",
    },
    trainingCompletion: {
      value: 30,
      trend: "down",
    },
    ticketsResolved: {
      value: 120,
      trend: "up",
    },
    avgResolutionTime: {
      value: 2.1,
      trend: "up",
    },
  },
  {
    trend: "up",
    globalRank: {
      value: 12,
      trend: "up",
    },
    teamRank: {
      value: 3,
      trend: "up",
    },
    name: "Priyanshu Shivdashani",
    empid: 352124,
    points: {
      value: 750,
      trend: "up",
    },
    trainingCompletion: {
      value: 100,
      trend: "up",
    },
    ticketsResolved: {
      value: 110,
      trend: "up",
    },
    avgResolutionTime: {
      value: 2.1,
      trend: "up",
    },
  },
  {
    trend: "up",
    globalRank: {
      value: 20,
      trend: "up",
    },
    teamRank: {
      value: 4,
      trend: "up",
    },
    name: "Vishal Sinha",
    empid: 4291475,
    points: {
      value: 600,
      trend: "up",
    },
    trainingCompletion: {
      value: 100,
      trend: "up",
    },
    ticketsResolved: {
      value: 70,
      trend: "down",
    },
    avgResolutionTime: {
      value: 3.1,
      trend: "down",
    },
  },
  {
    trend: "up",
    globalRank: {
      value: 32,
      trend: "up",
    },
    teamRank: {
      value: 5,
      trend: "up",
    },
    name: "Abhishek Kumar",
    empid: 9482642,
    points: {
      value: 400,
      trend: "up",
    },
    trainingCompletion: {
      value: 80,
      trend: "up",
    },
    ticketsResolved: {
      value: 42,
      trend: "down",
    },
    avgResolutionTime: {
      value: 2.4,
      trend: "down",
    },
  },
];
