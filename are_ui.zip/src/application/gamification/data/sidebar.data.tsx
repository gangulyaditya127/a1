import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

export const SIDEBAR_DATA_EMPLOYEE: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "0",
          content: "Home",
          icon: "home",
          route: "/gamification/home",
        },
        {
          key: "001",
          content: "Performance Booster",
          icon: "rocket",
          route: "/gamification/performace-booster",
        },
        {
          key: "1",
          content: "Learning Odyssey",
          icon: "graduation-cap",
          route: "/gamification/course",
        },
        {
          key: "4",
          content: "War Room",
          icon: "swords",
          route: "/gamification/war-room",
        },
        {
          key: "5",
          content: "Innovation Lab",
          icon: "flask-conical",
          route: "/gamification/innovation",
        },
        {
          key: "3",
          content: "Leaderboard",
          icon: "award",
          route: "/gamification/leaderboard",
        },
        {
          key: "444",
          content: "ARE Workshop Leaderboard",
          icon: "trophy",
          route: "/gamification/are-workshop",
        },
      ],
    },
  ],
  bottomNavList: [
    {
      key: "7",
      content: "Profile",
      icon: "circle-user-round",
      route: "/gamification/profile",
    },
    {
      key: "8",
      content: "Logout",
      icon: "log-out",
      route: "/gamification-onboard",
    },
  ],
};
export const SIDEBAR_DATA_MANAGER_2: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "g_0",
          content: "Home",
          icon: "home",
          route: "/gamification/home",
        },
        {
          key: "g_1",
          content: "Configure Performance Booster",
          icon: "rocket",
          route: "/gamification/configure-booster",
        },
        {
          key: "g_2",
          content: "Configure Learning Odyssey",
          icon: "graduation-cap",
          route: "/gamification/configure-learning",
        },
        {
          key: "g_3",
          content: "Configure Daily Quest",
          icon: "ferris-wheel",
          route: "/gamification/configure-daily-quest",
        },
        {
          key: "g_4",
          content: "War room control",
          icon: "swords",
          route: "/gamification/war-room-control",
        },
        {
          key: "g_5",
          content: "Innovation central lab",
          icon: "flask-conical",
          route: "/gamification/innovation-control",
        },
        {
          key: "a_444",
          content: "ARE Workshop Leaderboard",
          icon: "trophy",
          route: "/gamification/are-workshop",
        },
      ]
    }
  ],
  bottomNavList: [
    {
      key: "g_8",
      content: "Logout",
      icon: "log-out",
      route: "/gamification-onboard",
    },
  ],
}

