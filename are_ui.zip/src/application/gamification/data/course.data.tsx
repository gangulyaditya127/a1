import dynamicIconImports from "lucide-react/dynamicIconImports";

export const COURSE_LIST: {
  name: string;
  description: string;
  icon: keyof typeof dynamicIconImports;
  route?: string;
}[] = [
  {
    name: "DevOps Culture",
    description:
      "Through this course, you will understand the DevOps culture and its building blocks. ",
    icon: "boxes",
    route: "https://ievolveng.ultimatix.net/ievolve/coursedetails/55181",
  },
  {
    name: "Puppet 5 - Cardinal",
    description:
      "Puppet is an automated Configuration Management tool to manage infrastructure on physical or virtual machines.",
    icon: "memory-stick",
    route: "https://play.fresco.me/course/280",
  },
  {
    name: "Node.js Serenade",
    description:
      "In this course, we will learn how to build enterprise grade Node.js application.",
    icon: "server",
    route: "https://play.fresco.me/course/355",
  },
  {
    name: "Threat Hunting",
    description:
      "In this course, you will explore the world of 'Threat Hunting'. The course explains the procedure to perform Threat Hunting.",
    icon: "server",
    route: "https://ievolveng.ultimatix.net/ievolve/coursedetails/57667",
  },
  {
    name: "Azure Essentials",
    description:
      "This course will introduce you to the diverse services and products offered by Azure.",
    icon: "server-cog",
    route: "https://play.fresco.me/course/200",
  },
];
