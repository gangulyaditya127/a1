import { GamificationLearningDataGridProps } from "../page/admin/GamificationAdminLearning";

export const GAMIFICATION_LEARNING_DATA:GamificationLearningDataGridProps[]=[
    {
       name:"Sudhanshu Singh",
       empId:"2096742",
       role:"Developer",
       noOfAssignedCourse:12,
       noOfCompletedCourse:9,
       noOfPendingCourse:3,
       completionPercentage:75 
    },
    {
        "name": "John Smith",
        "empId": "1004567",
        "role": "Support Engineer",
        "noOfAssignedCourse": 10,
        "noOfCompletedCourse": 7,
        "noOfPendingCourse": 3,
        "completionPercentage": 70
    },
    {
        "name": "Jane Doe",
        "empId": "2345678",
        "role": "Application Support Analyst",
        "noOfAssignedCourse": 8,
        "noOfCompletedCourse": 8,
        "noOfPendingCourse": 0,
        "completionPercentage": 100
    },
    {
        "name": "Mike Johnson",
        "empId": "3456789",
        "role": "Production Support Manager",
        "noOfAssignedCourse": 12,
        "noOfCompletedCourse": 9,
        "noOfPendingCourse": 3,
        "completionPercentage": 75
    },
    {
        "name": "Emily Davis",
        "empId": "4567890",
        "role": "Database Administrator",
        "noOfAssignedCourse": 9,
        "noOfCompletedCourse": 7,
        "noOfPendingCourse": 2,
        "completionPercentage": 78
    },
    {
        "name": "Michael Brown",
        "empId": "5678901",
        "role": "Systems Administrator",
        "noOfAssignedCourse": 11,
        "noOfCompletedCourse": 10,
        "noOfPendingCourse": 1,
        "completionPercentage": 91
    }
]