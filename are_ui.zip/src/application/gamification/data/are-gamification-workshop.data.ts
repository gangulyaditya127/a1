export const ARE_WORKSHOP_DATA: any = {
    "teams": [
        {
            "team_name": "Reliability Royals (Team 1)",
            "members": [
                {
                    "name": "Srivatsan KC",
                    "id": "390393",
                    "email": "srivatsan.kc@tcs.com",
                    "location": "Bangalore"
                },
                {
                    "name": "Deepak Sundaresan",
                    "id": "203740",
                    "email": "deepak.sundaresan@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Mr. Jagan Mohan P",
                    "id": "2521200",
                    "email": "p.jaganmohan@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Brajesh Varma Pandalam",
                    "id": "120606",
                    "email": "b.varma@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Amit Kumar",
                    "id": "202285",
                    "email": "amit34.k@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Atul Pevekar",
                    "id": "172749",
                    "email": "debasish.bhuniya@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Deblina Pathak",
                    "id": "1918091",
                    "email": "deblina.p@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Shankhanil Ghosh",
                    "id": "2143475",
                    "email": "ghosh.shankhanil@tcs.com",
                    "location": "Kolkata"
                }
            ],
            "round_1": 5,
            "round_2": 4,
            "round_3": 5,
            "round_4": 3,
            "round_5": 5,
            "round_6": 9 + ((16 + 16 + 7) * 3),
            "round_7": 13,
            "round_8": 3,
            "round_9": 2 * 2,
            "round_10": 37,
            "total": null,
            "rank": null
        },
        {
            "team_name": "Incident Eliminators (Team 2)",
            "members": [
                {
                    "name": "Rajasekar Jayakumar",
                    "id": "245275",
                    "email": "rajasekar.jayakumar@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Ramasubramanian Kulandan",
                    "id": "363923",
                    "email": "ramasubramanian.kulandan@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Karthikeyan R",
                    "id": "160940",
                    "email": "karthi.r@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Samanwita Mukherjee",
                    "id": "2382608",
                    "email": "samanwita.mukherjee@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Samarpan Dutta",
                    "id": "332492",
                    "email": "samarpan.dutta@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Tushar Sharma",
                    "id": "290428",
                    "email": "s.jagannathan@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Syed Shadab Hussain",
                    "id": "272798",
                    "email": "syedshadab.hussain@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Sumanta Datta",
                    "id": "1081373",
                    "email": "sumanta.datta@tcs.com",
                    "location": "Kolkata"
                }
            ],
            "round_1": 7,
            "round_2": 5,
            "round_3": 5,
            "round_4": 4,
            "round_5": 4,
            "round_6": 3 + ((7 + 2 + 10) * 3),
            "round_7": 3,
            "round_8": 1,
            "round_9": 0,
            "round_10": 37,
            "total": null,
            "rank": null
        },
        {
            "team_name": "Downtime Daredevil (Team 3)",
            "members": [
                {
                    "name": "Sriram G",
                    "id": "114779",
                    "email": "g.sriram@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Victor Armstrong",
                    "id": "122667",
                    "email": "victor.armstrong@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Jagannathan S",
                    "id": "125082",
                    "email": "s.jagannathan@tcs.com",
                    "location": "Coimbatore"
                },
                {
                    "name": "Debasish Bhuniya",
                    "id": "899344",
                    "email": "debasis.bhuniya@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Devjeet Sarkar",
                    "id": "141399",
                    "email": "devjeet.sarkar@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Abu Ahmed Bakker",
                    "id": "2068267",
                    "email": "abuahmed.bakker@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Santanu Ghosal",
                    "id": "876588",
                    "email": "santanu.ghosal@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Soumadeep Roy",
                    "id": "2285922",
                    "email": "roy.soumadeep@tcs.com",
                    "location": "Kolkata"
                }
            ],
            "round_1": 8,
            "round_2": 4,
            "round_3": 4,
            "round_4": 4,
            "round_5": 5,
            "round_6": 36 + ((7 + 14 + 3) * 3),
            "round_7": 3,
            "round_8": 3,
            "round_9": 0,
            "round_10": 33,
            "total": null,
            "rank": null
        },
        {
            "team_name": "Uptime Super Kings (Team 4)",
            "members": [
                {
                    "name": "Anil Kumar M P",
                    "id": "1025922",
                    "email": "anilkumar.mancheripalliyalil@tcs.com",
                    "location": "Kochi"
                },
                {
                    "name": "Ms. Mohana S",
                    "id": "181488",
                    "email": "priya.mohana5@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Ms. Devi S",
                    "id": "2191348",
                    "email": "s.devi13@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Anindya Hazra",
                    "id": "342736",
                    "email": "anindya.hazra@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Somnath Chatterjee",
                    "id": "1313658",
                    "email": "somnath.c2@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Ananyo Bondyopadhyay",
                    "id": "1627874",
                    "email": "ananyo.b1@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Sumanta Deyashi",
                    "id": "2059225",
                    "email": "sumanta.deyashi@tcs.com",
                    "location": "Kolkata"
                }
            ],
            "round_1": 9,
            "round_2": 5,
            "round_3": 2,
            "round_4": 2,
            "round_5": 4,
            "round_6": 15 + (1 * 3),
            "round_7": 6,
            "round_8": 5,
            "round_9": 0,
            "round_10": 32,
            "total": null,
            "rank": null
        },
        {
            "team_name": "Failover Fighters (Team 5)",
            "members": [
                {
                    "name": "Gyan Singh",
                    "id": "1368574",
                    "email": "gyan.singh1@tcs.com",
                    "location": "Pune"
                },
                {
                    "name": "Mr. Gopi Kumar",
                    "id": "2189393",
                    "email": "gopi.kumar@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Ms. Prachee Dash",
                    "id": "251174",
                    "email": "prachee.dash@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Swati Saha",
                    "id": "196311",
                    "email": "swati.saha@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Ujjwal Syangbo",
                    "id": "370541",
                    "email": "ujjwal.syangbo@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Sanjoy Santra",
                    "id": "167214",
                    "email": "sanjoy.santra@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "MD Islam",
                    "id": "1120657",
                    "email": "md.ai@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Angitha Thuvassery",
                    "id": "2557637",
                    "email": null,
                    "location": "Kolkata"
                }
            ],
            "round_1": 8,
            "round_2": 5,
            "round_3": 3,
            "round_4": 4,
            "round_5": 5,
            "round_6": (30+6+12),
            "round_7": 7,
            "round_8": 3,
            "round_9": 2 * 2,
            "round_10": 36,
            "total": null,
            "rank": null
        },
        {
            "team_name": "The Load Balancers (Team 6)",
            "members": [
                {
                    "name": "Sathiesh Kumar E",
                    "id": "565184",
                    "email": "sathieshkumar.e@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Bikash Kumar Dubey",
                    "id": "726076",
                    "email": "bikash.dubey@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Minni Koda",
                    "id": "128132",
                    "email": "kodali.sunitha@tcs.com",
                    "location": "Chennai"
                },
                {
                    "name": "Prithwish Aich",
                    "id": "224819",
                    "email": "prithwish.aich@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Md Basir Alam",
                    "id": "1583669",
                    "email": "mdbasir.alam@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Naga Siva Prabhavathi Ande",
                    "id": "393811",
                    "email": "ande.prabhavathi@tcs.com",
                    "location": "Mumbai"
                },
                {
                    "name": "Aditya Ganguly",
                    "id": "1334398",
                    "email": "aditya.ganguly@tcs.com",
                    "location": "Kolkata"
                },
                {
                    "name": "Rincy John",
                    "id": "1079014",
                    "email": null,
                    "location": "Kolkata"
                }
            ],
            "round_1": 7,
            "round_2": 5,
            "round_3": 3,
            "round_4": 2,
            "round_5": 3,
            "round_6": 16 * 3,
            "round_7": 9,
            "round_8": 5, //5
            "round_9": 2 * 2,
            "round_10": 31,
            "total": null,
            "rank": null
        }
    ]
}