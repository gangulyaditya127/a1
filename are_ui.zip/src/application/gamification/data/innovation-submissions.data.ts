import { InnovationLabSubmissionProp } from "../page/employee/GamificationInnovationLabSubmissions";

export const IDEA_SUBMISSION_DATA:InnovationLabSubmissionProp[]=[
    {
        "id": "0011",
        "title": "Automated Invoice Processing",
        "improvementType": "Automation",
        "expectedSavings": 50000,
        "approvalStatus": "pending",
        "points": 0
    },
    {
        "id": "0012",
        "title": "Simplified User Onboarding",
        "improvementType": "Simplification",
        "expectedSavings": 20000,
        "approvalStatus": "approved",
        "points": 50
    },
    {
        "id": "0013",
        "title": "Elimination of Redundant Data Entry",
        "improvementType": "Elimination",
        "expectedSavings": 30000,
        "approvalStatus": "rejected",
        "points": 0
    },
    {
        "id": "0014",
        "title": "Optimization of Supply Chain Management",
        "improvementType": "Optimization",
        "expectedSavings": 45000,
        "approvalStatus": "approved",
        "points": 75
    },
    {
        "id": "0015",
        "title": "Automated Customer Support Chatbots",
        "improvementType": "Automation",
        "expectedSavings": 60000,
        "approvalStatus": "pending",
        "points": 0
    },
    {
        "id": "0016",
        "title": "Simplification of Report Generation",
        "improvementType": "Simplification",
        "expectedSavings": 15000,
        "approvalStatus": "approved",
        "points": 30
    },
    {
        "id": "0017",
        "title": "Elimination of Manual Approval Processes",
        "improvementType": "Elimination",
        "expectedSavings": 25000,
        "approvalStatus": "rejected",
        "points": 0
    },
    {
        "id": "0018",
        "title": "Optimization of Resource Allocation",
        "improvementType": "Optimization",
        "expectedSavings": 35000,
        "approvalStatus": "approved",
        "points": 60
    }
]