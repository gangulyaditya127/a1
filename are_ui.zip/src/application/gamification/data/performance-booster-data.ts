import { getNthDateNumericFormat } from "@/lib/date.utils";
import { SpeedBoosterProps } from "../page/admin/GamificationAdminPerformanceBoosterConfig";

export const PERFORMACE_BOOSTER_DATA:SpeedBoosterProps[]=[
    {
        title:"Learning Quest",
        description:"Complete atleast 3 courses from Learnign Odyssey before 07/20/2024 to get 20 extra points.",
        status:"active",
        startDate:getNthDateNumericFormat(-8),
        endDate:getNthDateNumericFormat(3),
        points:20,
        questType:"Learning Odyssys"
    },
    {
        title:"Innovation Quest",
        description:"Submit and get approval for atleast 1 innovation idea before 09/20/2024 to get 50 extra points.",
        status:"active",
        startDate:getNthDateNumericFormat(-8),
        endDate:getNthDateNumericFormat(5),
        points:50,
        questType:"Innovation Lab"
    },
]