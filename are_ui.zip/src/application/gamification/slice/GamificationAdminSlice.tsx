import { PayloadAction, createSlice } from "@reduxjs/toolkit";

type Option = {
    value: string;
    label: string;
};
const kpiList: Option[] = [
    {
        value: "WarRoom",
        label: "War Room"
    },
    {
        value: "InnovationLab",
        label: "Innovation Lab"
    },
    {
        value: "LearningOdysyss",
        label: "Learning Odysyss"
    },
]
const teamList: Option[] = [
    "APAC Finance",
    "EMEA Finance",
    "Automation & Supply Chain",
    "Regulatory Reporting",
    "Taxation & Product Control",
    "Treasury & Allocation",
].map(el => ({ value: el.split(" ").join(""), label: el }))

type GamificationKPIComparisionGraphDataProps = {

}
type GamificationKPIComparisionFilterDataProps = {
    kpi: any[],
    team: any[]
}

type TeamKPITrendFiltersProps={
    kpi:string,
    duration:string
}

type GamificationAdminSliceProps = {
    gamificationKPIComparisionGraphData: GamificationKPIComparisionGraphDataProps[],
    gamificationKPIComparisionFilterData: GamificationKPIComparisionFilterDataProps,
    gamificationTeamKPITrendFilterData:TeamKPITrendFiltersProps
}

const initialState: GamificationAdminSliceProps = {
    gamificationKPIComparisionGraphData: [],
    gamificationKPIComparisionFilterData: {
        kpi: kpiList.map(el=>el.value),
        team: teamList.filter((_,i)=>i<5).map(el=>el.value)
    },
    gamificationTeamKPITrendFilterData:{
        kpi:"ticket",
        duration:"30"
    }
}

const gamificationAdminSlice = createSlice({
    name: "gamificationAdminSlice",
    initialState,
    reducers: {
        updateGamificationKPIComparisionFilterKPI: (state, action: PayloadAction<any>) => {
            state.gamificationKPIComparisionFilterData.kpi = action.payload
        },
        updateGamificationKPIComparisionFilterTeam: (state, action: PayloadAction<any>) => {
            state.gamificationKPIComparisionFilterData.team = action.payload
        },
        updateGamificationTeamKPITrendFilterKPI:(state,action:PayloadAction<string>)=>{
            state.gamificationTeamKPITrendFilterData.kpi=action.payload
        },
        updateGamificationTeamKPITrendFilterDuration:(state,action:PayloadAction<string>)=>{
            state.gamificationTeamKPITrendFilterData.duration=action.payload
        },

    },
});

export const {
    updateGamificationKPIComparisionFilterKPI,
    updateGamificationKPIComparisionFilterTeam,
    updateGamificationTeamKPITrendFilterKPI,
    updateGamificationTeamKPITrendFilterDuration
} = gamificationAdminSlice.actions;

export default gamificationAdminSlice.reducer;
