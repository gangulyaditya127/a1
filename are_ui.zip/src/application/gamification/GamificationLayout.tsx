import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { SIDEBAR_DATA_EMPLOYEE, SIDEBAR_DATA_MANAGER_2 } from "./data/sidebar.data";
import { useTranslation } from "react-i18next";

function GamificationLayout() {
  const dispatch = useAppDispatch();
  const { role } = useAppSelector((state) => state.auth)
  const { t, ready, i18n } = useTranslation('/gamification/common')
  useEffect(() => {
    if (role && ready) {
      dispatch(updateSideBarNavigation(role == "manager_2" ? SIDEBAR_DATA_MANAGER_2 : SIDEBAR_DATA_EMPLOYEE));
      dispatch(updateTopNavigation({ navList: (t('topNav', { returnObjects: true }) as any), isHome: false }));
    }
  }, [role, i18n.language]);
  return <Outlet />;
}
export default GamificationLayout;
