import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet } from "react-router-dom";

const ProtectedRouteManagerL2 = () => {
  const role = useAppSelector((state) => state.auth.role);
  return role=="manager_2" ? (
    <Outlet />
  ) : (
    <Navigate to={`/unauthorized`} replace={true}/>
  );
};

export default ProtectedRouteManagerL2;
