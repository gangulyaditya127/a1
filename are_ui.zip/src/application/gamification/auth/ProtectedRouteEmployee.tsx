import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet } from "react-router-dom";

const ProtectedRouteEmployee = () => {
  const role = useAppSelector((state) => state.auth?.role);
  return role == "employee" ? (
    <Outlet />
  ) : (
    <Navigate to={`/unauthorized`} replace={true} />
  );
};

export default ProtectedRouteEmployee;
