import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link, useNavigate } from "react-router-dom";
import { Icon } from "@/components/ui/icon";
import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { SlashIcon } from "lucide-react";
import { cn } from "@/lib/tailwind.utils";
import { updateLoginStatus, updateRole } from "@/auth/slice/authSlice";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
const GamificationUserOnboard = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate()
  const isAdmin = useAppSelector((state) => state.auth.isAdmin)
  const rawUserDetails = useAppSelector((state) => state.auth.rawUserDetails)
  const { t, ready } = useTranslation('/gamification/onboard')
  useEffect(() => {
    dispatch(
      updateSideBarNavigation({
        hasSideBar: false,
        sideBarNavList: [],
        bottomNavList: [],
      }),
    );
    dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
  }, []);
  const handleManger1Login = () => {
    dispatch(updateLoginStatus({ isLoggedIn: true, userName: 'gamification_guest', isAdmin: isAdmin ? isAdmin : 'N', rawUserDetails }))
    dispatch(updateRole({ role: "manager_2" }))
    navigate('/gamification/home')
  }
  const handleEmployeeLogin = () => {
    dispatch(updateLoginStatus({ isLoggedIn: true, userName: 'gamification_guest', isAdmin: isAdmin ? isAdmin : 'N', rawUserDetails }))
    dispatch(updateRole({ role: "employee" }))
    navigate('/gamification/home')
  }
  const handleAREWorkshop = () => {
    dispatch(updateLoginStatus({ isLoggedIn: true, userName: 'gamification_guest', isAdmin: isAdmin ? isAdmin : 'N', rawUserDetails }))
    dispatch(updateRole({ role: "employee" }))
    navigate('/gamification/are-workshop')
  }



  return (
    <section className="py-16 pb-40">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/operate" />
        {ready && <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('breadcrumb.0')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/operate">{t('breadcrumb.1')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('breadcrumb.2')}​</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>}
        {
          !ready ?
            <div className="grid grid-cols-2 border-t mt-6">
              <Skeleton />
              <Skeleton />
            </div>
            :
            <>
              <div onClick={handleAREWorkshop} className="w-full rounded-md cursor-pointer mb-6 mt-4 text-sm h-8 bg-secondary/90 flex items-center px-4 justify-between col-span-2">
                <p className="font-medium hover:underline">ARE Gamified Workshop - Kolkata</p>
                <div className="flex gap-1 items-center text-xs">
                  {/* <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                  </span> */}
                  <p className="font-medium ">17/03/2025-19/03/2025</p>
                </div>
              </div>
              <div className="grid grid-cols-2 border-t mt-6">
                <Feature title={t('teamMember.title')} description={t('teamMember.description')} icon={<Icon name="user" />} index={0} onClick={handleEmployeeLogin} />
                <Feature title={t('manager.title')} description={t('manager.description')} icon={<Icon name="cctv" />} index={1} onClick={handleManger1Login} />
              </div>
            </>
        }
      </Container>
      <Meteors number={5} />
    </section>
  );
};
export default GamificationUserOnboard;

const Feature = ({
  title,
  description,
  icon,
  index,
  onClick
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  index: number;
  className?: string
  onClick?: () => void
}) => {
  return (
    <div
      className={cn(
        "flex flex-col lg:border-r  py-10 relative group/feature dark:border-neutral-800",
        (index === 0 || index === 4) && "lg:border-l dark:border-neutral-800",
        index < 4 && "lg:border-b dark:border-neutral-800 cursor-pointer"
      )}
      onClick={onClick}
    >
      {index < 4 && (
        <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-t from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none" />
      )}
      {index >= 4 && (
        <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-b from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none" />
      )}
      <div className="mb-4 relative z-10 px-10 text-neutral-600 dark:text-neutral-400">
        {icon}
      </div>
      <div className="text-lg font-bold mb-2 relative z-10 px-10">
        <div className="absolute left-0 inset-y-0 h-6 group-hover/feature:h-8 w-1 rounded-tr-full rounded-br-full bg-neutral-300 dark:bg-neutral-700 group-hover/feature:bg-blue-500 transition-all duration-200 origin-center" />
        <span className="group-hover/feature:translate-x-2 transition duration-200 inline-block text-neutral-800 dark:text-neutral-100">
          {title}
        </span>
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-xs relative z-10 px-10">
        {description}
      </p>
    </div>
  );
};
