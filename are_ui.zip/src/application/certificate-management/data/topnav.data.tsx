import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Certificate Mangement",
        route: "/certificate-management",
        key: "1",
    },
]