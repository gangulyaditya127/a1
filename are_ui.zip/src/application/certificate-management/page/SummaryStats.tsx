import { FileText } from "lucide-react";
type SummaryStatsProps={onClick:()=>void};
const data = [
  { label: "Total Certificates", value: 52517 },
  { label: "Active Certificates till 2024", value: 12266 },
  { label: "Active Certificates till 2025", value: 38989 },
];

const SummaryStats = ({onClick}:SummaryStatsProps) => {
  return (
    <div className="flex flex-wrap gap-4">
      {data.map((item, idx) => (
        <div
          key={idx} onClick={onClick}
          className="bg-gray-200 dark:bg-gray-700 shadow px-4 py-2 rounded w-fit flex items-center gap-3"
        >
          <FileText className="text-gray-500 dark:text-gray-300" size={20} />
          <div>
            <div className="text-sm">{item.label}</div>
            <div className="text-lg font-bold">{item.value}</div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SummaryStats;

