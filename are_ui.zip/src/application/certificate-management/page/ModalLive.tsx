import { X } from "lucide-react";
type ModalProps = {
    isVisible: boolean;
    onClosed: () => void;
  };
  
  const ModalLive: React.FC<ModalProps> = ({ isVisible, onClosed }) => {
    if (!isVisible) return null;
  
  
  
  
    return (
        <div className="fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm flex justify-center items-center z-50">
        <div className="bg-gray-200 dark:bg-gray-700 p-6 rounded-lg w-full max-w-3xl relative">
          {/* Close Icon */}
          <button
            onClick={onClosed}
            className="absolute top-2 right-2 text-gray-500 hover:text-red-500"
          >
            <X size={30} />
          </button>
  
          {/* Form */}
          <h2 className="text-lg font-semibold mb-4">Enter Certificate Details</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
            <input
              type="text"
              placeholder="Enter Application Name *"
              className="dark:text-black border border-gray-300 dark:border-gray-700 rounded px-3 py-2 w-full"
            />
            <input
              type="text"
              placeholder="Enter URL *"
              className=" dark:text-black border border-gray-300 dark:border-gray-700 rounded px-3 py-2 w-full"
            />
            <input
              type="text"
              placeholder="Enter Port *"
              className="dark:text-black border border-gray-300 dark:border-gray-700 rounded px-3 py-2 w-full"
            />
          </div>
  
          {/* Submit Button */}
          <div className="mt-6 flex justify-center">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded">
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  export default ModalLive;
  