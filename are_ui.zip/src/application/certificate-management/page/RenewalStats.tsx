const stats = [
    { label: "Renewed In Last 7 Days", value: 28, color: "bg-green-600" },
    { label: "Expired In Last 7 Days", value: 7, color: "bg-red-600" },
  ];
  type RenewalStats={onClick:()=>void};
  const RenewalStats = ({ onClick}:RenewalStats  ) => {
    return (
      <div className="flex flex-row gap-4 ">
        {stats.map((item, idx) => (
          <div
            key={idx}
            onClick={onClick} 
            className="cursor-pointer gap-4 flex flex-col h-[210px] justify-center items-center p-4 rounded shadow bg-gray-200 dark:bg-gray-700 hover:shadow-md group relative"
          >
            {/* Tooltip */}
           
                <div className="absolute top-8 left-1 px-1 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition whitespace-nowrap z-20">
                  {item.value} certificates {item.label}
                </div> 
                
           
            <div
              className={`w-12 h-12 flex  items-center justify-center rounded-full text-white font-bold ${item.color} shadow-md group-hover:scale-110 transition`}
            >
              {item.value}
            </div>
            <div className="ml-4 text-sm font-semibold">{item.label}</div>
          </div>
      
        ))}
      </div>
    );
  };
  
  export default RenewalStats;
  