import { Tabs, TabsList, TabsTrigger } from "@radix-ui/react-tabs";
import { useState } from "react";
import SummaryStats from "./SummaryStats";
import ModalDetails from "./ModalDetails";
import { TabsContent } from "@/components/ui/tabs";
import ExpirationCards from "./ExpirationCards";
import RenewalStats from "./RenewalStats";
import CertificateTable from "./CertificateTable";
import CertificateRenew from "./CertificatePlannedToRenew";
import ChartDashboard from "./Chart";
import ModalLive from "./ModalLive";
import SupportChartsDashboard from "./HorizontalChart";
const Dashboard=()=>{
    const [modalVisible, setModalVisible] = useState(false);
    const [modalLive, setModalLive] = useState(false);
  const openModal = () => setModalVisible(true);
  const closeModal = () => setModalVisible(false);
  const openModalLive = () => setModalLive(true);
  const closeModalLive = () => setModalLive(false);
  const [selectedTab, setSelectedTab] = useState("");

    return(
<div className="p-4 ml-2">
<Tabs className="space-y-4" value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="flex-x-4" >
          <TabsTrigger value="" className="px-2 py-1 rounded-3xl font-normal hover:bg-purple-400 uppercase tracking-wider data-[state=active]:bg-purple-100 data-[state=active]:bg-purple-500 data-[state=active]:text-white dark:font-normal ">
            Dashboard
          </TabsTrigger>
          </TabsList>
          <TabsContent value="">
          <div className="flex flex-wrap gap-10 space-y-2">
            <SummaryStats onClick={openModal} />
            <ModalDetails visible={modalVisible} onClose={closeModal} />
            <div className="py-1 px-40 ">
           <button
                onClick={openModalLive}
                className=" bg-green-500 py-2 px-2 text-white rounded-xl hover:bg-green-800 animate-pulse"
              >
                Live Certificate Status
              </button></div>
              <ModalLive isVisible={modalLive} onClosed={closeModalLive} />
          </div>
          <div className="flex flex-col gap-4 mt-12">
  <div className="flex flex-wrap gap-4 items-start">
    {/* Upcoming Expiration */}
    <div className="flex-1">
      <ExpirationCards onClick={openModal} />
    </div>

    {/* Renewed + Expired side by side */}
    <div className="gap-4 min-w-[350px]">
      <RenewalStats onClick={openModal} />
    </div>
  </div>
</div>
<div className="mb-4">
<CertificateTable /></div>
<div className="mt-8">
<ChartDashboard />
</div>
<div className="mt-8">
<SupportChartsDashboard />
</div>
<div className="mt-8">
<CertificateRenew />
</div>


        </TabsContent>



          </Tabs>
          
          </div>
    );
};
export default Dashboard;