import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { Outlet } from "react-router-dom";

import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { TOP_NAV_LIST } from "@/application/certificate-management/data/topnav.data";
import SIDEBAR_DATA from "@/application/certificate-management/data/sidenav.data";




export default function CertificateMgmtLayout() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(updateTopNavigation({
            navList: TOP_NAV_LIST,
            isHome: false,
            isAMS: false
        }))
        dispatch(
            updateSideBarNavigation(SIDEBAR_DATA)
        )
    }, [])
    

    return <Outlet/>
}