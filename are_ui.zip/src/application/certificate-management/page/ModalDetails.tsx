import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/tailwind.utils";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
const ModalDetails = ({ visible, onClose }:any) => {
    if (!visible) return null;
  
    const rows = [
      {
        dn:"O-Citigroup Inc.,C=BS",
        serialnumber:"6900000F6C66",
        lob:"Capital Investments",
        startdate: "13/04/23",
        expirationdate:"13/04/25",
        owner: "Sampat Therala",
        csiID:"175223",
        email: "MICROSOFT",
        vendor: "MICROSOFT",
        manager: "Sofia Jones Nathan",
        lead: "Venkata Uttam Chunduri",
        remarks: "",
      },
      {
        dn:"O-Citigroup Inc.,C=BS",
        serialnumber:"6900000F6C66",
        lob:"Capital Investments",
        startdate: "13/04/23",
        expirationdate:"13/04/25",
        owner: "Sampat Therala",
        csiID:"175223",
        email: "MICROSOFT",
        vendor: "MICROSOFT",
        manager: "Sofia Jones Nathan",
        lead: "Venkata Uttam Chunduri",
        remarks: "",
      },

      
    ];

    const exportToExcel = () => {
        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Certificate Expiry");
    
        const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
        const fileData = new Blob([excelBuffer], { type: "application/octet-stream" });
        saveAs(fileData, "certificate_details.xlsx");
      };
  
    return (
      <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
        <div className="bg-white dark:bg-gray-800 w-11/12 max-w-5xl rounded shadow-lg p-4">
          <h2 className="text-lg font-semibold mb-4">Certificate Details</h2>
          <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
            <Table className="w-full text-sm border border-gray-200 dark:border-gray-600">
              <TableHeader className="bg-violet-500 text-white">
                <TableRow>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">DN</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Serial Number</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">LOB</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Start Date</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Expiration Date</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">CERT Owner Name</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">CERT Owner Email</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">CSI ID</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Vendor</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Support Manager</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Support Lead</TableHead>
                  <TableHead className="place-items-center  text-center border border-gray-300 text-white">Remarks</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((row, idx) => (
                  <TableRow key={idx} className={cn(
                                                            "group/team-row border-0",
                                                            idx % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                                                          )}>
                    <TableCell className="place-items-center  text-center">{row.dn}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.serialnumber}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.lob}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.startdate}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.expirationdate}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.owner}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.email}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.csiID}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.vendor}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.manager}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.lead}</TableCell>
                    <TableCell className="place-items-center  text-center">{row.remarks}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button className="bg-blue-500 text-white px-3 py-1 rounded" onClick={exportToExcel} >
              Export to Excel
            </button>
            <button className="bg-red-500 text-white px-3 py-1 rounded" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  export default ModalDetails;
  