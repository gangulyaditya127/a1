
type ExpirationCardsProps={onClick:()=>void};
const data = [
    { label: "3d", value: 81, color: "bg-red-500" },
    { label: "7d", value: 249, color: "bg-red-600" },
    { label: "30d", value: 1394, color: "bg-yellow-500" },
    { label: "60d", value: 2334, color: "bg-green-700" },
    { label: "90d", value: 2380, color: "bg-blue-400" },
  ];
  
  const ExpirationCards = ({ onClick}:ExpirationCardsProps ) => {
    return (
      <div className="bg-gray-200 dark:bg-gray-700 rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-6">Upcoming Expiration</h2>

      <div className="relative mt-8">
        {/* Horizontal line connecting below circles but above labels */}
        <div className="absolute top-[80px] left-0 w-full h-0.5 bg-gray-300 dark:bg-gray-600 z-0" />

        <div className="flex justify-between items-end relative z-10">
          {data.map((item, idx) => (
            <div key={idx} className="flex flex-col items-center group cursor-pointer w-full" onClick={onClick}>
              
              {/* Tooltip */}
              <div className="relative mb-2 group">
                <div className="absolute -top-8 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition whitespace-nowrap z-20">
                  {`${item.value} certificates expiring in upcoming ${item.label}ays`}
                </div>

                {/* Circle */}
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-bold ${item.color} shadow-md group-hover:scale-110 transition`}
                >
                  {item.value}
                </div>
              </div>

              {/* Short vertical line down to horizontal */}
              <div className="h-5 w-0.5 bg-gray-400 dark:bg-gray-500 mb-2" />

              {/* Label under the horizontal line */}
              <div className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>

  
    );
  };
  
  export default ExpirationCards;
 
  