import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as BarTooltip, Legend as BarLegend,
    ResponsiveContainer, PieChart, Pie, Cell,
    Legend ,Tooltip
  } from "recharts";
  // Sample static data
  const barData = [
    { region: "Other", MAR: 900, APR: 1800, MAY: 1500, JUN: 300 },
    { region: "NAM", MAR: 100, APR: 300, MAY: 500, JUN: 100 },
    { region: "APAC", MAR: 100, APR: 300, MAY: 500, JUN: 100 },
    { region: "EMEA", MAR: 100, APR: 100, MAY: 150, JUN: 150 },
    { region: "PBWM", MAR: 0, APR: 0, MAY: 0, JUN: 0 },
  ];
  
  const pieData = [
    { name: "MICROSOFT", value: 95.4, color: "#00674F" },
    { name: "VERISIGN", value: 4.37, color: "#facc15" },
    { name: "OTHER", value: 0.50, color: "#D3D3D3" },
  ];
  
  const ChartDashboard = () => {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Bar Chart */}
        <div className="bg-gray-200 dark:bg-gray-700 p-4 rounded shadow ">
          <h2 className="text-lg font-semibold mb-4 place-items-center  text-center">Upcoming Expiration - Next 90 Days Region Wise</h2>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={barData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="region" stroke="#D3D3D3" />
              <YAxis domain={[0,'dataMax+50']} stroke="#D3D3D3" />
              <BarTooltip />
              <BarLegend />
              <Bar dataKey="MAR" fill="#60a5fa" />
              <Bar dataKey="APR" fill="#86efac" />
              <Bar dataKey="MAY" fill="#facc15" />
              <Bar dataKey="JUN" fill="#f472b6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
  
        {/* Pie Chart */}
        <div className="bg-gray-200 dark:bg-gray-700 p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-4 place-items-center  text-center ">Vendor-wise Upcoming Expirations - Next 90 Days</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                outerRadius={100}
                dataKey="value"
                label
                labelLine
                stroke="none"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip/>
              <Legend iconType="circle" layout="vertical" align="right" verticalAlign="top" />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  };
  
  export default ChartDashboard;
  