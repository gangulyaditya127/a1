import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/tailwind.utils";
import styles from "../style/certificatemanagement.module.css";

const tableData = [
  { domain: "Banking Lenging & Trust", "Mar25": 14, "7D": 12, "30D": 93, "60D": 82, "90D": 196, "Aug25":210, "Sep25":150,"Oct25":120, total: 397 },
  { domain: "Capital Investments", "Mar25": 1, "7D": 3, "30D": 15, "60D": 20, "90D": 38,"Aug25":210, "Sep25":150,"Oct25":120, total: 77 },
  { domain: "Cards", "Mar25": 0, "7D": 0, "30D": 0, "60D": 0, "90D": 0, "Aug25":210, "Sep25":150,"Oct25":120, total: 0 },
  { domain: "DWH", "Mar25": 2, "7D": 4, "30D": 23, "60D": 35, "90D": 54,"Aug25":210, "Sep25":150,"Oct25":120, total: 118 },
  { domain: "Data Services", "Mar25": 2, "7D": 4, "30D": 23, "60D": 35, "90D": 54, "Aug25":210, "Sep25":150,"Oct25":120,total: 118 },
  { domain: "Total", "Mar25": 17, "7D": 19, "30D": 23, "60D": 35, "90D": 54, "Aug25":210, "Sep25":150,"Oct25":120,total: 118 },
 
];

const CertificateRenew = () => {
  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(tableData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Certificate Expiry");

    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(fileData, "certificate_expiry.xlsx");
  };

  return (
    <div className={`${styles.scrollbarCustom} mt-8 bg-gray-200 dark:bg-gray-700 rounded-lg shadow p-4 sticky top-0 overflow-y-scroll h-80`}>
           <div className="flex justify-between items-center mb-4">
      <h2 className="text-lg font-semibold">Certificate Planned to Renew</h2>
        <button
          onClick={exportToExcel}
          className="bg-green-600 text-white px-2 py-2 rounded hover:bg-green-700"
        >
          Export To Excel
        </button>
      </div>
<div className="">
      <Table className="w-full border border-gray-200">
        <TableHeader className="bg-violet-500">
             <TableRow>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">LOBName</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Mar25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">April25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">May25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Jun25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Jul25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Aug25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Sep25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Oct25</TableHead>
            <TableHead className="place-items-center  text-center border border-gray-300 text-white">Total Count</TableHead>
            </TableRow>
        </TableHeader>
        
        <TableBody>
          {tableData.map((row, idx) => (
            <TableRow key={idx}  className={cn(
                                          "group/team-row border-0",
                                          idx % 2 == 0 ? "bg-secondary/80 dark:bg-secondary" : "",
                                        )}>
              <TableCell className="place-items-center  text-center">{row.domain}</TableCell>
              <TableCell className="place-items-center  text-center">{row["Mar25"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["7D"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["30D"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["60D"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["90D"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["Aug25"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["Sep25"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row["Oct25"]}</TableCell>
              <TableCell className="place-items-center  text-center">{row.total}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
    </div>
  );
};

export default CertificateRenew;
