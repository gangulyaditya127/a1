
 import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, } from "recharts";

const supportManagerData = [ { name: "Debolina", MAR: 10, APR: 0, MAY: 0, JUN: 0, }, { name: "Sudhanshu", MAR: 500, APR: 400, MAY: 200, JUN: 100, }, { name: "Sumanta", MAR: 900, APR: 600, MAY: 300, JUN: 200, }];

const supportLeadData = [ { name: "Shankhanil", MAR: 10, APR: 10, MAY: 10, JUN: 10, }, { name: "Shadab", MAR: 250, APR: 300, MAY: 200, JUN: 100, }, { name: "Sakil", MAR: 1000, APR: 600, MAY: 300, JUN: 200, }];

const barColors = { MAR: "#60a5fa", APR: "#86efac", MAY: "#facc15", JUN: "#f472b6", };

const HorizontalBarChart = ({ data, title }:any) => (

  <div className="bg-gray-200 dark:bg-gray-700 p-4 rounded shadow w-full">
    <h2 className="text-lg font-semibold text-center mb-4">{title}</h2>
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
        layout="vertical"
        data={data}
        margin={{ top: 20, right: 10, left: 10, bottom: 10 }}
      >
        <XAxis type="number" stroke="#e5e7eb" />
        <YAxis dataKey="name" type="category" stroke="#e5e7eb" width={130} />
        <Tooltip />
        <Bar dataKey="MAR"  fill={barColors.MAR} />
        <Bar dataKey="APR" fill={barColors.APR} />
        <Bar dataKey="MAY"  fill={barColors.MAY} />
        <Bar dataKey="JUN"  fill={barColors.JUN} />
         <Legend iconType="square" layout="vertical" align="right" verticalAlign="top" />
      </BarChart>
    </ResponsiveContainer>
  </div>
);
export default function SupportChartsDashboard() { 
    return (
         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6"> <HorizontalBarChart
data={supportManagerData}
title="Upcoming Expiration - Next 90 Days By Support Manager (Top 10)"
/> <HorizontalBarChart
data={supportLeadData}
title="Upcoming Expiration - Next 90 Days By Support Lead (Top 10)"
/> </div>
 ); }
