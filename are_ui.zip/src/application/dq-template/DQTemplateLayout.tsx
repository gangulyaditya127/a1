import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import SIDEBAR_DATA from "./data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";

function DQTemplateLayout() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({
                navList: [
                    {
                        content: 'DQ Template',
                        route: "/dq/home",
                        key: "1",
                    },
                ],
                isHome: false,
                isAMS: false,
            }),
        );
    }, []);
    return <Outlet />;
}
export default DQTemplateLayout;
