import Container from "@/components/ui/container";
import ResolutionForm from "../features/resolution-form";

export default function DQHome() {
  return (
    <Container className="max-w-3xl my-6">
      <h2 className="text-2xl font-medium">Incident resolution data quality template</h2>
      <ResolutionForm />
    </Container>
  )
}