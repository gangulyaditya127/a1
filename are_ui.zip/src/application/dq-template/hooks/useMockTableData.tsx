import { getNthHourNumericFormat } from "@/lib/date.utils"
import { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

const hourPadd = [-1, -3, -2, 4, -3, -2, -2]

export const useMockTableData = () => {
    const { t, ready, i18n } = useTranslation('/irr/data')
    const [data, setData] = useState<any>();
    useEffect(() => {
        if (ready) {
            console.log('Mock Tbale hook')
            const JSON_DATA = (t('irrData', { returnObjects: true }) as any[])
                .map(({ incidentNumber, incidentTitle, priority, resolutionFound, category, match }, i: any) => ({
                    incidentNumber, incidentTitle, priority, resolutionFound, category, match,
                    createdAt: getNthHourNumericFormat(hourPadd[i])
                }));
            setData(JSON_DATA)
        }
    }, [i18n.language])

    return { ready, data }
}

// incidentNumber: "INC76497584",
//     incidentTitle: "cdcgsker34: ITM_K_20 ATM Withdrawal Server Failure",
//     priority: "Medium",
//     resolutionFound: true,
//     createdAt:getNthHourNumericFormat(-2),
//     match:91,
//     category:'Infra/Server Issue',