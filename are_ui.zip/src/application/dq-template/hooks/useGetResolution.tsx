import { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

export const useGetResolutionRecommendation = (incidentNumber: string) => {
    const [data, setData] = useState({})
    const { t, ready, i18n } = useTranslation('/irr/data')

    useEffect(() => {
        if (ready) {
            console.log('Mock Tbale hook')
            const JSON_DATA = (t('irrData', { returnObjects: true }) as any[]).
                filter((el) => el.incidentNumber === incidentNumber)?.[0]
                ?.resolution ?? "Not found"
            setData(JSON_DATA)
            console.log({JSON_DATA})
        }
    }, [incidentNumber, i18n.language])

    return {ready,data}
}