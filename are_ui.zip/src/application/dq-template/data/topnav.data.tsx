import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "DQ Template",
    route: "/dq/home",
    key: "1",
  },
];
