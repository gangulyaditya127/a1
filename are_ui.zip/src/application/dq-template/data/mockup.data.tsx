export const eventCodeData = [
    {
        Code: "Event-001-PaymentProcessingFailure",
        rootCauseCategory: "application-failure",
        rootCauseSubcategory: "code-error",
        detailedRca: "Application crashed due to unhandled exception in the payment processing module.",
        actionTaken: "Identified the exception handling issue in the payment module and implemented proper error handling.",
        resolutionType: "fix-deployed",
        preventiveAction:
            "Added comprehensive exception handling and implemented additional unit tests for the payment module.",
    },
    {
        Code: "Event-002-DatabaseConnectivityIssue",
        rootCauseCategory: "infrastructure-issue",
        rootCauseSubcategory: "network-failure",
        detailedRca: "Network connectivity issues between application server and database caused timeout errors.",
        actionTaken: "Restarted network services and reconfigured connection pooling settings.",
        resolutionType: "configuration-change",
        preventiveAction: "Implemented network monitoring alerts and increased connection timeout thresholds.",
    },
    {
        Code: "Event-003-BatchProcessingFailure",
        rootCauseCategory: "batch-failure",
        rootCauseSubcategory: "data-validation",
        detailedRca: "Batch job failed due to unexpected data format in source files.",
        actionTaken: "Modified batch process to handle the new data format and reprocessed the failed batch.",
        resolutionType: "fix-deployed",
        preventiveAction: "Enhanced data validation checks and implemented alerting for data format changes.",
    },
    {
        Code: "Event-004-PaymentGatewayOutage",
        rootCauseCategory: "third-party-dependency",
        rootCauseSubcategory: "api-unavailable",
        detailedRca: "Payment gateway API was unavailable during checkout process.",
        actionTaken:
            "Implemented fallback to secondary payment provider and coordinated with the primary provider to resolve their outage.",
        resolutionType: "workaround-implemented",
        preventiveAction:
            "Improved failover mechanism and implemented circuit breaker pattern for all third-party API calls.",
    },
    {
        Code: "Event-005-DatabasePerformanceIssue",
        rootCauseCategory: "database-issue",
        rootCauseSubcategory: "deadlock",
        detailedRca: "Database deadlock occurred during peak transaction processing.",
        actionTaken: "Identified and optimized the queries causing contention and added appropriate indexes.",
        resolutionType: "performance-optimization",
        preventiveAction:
            "Implemented query monitoring and scheduled regular database maintenance to prevent future deadlocks.",
    },
    {
        Code: "Order #1",
        rootCauseCategory: "Order Cancellation",
        rootCauseSubcategory: "Application Sync Issue",
        detailedRca: "order cancelled in CRM and not replicated to ECC",
        actionTaken: "Edited and saved the order in ACP and the order got cancel in ECC as well",
        resolutionType: "Permanent Fix",
        preventiveAction: "Added comprehensive exception handling and implemented additional unit tests for the payment module.",
    },
    {
        Code: "Order #2",
        rootCauseCategory: "Order Cancellation",
        rootCauseSubcategory: "Plant Change Issue",
        detailedRca: "Cancellation performed after changing Plant of the material",
        actionTaken: "we changed the plant back and then cancelled the line item which helped in cancellation of order",
        resolutionType: "Permanent Fix",
        preventiveAction: "Before Order reflect in error Plant of any material should be changed and then order cancellation should be done",
    },
    {
        Code: "Order #3",
        rootCauseCategory: "Order Error",
        rootCauseSubcategory: "Material Data Maintenance",
        detailedRca: "Ship-To Party was not replicated in ECC due to wrong Country Code entered for country/Region Combination entered",
        actionTaken: "Corrected the Country Code in Web UI for valid entry after checking T005E entry",
        resolutionType: "Permanent Fix",
        preventiveAction: "Use Ship to party with correct country code",
    },
    {
        Code: "Order #4",
        rootCauseCategory: "Order Error",
        rootCauseSubcategory: "Customer Master Data not maintained",
        detailedRca: "Sold to Party was not maintained on Sales Area",
        actionTaken: "We requested business to extend the Ship-To party on required Sales area",
        resolutionType: "Permanent Fix",
        preventiveAction: "Use Correct Sold to party mapped to Sales area",
    },

    {
        Code: "Order #5",
        rootCauseCategory: "Order Replication",
        rootCauseSubcategory: "SLOC Incompletion Issue",
        detailedRca: "error for SLOC incompletion, SLOC is not extended at plant for the Material",
        actionTaken: "Edited and saved the order in ACP and the order got cancel in ECC as well",
        resolutionType: "Permanent Fix",
        preventiveAction: "Not Applicable",
    },

    {

        Code: "Resolution Dashboard #1",

        rootCauseCategory: "Missing FO Details",

        rootCauseSubcategory: "Application Sync Issue",

        detailedRca: "FO Created in TM takes time to replicate in ECC",

        actionTaken: "No Action Required, wait for 15minutes for Batch job to auto replicated data in ECC",

        resolutionType: "User training issue",

        preventiveAction: "USers should wait for 15 minutes for data to sync between systems",

    },
    {

        Code: "Resolution Dashboard #2",

        rootCauseCategory: "Missing FO Details",

        rootCauseSubcategory: "Datetime mismatch",

        detailedRca: "FO details are not synced in ECC resulting in datetime mismatch between SO and FO",

        actionTaken: "FO to be re-triggered to ECC",

        resolutionType: "Permanent Fix",

        preventiveAction: "While updating FO user should sync details to ECC",

    },
    {

        Code: "CO09 #1",

        rootCauseCategory: "Record Inconsistencies",

        rootCauseSubcategory: "Application Sync Issue",

        detailedRca: "Order not getting confirmed on correct date because old orders are open in the system making false shortage",

        actionTaken: "Helped user close old orders, and performed BOP to update the new order with latest ATP dates.",

        resolutionType: "User training issue",

        preventiveAction: "User to mark order PGI/closed in system",

    },

    {

        Code: "CO09 #2",

        rootCauseCategory: "Record Inconsistencies",

        rootCauseSubcategory: "Application Sync Issue",

        detailedRca: "Order Open In ECC, Causing it to reflect in APO and consume stocks",

        actionTaken: "User CCR to remove inconsistencies",

        resolutionType: "Permanent Fix",

        preventiveAction: "CCR Monitoring",

    },

]
export const rootCauseCategories = [
    {
        value: "application-failure",
        label: "Application Failure",
        subcategories: [
            { value: "code-error", label: "Code Error" },
            { value: "memory-leak", label: "Memory Leak" },
            { value: "configuration-issue", label: "Configuration Issue" },
        ],
    },
    {
        value: "infrastructure-issue",
        label: "Infrastructure Issue",
        subcategories: [
            { value: "server-down", label: "Server Down" },
            { value: "network-failure", label: "Network Failure" },
            { value: "storage-issue", label: "Storage Issue" },
        ],
    },
    {
        value: "batch-failure",
        label: "Batch Failure",
        subcategories: [
            { value: "scheduling-error", label: "Scheduling Error" },
            { value: "data-validation", label: "Data Validation" },
            { value: "resource-constraint", label: "Resource Constraint" },
        ],
    },
    {
        value: "database-issue",
        label: "Database Issue",
        subcategories: [
            { value: "query-timeout", label: "Query Timeout" },
            { value: "deadlock", label: "Deadlock" },
            { value: "corruption", label: "Data Corruption" },
        ],
    },
    {
        value: "third-party-dependency",
        label: "Third-Party Dependency",
        subcategories: [
            { value: "api-unavailable", label: "API Unavailable" },
            { value: "version-incompatibility", label: "Version Incompatibility" },
            { value: "rate-limiting", label: "Rate Limiting" },
        ],
    },
    {
        value: "Order Cancellation",
        label: "Order Cancellation",
        subcategories:
            [
                {
                    value: "Application Sync Issue",
                    label: "Application Sync Issue"
                },
                {
                    value: "Plant Change Issue",
                    label: "Plant Change Issue"
                },
            ],
    },

    {
        value: "Order Error",
        label: "Order Error",
        subcategories:
            [
                {
                    value: "Material Data Maintenance",
                    label: "Material Data Maintenance"
                },
                {
                    value: "Customer Master Data not maintained",
                    label: "Customer Master Data not maintained"
                },
            ],
    },
    {
        value: "Order Replication",
        label: "Order Replication",
        subcategories:
            [
                {
                    value: "SLOC Incompletion Issue",
                    label: "SLOC Incompletion Issue"
                },
            ],
    },
    {
        value: "Missing FO Details",
        label: "Missing FO Details",
        subcategories:
            [
                {
                    value: "Application Sync Issue",
                    label: "Application Sync Issue"
                },
                {
                    value: "Datetime mismatch",
                    label: "Datetime mismatch"
                },
            ],
    },

    {
        value: "Record Inconsistencies",
        label: "Record Inconsistencies",
        subcategories:
            [
                {
                    value: "Application Sync Issue",
                    label: "Application Sync Issue"
                },
            ],
    },

]
export const resolutionTypes = [
    {
        value: "Permanent Fix",
        label: "Permanent Fix"
    },
    {
        value: "Workaround-implemented",
        label: "Workaround Implemented"
    },
    {
        value: "User training issue",
        label: "User training issue"
    },
    { value: "fix-deployed", label: "Fix Deployed" },
    { value: "configuration-change", label: "Configuration Change" },
    { value: "performance-optimization", label: "Performance Optimization" },
    { value: "no-action-required", label: "No Action Required" },
]
export const getLabelFromValue = (options: any[], value: string) => {
    const option = options.find((opt) => opt.value === value)
    return option ? option.label : value
}
export const getSubcategories = (categoryValue: string) => {
    const category = rootCauseCategories.find((cat) => cat.value === categoryValue)
    return category ? category.subcategories : []
}
export const getEventCodeList = () => {
    return eventCodeData.map(({ Code: code }) => ({ value: code, label: code }))
}
export const getRootCauseCategory = () => {
    return rootCauseCategories.map(({ label, value }) => ({ label, value }))
}