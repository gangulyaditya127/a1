import { z } from 'zod';
export const resolutionSchema = z.object({
    eventCode: z.string({ message: 'Event code can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    rootCauseCategory: z.string({ message: 'Root cause category can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    rootCauseSubcategory: z.string({ message: 'Root cause sub-category can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    detailedRca: z.string({ message: 'RCA can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    actionTaken: z.string({ message: 'Action Taken can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    resolutionType: z.string({ message: 'Resolution type can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' }),
    preventiveAction: z.string({ message: 'Preventive action can\'t be empty ' })
        .min(1, { message: 'Event code can\'t be empty ' })

})