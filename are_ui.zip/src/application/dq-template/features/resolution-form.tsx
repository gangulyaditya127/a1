import { useForm } from "react-hook-form"
import { resolutionSchema } from "../type/resolution-type"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox"
import { eventCodeData, getEventCodeList, getRootCauseCategory, getSubcategories, resolutionTypes } from "../data/mockup.data"
import { useEffect, useRef, useState } from "react";
import AutoTextArea from "@/components/ui/auto-grow-text-area";
import { Button } from "@/components/ui/button";
import ResolutionOutput from "./resolution-output";
export default function ResolutionForm() {
    const resolutionForm = useForm<z.infer<typeof resolutionSchema>>({
        resolver: zodResolver(resolutionSchema),
        defaultValues: {
            eventCode: "",
            rootCauseCategory: "",
            rootCauseSubcategory: "",
            detailedRca: "",
            actionTaken: "",
            resolutionType: "",
            preventiveAction: "",
        },
    })
    const [subcategories, setSubcategories] = useState<{ value: string; label: string }[]>([]);
    const eventCode = resolutionForm.watch('eventCode');
    const category = resolutionForm.watch('rootCauseCategory');
    const rcaRef = useRef(null);
    const actionRef = useRef(null);
    const preventiveRef = useRef(null);
    const [result, setResult] = useState({
        isOpen: false,
        output: ""
    })


    useEffect(() => {
        if (category) {
            setSubcategories(getSubcategories(category))
            // Clear subcategory if it's not valid for the new category 
            if (!getSubcategories(category).some((sub) => sub.value === resolutionForm.getValues().rootCauseSubcategory)) {
                resolutionForm.setValue("rootCauseSubcategory", "");
            }
        } else {
            setSubcategories([])
        }
    }, [category])

    useEffect(() => {
        handleEventCodeSelect(eventCode)
    }, [eventCode])

    const handleEventCodeSelect = (code: string) => {
        const eventData = eventCodeData.find((event) => event.Code === code)
        if (eventData) {
            Object.entries(eventData).forEach(
                ([name, value]: any) => resolutionForm.setValue(name, value));
        }
    }
    const onSubmit = (values: z.infer<typeof resolutionSchema>) => {
        const output = ` 
<<Event Code>>: ${values.eventCode} 
<<Root Cause Category>>: ${values.rootCauseCategory} 
<<Root Cause Subcategory>>: ${values.rootCauseSubcategory} 
<<Detailed Root Cause Analysis>>: ${values.detailedRca} 
<<Action Taken>>: ${values.actionTaken} 
<<Resolution Type>>: ${values.resolutionType} 
<<Preventive Action>>: ${values.preventiveAction}`.trim()
        setResult({
            output,
            isOpen: true
        })

    }
    const handleDialogChange = () => {
        setResult((prev) => ({
            ...prev,
            isOpen: !prev.isOpen
        }))
    }

    return (
        <>
            <Form {...resolutionForm}>
                <form onSubmit={resolutionForm.handleSubmit(onSubmit)} className="grid gap-4 mt-4">
                    <FormField
                        control={resolutionForm.control}
                        name="eventCode"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Event Code</FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox optionList={getEventCodeList()} field="Event Code" setValue={field.onChange} value={field.value} placeholder="Select Event Code" widthClass="w-full" />
                                </FormControl>
                                <FormDescription>
                                    Select event code for auto population of resolution fields
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="rootCauseCategory"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Root cause category</FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox optionList={getRootCauseCategory()} field="Root cause category" setValue={field.onChange} value={field.value} placeholder="Select root cause category" widthClass="w-full" />
                                </FormControl>
                                <FormDescription>
                                    Root cause category for the incident
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="rootCauseSubcategory"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Root cause sub-category</FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox optionList={subcategories} field="Root cause sub-category" setValue={field.onChange} value={field.value} placeholder="Select root cause sub-category" widthClass="w-full" />
                                </FormControl>
                                <FormDescription>
                                    Root cause sub-category for the incident
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="detailedRca"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Detailed RCA</FormLabel>
                                <FormControl>
                                    <AutoTextArea placeholder="Enter root cause analysis" className="" id={`rca`} maxRows={6} defaultRows={3} ref={rcaRef} onChange={field.onChange} value={field.value} />
                                </FormControl>
                                <FormDescription>
                                    Detailed root cause analysis for the incident
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="actionTaken"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Action Taken</FormLabel>
                                <FormControl>
                                    <AutoTextArea placeholder="Enter action taken" className="" id={`rca`} maxRows={6} defaultRows={3} ref={actionRef} onChange={field.onChange} value={field.value} />
                                </FormControl>
                                <FormDescription>
                                    Action taken for the incident
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="resolutionType"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Resolution type</FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox optionList={resolutionTypes} field="Resolution type" setValue={field.onChange} value={field.value} placeholder="Select resolution type" widthClass="w-full" />
                                </FormControl>
                                <FormDescription>
                                    Resolution type for the incident
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={resolutionForm.control}
                        name="preventiveAction"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Preventive action</FormLabel>
                                <FormControl>
                                    <AutoTextArea placeholder="Enter preventive action" className="" id={`preventiveAction`} maxRows={6} defaultRows={3} ref={preventiveRef} onChange={field.onChange} value={field.value} />
                                </FormControl>
                                <FormDescription>
                                    Enter preventive actions to avoid future incidents
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                    </div>
                    <Button type="button" variant="outline" onClick={() => resolutionForm.reset()}>
                        Reset
                    </Button>
                    <Button type="submit" className="w-full bg-tcs-primary rounded-lg dark:bg-[#2469BC] text-primary">
                        Generate Resolution
                    </Button>
                </form>
            </Form >
            <ResolutionOutput isOpen={result.isOpen} output={result.output} setIsOpen={handleDialogChange} />
        </>
    )
}