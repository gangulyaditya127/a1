import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast";
import { Copy } from "lucide-react";
export default function ResolutionOutput({ output, isOpen, setIsOpen }: { output: string, isOpen: boolean, setIsOpen: any }) {
    const { toast } = useToast()
    const handleCopy = async () => {
        if (output) {
            try {
                await navigator.clipboard.writeText(output)
                toast({
                    title: "Copied to clipboard",
                    description: "Resolution description has been copied to clipboard",
                    duration: 3000,
                })
            } catch (err) {
                toast({
                    title: "Failed to copy",
                    description: "Could not copy text to clipboard",
                    variant: "destructive",
                    duration: 3000,
                })
            }
        }
    }
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogContent className="sm:max-w-[70vw]">
                <DialogHeader>
                    <DialogTitle>Resolution Description</DialogTitle>
                    <DialogDescription>
                        Copy this resolution description to your ServiceNow ticket.
                    </DialogDescription>
                </DialogHeader>
                <div className="w-full overflow-scroll bg-secondary rounded-sm p-4">
                    <pre className="grid gap-4 py-4">
                        {output}
                    </pre>
                </div>
                <DialogFooter>
                    <Button type="button" variant="secondary" size="sm" onClick={handleCopy} className="gap-1 rounded-lg" >
                        <Copy className="h-4 w-4" />
                        Copy to Clipboard
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}