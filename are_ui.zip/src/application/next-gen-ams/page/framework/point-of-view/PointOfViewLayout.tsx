import DetailedSideNav from "@/components/layout/DetailedSideNav";
import Container from "@/components/ui/container";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Outlet } from "react-router-dom";
import { Meteors } from "@/components/ui/meteors";

const PointOfViewLayout = () => {
  return (
    <section className="relative pt-[57px]">
      <Container>
        <ResizablePanelGroup direction="horizontal" className="w-full">
          <ResizablePanel defaultSize={15} maxSize={25} minSize={15}>
            <div className="p-4 pt-8">
              <DetailedSideNav />
            </div>
          </ResizablePanel>
          <ResizableHandle withHandle />
          <ResizablePanel defaultSize={75}>
            <ScrollArea className="h-[calc(100vh-67px)]">
              <Outlet />
            </ScrollArea>
          </ResizablePanel>
        </ResizablePanelGroup>
      </Container>

      <Meteors number={5} />
    </section>
  );
};
export default PointOfViewLayout;
