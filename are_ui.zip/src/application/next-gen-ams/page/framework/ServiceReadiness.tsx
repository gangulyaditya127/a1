import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
// import HANDOVER_SLIDE from "@/assets/docs/Framework/Next Gen AMS - Dev_Ops Handover Process v2.0.pdf";
import BlogHeader from "../../features/BlogHeader";
import { Separator } from "@/components/ui/seperator";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
const ServiceReadiness = () => {
  const { t, ready } = useTranslation('next-gen-ams/framework/ServiceReadiness')
  if(!ready){
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />

        <div className="leading-7">
          <ul className="mb-2 mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              <ul className="list-disc pl-4">
                <li>{t('content.1')}</li>
                <li>{t('content.2')}</li>
                <li>{t('content.3')}</li>
                <li>{t('content.4')}</li>
                <li>{t('content.5')}</li>
              </ul>
            </li>
          </ul>
          {/* <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <iframe
                  src={HANDOVER_SLIDE}
                  className="h-[30rem] w-full"
                ></iframe>
              </li>
            </ul>
          </div> */}
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default ServiceReadiness;
