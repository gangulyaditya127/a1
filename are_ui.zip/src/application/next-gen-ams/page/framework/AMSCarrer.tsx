import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import AMS_LEARN_SLIDE from "@/assets/docs/Manage/Next Gen AMS - Career & Learning Builder.pdf?url";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import PDFViewer from "@/components/ui/pdf-viewer";
const AMSCarrer = () => {
  const { t, ready } = useTranslation('next-gen-ams/framework/AMSCarrer')
  if(!ready){
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
      <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              {t('content.1')}
            </li>
          </ul>
          <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <h4 className="mb-2 underline"></h4>
                <PDFViewer
                  fileUrl={AMS_LEARN_SLIDE}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default AMSCarrer;
