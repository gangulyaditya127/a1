import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import ISMAR_CATLOG_SLIDE from "@/assets/docs/Framework/iSmart & BOTs overview 3.pdf?url";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
import PRODUCT_DEMO from "@/assets/Video/Doing Production Management is like_5.mp4";
import DEMO_VIDEO_THUMBNAIL from "@/assets/Video/thumbnail/Doing Production Management is like_5_Moment(2).jfif";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";

const IsmartCatlogLayout = () => {
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>Intelligent Support Mart</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title="Intelligent Support Mart" className="mb-3 mt-6" />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-5">
            <li>
              Welcome to the Intelligent Support Mart Catalog, your comprehensive guide to the
              offerings and modules provided by the Intelligent Support Mart platform. Developed
              by TCS, Intelligent Support Mart is a cutting-edge solution designed to enhance
              automation and productivity across various sectors and regions.
              This platform is GenAI-ready and serves as a one-stop solution for
              all transformation needs under the production management umbrella.
            </li>
          </ul>
          <div className="mt-4">
            <ul className="flex flex-col gap-6">
              <li>
                <VideoPlayer
                  src={PRODUCT_DEMO}
                  autoPlay={false}
                  loop={true}
                  className="rounded-xl"
                  thumbnail={DEMO_VIDEO_THUMBNAIL}
                  title={"Explore our Excellence"}
                />
              </li>
              <li>
                <PDFViewer
                  fileUrl={ISMAR_CATLOG_SLIDE}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default IsmartCatlogLayout;
