import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";

import AMS_POV from "@/assets/docs/Next Gen AMS - Operating Model Trends and Implications - TCS POV.pdf?url";
// import AMS_FRAMEWORK from '@/assets/docs/Next Gen AMS - TCS Framework Components (1).pdf'
// import TEAM_BUILDER from '@/assets/docs/Next Gen AMS - Training & Team Builder.pdf'
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import PDFViewer from "@/components/ui/pdf-viewer";

const OperatingModelPOV = () => {
  const { t, ready } = useTranslation('next-gen-ams/framework/OperatingModelPOV')
  if(!ready){
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>
                {t('title')}
              </BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-5">
            <li>
              {t('content.0')}
            </li>
          </ul>
        </div>
        <div className="mt-4">
          <ul className="flex list-decimal flex-col gap-8 px-4">
            <li>
              <h4 className="mb-2 underline">
                {t('content.1')}
              </h4>
              <PDFViewer
                fileUrl={AMS_POV}
              />
            </li>
          </ul>
        </div>
      </Container>
      <ContactCard contactList={[
        {
          name: "Rajesh Tengshe",
          mail: "rajesh.Tengshe@tcs.com"
        }
      ]} />
    </section>
  );
};
export default OperatingModelPOV;
