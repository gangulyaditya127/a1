
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Separator } from "@/components/ui/seperator";
import USER_IMG_SUDIPTA from '@/assets/UserProfiles/Team/Sudipta_Maiti.jfif'
import USER_IMG_KAMRUZ from '@/assets/UserProfiles/Team/kamruz.jfif'
import USER_IMG_ASHIS from '@/assets/UserProfiles/Team/ahis.jfif'

import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
export default function AboutUs() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(
            updateSideBarNavigation({
                hasSideBar: false,
                sideBarNavList: [],
                bottomNavList: [],
            }),
        );
        dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
    }, []);
    return (
        <section className="pt-16">
            <Container className="mt-8 max-w-6xl">
                <NavigateBackButton fallbackUrl="/" />
                <MeetOurTeam />
            </Container>
        </section>
    )
}

const MeetOurTeam = () => {
    return (
        <div className="py-2 pb-8">
            <div className="uppercase flex gap-1 text-xs tracking-wider">
                <p className="border border-primary px-2 py-[2px] rounded-3xl">Who</p>
                <p className="border border-primary px-2 py-[2px] rounded-3xl">We</p>
                <p className="border border-primary px-2 py-[2px] rounded-3xl">Are</p>
            </div>
            <div className="  mt-2">
                <p className="text-3xl font-medium">US South East Banking & LATAM - SEBL <br /> iSmart Team</p>
                <p className="text-muted-foreground mt-1">sebl-ismart@tcscomprod.onmicrosoft.com</p>
            </div>
            <Separator className="mt-4" />
            <div className="grid grid-cols-2 gap-6 mt-4">
                <p className="uppercase tracking-wider ">
                    We are a diverse team of domain experts and problem solvers
                </p>
                <p className="text-muted-foreground">
                    At the heart of iSmart, a groundbreaking application support portal, is a dynamic team of innovators, tech enthusiasts, and problem solvers. We are a diverse group united by a shared passion for transforming production management through AI-driven solutions. <br/><br/> With a deep commitment to excellence and a focus on delivering results, our team brings together years of experience and a relentless drive to push the boundaries of what's possible.
                </p>
            </div>
            <div className="grid grid-cols-4 gap-6 mt-12">
                <div className="">
                    <img src={USER_IMG_SUDIPTA} alt="" className="w-full aspect-square rounded-2xl" />
                    <div className="mt-4">
                        <p className="font-medium">Sudipta Maiti</p>
                        <p className="text-muted-foreground">BFSI SEBL Transformation head</p>
                        <p className="text-muted-foreground">sudipta.maiti@tcs.com</p>
                    </div>
                </div>
                <div className="">
                    <img src={USER_IMG_ASHIS} alt="" className="w-full aspect-square rounded-2xl" />
                    <div className="mt-4">
                        <p className="font-medium">Ashis Taru Mukherjee</p>
                        <p className="text-muted-foreground">BFSI SEBL Automation head</p>
                        <p className="text-muted-foreground">ashistaru.mukherjee@tcs.com</p>
                    </div>
                </div>
                <div className="">
                    <img src={USER_IMG_KAMRUZ} alt="" className="w-full aspect-square rounded-2xl" />
                    <div className="mt-4">
                        <p className="font-medium">Kamruzzaman Saikh</p>
                        <p className="text-muted-foreground">BFSI SEBL GenAI head</p>
                        <p className="text-muted-foreground">kamruzzaman.shaikh@tcs.com</p>
                    </div>
                </div>

            </div>
        </div>
    )
}