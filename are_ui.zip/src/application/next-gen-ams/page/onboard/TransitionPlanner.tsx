import Container from "@/components/ui/container";
import { Link } from "react-router-dom";
import BlogHeader from "../../features/BlogHeader";
import { Separator } from "@/components/ui/seperator";
import {
  Breadcrumb,
  BreadcrumbItem, BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Meteors } from "@/components/ui/meteors";
// import TRANSITION_SLIDE from "@/assets/docs/Onboard/Digital Transition Planner.pdf";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { useTranslation } from "react-i18next";
const TransitionPlanner = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/TransitionPlanner')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <Link to="/" className="text-xs py-2 mb-2 flex gap-1 text-muted-foreground hover:text-foreground hover:underline">
          <Icon name="move-left" className="size-4" />
          <span>{t('back')}</span>
        </Link >
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbList>
              <Link to="/">{t('home')}</Link>
            </BreadcrumbList>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbList>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbList>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('content.0')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.1')}
            </li>
            <li>
              {t('content.2')}
            </li>
            <li>
              <Link to="/doc/nao" className="underline flex items-center gap-2 text-[#065AC2] dark:text-[#6BAEFF] visited:text-[#6A21AD] dark:visited:text-[#CC95FD]">
                <Icon name="link" className="h-4 w-4"></Icon>
                <span>{t('content.3')}</span>
              </Link>
            </li>
          </ul>
          {/* <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <h4 className="mb-2 underline"></h4>
                <iframe
                  src={TRANSITION_SLIDE}
                  className="h-[30rem] w-full"
                ></iframe>
              </li>
            </ul>
          </div> */}
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default TransitionPlanner;
