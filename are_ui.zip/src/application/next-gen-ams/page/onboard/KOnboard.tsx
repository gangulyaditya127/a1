import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
import { SlashIcon } from "lucide-react";
import KONBOARD_VID from "@/assets/Video/KOnboard v2 1.mp4";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import KONBOARD_DOC from '@/assets/docs/Onboard/kOnBoard_V5.pdf?url'
import { useTranslation } from "react-i18next";
import PDFViewer from "@/components/ui/pdf-viewer";
const KOnboard = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/KOnboard')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <Link to="/" className="text-xs py-2 mb-2 flex gap-1 text-muted-foreground hover:text-foreground hover:underline">
          <Icon name="move-left" className="size-4" />
          <span>{t('back')}</span>
        </Link >
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title={t('title')} className="mb-3 mt-6" />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              <p className="mb-2 underline">
                {t('content.1')}
              </p>
              <ul className="flex list-decimal flex-col gap-2 pl-4">
                <li>
                  <p className="font-medium">
                    {t('content.2')}
                  </p>
                  <ul className="list-disc pl-4">
                    <li>
                      {t('content.3')}
                    </li>
                    <li>{t('content.4')}</li>
                    <li>{t('content.5')}</li>
                    <li>
                      {t('content.6')}
                    </li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">
                    {t('content.7')}
                  </p>
                  <ul className="list-disc pl-4">
                    <li>{t('content.8')}</li>
                    <li>{t('content.9')}</li>
                    <li>{t('content.10')}</li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">
                    {t('content.11')}
                  </p>
                  <ul className="list-disc pl-4">
                    <li>
                      {t('content.12')}
                    </li>
                    <li>{t('content.13')}</li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">{t('content.14')}</p>
                  <ul className="list-disc pl-4">
                    <li>
                      {t('content.15')}
                    </li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">{t('content.16')}</p>
                  <ul className="list-disc pl-4">
                    <li>{t('content.17')}</li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
          
          <div className="mt-4">
            <VideoPlayer
              src={KONBOARD_VID}
              autoPlay={false}
              loop={true}
              className="rounded-xl"
              title={"Explore our Excellence"}
            />
          </div>
          <div className="mt-4">
            <ul className="flex flex-col gap-8">
              <li>
                <PDFViewer
                  fileUrl={KONBOARD_DOC}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Antony Akkarakaran George",
            mail: "antony.george@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default KOnboard;
