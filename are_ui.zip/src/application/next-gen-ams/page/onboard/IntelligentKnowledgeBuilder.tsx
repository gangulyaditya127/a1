import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import KNOWLED_BUILDER_DOC from "@/assets/docs/Onboard/intelligent knowledge builder.pdf?url";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
import ESTIMATOR_VID from "@/assets/Video/TCS_SPEECH_TO_TEXT_&_KNOWLEDGE_BOT_ 2.mp4";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { useTranslation } from "react-i18next";
import PDFViewer from "@/components/ui/pdf-viewer";
const IntelligentKnowledgeBuilder = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/IntelligentKnowledgeBuilder')
  if(!ready){
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <Link to="/" className="text-xs py-2 mb-2 flex gap-1 text-muted-foreground hover:text-foreground hover:underline">
          <Icon name="move-left" className="size-4" />
          <span>{t('back')}</span>
        </Link >
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              <p className="font-bold">{t('content.1')}</p>
              <ul className="flex list-decimal flex-col gap-4 pl-4">
                <li>
                  <div className="flex flex-col gap-2">
                    <p className="w-full">
                      <span className="underline">{t('content.2')}</span>
                      <span> : </span>
                    </p>
                    <p>
                      {t('content.3')}
                    </p>
                    <p>{t('content.4')}</p>
                    <ul className="list-disc pl-5">
                      <li>
                        {t('content.5')}
                      </li>
                      <li>
                        {t('content.6')}
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <div className="flex flex-col gap-2">
                    <p className="w-full">
                      <span className="underline">{t('content.7')}</span>
                      <span> : </span>
                    </p>
                    <p>
                      {t('content.8')}
                    </p>
                    <p>{t('content.9')}</p>
                    <ul className="list-disc pl-5">
                      <li>
                        {t('content.10')}
                      </li>
                      <li>
                        {t('content.11')}
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </li>
            <li>
              {t('content.12')}
            </li>
          </ul>

          <div className="mt-4">
            <VideoPlayer
              src={ESTIMATOR_VID}
              autoPlay={false}
              loop={true}
              className="rounded-xl"
              title={"Explore our Excellence"}
            />
          </div>
          <div className="mt-4">
            <ul className="flex flex-col gap-8">
              <li>
                <PDFViewer
                  fileUrl={KNOWLED_BUILDER_DOC}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default IntelligentKnowledgeBuilder;
