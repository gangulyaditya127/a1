import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem, BreadcrumbSeparator,
  BreadcrumbPage
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../../features/BlogHeader";
import ContactCard from "../../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
const Estimators = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/Estimators')
  if (!ready) {
    return null;
  }
  return (
    <section className="pb-12">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">{t('home')}</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('app')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title={t('title')} className="mb-3 mt-6" />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              <p className="font-medium">
                {t('content.1')}
              </p>
              <ul className="mt-2 flex flex-col gap-1">
                <li>
                  <Link to="top-down" className="underline flex items-center gap-2 text-[#065AC2] dark:text-[#6BAEFF] visited:text-[#6A21AD] dark:visited:text-[#CC95FD]">
                    <Icon name="link" className="h-4 w-4"></Icon>
                    <span>{t('content.2')}</span>
                  </Link>
                </li>
                <li>
                  <Link to="bottom-up" className="underline flex items-center gap-2 text-[#065AC2] dark:text-[#6BAEFF] visited:text-[#6A21AD] dark:visited:text-[#CC95FD]">
                    <Icon name="link" className="h-4 w-4"></Icon>
                    <span>{t('content.3')}</span>
                  </Link>
                </li>
              </ul>
            </li>
            <li>
              {t('content.4')}
            </li>
            <li>
              <ul className="flex list-decimal flex-col gap-2 pl-4">
                <li>
                  <p className="font-medium">{t('content.5')}</p>
                  <ul className="flex list-disc flex-col gap-1 pl-4">
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.6')}</span>
                        <span>
                          {" "}
                          {t('content.7')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.8')}</span>
                        <span>
                          {" "}
                          {t('content.9')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.10')}</span>
                        <span>
                          {" "}
                          {t('content.11')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.12')}</span>
                        <span>
                          {" "}
                          {t('content.13')}
                        </span>
                      </p>
                    </li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">{t('content.14')}</p>
                  <ul className="flex list-disc flex-col gap-1 pl-4">
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.15')}</span>
                        <span>
                          {" "}
                          {t('content.16')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.17')}</span>
                        <span>
                          {" "}
                          {t('content.18')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.19')}</span>
                        <span>
                          {" "}
                          {t('content.20')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.21')}</span>
                        <span>
                          {" "}
                          {t('content.22')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.23')}</span>
                        <span>
                          {" "}
                          {t('content.24')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.25')}</span>
                        <span>
                          {" "}
                          {t('content.26')}
                        </span>
                      </p>
                    </li>
                  </ul>
                </li>
                <li>
                  <p className="font-medium">{t('content.27')}</p>
                  <ul className="flex list-disc flex-col gap-1 pl-4">
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.28')}</span>
                        <span>
                          {" "}
                          {t('content.29')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.30')}</span>
                        <span>
                          {" "}
                          {t('content.31')}
                        </span>
                      </p>
                    </li>
                    <li>
                      <p className="space-2">
                        <span className="">{t('content.32')}</span>
                        <span>
                          {" "}
                          {t('content.33')}
                        </span>
                      </p>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              {t('content.34')}
            </li>
          </ul>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Sudipta Maiti",
            mail: "sudipta.maiti@tcs.com",
          },
          {
            name: "Jaya Raj",
            mail: "raj.jaya@tcs.com",
          },
          {
            name: "Taj peeran",
            mail: "tajpeeran.a@tcs.com",
          },
          {
            name: "Dinakar Prabhakar",
            mail: "dinakar.prabhakar@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default Estimators;
