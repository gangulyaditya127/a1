import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../../features/BlogHeader";
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Icon } from "@/components/ui/icon";
import { useTranslation } from "react-i18next";
const TopDownEstimator = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/TopDownEstimator')
  if (!ready) {
    return null;
  }
  return (
    <section className="">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/doc/estimators/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/doc/estimators">{t('app')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('subheading')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
            {t('content.0')}
            </li>
            <li>
            {t('content.1')}
            </li>
            <li>
            {t('content.2')}
            </li>
            <li>
              <Link to="/doc/iprompt" className="underline flex items-center gap-2 text-[#065AC2] dark:text-[#6BAEFF] visited:text-[#6A21AD] dark:visited:text-[#CC95FD]">
                <Icon name="link" className="h-4 w-4"></Icon>
                <span>{t('content.3')}</span>
              </Link>
            </li>
          </ul>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default TopDownEstimator;
