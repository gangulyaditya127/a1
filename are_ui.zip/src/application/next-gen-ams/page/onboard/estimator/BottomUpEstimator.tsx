import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../../features/BlogHeader";
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
const BottomUpEstimator = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/BottomUpEstimator')
  if (!ready) {
    return null;
  }
  return (
    <section className="">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/doc/estimators/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/doc/estimators">{t('app')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('subheading')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
            {t('content.0')}
            </li>
            <li>
            {t('content.1')}
            </li>
            <li>
            {t('content.2')}
            </li>
          </ul>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Jaya Raj",
            mail: "raj.jaya@tcs.com",
          },
          {
            name: "Taj peeran",
            mail: "tajpeeran.a@tcs.com",
          },
          {
            name: "Dinakar Prabhakar",
            mail: "dinakar.prabhakar@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default BottomUpEstimator;
