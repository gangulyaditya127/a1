import { Icon } from "@/components/ui/icon";
import { Separator } from "@/components/ui/seperator";
import { cn } from "@/lib/tailwind.utils";
import { NavLink } from "react-router-dom";
import { useTranslation } from "react-i18next";
const EstimatorSidebar = () => {
  const { t, ready } = useTranslation('next-gen-ams/onboard/estimators/EstimatorSidebar')
  if (!ready) {
    return "";
  }
  return (
    <div className="flex cursor-pointer flex-col gap-2 text-nowrap text-sm text-muted-foreground">
      <NavLink to="/doc/estimators" end>
        {(
          { isActive }, //isPending, isTransitioning <-- extra two parameters
        ) => (
          <p
            className={cn(
              "hover:text-foreground",
              isActive ? "font-medium text-foreground" : "",
            )}
          >
            {t('content.0')}
          </p>
        )}
      </NavLink>
      <Separator />
      <div className="flex flex-col gap-2">
        <NavLink to="/doc/estimators/top-down">
          {(
            { isActive }, //isPending, isTransitioning <-- extra two parameters
          ) => (
            <div
              className={cn(
                "flex items-center gap-1 hover:text-foreground ",
                isActive ? "font-medium text-foreground" : "",
              )}
            >
              <Icon name="arrow-down-narrow-wide" className="size-4 shrink-0" />
              <p>{t('content.1')}</p>
            </div>
          )}
        </NavLink>
        <NavLink to="/doc/estimators/bottom-up">
          {(
            { isActive }, //isPending, isTransitioning <-- extra two parameters
          ) => (
            <div
              className={cn(
                "flex items-center gap-1 hover:text-foreground",
                isActive ? "font-medium text-foreground" : "",
              )}
            >
              <Icon name="arrow-up-narrow-wide" className="size-4 shrink-0" />
              <p>{t('content.2')}</p>
            </div>
          )}
        </NavLink>
      </div>
    </div>
  );
};
export default EstimatorSidebar;
