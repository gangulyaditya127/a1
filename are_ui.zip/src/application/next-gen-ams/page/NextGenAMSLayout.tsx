// import Footer from "@/components/layout/Footer";
import { Worker } from '@react-pdf-viewer/core';
import { Outlet } from "react-router-dom";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";


const NextGenAMSLayout = () => {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(
      updateSideBarNavigation({
        hasSideBar: false,
        sideBarNavList: [],
        bottomNavList: [],
      }),
    );
    dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
  }, []);
  return (
    <div className="grid min-h-screen">
      <Worker workerUrl='/js/pdf.worker.min.js'>
        <Outlet />
      </Worker>
      {/* <Footer/> //grid-rows-[1fr_50px]*/}
    </div>
  );
};
export default NextGenAMSLayout;
