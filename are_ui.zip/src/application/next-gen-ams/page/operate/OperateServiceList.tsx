import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
// import { APP_LIST } from "@/components/layout/data/APP_LIST";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { HoverEffect } from "@/components/ui/card-hover-effect";
import Container from "@/components/ui/container";
import { IconNameProp } from "@/components/ui/icon";
import { Meteors } from "@/components/ui/meteors";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Separator } from "@/components/ui/seperator";
import { useAppDispatch } from "@/lib/redux/hooks";
import { SlashIcon } from "lucide-react";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

type appList={
  route?: any;
  displayText: any;
  title?: string;
  description: string;
  link?: string;
  icon?: IconNameProp;
  openInNew?: boolean,
  key:number
}[];


const OperateServiceList = () => {
  const { ready, t } = useTranslation('ismart_app_operate')
  if (!ready) return null;
  const APP_LIST = t("app", { returnObjects: true }) as appList
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(
      updateSideBarNavigation({
        hasSideBar: false,
        sideBarNavList: [],
        bottomNavList: [],
      }),
    );
    dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
  }, []);
  return (
    <section className="py-20 pb-24">
      <Container className="max-w-6xl">
        <NavigateBackButton />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>Demos</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title="Demos" className="mb-3 mt-6" />
        <Separator />
        <HoverEffect
          className="py-4"
          items={APP_LIST.filter((el)=>el.route!="/coming-soon").map((el,i) => ({
            title: el.displayText,
            link: el.route,
            description: el.description,
            icon: el.icon,
            openInNew: el.openInNew,
            key:i
          }))}
        />
      </Container>
      <Meteors number={5} />
    </section>
  );
};

export default OperateServiceList;
