import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";

const RioAssesmentQuestion = () => {
  const { t, ready } = useTranslation('next-gen-ams/transform/RioAssesmentQuestion')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16 pb-52">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('app')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
            {t('content.0')}
            </li>
            <li>
              <p>{t('content.1')}</p>
              <ul className="list-disc pl-4">
                <li>
                {t('content.2')}
                </li>
                <li>
                {t('content.3')}
                </li>
                <li>{t('content.4')}</li>
              </ul>
            </li>
            <li>
            {t('content.5')}
            </li>
          </ul>
          <div className="mt-4">
            {/* <VideoPlayer src={KONBOARD_VID} autoPlay={false} loop={true} className='rounded-xl' title={"Explore our Excellence"} /> */}
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Karthikeyan Elumalai",
            mail: "e.karthik@tcs.com",
          },
          {
            name: "AK Balaji",
            mail: "balaji.ak@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default RioAssesmentQuestion;
