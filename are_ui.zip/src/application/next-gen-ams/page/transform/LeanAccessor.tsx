import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import LEAN_SLIDE from "@/assets/docs/Transform/LEAN Assessment Framework for AMS.pdf?url";
import BlogHeader from "../../features/BlogHeader";
import { Separator } from "@/components/ui/seperator";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import { Icon } from "@/components/ui/icon";
import PDFViewer from "@/components/ui/pdf-viewer";

const LeanAccessor = () => {
  const { t, ready } = useTranslation('next-gen-ams/transform/LeanAccessor')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">Home</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>Lean Accessor</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title={t('title')} className="mb-3 mt-6" />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              {t('content.1')}
              <ul className="list-decimal pl-4">
                <li> {t('content.2')}</li>
                <li>
                  {t('content.3')}{" "}
                </li>
                <li> {t('content.4')}</li>
              </ul>
            </li>
          </ul>
          <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <h4 className="mb-2 underline"></h4>
                <PDFViewer
                  fileUrl={LEAN_SLIDE}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Rajesh Tengshe",
            mail: "rajesh.tengshe@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default LeanAccessor;
