import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem, BreadcrumbSeparator,
  BreadcrumbPage
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
import SERVICECLINIC_VID from "@/assets/Video/Service Clinic v3 1.mp4?url";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import { Icon } from "@/components/ui/icon";
const ServiceClinic = () => {
  const { t, ready } = useTranslation('next-gen-ams/transform/ServiceClinic')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">Home</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>TCS ITSM Analytics</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title={t('title')} className="mb-3 mt-6" />
        <Separator />

        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              {t('content.1')}
            </li>
            <li>
              {t('content.2')}
            </li>
          </ul>
          <div className="mt-4">
            <VideoPlayer
              src={SERVICECLINIC_VID}
              autoPlay={false}
              loop={true}
              className="rounded-xl"
              title={"Explore our Excellence"}
            />
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard
        contactList={[
          {
            name: "Jaya Raj",
            mail: "raj.jaya@tcs.com",
          },
          {
            name: "Taj peeran",
            mail: "tajpeeran.a@tcs.com",
          },
          {
            name: "Dinakar Prabhakar",
            mail: "dinakar.prabhakar@tcs.com",
          },
        ]}
      />
    </section>
  );
};
export default ServiceClinic;
