import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import SUCESS_BANK from "@/assets/docs/CaseStudies/Strengthening the basics to stabilize operations for an Indian Retailer.pdf?url";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
const StrengtheningOperations = () => {
  return (
    <section className="py-16 pb-40">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/doc/case-study" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">Home</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/case-study">Case Studies</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>
                Strengthening the basics to stabilize operations for an Indian Retailer
              </BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <BlogHeader
          title={"Strengthening the basics to stabilize operations for an Indian Retailer"}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <h4 className="mb-2 underline"></h4>
                <PDFViewer
                  fileUrl={SUCESS_BANK}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default StrengtheningOperations;
