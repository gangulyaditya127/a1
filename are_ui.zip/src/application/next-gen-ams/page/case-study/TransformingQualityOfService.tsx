import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import TQS_DOC from "@/assets/docs/CaseStudies/Transforming Quality of Services with Intelligent Conversational Assistant.pdf?url";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import PDFViewer from "@/components/ui/pdf-viewer";
const TransformingQualityOfService = () => {
  const { t, ready } = useTranslation('next-gen-ams/case-study/TransformingQualityOfService')
  if(!ready){
    return null;
  }
  return (
    <section className="py-16 pb-40">
      <Container className="relative mx-auto mt-9 max-w-4xl">
        <NavigateBackButton fallbackUrl="/doc/case-study" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/doc/case-study">{t('app')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <BlogHeader title={t('title')} className="mt-6" />
        <p className="text-muted-foreground mt-1">{t('content.0')}</p>
        <Separator className="mt-3"/>
        <div className="leading-7">
          {/* <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              Dive into our Transforming Quality of Services with Intelligent Conversational Assistant section, where we highlight the
              remarkable achievements of our clients using the Next Gen AMS
              framework and the iSmart platform.
            </li>
            <li>
              Each success story showcases how our innovative solutions have
              driven efficiency, productivity, and transformation across various
              industries, providing real-world examples of challenges overcome
              and goals achieved.
            </li>
          </ul> */}
          <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <h4 className="mb-2 underline"></h4>
                <PDFViewer
                  fileUrl={TQS_DOC}
                />
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default TransformingQualityOfService;
