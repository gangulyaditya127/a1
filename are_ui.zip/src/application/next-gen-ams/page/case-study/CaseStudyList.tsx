import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem, BreadcrumbSeparator,
    BreadcrumbPage
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";

type appList = {
    title: string;
    description: string;
    href: string
}[];

const CaseStudyList = () => {
    const { t, ready } = useTranslation('next-gen-ams/case-study/CaseStudyList')
    const { t: case_study } = useTranslation('ismart_app_case_study')
    if (!ready) {
        return null;
    }
    const APP_LIST = case_study("app", { returnObjects: true }) as appList
    return (
        <section className="py-20 pb-24">
            <Container className="max-w-6xl">
                <NavigateBackButton className="px-4"/>
                <Breadcrumb className="px-4">
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">{t('home')}</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{t('title')}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title={t('title')} className="mb-3 mt-6 px-4" />
                <Separator className="px-4"/>
                <div className="grid gap-4 py-4">
                    {
                        APP_LIST.map((el, index) => (
                            <CaseStudyListItem
                                title={el.title}
                                link={el.href}
                                index={index}
                                key={index}
                            />
                        ))
                    }
                </div>
            </Container>
            <Meteors number={5} />
        </section>
    );
};



function CaseStudyListItem({
    title,
    link,
    index
}: {
    title: string,
    link: string,
    index: number
}) {
    return (
        <Link to={link} className="transition-colors group text-muted-foreground flex gap-2 items-center hover:bg-secondary/70 px-4 py-2 rounded-lg">
            <p className="shrink-0">{title}</p>
            <Separator className="shrink group-hover:text-muted-foreground transition-colors"/>
            <p>{index+1}</p>
        </Link>
    )
}



export default CaseStudyList;
