import Testimonials from "@/application/ismart/features/Testimonials";
import Container from "@/components/ui/container";

export default function TestimonialPage() {
    return (
        <Container className="mt-32">
            <Testimonials />
        </Container>
    )
}