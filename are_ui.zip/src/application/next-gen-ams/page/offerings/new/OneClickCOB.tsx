import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import DOC from "@/assets/docs/1TouchCOB.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const OneClickCOB = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>One Click COB</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="One Click COB"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            One Click COB Module is a Single One Stop Shop solution for all failover needs. Unified Interface that is built provides a visual representation of the Traffic patterns between the Data Centers and the Data Center availability status along with providing an ability to invoke the failover with a single click followed by Authentication to initiate the Data Center failover.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={DOC}
                            />

                        </ul>
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default OneClickCOB;

