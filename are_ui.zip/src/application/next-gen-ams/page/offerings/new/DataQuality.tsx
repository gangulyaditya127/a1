import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import DOC from "@/assets/docs/Operate/DQ_ARE.pdf";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const DataQuality = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Data Quality Agent</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Data Quality Agent"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            Data quality engine is to improve the ticket resolution data quality in service now.
                        </li>
                        <li>
                            The tool can audit the existing quality of data entry in ITSM tool and also provide a templatized approach to improve the quality of entry going forward.
                        </li>
                        <li>
                            The improved quality of data in Service Now forms the foundation for building AI based intelligent resolution recommenders and root cause analyzers.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={DOC}
                            />

                        </ul>
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default DataQuality;

