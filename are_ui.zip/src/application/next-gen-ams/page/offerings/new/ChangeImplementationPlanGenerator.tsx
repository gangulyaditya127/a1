import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import DOC from "@/assets/docs/Gen AI for Change Imp Plan Creation.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const ChangeImplementationPlanGenerator = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Change Implementation Plan Generation</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Change Implementation Plan Generation"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            Change Implementation plan creation is an essential process before deploying changes in production and could often be a time-consuming process.
                        </li>
                        <li>
                            These are reviewed by the Change Approval Board governance call by the relevant stakeholders before the change is approved. The Gen AI based agent automatically generates a change implementation plan in a defined template. The Gen AI agent is trained based on the input system requirements or user story documents and the desired template.
                        </li>
                        <li>
                            A typical change implementation plan could have sections that include Change description, Scope, Impacted Systems, Stakeholders, Pre-Implementation Activities, Detailed Implementation Activities, Cutover Implementation Window, Post Implementation Activities, Risk & Mitigation, Rollout Plan, and Communication Plan.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={DOC}
                            />

                        </ul>
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default ChangeImplementationPlanGenerator;

