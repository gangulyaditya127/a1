import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
// import QUICK_ASSESMENT_DOC from "@/assets/docs/ARE Quick Assessment.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
// import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const DueDeligenceToolkit = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Due Diligence Toolkit</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Due Diligence Toolkit"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            The Due Diligence Toolkit is designed to assist teams that study a given customer landscape, that is under the scope of Application Maintenance and Support.
                        </li>
                        <li>
                            It consists of:
                            <ul className="list-disc pl-5">
                                <li>A standard template to consolidate questions and seek information from customer</li>
                                <li>A detailed set of tasks to be performed during Due Diligence and the owner(organization role) responsible for the task. It can also be used to track and visualize the progress and follow up on the incomplete activities.
                                </li>
                            </ul>
                        </li>
                    </ul>
                    {/* <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={QUICK_ASSESMENT_DOC}
                            />

                        </ul>
                    </div> */}
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default DueDeligenceToolkit;

