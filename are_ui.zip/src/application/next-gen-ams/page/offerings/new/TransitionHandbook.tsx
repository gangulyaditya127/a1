import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
// import QUICK_ASSESMENT_DOC from "@/assets/docs/ARE Quick Assessment.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
// import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const TransitionHandbook = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Transition Handbook</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Transition Handbook"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            Transition Handbook is a comprehensive set of documents that assist teams to define the transition approach, plan the transition and govern the progress.
                        </li>
                        <li>
                            It comprises of the following assets:
                            <ul className="list-disc pl-5">
                                <li>
                                    Transition Approach for Application Maintenance
                                </li>
                                <li>
                                    Transition Deliverables
                                </li>
                                <li>
                                    Pre Transition Checklist
                                </li>
                                <li>
                                    KT Evaluation Checklist
                                </li>
                                <li>
                                    Secondary Support Evaluation Checklist
                                </li>
                                <li>
                                    IT Shift Scheduler
                                </li>
                                <li>
                                    Operational Review & Governance Template (Weekly, Monthly)
                                </li>
                                <li>
                                    IT Health check Monitoring checklist
                                </li>
                            </ul>
                        </li>
                    </ul>
                    {/* <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={QUICK_ASSESMENT_DOC}
                            />

                        </ul>
                    </div> */}
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Rajesh Tengshe",
                    mail: "rajesh.tengshe@tcs.com"
                }
            ]} />
        </section>
    );
};
export default TransitionHandbook;

