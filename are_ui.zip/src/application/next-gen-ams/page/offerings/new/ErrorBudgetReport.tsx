import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import DOC from "@/assets/docs/Gen AI Based Error Budget Reporting.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const ErrorBudgetReport = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Error Budget Report (Gen AI)</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Error Budget Report (Gen AI)"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            SRE proposes 4 golden signals to take control of stability and quality of production – Volume, Availability, Latency and Error. The Gen AI based error budget reporting tool processes voluminous system logs of several applications and automatically publishes the Error Budget reports. It summarizes the health by the key SRE metrics. It also calculates the deviations against the SLO and Error Budgets.
                        </li>
                        <li>
                            This tool significantly assists SRE engineers to analyze enormous amount of log data, create error budget reports and develop observations, potential risks and insights that can help improve the quality of production.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={DOC}
                            />

                        </ul>
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default ErrorBudgetReport;

