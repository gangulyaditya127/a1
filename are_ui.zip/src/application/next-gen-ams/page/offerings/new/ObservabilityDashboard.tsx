import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import DOC from "@/assets/docs/TCS observabilityDashboard.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import ContactCard from "@/application/next-gen-ams/features/ContactCard";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
const ObservabilityDashboard = () => {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Observability Dashboard</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title="Observability Dashboard"
                    className="mb-3 mt-6"
                />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            Observability Dashboard is a critical component of ARE’ Observability suite of solutions. It provides an integrated visualization of both horizontal observability (Customer journeys, Business Processes) and Vertical Observability (health of Application Health, Middleware & Infrastructure health).
                        </li>
                        <li>
                            This helps in alleviating the need of monitoring engineers to look at multiple screens to take control of production environment, thereby facilitating faster response. It also provides the ability to get early warning/ alerts of any degradation of health, which enables proactive maintenance.
                        </li>
                        <li>
                            Other capabilities such as Event Correlation helps in correlating events from across multiple sources, thereby deduplicating alerts/ tickets to reduce the workload on the service engineers.
                        </li>
                        <li>
                            The Anomaly detection solution from ARE works closely with Observability dashboard by building ML models that can dynamically adjust baselines/ thresholds to reduce false alerts and detect variation (anomalies) to proactively identify and address potential issues.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <ul className="flex flex-col">
                            <PDFViewer
                                fileUrl={DOC}
                            />

                        </ul>
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard contactList={[
                {
                    name: "Ramanujam Srinivasagopalan",
                    mail: "r.srinivasagopalan@tcs.com"
                }
            ]} />
        </section>
    );
};
export default ObservabilityDashboard;

