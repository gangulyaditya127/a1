import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import BlogHeader from "../../../features/BlogHeader";
import BATCH_DOC from '@/assets/docs/Operate/GenAI/TCS ARE GenMindLab - ARP Doc Generator.pdf?url'
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";

const ARPGenAIDoc = () => {
    return (
        <section className="py-16 pb-24">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/doc/ismart-catalog" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/ismart-catalog">Intelligent Support Mart</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/ismart-catalog/GenMindLab`}> GenMindLab</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/gen-ai-usecase`}> Gen AI Usecases</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>ARP (Application Recovery Procedure) document generator​</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title="ARP (Application Recovery Procedure) document generator​ in production management" className="mb-3 mt-6" />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            The ARP (Application Recovery Procedure) Document Generator is a Gen Al-based solution designed to automate the creation of comprehensive recovery procedures based on incident data and workflow definitions.
                        </li>
                        <li>
                            This tool assists Application or Production Support teams by generating accurate and relevant ARP documents, outlining the necessary steps for system recovery. By utilizing Al to analyze workflow data, the tool simplifies the documentation process and ensures that recovery actions are consistently documented and aligned with workflows executions.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <PDFViewer
                            fileUrl={BATCH_DOC}
                        />
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard />
        </section>
    );
};
export default ARPGenAIDoc;
