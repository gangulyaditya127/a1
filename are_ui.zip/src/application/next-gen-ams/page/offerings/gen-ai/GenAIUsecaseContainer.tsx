import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
// import { HoverEffect } from "@/components/ui/card-hover-effect";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
// import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
// import { GEN_AI_USECASES } from "./data.gen-ai-usecase";
import GenAIContainerV2 from "./GenAIContainerV2";


const GenAIUsecaseContainer = () => {
    return (
        <section className="py-20 pb-24">
            <Container className="max-w-6xl">
                <NavigateBackButton />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/ismart-catalog">Intelligent Support Mart</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/ismart-catalog/GenMindLab`}>GenMindLab</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage> Gen AI Usecases</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title={"Intelligent Support Mart - Gen AI Usecases"} className="mb-3 mt-6" />
                {/* <Separator /> */}
                {/* <HoverEffect
                    className="py-4"
                    items={GEN_AI_USECASES.map((el, i) => ({
                        title: el.title,
                        link: el.href,
                        description: el.description,
                        key: i
                    }))}
                /> */}
                <GenAIContainerV2 />
            </Container>
            <Meteors number={5} />
        </section>
    );
};

export default GenAIUsecaseContainer;
