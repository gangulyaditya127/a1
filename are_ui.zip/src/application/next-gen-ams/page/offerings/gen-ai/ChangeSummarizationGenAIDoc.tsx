import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import BlogHeader from "../../../features/BlogHeader";
import BATCH_DOC from '@/assets/docs/Operate/GenAI/TCS ARE GenMindLab - Change Summarization.pdf?url'
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";

const ChangeSummarizationGenAIDoc = () => {
    return (
        <section className="py-16 pb-24">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/doc/ismart-catalog" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/ismart-catalog">Intelligent Support Mart</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/ismart-catalog/GenMindLab`}>GenMindLab</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/gen-ai-usecase`}> Gen AI Usecases</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Change summarization​ in production management</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title="Change summarization​ in production management" className="mb-3 mt-6" />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            This feature aims to automate the generation of concise change summaries from change descriptions and justifications. By leveraging Gemini's LLM capabilities, this feature reduces the manual effort required for summarizing changes, thus accelerating the review process. The ICRM tool will process approximately 6000+ changes monthly, equating to a significant reduction in manual work.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <PDFViewer
                            fileUrl={BATCH_DOC}
                        />
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard />
        </section>
    );
};
export default ChangeSummarizationGenAIDoc;
