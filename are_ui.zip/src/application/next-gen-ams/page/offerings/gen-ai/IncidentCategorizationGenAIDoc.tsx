import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import BlogHeader from "../../../features/BlogHeader";
import BATCH_DOC from '@/assets/docs/Operate/GenAI/TCS ARE GenMindLab - Incident Categorization.pdf?url'
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";

const IncidentCategorizationGenAIDoc = () => {
    return (
        <section className="py-16 pb-24">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/doc/ismart-catalog" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/ismart-catalog">Intelligent Support Mart</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/ismart-catalog/GenMindLab`}> GenMindLab</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to={`/doc/gen-ai-usecase`}> Gen AI Usecases</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Incident categorization in production management</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title="Incident categorization in production management" className="mb-3 mt-6" />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            The modern business landscape demands a proactive approach to customer service, where understanding recurring issues is crucial for effective problem resolution. MW team often receive numerous incident tickets through platforms like ServiceNow, which can become overwhelming without proper categorization.
                        </li>
                        <li>
                            Analyzing these tickets for recurring patterns and themes enables businesses to categorize issues effectively, allowing them to prioritize resources and address customer challenges promptly. This, in turn, leads to enhanced customer satisfaction, streamlined operations, and improved service quality.
                        </li>
                    </ul>
                    <div className="mt-4">
                        <PDFViewer
                            fileUrl={BATCH_DOC}
                        />
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard />
        </section>
    );
};
export default IncidentCategorizationGenAIDoc;
