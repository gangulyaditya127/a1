export const GEN_AI_USECASES = [
    {
        "title": "Change summarization​​",
        "href": "/doc/gen-ai/change-summary",
        "description":
            "This feature aims to automate the generation of concise change summaries from change descriptions and justifications. By leveraging Gemini's LLM capabilities, this feature reduces the manual effort required for summarizing changes, thus accelerating the review process. The ICRM tool will process approximately 6000+ changes monthly, equating to a significant reduction in manual work..​"
    },
    {
        "title": "Incident categorization",
        "href": "/doc/gen-ai/incident-categorization",
        "description":
            "The modern business landscape demands a proactive approach to customer service, where understanding recurring issues is crucial for effective problem resolution. MW team often receive numerous incident tickets through platforms like ServiceNow, which can become overwhelming without proper categorization. Analyzing these tickets for recurring patterns and themes enables businesses to categorize issues effectively, allowing them to prioritize resources and address customer challenges promptly. This, in turn, leads to enhanced customer satisfaction, streamlined operations, and improved service quality.​"
    },
    {
        "title": "MIM resolution recommender",
        "href": "/doc/gen-ai/mim",
        "description":
            "Empower business to streamline issue resolution with Al-driven insights, leveraging Google Vertex Al's cutting-edge technology. The idea is to introduce a tool which can provide resolution recommendations and to challenge manual resolution process, which are often time consuming, prone to errors and lack standardized approach​"
    },
    {
        "title": "ARP document generator​​",
        "href": "/doc/gen-ai/arp",
        "description":
            "The ARP (Application Recovery Procedure) Document Generator is a Gen Al-based solution designed to automate the creation of comprehensive recovery procedures based on incident data and workflow definitions. This tool assists Application or Production Support teams by generating accurate and relevant ARP documents, outlining the necessary steps for system recovery. By utilizing Al to analyze workflow data, the tool simplifies the documentation process and ensures that recovery actions are consistently documented and aligned with workflows executions.​"
    }
]