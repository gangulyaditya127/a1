import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { Link } from "react-router-dom";
import BlogHeader from "../../../features/BlogHeader";
import BOT_DOC from '@/assets/docs/Operate/iSmart - Solution-BotsFamily.pdf?url'
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import { Icon } from "@/components/ui/icon";
import PDFViewer from "@/components/ui/pdf-viewer";
const BotFamilyDoc = () => {

    const { t, ready } = useTranslation('/next-gen-ams/offerings/ismart/BotFamilyDoc');
    if (!ready) {
        return null;
    }
    return (
        <section className="py-16 pb-24">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/doc/ismart-catalog" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/are-assets">Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{t('title')}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title={t('title')} className="mb-3 mt-6" />
                <Separator />
                <div className="leading-7">
                    <ul className="mt-4 flex flex-col gap-y-4">
                        <li>
                            {t('content.0')}
                        </li>
                        <ul className="list-disc space-y-1.5 pl-4">
                            <li>
                                <span className="underline">{t('content.1')}</span> {t('content.2')}
                            </li>
                            <li>
                                <span className="underline">{t('content.3')}</span> {t('content.4')}
                            </li>
                            <li>
                                <span className="underline">{t('content.5')}</span> {t('content.6')}
                            </li>
                        </ul>
                    </ul>
                    <div className="mt-4">
                        <PDFViewer
                            fileUrl={BOT_DOC}
                        />
                    </div>
                </div>
            </Container>
            <Meteors number={5} />
            <ContactCard />
        </section>
    );
};
export default BotFamilyDoc;
