import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import BlogHeader from "../../../features/BlogHeader";
import IPROMPT_DOC from '@/assets/docs/Operate/iSmart - Solution-iPrompt.pdf?url'
import ContactCard from "../../../features/ContactCard";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
const IPromptDoc = () => {
  return (
    <section className="py-16 pb-24">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/doc/ismart-catalog" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">Home</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon></SlashIcon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <Link to="/doc/are-assets">Assets</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon></SlashIcon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>Effort Calculator​</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title="Effort Calculator​" className="mb-3 mt-6" />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              Estimating effort for application management engagements is often time-consuming and prone to
              human error. Traditional methods may not accurately account for application complexity and historical
              performance data.
            </li>
            <li>
              Effort Calculator​ is a tool that utilizes function point estimation and machine learning to streamline effort
              estimation for application management engagements.
            </li>
          </ul>
          <div className="mt-4">
            <PDFViewer
              fileUrl={IPROMPT_DOC}
            />
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard />
    </section>
  );
};
export default IPromptDoc;
