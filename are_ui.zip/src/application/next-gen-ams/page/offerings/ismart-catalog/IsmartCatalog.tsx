import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
// import { ISMART_DOCS } from "@/components/layout/data/ISMART_DOC";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { SlashIcon } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import TiltCard from "@/application/ismart/features/TiltCard";

const categories = [
  {
    value: "Onboarding",
    label: "Onboarding",
    image: "/assets/appthumbnail/app_onboarding.jpg"
  },
  {
    value: "Observability Assists",
    label: "Observability Assists",
    image: "/assets/appthumbnail/iPrompt.jpg"
  },
  {
    value: "Ticket Management & Resolution",
    label: "Ticket Management & Resolution",
    image: "/assets/appthumbnail/iprm.avif"
  },
  {
    value: "Operations",
    label: "Operations",
    image: "/assets/appthumbnail/iprm.jfif"
  },
  {
    value: "Governance and Management",
    label: "Governance and Management",
    image: "/assets/appthumbnail/regulatory.jpg"
  },
  {
    value: "GenMindLab",
    label: "GenMindLab",
    image: "/assets/appthumbnail/knowledge_amanagement.jpg"
  },

]



const IsmartCatalog = () => {
  const { t, ready } = useTranslation('ismart_doc');
  const { t: common } = useTranslation('common')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-20 pb-24">
      <Container className="max-w-6xl">
        <NavigateBackButton fallbackUrl="/" className="" />
        <Breadcrumb className="">
          <BreadcrumbList>
            <BreadcrumbItem>
              <Link to="/">{common('home')}</Link>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <SlashIcon />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('title')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <BlogHeader title={t('title')} className="mt-6 " />
        <p className="mt-2 text-muted-foreground ">{t('subtitle')}</p>
        <div className="grid grid-cols-4 gap-4 mt-6">
          {
            categories.map(cat => (
              <TiltCard
                title={cat.value}
                openInNew={false}
                link={cat.value}
                img={cat.image}
                className={"bg-gradient-to-br from-secondary to-secondary"}
                key={cat.value}
                description={""}
              />
            ))
          }
        </div>


      </Container>
      <Meteors number={5} />
    </section>
  );
};

export default IsmartCatalog;
