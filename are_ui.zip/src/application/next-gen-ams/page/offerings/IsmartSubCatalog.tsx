import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { IconNameProp } from "@/components/ui/icon";
import { Meteors } from "@/components/ui/meteors";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Separator } from "@/components/ui/seperator";
import { SlashIcon } from "lucide-react";
import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { Link, useParams } from "react-router-dom";
import { HoverEffect } from "@/components/ui/card-hover-effect";
type IsmartDocListProp = {
    icon: IconNameProp,
    displayText: string,
    route: string,
    key: number,
    openInNew: boolean,
    description: string
    tag?: string
}[]
const IsmartSubCatalog = () => {
    const { t: common } = useTranslation('common')
    const { t, ready, i18n } = useTranslation('ismart_doc');

    const { tag } = useParams()
    const ISMART_DOCS = useMemo<IsmartDocListProp>(() => {
        return t('doc', { returnObjects: true }) as IsmartDocListProp
    }, [i18n.language])
    if (!ready) {
        return null
    }
    return (
        <section className="py-20 pb-24">
            <Container className="max-w-6xl">
                <NavigateBackButton fallbackUrl="/" className="" />
                <Breadcrumb className="">
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">{common('home')}</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/doc/ismart-catalog">{t('title')}</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{tag}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title={`${t('title')} - ${tag}`} className="mt-6 " />
                <Separator className="mt-3" />
                <HoverEffect
                    className="py-4 lg:grid-cols-2"
                    items={ISMART_DOCS.filter(el => el.tag == tag).map((el, i) => ({
                        title: el.displayText,
                        link: el.route,
                        description: el.description,
                        icon: el.icon,
                        key: i,
                    }))}
                />

            </Container>
            <Meteors number={5} />
        </section>
    )
}
export default IsmartSubCatalog;