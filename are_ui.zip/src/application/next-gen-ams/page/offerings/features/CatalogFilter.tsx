import { Option } from "@/components/ui/multi-select-combo";
import { cn } from "@/lib/tailwind.utils";
import { CheckCheckIcon } from "lucide-react";

import { useState } from "react";

const categories: Option[] = [
    {
        value: "Onboarding",
        label: "Onboarding"
    },
    {
        value: "Observability Assists",
        label: "Observability Assists"
    },
    {
        value: "Ticket Management & Resolution",
        label: "Ticket Management & Resolution"
    },
    {
        value: "Operations",
        label: "Operations"
    },
    {
        value: "Governance and Management",
        label: "Governance and Management"
    },

]

const CatalogFilter = () => {
    const [selectedCat, setSelectedCat] = useState<string[]>(() => categories?.map(el => el.value));

    const handleClick = (value: string) => {
        selectedCat?.includes(value) ?
            setSelectedCat(prevState => (
                prevState.filter(el => el != value)
            )) :
            setSelectedCat((prevState) => ([...prevState, value]))

    }

    const isSelected = (value: string) => {
        return selectedCat.includes(value)
    }

    return (
        <div className="mt-2 text-sm">
            <p className="font-medium text-muted-foreground mb-2">Categories</p>
            <div className="flex items-center gap-4 ">
                {
                    categories?.map(({ value, label }) => (
                        <button className={cn("bg-secondary px-6 py-3 relative rounded-lg", isSelected(value) ? "bg-blue-600" : "bg-secondary")} onClick={() => handleClick(value)}>
                            {isSelected(value) ? <CheckCheckIcon className="absolute top-0 left-1 h-4 w-4" /> : null}
                            {label}
                        </button>
                    ))
                }
            </div>
        </div>
    )
}
export default CatalogFilter;