import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
import FRAMEWORK_FOR_AMS from "@/assets/docs/Offerings/ARE Overview - 27 Feb 2025.pdf?url";
import { Separator } from "@/components/ui/seperator";
import BlogHeader from "../../features/BlogHeader";
import ContactCard from "../../features/ContactCard";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useTranslation } from "react-i18next";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
import ABOUT_VID from '@/assets/Video/ARE AV - 3-40 min.mp4'
import PDFViewer from "@/components/ui/pdf-viewer";
const AboutNextGenAMS = () => {
  const { t, ready } = useTranslation('next-gen-ams/offerings/AboutNextGenAMS')
  if (!ready) {
    return null;
  }
  return (
    <section className="py-16 pb-40">
      <Container className="relative mx-auto mt-6 max-w-4xl">
        <NavigateBackButton fallbackUrl="/" />
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink>
                <Link to="/">{t('home')}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <Icon name="slash"></Icon>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage>{t('about')}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <BlogHeader
          title={t('title')}
          className="mb-3 mt-6"
        />
        <Separator />
        <div className="leading-7">
          <ul className="mt-4 flex flex-col gap-y-4">
            <li>
              {t('content.0')}
            </li>
            <li>
              {t('content.1')}
            </li>
          </ul>
          <div className="mt-4">
            <VideoPlayer
              src={ABOUT_VID}
              autoPlay={false}
              loop={true}
              className="rounded-xl"
              title={"Explore our Excellence"}
            />
          </div>
          <div className="mt-4">
            <ul className="flex flex-col">
              <li>
                <PDFViewer
                  fileUrl={FRAMEWORK_FOR_AMS}
                />
               
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Meteors number={5} />
      <ContactCard contactList={[
        {
          name: "Ramanujam Srinivasagopalan",
          mail: "r.srinivasagopalan@tcs.com"
        }
      ]} />
    </section>
  );
};
export default AboutNextGenAMS;

