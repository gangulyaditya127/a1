import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { ArrowRightIcon, Cctv, Clover, ToolCase, Fingerprint, GraduationCap, Origami, SearchIcon, ShieldCheck, Siren, SlashIcon, Ticket, MemoryStick, PencilRuler, Replace } from "lucide-react";
import { useId, useState } from "react";
import { Link } from "react-router-dom";
import BlogHeader from "../features/BlogHeader";
import { Separator } from "@/components/ui/seperator";
import { cn } from "@/lib/tailwind.utils";
import { ARE_ASSETS } from "../data/are-assets";
import { AgentsData } from "@/application/agentic-are/data/areagent.data";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Input } from "@/components/ui/input";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { updateSearch, updateSelectedTab, updateSelectedTag } from "../slice/areAssersSlice";
import { useDispatch } from "react-redux";
const SECTIONS = [
    {
        value: 'all',
        label: 'Alls',
        icon: <ToolCase className="h-4 w-4" />
    },
    {
        value: 'onboarding',
        label: 'Assess & Onboard',
        icon: <Clover className="h-4 w-4" />
    },
    // {
    //     value: 'common-purpose',
    //     label: 'Common Purpose',
    //     icon: <ChevronsLeftRight className="h-4 w-4" />
    // },
    {
        value: 'incident-request-problem-management',
        label: 'Incident, Request & Problem',
        icon: <Ticket className="h-4 w-4" />
    },
    {
        value: 'observability-event-management-agents',
        label: 'Observability & Event',
        icon: <Cctv className="h-4 w-4" />
    },

    {
        value: 'change-and-certificate-management',
        label: 'Change',
        icon: <Replace className="h-4 w-4" />
    },
    {
        value: 'certificate-management',
        label: 'Certificate',
        icon: <ShieldCheck className="h-4 w-4" />
    },

    {
        value: 'capacity',
        label: 'Capacity',
        icon: <MemoryStick className="h-4 w-4" />
    },
    {
        value: 'security',
        label: 'Security',
        icon: <Fingerprint className="h-4 w-4" />
    },
    {
        value: 'sre',
        label: 'SRE',
        icon: <PencilRuler className="h-4 w-4" />
    },
    {
        value: 'governance-operations-agents',
        label: 'Governance & Operations',
        icon: <Siren className="h-4 w-4" />
    },
    {
        value: 'talent-management',
        label: 'Knowledge and Talent Management',
        icon: <GraduationCap className="h-4 w-4" />
    },
]


export default function AREAssets() {
    const dispatch = useAppDispatch();
    const selectedTab = useAppSelector((state) => state.areAssets.selectedTab);
    return (
        <section className="py-20 pb-24">
            <Container className="max-w-6xl">
                <NavigateBackButton />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>TCS ARE Assets</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>

                <BlogHeader title={"TCS ARE Assets "} className="mt-8" />
                <p className="text-muted-foreground mt-1 ">From performance hiccups to reliability gaps, We have a solution for every AMS challenge.</p>
                <Separator className="my-12" />
                <Tabs
                    value={selectedTab}
                    onValueChange={(selectedTab) => dispatch(updateSelectedTab({ selectedTab }))}
                    className="grid grid-cols-[360px_auto]">
                    <TabsList className="sticky top-[90px] h-screen text-muted-foreground font-medium bg-background flex-col" >
                        {SECTIONS.map(({ icon, label, value }) => (
                            <TabsTrigger
                                value={value}
                                key={value}
                                className={cn('cursor-pointer block px-2 py-2 hover:text-foreground transition-color duration-100 text-md')}>
                                <div className="flex items-center gap-2">
                                    {icon}
                                    <span>{label}</span>
                                </div>
                            </TabsTrigger>
                        ))}
                    </TabsList>
                    {SECTIONS.map(({ label, value }) => (
                        <TabsContent value={value}>
                            <AREAssetTabContent label={label} value={value} key={value} />
                        </TabsContent>
                    ))}
                </Tabs>
            </Container>
        </section>
    )
}


const AREAssetTabContent = ({ label, value }: { label: string, value: string }) => {
    const selectedTag = useAppSelector((state) => state.areAssets.selectedTag);
    const search = useAppSelector((state) => state.areAssets.search);
    const dispatch = useDispatch();

    const setSelectedTag = (selectedTag: string) => {
        dispatch(updateSelectedTag({ selectedTag }))
    }

    const setSearch = (search: string) => {
        dispatch(updateSearch({ search }))
    }
    const [assetList] = useState(() => {
        let genericAssets: { isGenAI?: boolean; title: string; href: string; description: string; }[] = [];
        let agents = [];

        if (value == "all") {
            ARE_ASSETS.forEach(el => {
                genericAssets.push(...el.items)
            })
            agents = AgentsData.map((item, index) => ({
                href: `/agentic-are/${item.slug}`,
                title: item.AgentName,
                description: item.Description,
                isGenAI: true,
                index: `gen-ai-${index}`,
                ...item
            }));
        } else {
            genericAssets = ARE_ASSETS
                .filter((el) => el.sectionValue === value)[0]?.items ?? [];
            agents = AgentsData.filter((el) => el["are-asset-category"] === value).map((item, index) => ({
                href: `/agentic-are/${item.slug}`,
                title: item.AgentName,
                description: item.Description,
                isGenAI: true,
                index: `gen-ai-${index}`,
                ...item
            }));
        }
        return [...genericAssets.map((el, index) => ({ ...el, index: `generic-${index}` })), ...agents].sort((a, b) => a.title.trim().localeCompare(b.title.trim(), undefined, { sensitivity: 'base' }));
    })
    const id = useId();

    const filteredAgentList = assetList.filter((el) => {
        const isSearchPresent = el.title.toLowerCase().includes(search.toLowerCase());
        const isTag = selectedTag == "GenAI" ? el.isGenAI : selectedTag == "generic" ? !el.isGenAI : true;
        return isSearchPresent && isTag
    })

    const selectedTagAssetCount = assetList.filter((el) => selectedTag == "GenAI" ? el.isGenAI : selectedTag == "generic" ? !el.isGenAI : true).reduce((acc) => acc + 1, 0);

    return (
        <>
            <h2 className="font-medium mb-2" >{label}{" "} ({selectedTagAssetCount})</h2>
            <div className="flex items-center justify-between mb-4 gap-4">
                <ToggleGroup onValueChange={(val) => {
                    setSelectedTag(val.length != 0 ? val : "all")
                }} variant="outline" className="inline-flex  w-[270px] cursor-pointer rounded-xl  shrink-0" type="single" value={selectedTag} defaultValue="all">
                    <ToggleGroupItem value="all" className="cursor-pointer">All</ToggleGroupItem>
                    <ToggleGroupItem value="GenAI" className="cursor-pointer">GenAI</ToggleGroupItem>
                    <ToggleGroupItem value="generic" className="cursor-pointer">Non-GenAI</ToggleGroupItem>
                </ToggleGroup>
                <div className="*:not-first:mt-2 w-full">
                    <div className="relative">
                        <Input
                            id={id}
                            className="peer ps-9 pe-9 h-9"
                            placeholder="Search..."
                            type="search"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <div className="text-muted-foreground/80 pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50">
                            <SearchIcon size={16} />
                        </div>
                        <button
                            className="text-muted-foreground/80 hover:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 absolute inset-y-0 end-0 flex h-full w-9 items-center justify-center rounded-e-md transition-[color,box-shadow] outline-none focus:z-10 focus-visible:ring-[3px] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50"
                            aria-label="Submit search"
                            type="submit"
                        >
                            <ArrowRightIcon size={16} aria-hidden="true" />
                        </button>
                    </div>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                {
                    filteredAgentList.map((itemdetails) => (
                        <Link
                            to={itemdetails.href}
                            key={itemdetails.index}
                            className="relative h-40 bg-secondary/50 p-6 rounded-lg overflow-hidden  hover:-translate-y-1 transition-transform ease-in-out duration-100 border border-1"
                        >

                            <p className="text-base font-medium text-neutral-800 dark:text-white relative z-20">
                                {itemdetails.title}
                            </p>
                            <p className="text-neutral-600 dark:text-neutral-400 mt-3 text-sm font-normal relative z-20 line-clamp-3 ">
                                {itemdetails.description}
                            </p>
                            {itemdetails?.isGenAI && <p className="text-xs font-medium bg-blue-600 py-[2px] px-[10px] rounded-full mt-2 flex w-fit">GenAI</p>}
                        </Link>
                    ))
                }
            </div>
            {
                filteredAgentList.length == 0 && (
                    <div className="flex flex-col items-center gap-2 mt-12 rounded-lg w-full text-sm text-muted-foreground">
                        <Origami className="h-10 w-10" />
                        <p>{getNotFoundText(search, selectedTag, label)}</p>
                    </div>
                )
            }
        </>
    )
}

const getNotFoundText = (search: string, selectedTag: string, section: string) => {
    return (`No ARE asset present ${search.length != 0 ? `with search keyword "${search}"` : ''}` +
        `${selectedTag != "all" ? ` inside ${selectedTag} category` : ''} for ${section}`)
}

export const Grid = ({
    pattern,
    size,
}: {
    pattern?: number[][];
    size?: number;
}) => {
    const p = pattern ?? [
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    ];
    return (
        <div className="pointer-events-none absolute left-1/2 top-0  -ml-20 -mt-2 h-full w-full [mask-image:linear-gradient(white,transparent)]">
            <div className="absolute inset-0 bg-gradient-to-r  [mask-image:radial-gradient(farthest-side_at_top,white,transparent)] dark:from-zinc-900/30 from-zinc-100/30 to-zinc-300/30 dark:to-zinc-900/30 opacity-100">
                <GridPattern
                    width={size ?? 20}
                    height={size ?? 20}
                    x="-12"
                    y="4"
                    squares={p}
                    className="absolute inset-0 h-full w-full  mix-blend-overlay dark:fill-white/10 dark:stroke-white/10 stroke-black/10 fill-black/10"
                />
            </div>
        </div>
    );
};

export function GridPattern({ width, height, x, y, squares, ...props }: any) {
    const patternId = useId();

    return (
        <svg aria-hidden="true" {...props}>
            <defs>
                <pattern
                    id={patternId}
                    width={width}
                    height={height}
                    patternUnits="userSpaceOnUse"
                    x={x}
                    y={y}
                >
                    <path d={`M.5 ${height}V.5H${width}`} fill="none" />
                </pattern>
            </defs>
            <rect
                width="100%"
                height="100%"
                strokeWidth={0}
                fill={`url(#${patternId})`}
            />
            {squares && (
                <svg x={x} y={y} className="overflow-visible">
                    {squares.map(([x, y]: any) => (
                        <rect
                            strokeWidth="0"
                            key={`${x}-${y}-${patternId}`}
                            width={width + 1}
                            height={height + 1}
                            x={x * width}
                            y={y * height}
                        />
                    ))}
                </svg>
            )}
        </svg>
    );
}
