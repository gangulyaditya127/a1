import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function DOCShimmerLoader() {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <Skeleton className="h-4 w-10 mb-2 rounded-lg" />
                <Skeleton className="h-4 w-32 mb-4 rounded-lg" />
                <Skeleton className="h-14 w-full mb-6 rounded-lg" />
                <Skeleton className="h-[200px] w-full mb-6 rounded-lg" />
                <Skeleton className="h-[300px] w-full rounded-lg" />
            </Container>
        </section>

    )
}