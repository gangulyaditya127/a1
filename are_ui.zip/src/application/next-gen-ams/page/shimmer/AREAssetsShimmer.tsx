import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function AREAssetsShimmer() {
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-6xl">
                <Skeleton className="h-4 w-10 mb-2 rounded-lg" />
                <Skeleton className="h-4 w-32 mb-4 rounded-lg" />
                <Skeleton className="h-14 w-full mb-6 rounded-lg" />
                <Skeleton className="h-6 w-32 mb-4 rounded-lg" />
                <div className="grid grid-cols-[360px_auto] gap-8">
                    <div className="flex flex-col gap-2">
                        {new Array(5).fill(0).map((_, i) => (
                            <Skeleton className="h-9 w-full rounded" key={i} />
                        ))}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        {new Array(4).fill(0).map((_, i) => (
                            <Skeleton className="h-[200px] w-full rounded-lg" key={i} />
                        ))}
                    </div>
                </div>
            </Container>
        </section>
    )
}