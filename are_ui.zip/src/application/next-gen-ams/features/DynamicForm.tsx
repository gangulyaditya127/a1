import { useState, useEffect, useCallback } from 'react'
import { useForm, FieldErrors, FieldValues, Control } from 'react-hook-form'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form'
import { useLocation, useParams, useSearchParams } from 'react-router-dom'
import { useSubmitMaturityAssessmentMutation } from '../slice/nextGenAMSAPISlice'
import { Loader } from 'lucide-react'

type FieldData = {
    id: number
    fieldName: string
    type: string
    options: string
    hasRemarks: string;
    answer?: string | string[]
    remarks?: string
}

export type FormData = {
    pageData: {
        [key: string]: Array<{
            title: string
            fields: FieldData[]
        }>
    }
}

type FieldProps = {
    formField: FieldData,
    control: Control<FieldValues, any>,
    errors: FieldErrors<FieldValues>,
    fieldTitle?: string,
    isSubmitted?: boolean
}

const Field = ({ formField, control, isSubmitted }: FieldProps) => {

    const [validationRule] = useState(() => !isSubmitted ? ({ required: 'This field is required' }) : ({ required: false }));


    switch (formField.type) {
        case "select":
            return (
                <FormField
                    control={control}
                    name={`answer.${formField.id}`}
                    defaultValue={formField.answer}
                    rules={validationRule}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>{formField.fieldName}</FormLabel>
                            <FormControl>
                                <Select {...field} onValueChange={field.onChange} value={field.value} defaultValue={(formField.answer as string) ?? ''}  >
                                    <SelectTrigger className="w-full">
                                        <SelectValue placeholder={`Select ${formField.fieldName}`} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {formField.options.split(',').map((option: any) => (
                                            <SelectItem key={option} value={option}>
                                                {option}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            )
        case 'top5freetext':
            return (
                <div className="mb-4 space-y-2">
                    {
                        new Array(5).fill(0).map((_, index) => {
                            return (
                                <FormField
                                    key={index}
                                    name={`answer.${formField.id}.${index}`}
                                    control={control}
                                    defaultValue={formField?.answer?.[index] ?? ''}
                                    rules={validationRule}
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormItem>
                                                <FormControl>
                                                    <Input {...field} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        </FormItem>
                                    )}
                                />
                            );
                        })
                    }
                </div >
            )
        default:
            return (
                <FormField
                    control={control}
                    name={`answer.${formField.id}`}
                    defaultValue={formField.answer ?? ''}
                    rules={validationRule}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>{formField.fieldName}</FormLabel>
                            <FormControl>
                                <Input {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            )
    }
}

export default function DynamicForm({ initialData, disabled = false, isAdmin = false, isSubmitted }: { initialData: FormData, disabled: boolean, isAdmin: boolean, isSubmitted?: boolean }) {
    const [currentPage, setCurrentPage] = useState(1)
    const form = useForm({
        mode: 'onChange'
    });
    const { id } = useParams()
    const [apiTrigger, { isLoading }] = useSubmitMaturityAssessmentMutation()

    const location = useLocation()
    let [_, setSearchParams] = useSearchParams();

    const { control, handleSubmit, formState: { errors }, trigger, reset } = form
    const totalPages = Object.keys(initialData.pageData).length

    const [validationRule] = useState(() => !isSubmitted ? ({ required: 'This field is required' }) : ({ required: false }));

    console.log({ isSubmitted })
    useEffect(() => {

        const searchParams = new URLSearchParams(location.search)
        const savedData = searchParams.get('formData')
        if (savedData) {
            const parsedData = JSON.parse(decodeURIComponent(savedData))
            reset(parsedData)
            setCurrentPage(parseInt(searchParams.get('page') || '1', 10))
        } else {
            handleReset()
        }
        console.log({ isAdmin })
    }, [])

    const updateURL = useCallback((data: any, page: number, preventScrollReset = true) => {
        const encodedData = encodeURIComponent(JSON.stringify(data, function (_, v) { return v === undefined ? null : v; }))
        console.log({ data, page, modifiedData: [], encodedData })
        setSearchParams({ formData: encodedData, page: String(page) }, {
            preventScrollReset
        })
    }, [setSearchParams])

    const onSubmit = async (data: any) => {
        try {
            updateURL(form.getValues(), currentPage, true)
            const outputData: FormData = structuredClone(initialData)
            Object.keys(outputData.pageData).forEach((page) => {
                outputData.pageData[page].forEach((section) => {
                    section.fields.forEach((field) => {
                        if (field.type === 'top5freetext') {
                            field.answer = Object.values(data.answer[field.id])
                                .filter(Boolean)
                                .map(String)
                                .join('||')
                        } else {
                            field.answer = data.answer[field.id]
                        }
                        if (field.hasRemarks === 'Y') {
                            field.remarks = data.remarks[field.id] || ''
                        }
                    })
                })
            })
            let requestPayload = { ...outputData, isDraft: 'N', req_num: id }
            await apiTrigger(requestPayload)
        } catch (error) {
            console.error(error)
        }
    }

    const saveAsDraft = async () => {
        try {
            updateURL(form.getValues(), currentPage, true)
            const data = form.getValues()
            const outputData: FormData = structuredClone(initialData)
            Object.keys(outputData.pageData).forEach((page) => {
                outputData.pageData[page].forEach((section) => {
                    section.fields.forEach((field) => {
                        if (field.type === 'top5freetext') {
                            field.answer = Object.values(data.answer[field.id])
                                .filter(Boolean)
                                .map(String)
                                .join('||')
                        } else {
                            field.answer = data.answer[field.id]
                        }
                        if (field.hasRemarks === 'Y') {
                            field.remarks = data.remarks[field.id] || ''
                        }
                    })
                })
            })
            let requestPayload = { ...outputData, isDraft: 'Y', req_num: id }
            await apiTrigger(requestPayload)
        } catch (error) {
            console.error(error)
        }
    }

    const currentPageData = initialData.pageData[`Page ${currentPage}`]

    const validateCurrentPage = async () => {
        const currentPageData = initialData.pageData[`Page ${currentPage}`]
        const fieldNames = currentPageData.flatMap(section => {
            return section.fields.flatMap(field => {
                const names = [`answer.${field.id}`]
                if (field.hasRemarks === 'Y') {
                    names.push(`remarks.${field.id}`)
                }
                return names;
            })
        })
        console.log({ currentPageData, fieldNames })
        const isValid = await trigger(fieldNames, {
            shouldFocus: true
        })
        return isValid
    }
    const handleNextPage = async () => {
        const isValid = await validateCurrentPage()

        updateURL(form.getValues(), isValid ? currentPage + 1 : currentPage, !isValid)
        if (isValid) {
            setCurrentPage(currentPage + 1)
        } else {
            console.log('Please fill in all required fields before proceeding.')
        }
    }
    const handlePreviousPage = () => {
        updateURL(form.getValues(), currentPage - 1)
        setCurrentPage(currentPage - 1)
    }

    const handleReset = useCallback(() => {
        // Reset the form to initial values
        const initialFormValues = Object.keys(initialData.pageData).reduce((acc: any, pageKey) => {
            initialData.pageData[pageKey].forEach(section => {
                section.fields.forEach(field => {
                    if (field.type === 'top5freetext') {
                        acc[`answer.${field.id}`] = ['', '', '', '', ''];
                    } else {
                        acc[`answer.${field.id}`] = field.answer || '';
                    }
                    if (field.hasRemarks === 'Y') {
                        acc[`remarks.${field.id}`] = field.remarks || '';
                    }
                });
            });
            return acc;
        }, {})
        console.log({ initialFormValues })
        setSearchParams({ page: '1' })
        reset(initialFormValues)
        setCurrentPage(1);

    }, [initialData, reset]);


    return (
        <Form {...form}>
            <h3 className='text-2xl my-2 mb-3 text-muted-foreground'>{currentPage == 1 ? "Hotspot" : "ITSM Practices"}</h3>
            <form onSubmit={handleSubmit(onSubmit)} className='space-y-6 pb-32'>
                {currentPageData?.map((section) => (
                    <fieldset className="border p-4 rounded-md" key={section.title} disabled={disabled}>
                        <legend className="-ml-1 px-1 text-sm font-medium">
                            {section.title}
                        </legend>
                        {section.fields.map((field) => (
                            <fieldset key={field.id} className={field.fieldName?.length ? "border p-4 rounded-md" : ''}>
                                <Field formField={field} control={control} errors={errors} fieldTitle={section.title} isSubmitted={isSubmitted} />
                                {
                                    field.hasRemarks === 'Y' && (
                                        <FormField
                                            control={control}
                                            name={`remarks.${field.id}`}
                                            defaultValue={field?.remarks ?? ''}
                                            rules={validationRule}
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Remarks</FormLabel>
                                                    <FormControl>
                                                        <Textarea
                                                            className="mt-1"
                                                            placeholder="Remarks"
                                                            {...field}
                                                        />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )
                                }
                            </fieldset>
                        ))}
                    </fieldset>
                ))}
                <div className="fixed bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 bg-background rounded-lg p-2 border">
                    <div className="aspect-square h-10  rounded-lg bg-secondary/80 grid place-items-center text-md">
                        <p>
                            <span>{currentPage}</span>
                            <span className='text-xs font-muted-foreground'>/{totalPages}</span>
                        </p>
                    </div>
                    <Button type="button" className='w-24 rounded-lg' variant="secondary" onClick={handlePreviousPage} disabled={currentPage <= 1}>
                        Previous
                    </Button>
                    {currentPage < totalPages ? (
                        <Button type="button" className='w-24 rounded-lg' variant="secondary" onClick={(e) => {
                            e.preventDefault()
                            handleNextPage()
                        }}>
                            Next
                        </Button>
                    ) : (
                        <Button type="submit" variant='primary' className='w-24 gap-2' disabled={disabled}>
                            {
                                isLoading && <Loader className='animate-spin w-4 h-4' />
                            }
                            Submit
                        </Button>
                    )}
                    <Button type="button" variant='destructive' className='w-24 rounded-lg' disabled={disabled} onClick={handleReset}>
                        Reset
                    </Button>
                    <Button type="button" variant='primary' className='w-34 rounded-lg gap-2' disabled={disabled || isLoading} onClick={saveAsDraft}>
                        {isLoading && <Loader className='animate-spin w-4 h-4' />}
                        Save as Draft
                    </Button>
                </div>
            </form>
        </Form>
    )
}