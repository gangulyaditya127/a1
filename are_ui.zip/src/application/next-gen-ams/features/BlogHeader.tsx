import { cn } from "@/lib/tailwind.utils";

const BlogHeader = ({
  title,
  className,
}: {
  title: string;
  className?: string;
}) => {
  return (
    <div className={cn("flex items-center justify-between gap-x-8", className)}>
      <h1 className="text-4xl font-tcs-title">{title}</h1>
    </div>
  );
};
export default BlogHeader;
