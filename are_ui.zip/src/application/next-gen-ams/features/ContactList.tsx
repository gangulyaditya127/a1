import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Icon } from "@/components/ui/icon";
import { Separator } from "@/components/ui/seperator";
export type ContactListProps = {
  contactList?: {
    name: string;
    mail: string;
    phone?: string;
  }[];
};
const ContactList = ({
  contactList = [
    {
      name: "Sudipta Maiti",
      mail: "sudipta.maiti@tcs.com",
    },
    {
      name:"SEBL iSmart Team",
      mail:"sebl-ismart@tcscomprod.onmicrosoft.com"
    }
  ],
}: ContactListProps) => {
  return (
    <div className="flex flex-col gap-4">
      {contactList.map((contact, i) => (
        <>
          <div className="flex space-x-2" key={i}>
            <Avatar>
              <AvatarFallback className="uppercase">
                {contact.name?.substring(0, 2)}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1">
              <p className="text-sm">{contact.name}</p>
              {contact.mail && (
                <div className="flex items-center gap-1">
                  <Icon name="at-sign" className="color-muted size-3" />
                  <span className="text-xs text-muted-foreground">
                    {contact.mail}
                  </span>
                </div>
              )}
              {contact.phone && (
                <div className="flex items-center gap-1">
                  <Icon name="phone" className="color-muted size-3" />
                  <span className="text-xs text-muted-foreground">
                    {contact.phone}
                  </span>
                </div>
              )}
            </div>
          </div>
          {i != contactList.length - 1 && (
            <div className="flex-2 flex items-center gap-2 text-muted-foreground">
              <Separator className="shrink" />
              <p>or</p>
              <Separator className="shrink" />
            </div>
          )}
        </>
      ))}
    </div>
  );
};
export default ContactList;
