import { Icon } from "@/components/ui/icon";
import ContactList, { ContactListProps } from "./ContactList";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

const ContactCard = ({ contactList }: ContactListProps) => (
  <Dialog>
    <DialogTrigger asChild>
      <div className="border-1 fixed bottom-8 right-0 z-[20] flex cursor-pointer items-center gap-2 rounded-s-[2rem] rounded-tr-md border border-b-0 bg-tcs-primary py-4 pl-6 pr-8 text-sm font-medium text-black dark:bg-[#2469BC] dark:text-white dark:font-normal">
        <Icon name="headset" className="size-4" strokeWidth={2.75} />
        <p>Contact</p>
      </div>
    </DialogTrigger>
    <DialogContent className="sm:max-w-md">
      <p className="mb-4 text-sm text-muted-foreground">
        For details and accessing asset, please contact
      </p>
      <ContactList contactList={contactList} />
    </DialogContent>
  </Dialog>
);
export default ContactCard;
