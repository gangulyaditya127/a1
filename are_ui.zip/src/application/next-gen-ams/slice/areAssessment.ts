import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    businessGroup: "",
    isu: "",
    subIsu: "",
    account: "",
    req_id: "",
    selectedKPI: [] as string[],
};

const areAssessmentSlice = createSlice({
    name: 'next-gen-are-help-slice',
    initialState,
    reducers: {
        updateHelpForm: (state, action) => {
            state.businessGroup = action.payload.businessGroup;
            state.isu = action.payload.isu;
            state.subIsu = action.payload.subIsu;
            state.account = action.payload.account;
            state.req_id = action.payload.req_id;
        },
        updateSelectedSlice: (state, action) => {
            // Assuming action.payload is an array of KPIs or a single KPI
            state.selectedKPI = action.payload;
            // If you want to append instead of replace:
            // state.selectedKPI.push(action.payload);
        }
    }
});

export const { updateHelpForm, updateSelectedSlice } = areAssessmentSlice.actions;

export default areAssessmentSlice.reducer;