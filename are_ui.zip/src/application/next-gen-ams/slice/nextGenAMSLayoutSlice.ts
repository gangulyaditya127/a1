import { createSlice } from "@reduxjs/toolkit";

type NextGenAMSLayoutTypes = {
  showDefaultFooter: boolean;
};

const initialState: NextGenAMSLayoutTypes = {
  showDefaultFooter: true,
};

const nextGenAMSLayoutSlice = createSlice({
  name: "next-gen-ams-layout-slice",
  initialState,
  reducers: {
    updateFooterVisibility: (state, action) => {
      state.showDefaultFooter = action.payload.showDefaultFooter;
    },
  },
});
export const { updateFooterVisibility } = nextGenAMSLayoutSlice.actions;
export default nextGenAMSLayoutSlice.reducer;
