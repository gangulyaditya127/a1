import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
type IncidentData = Record<string, any> | null;
export type submitRequestProps = {
    empid: number;
    email: string;
    bu: string;
    isu: string;
    sub_isu: string;
    account?: string;
    engagement?: string;
    opportunity?: string;
    teamSize?: string;
    techStack?: string;
    locations?: string;
    totalInc?: string;
    amslob?: string;
    totalSR?: string;

    // Renamed to match JSON keys
    req_num?: string | null;
    contract_id?: string;
    contract_start_date?: string;
    contract_end_date?: string;
    new_logo?: string;

    totalP1Inc?: number;
    totalP2Inc?: number;
    totalP3Inc?: number;
    totalP4Inc?: number;

    totalP1SR?: number;
    totalP2SR?: number;
    totalP3SR?: number;
    totalP4SR?: number;
};

export type submitRequestMockProps = {
    userId: number;
    businessGroup: string;
    isu: string;
    subIsu: string;
    account: string;
    kpi?: string[];
}

export type loginUserProps = {
    empid: number,
    pass: string
}
export type requestListProps = {
    empid: number,
    isAdmin: 'Y' | 'N',
    req_num?: string
}
export type updateRequestProps = {
    empid: number,
    email: string,
    req_num: string,
    state: string
}
export type getMaturityResultProps = {
    empid: number,
    isAdmin: 'Y' | 'N',
    req_num: string
}
export interface MaturityResult {
    reqNum: string
    tableData: MaturityTable[]
}

export interface MaturityTable {
    "Group Name": string
    "Question ID": string
    Question: string
    Answer: string
    Remarks: string
    Category: string
    Observation: string
    "ARE Solution": string
    Software: string
    Hardware: string
    "Connectivity Needed": string
    "Time Frame": string
    "Associates Required": string
    "Map Remarks": string
    Benefits: string
    "Updated By": string
    "Sub Root Question ID"?: string
}

export interface MaturityAssessmentFetchRequestProps {
    businessGroup?: string;
    isu?: string;
    subIsu?: string;
    account?: string;
}

export const nextGenAMSAPI = createApi({
    reducerPath: 'nextGenAMSAPI',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/user/` }),
    tagTypes: ['auth_api', 'ams_req_status', 'maturity_assesment', 'maturity_result', 'postmortem'],
    endpoints: ({ query, mutation }) => ({
        submitRequest: query<any, submitRequestProps>({
            query: (queryParams) => ({
                url: `submitRequestByUser`,
                params: queryParams
            }),
            providesTags: ['ams_req_status']
        }),
        fetchBusinessGroups: query<any, void>({
            query: () => ({
                url: `http://127.0.0.1:5000/getBusinessGroup`,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        fetchISU: query<any, any>({
            query: (queryParams) => ({
                url: `http://127.0.0.1:5000/getIsu`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        fetchSubISU: query<any, any>({
            query: (queryParams) => ({
                url: `http://127.0.0.1:5000/getSubIsu`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        fetchAccounts: query<any, any>({
            query: (queryParams) => ({
                url: `http://127.0.0.1:5000/getAccounts`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        submitKPIMock: mutation<any, any>({
            query: (body) => ({
                url: `http://127.0.0.1:5000/postKpis`,
                method: 'POST',
                body,
                headers: {
                    'Content-Type': 'application/json',
                },
            }),
            invalidatesTags: ['ams_req_status'],
        }),
        submitRequestMock: mutation<any, submitRequestMockProps>({
            query: (body) => ({
                url: `http://127.0.0.1:5000/postRequest`,
                method: 'POST',
                body, // RTK Query automatically sends JSON
                headers: {
                    'Content-Type': 'application/json',
                },
            }),
            invalidatesTags: ['ams_req_status'],
        }),
        fetchChatHistory: query<any, any>({
            query: (queryParams) => ({
                url: `http://127.0.0.1:8009/are-getChatHistory`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        submitChatResponse: mutation<any, any>({
            query: (body) => ({
                url: `http://127.0.0.1:8009/are-question`,
                method: 'POST',
                body, // RTK Query automatically sends JSON
                headers: {
                    'Content-Type': 'application/json',
                },
            }),
            invalidatesTags: ['ams_req_status'],
        }),
        fetchMaturityAssessmentData: query<any, any>({
            query: (queryParams) => ({
                url: `http://127.0.0.1:5000/getSingleRequest`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        fetchMaturityAssessmentAllData: query<any, void>({
            query: () => ({
                url: `http://127.0.0.1:5000/getRequest`,
                // params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        fetchMaturityAssesment: query<any, any>({
            query: (queryParams) => ({ url: 'fetchMaturityAssessmentData', params: queryParams }),
            providesTags: ['maturity_assesment']
        }),
        fetchRequestList: query<any, requestListProps>({
            query: (queryParams) => ({ url: 'fetchRequestList', params: queryParams }),
            providesTags: ['ams_req_status']
        }),
        fetchRequestSingleRow: query<any, requestListProps>({
            query: (queryParams) => ({
                url: 'https://ismartams.tcsapps.com/api/java/ismartService/user/fetchRequestData',
                params: queryParams
            }),
            providesTags: ['ams_req_status']
        }),
        // uploadMaturityAssesmentExcel: mutation<any, any>({
        //     query: (body) => ({
        //         body,
        //         method: 'POST',
        //     }),
        //     invalidatesTags: ['maturity_assesment', 'maturity_result']
        // }),
        // fetchMaturityAssesment: mutation<any, any>({
        //     query: (body) => ({
        //         url: `fetchMaturityAssessmentData`,
        //         method: 'POST',
        //         params: body
        //     }),
        // }),
        uploadMaturityAssesmentExcel: mutation<any, any>({
            query: (body) => ({
                url: 'https://ismartams.tcsapps.com/api/python/maturityJava/process-excel',
                method: 'POST',
                body
            }),
            invalidatesTags: ['maturity_assesment']
        }),
        submitMaturityAssessment: mutation<any, any>({
            query: (body) => ({
                url: 'submitMaturityAssessmentData',
                method: 'POST',
                body
            }),
            invalidatesTags: ['maturity_assesment']
        }),
        updateRequest: query<any, updateRequestProps>({
            query: (queryParams) => ({ url: 'updateRequestByUser', params: queryParams }),
        }),
        getMaturityAssessmentResult: query<MaturityResult, getMaturityResultProps>({
            query: (queryParams) => ({ url: 'fetchMaturityAssessmentMappingData', params: queryParams }),
            providesTags: ['maturity_result']
        }),
        updateMaturityResult: mutation<any, any>({
            query: (body) => ({
                url: 'updateMaturityAssessmentMappingData',
                method: 'POST',
                body
            }),
            invalidatesTags: ['maturity_result']
        }),
        // fetchPostmortemInit: query<any, { req_id: string; incident_no: string }>({
        //     query: (params) => ({
        //     url: `${import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"}/postmortem/init`,
        //     method: 'POST',
        //     body: params,
        //     }),
        //     providesTags: ['postmortem'],
        // }),
        // submitPostmortemConversation: mutation<any, { req_id: string; answer: string; incident: IncidentData }>({
        //     query: (body) => ({
        //     url: `${import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"}/postmortem/conversation`,
        //     method: 'POST',
        //     body,
        //     }),
        //     invalidatesTags: ['postmortem'],
        // }),
        fetchPostmortemInit: mutation<any, { req_id: string; incident_no: string }>({  // ← Changed to mutation
            query: (body) => ({  // Note: still called 'query' property in mutation definition
                url: `${import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"}/postmortem/init`,
                //url: `${import.meta.env.VITE_POSTMORTEM_API ?? "https://ismartams.tcsapps.com/api/python_mcp"}/postmortem/init`,
                method: 'POST',
                body,  // Changed from 'params' to 'body'
            }),
            // Remove providesTags completely
        }),
        submitPostmortemConversation: mutation<any, { req_id: string; answer: string; incident: IncidentData }>({
            query: (body) => ({
                url: `${import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"}/postmortem/conversation`,
                //url: `${import.meta.env.VITE_POSTMORTEM_API ?? "https://ismartams.tcsapps.com/api/python_mcp"}/postmortem/conversation`,
                method: 'POST',
                body,
            }),
            // Remove invalidatesTags completely (not needed for this flow)
        }),

    }),
})

export const {
    useLazySubmitRequestQuery,
    useLazyFetchMaturityAssesmentQuery,
    useSubmitMaturityAssessmentMutation,
    useLazyFetchRequestListQuery,
    useLazyUpdateRequestQuery,
    useGetMaturityAssessmentResultQuery,
    useUpdateMaturityResultMutation,
    useUploadMaturityAssesmentExcelMutation,
    useSubmitRequestMockMutation,
    useSubmitKPIMockMutation,
    useLazyFetchBusinessGroupsQuery,
    useLazyFetchISUQuery,
    useLazyFetchSubISUQuery,
    useLazyFetchAccountsQuery,
    useLazyFetchMaturityAssessmentDataQuery,
    useLazyFetchMaturityAssessmentAllDataQuery,
    useLazyFetchChatHistoryQuery,
    useFetchChatHistoryQuery,
    useSubmitChatResponseMutation,
    useLazyFetchRequestSingleRowQuery,
    useFetchPostmortemInitMutation,  
    useSubmitPostmortemConversationMutation,
    // useLazyFetchPostmortemInitQuery,
    // useSubmitPostmortemConversationMutation,
} = nextGenAMSAPI