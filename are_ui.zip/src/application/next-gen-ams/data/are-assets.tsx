export const ARE_ASSETS: {
    section: string;
    sectionValue?: string;
    items: {
        isGenAI?: boolean;
        title: string;
        href: string;
        description: string;
    }[];
}[] = [
        {
            section: "Onboarding",
            sectionValue: "onboarding",
            items: [
                {
                    "title": "TCS ITSM Analytics",
                    "href": "/doc/service-clinic",
                    "description": "Advanced analytics tool that analyzes the ITSM ticket logs"
                },
                {
                    title: "ARE Quick Assessment",
                    href: "/doc/quick-assesment",
                    description: "ARE’s automation workbench has a compilation of automation use cases from our experiences globally. This helps us to assess Maturity of ITSM practices in given engagement and compute ARE Automation Index"
                },
                {
                    "title": "Lean Assessor",
                    "href": "/doc/lean-accessor",
                    "description": "Systematically analyze AMS teams from people and process dimensions."
                },
                {
                    "title": "Estimators",
                    "href": "/doc/estimators",
                    "description": "Streamline the process of estimating the effort"
                },
                {
                    title: "Due Diligence Toolkit",
                    href: "/doc/due-deligence-toolkit",
                    description: "The Due Diligence Toolkit is designed to assist teams that study a given customer landscape, that is under the scope of Application Maintenance and Support. It Consists of A standard template to consolidate questions and seek information from customer"
                },
                {
                    title: "Transition Handbook",
                    href: "/doc/transition-handbook",
                    description: "Transition Handbook is a comprehensive set of documents that assist teams to define the transition approach, plan the transition and govern the progress.It comprises of the following assets:"
                },
                {
                    "title": "Transition Planner / Digital DD Cube",
                    "href": "/doc/transition-planner",
                    "description": "Facilitate smooth transitions and due diligence (DD) processes during digital transformations, ensuring comprehensive planning and execution for production management."
                },
                {
                    "title": "Intelligent Knowledge Onboarder",
                    "href": "/doc/konboard",
                    "description": "TCS Intelligent Knowledge Based Onboarding platform",
                    isGenAI: true
                },
            ]
        },
        {
            section: "Observability & Event",
            sectionValue: 'observability-event-management-agents',
            items: [
                {
                    title: "Observability Dashboard",
                    href: "/doc/observability-dashboard",
                    description: "Observability Dashboard is a critical component of ARE’ Observability suite of solutions. It provides an integrated visualization of both horizontal observability (Customer journeys, Business Processes) and Vertical Observability (health of Application Health, Middleware & Infrastructure health)."
                },
                {
                    title: "Event Correlation & Alert/ticket deduplication",
                    href: "/doc/event-correlation",
                    description: "Event correlation looks at correlating events triggered, based on timing, network topology proximity, application interdependencies, ongoing changes/ maintenance etc. and ensures that they are grouped together so that only one ticket or one parent ticket is created. This also help monitoring teams to shift to alert-based event management, rather than being hooked on the monitors."
                },
                {
                    title: "Batch Health Analyzer",
                    href: "/doc/batch-status",
                    description: "It provides real-time insights into the health of your batch processing environment, enabling faster resolution of issues productivity. It empowers resources with proactive insights and improved batch processing efficiency."
                },
                {
                    title: "Anomaly Detection",
                    href: "/doc/anamoly-detection",
                    description: "In a large-scale IT production support environment, anomalies disrupt system performance, impact user experience, and increase operational costs. It is important to detect anomalies proactively and take steps to avert incidents in production. Anomalies could be observed in system performance (CPU consumption, Memory usage, Storage utilization, Response Times), batch performance (long running and short running jobs, failures etc.), Spurt in errors and warnings in system logs etc."
                }
            ]
        },
        {
            section: "Incident, Request & Problem",
            sectionValue: 'incident-request-problem-management',
            items: [
                {
                    title: "Ticket Creator Agent",
                    href: "/doc/ticket-creator",
                    description: "Organizations use ITSM tools to create and track maintenance tickets. In some organizations, tickets do come in through other channels such as mails, telephone calls or chats. Ticket Creator BOT assists in automatically creating a ticket in ITSM tool (ex- Service Now).",
                    isGenAI: true,
                },
                {
                    title: "Ticket Assignment Agent​​",
                    href: "/doc/ticket-assign",
                    description: "The Auto Assignment Agent is a Robotic Process Automation (RPA) solution designed to intelligently assign tickets to production support executives. The goal is to ensure that Response Service Level Agreements (SLA) are met, and to reduce the Turnaround Time (TAT) for incidents. The bot assesses ticket priority, evaluates support executive availability, expertise, and workload, and communicates with relevant alert systems for high-priority issues.​​"
                },
                {
                    title: "Incident Categorization Agent",
                    href: "/doc/ticket-cat",
                    description: "The Incident Categorization Agent is a powerful automation tool designed to classify incidents efficiently based on application name, ticket title, and description using historical data. It goes beyond categorization by recommending a higher priority if the ITSM tool assigns a lower priority.​​",
                    isGenAI: true,
                },
                {
                    title: "Integration Application Dependency Dashboard",
                    href: "/doc/iadd",
                    description: "Unravel dependencies. Fix faster.  Illuminate application & infrastructure dependencies."
                },
                {
                    title: "Ticket Log Collection Agent",
                    href: "/doc/ticket-log-collection",
                    description: "The Ticket Log Collector Agent is a powerful automation tool designed to assist support executives in efficiently attaching required logs for ticket analysis. By streamlining the log collection process, the bot helps reduce analysis and resolution time, thereby improving overall incident management efficiency."
                },
                {
                    title: "Root Cause Analysis Agent",
                    href: "/doc/rca",
                    description: "The Root Cause Analysis (RCA) Agent is an intelligent automation tool designed to assist support executives in identifying the root cause of issues efficiently. By leveraging attached logs and predefined analysis rules, the RCA Bot significantly reduces the time required for manual analysis, thereby accelerating issue resolution.",
                    isGenAI: true,
                },
                {
                    title: "Resolution Recommendation Agent",
                    href: "/doc/solution-recommendation",
                    description: "The Resolution Recommendation Agent bridges the gap between problem identification and resolution implementation by automating the process of updating incident details in ITSM tools or triggering self-healing actions based on predefined configurations. It ensures faster incident resolution, Updated knowledge repositories, Enhanced productivity for AMS (Application Management Services) teams. "
                }, {
                    title: "Intelligent Resolution Recommenders",
                    href: "/doc/irr",
                    description: "Resolve faster, smarter. Your ticket-solving copilot.",
                    isGenAI: true
                },
                {
                    title: "Intelligent Major Incident Briefing Paper",
                    href: "/doc/imbp",
                    description: "Dashboard highlighting severity based MIM(Major Incident Management) count along with causal analysis with drill down capability to identify resolution",
                    isGenAI: true,
                },
                {
                    title: "Regulatory Data Lineage Dashboard",
                    href: "/doc/regulatory",
                    description: "Reduce email and ticket volume by keeping stakeholders updated on real time basis."
                },
                // {
                //     title: "Text2SQL Converter",
                //     href: "/doc/text2sql",
                //     description: "Data extracts and Report requests is a primary category of service requests that we receive in an Application Maintenance context. Text2SQL makes it possible to easily write efficient, error-free SQL queries without knowing SQL."
                // },
                {
                    title: "Integrated Project Risk Management",
                    href: "/doc/iprm",
                    description: "Web based solution with workflow tracking mechanism to complete POA(Project Onboarding Assessment) or PRA(Project Risk Assesment) of new projects"
                },
                {
                    title: "Data Quality Agent",
                    href: "/doc/data-quality",
                    description: "Data quality engine is to improve the ticket resolution data quality in service now. The tool can audit the existing quality of data entry in ITSM tool and also provide a templatized approach to improve the quality of entry going forward. The improved quality of data in Service Now forms the foundation for building AI based intelligent resolution recommenders and root cause analyzers."
                }
            ]
        },
        {
            section: "Change",
            sectionValue: 'change-and-certificate-management',
            items: [
                {
                    title: "Service Risk Assessment Framework",
                    href: "/doc/service-risk-assessment",
                    description: "Proactively identify, evaluate, and mitigate risks associated with service delivery and application management"
                },
                {
                    title: "Integrated Change Review Management",
                    href: "/doc/icrm",
                    description: "Change with confidence, prevent downtime, streamline reviews."
                },
                {
                    title: "Change Implementation Plan Generator",
                    href: "/doc/change-implementation",
                    description: "Change Implementation plan creation is an essential process before deploying changes in production and could often be a time-consuming process.",
                    isGenAI: true,
                }
            ]
        },
        {
            section: "Certificate",
            sectionValue: 'certificate-management',
            items: [
                {
                    "title": "Automated Certificate Management",
                    "href": "/doc/icert",
                    "description": "Latest status of certificates being used in production ensuring RAG(Red, Amber, Green) status highlights upcoming certificate expiry. Month wise expiry depiction coupled with LOB(Line of Business) wise view"
                },
            ]
        },
        {
            section: "Governance & Operations",
            sectionValue: "governance-operations-agents",
            items: [
                {
                    title: "ARE Handbook & Maturity Assessment",
                    href: "/doc/are-handbook",
                    description: "ARE handbook is a comprehensive checklist that guides application maintenance teams to embrace the concepts of application reliability engineering. It also helps to assess the maturity of adoption and provides (a) Scores on the current compliance and (b) Prioritized roadmap for recommendations with indicative benefits and timelines."
                },
                {
                    title: "Intelligent Knowledge Builder",
                    href: "/doc/intellegient-knowledge-builder",
                    description: "Automated documentation with enhanced accessibility",
                    isGenAI: true,
                },
                {
                    title: "Daily Application Health Check",
                    href: "/doc/dahc",
                    description: "Real time status of application health check."
                },
                {
                    title: "Application Recovery Plan Updater",
                    href: "/doc/app-recovery",
                    description: "In a production environment, the failover process to COB (Continuity of Business) servers during an incident is critical for minimizing downtime. However, the existing step-by-step failover data is often scattered and not easily accessible, leading to delays in executing the failover or errors during the process. Furthermore, manually compiling an Application Recovery Process (ARP) document from this data is time-consuming and prone to inconsistencies, making it difficult for the support team to have a standardized and accurate recovery procedure.",
                    isGenAI: true
                },
                {
                    title: "Error Budget Report",
                    href: "/doc/budget-report",
                    description: "SRE proposes 4 golden signals to take control of stability and quality of production – Volume, Availability, Latency and Error. The Gen AI based error budget reporting tool processes voluminous system logs of several applications and automatically publishes the Error Budget reports. It summarizes the health by the key SRE metrics. It also calculates the deviations against the SLO and Error Budgets.",
                    isGenAI: true
                },
                {
                    "title": "Global Planner",
                    "href": "/doc/global-planner",
                    "description": "Handy list of upcoming planned global events like major releases, EOVS(End Of Version Support), monthly release dates etc."
                },
                {
                    title: "One Click COB",
                    href: "/doc/one-click-cob",
                    description: "A Single One Stop Shop solution for all failover needs. Unified Interface that is built provides a visual representation of the Traffic patterns between the Data Centers and the Data Center availability status along with providing an ability to invoke the failover with a single click followed by Authentication to initiate the Data Center failover."
                },
                {
                    title: "RiO Automation Maturity Workbench",
                    href: "/doc/rio-automation-maturity",
                    description: "It assesses the extent of automation adoption in AMS engagements."
                },
                {
                    title: "L1 Dashboard",
                    href: "/doc/l1-dashboard",
                    description: "Realtime status of incidents, MIM(Major Incident Management), change requests along with accountability matric, 13 months’ trend, LOB(Line of Business) & Country wise impact"
                },
                {
                    title: "Intelligent SLA management",
                    href: "/doc/isla",
                    description: "A comprehensive solution for intelligent SLA(Service Level Agreement) management, enabling organizations to proactively monitor and enforce service agreements, ultimately leading to improved service delivery and reduced operational costs"
                },
            ]
        },
        {
            section: "Talent Management",
            sectionValue: 'talent-management',
            items: [
                {
                    title: "AMS Career & Learning Builder.",
                    href: "/doc/ams-carrer",
                    description: "Support the continuous professional development and career progression of AMS professionals"
                },
                {
                    title: "Gamification",
                    href: "/doc/gamification",
                    description: "Unleash your inner hero. Boost productivity & teamwork."
                }
            ]
        }
    ]