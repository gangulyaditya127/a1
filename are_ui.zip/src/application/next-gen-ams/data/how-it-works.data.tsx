export const HOW_IT_WORKS = [
  {
    title: "New Business Transition",
    description: (
      <p className="dark:text-neutral-300">
        At least 20-25% of core team from ISU/BG
        <br />
        Ready to use tools and artefacts from component store
      </p>
    ),
    img: "https://s7ap1.scene7.com/is/image/TCSCOMprod/crypto-agility-quantum-computing-safety-card:Large?wid=1134&hei=692&dpr=off",
  },
  {
    title: "Maturity assessments",
    description: (
      <p className="dark:text-neutral-300">
        Periodic reviews leveraging the extended RiO framework
        <br />
        Compare results against the best within BG/TCS
      </p>
    ),
    img: "https://s7ap1.scene7.com/is/image/TCSCOMprod/gen-ai-in-ams-web-u?wid=1100&hei=434&dpr=off",
  },
  {
    title: "Talent development",
    description: (
      <p className="dark:text-neutral-300">
        Triage / communication training for Engineers
        <br />
        Culture, Engagement and Morale
      </p>
    ),
    img: "https://s7ap1.scene7.com/is/image/TCSCOMprod/gen-ai-in-ams-web-u?wid=1100&hei=434&dpr=off",
  },
];
