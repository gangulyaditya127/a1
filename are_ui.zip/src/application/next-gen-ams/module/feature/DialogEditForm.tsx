import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import HelpForm from './HelpForm';
import Container from '@/components/ui/container';
// import { useEffect, useState } from 'react';

type DialogEditFormProps = {
    open: boolean;
    setOpen: (open: boolean) => void;
    selectedRow: any;
    onSuccess: () => void;
};

const DialogEditForm = ({ open, setOpen, selectedRow, onSuccess }: DialogEditFormProps) => {
    // const [rowDetails, setRowDetails] = useState<any>(selectedRow);

    // const getRowDetails = async () => {
    //     try {
    //         const res = await fetch(`${import.meta.env.VITE_SPRING_BASE_URL}/user/fetchRequestData?empid=1890458&isAdmin=N&req_num=${selectedRow.req_num}`)
    //         const data = await res.json()
    //         setRowDetails(data[0])
    //     } catch (error) {
    //         console.log(error)
    //     }
    // }

    // useEffect(() => {
    //     if (open && selectedRow) {
    //         getRowDetails();
    //     }
    // }, [open, selectedRow]);

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="gap-4 w-full max-w-5xl">
                <DialogHeader className="md:pl-1">
                    <DialogTitle>Edit Response</DialogTitle>
                    <DialogDescription>Edit and save your response</DialogDescription>
                </DialogHeader>
                <Container className="gap-4 mt-4 overflow-y-auto py-4 md:pl-1 max-h-[400px]">
                    {selectedRow && <HelpForm reqNum={selectedRow.req_num} onSuccess={onSuccess} />}
                </Container>
            </DialogContent>
        </Dialog>
    );
};

export default DialogEditForm;
