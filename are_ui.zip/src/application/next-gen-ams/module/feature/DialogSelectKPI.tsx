import { useEffect, useState } from "react";
import {
    Dialog,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
    DialogContentWithNoCloseButton,
} from "@/components/ui/dialog";
import { ASSESSMENT_RESULT } from "../data/maturityAssessmentResult";
import { Button } from "@/components/ui/button";
import { OptionButton } from "@/components/ui/OptionButton";
import Container from "@/components/ui/container";
import { useDispatch } from "react-redux";
import { updateSelectedSlice } from "../../slice/areAssessment";
import { useSubmitKPIMockMutation } from "../../slice/nextGenAMSAPISlice";
import { toast } from "@/components/ui/use-toast";

interface DialogSelectKPIProps {
    selectedKPIs: string[];
    setSelectedKPIs: (kpIs: string[]) => void;
    req_id?: string;
}

const DialogSelectKPI = ({ selectedKPIs, setSelectedKPIs, req_id }: DialogSelectKPIProps) => {
    const [open, setOpen] = useState(false);
    const [submit, submissionResponse] = useSubmitKPIMockMutation()
    const dispatch = useDispatch();
    useEffect(() => {
        if (selectedKPIs.length < 1) {
            setOpen(true);
        }
    }, []);

    const handleSelect = (kpi: string) => {
        if (selectedKPIs.includes(kpi)) {
            setSelectedKPIs(selectedKPIs.filter((item) => item !== kpi));
        } else {
            setSelectedKPIs([...selectedKPIs, kpi]);
        }
    };

    const handleConfirm = () => {
        if (selectedKPIs.length >= 1) {
            // setOpen(false); 
            submit({ requestId: req_id, kpis: [...selectedKPIs] })
        }
    };

    useEffect(() => {
        const { data, error } = submissionResponse
        if (error) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
            return;
        }
        if (data) {
            toast({
                title: "Request Submitted Successfully"
            })
            dispatch(updateSelectedSlice(selectedKPIs));
            setOpen(false)
        }
    }, [submissionResponse])

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContentWithNoCloseButton
                className="gap-4"
                // prevents the default close behavior
                onEscapeKeyDown={(event) => {
                    event.preventDefault();
                }}
            >
                <DialogHeader className="md:pl-1">
                    <DialogTitle>Select KPIs</DialogTitle>
                    <DialogDescription>Choose KPIs for which your account is struggling</DialogDescription>
                </DialogHeader>
                <Container className="grid grid-cols-2 gap-4 mt-4 overflow-y-auto py-4 md:pl-1 max-h-[350px]">
                    {ASSESSMENT_RESULT.map((item) => (
                        <OptionButton
                            // key={item.kpi}
                            // className={`border h-16 ${selectedKPIs.includes(item.kpi) ? "bg-blue-500" : ""
                            //     }`}
                            // onClick={() => handleSelect(item.kpi)}
                            option={item.kpi}
                            isSelected={selectedKPIs.includes(item.kpi)}
                            onClick={() => handleSelect(item.kpi)}
                            className={`ring-0 py-8 rounded-lg text-wrap hover:scale-[1] ${selectedKPIs.includes(item.kpi) ? "bg-blue-500 hover:bg-blue-500 text-white" : ""}`}
                        >
                            {/* <p className="font-semibold">{item.kpi}</p> */}
                        </OptionButton>
                    ))}
                </Container>

                <DialogFooter className="mt-4 flex justify-between items-center">
                    <p className="text-sm text-gray-500">Selected: {selectedKPIs.length} </p>
                    <Button
                        onClick={handleConfirm}
                        disabled={selectedKPIs.length < 1}
                    // className={`px-4 py-2 rounded ${selectedKPIs.length < 5
                    //     ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                    //     : "bg-white font-semibold text-black"
                    //     }`}
                    >
                        Confirm Selection
                    </Button>
                </DialogFooter>
            </DialogContentWithNoCloseButton>
        </Dialog>
    );
};

export default DialogSelectKPI;