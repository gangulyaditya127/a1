import { useToast } from "@/components/ui/use-toast";
import { useUploadMaturityAssesmentExcelMutation } from "../../slice/nextGenAMSAPISlice";
import Loader from "@/components/ui/loader";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button"
import { Link, useNavigate } from "react-router-dom";
import FileUploader from "./FileUploader";

const ARE_EXCEL_TEMPLATE_LINK = "https://tcscomprod.sharepoint.com/:x:/s/SEBLTransformation/EQbnA0_nYx1BuKYHbEXXWckBRcGXcNb7QinU8YHUvqiz_Q?e=iHcNnE";

const ExcelUpload = () => {
    const [file, setFile] = useState<File[]>([]);
    const [uploadFile, { isError: isFileUploadError, isLoading: isUploadingFile, isSuccess, error: fileUploadError }] = useUploadMaturityAssesmentExcelMutation()
    const navigate = useNavigate();
    const { toast } = useToast()
    const handleFileUpload = () => {
        const formData = new FormData();
        formData.append('file', file?.[0])
        uploadFile(formData)
    }
    useEffect(() => {
        if (isFileUploadError) {
            toast({
                variant: "destructive",
                title: 'Uh no! Something went wrong',
                description: (fileUploadError as any)?.message ?? 'Unexpected Error from server'
            })
            return;
        }
        if (isSuccess) {
            toast({
                title: 'File uploaded successfully!',
                description: 'Check your maturity assesment results under recent submissions'
            })
            navigate('/help/submission')
            return;
        }
        console.log({ fileUploadError })
    }, [isSuccess, isFileUploadError])
    const isEnabled = () => {
        return file?.length == 1
    }

    return (
        <>
            <div className="grid max-w-6xl space-y-6 mb-4">
                <div className="flex gap-2 items-center">
                    <h1 className="text-muted-foreground uppercase">Upload Maturity assesment excel</h1>
                    <Link to={ARE_EXCEL_TEMPLATE_LINK} target="_blank" className="text-muted-foreground text-xs hover:underline">[Template]</Link>
                </div>
                <FileUploader files={file} setFiles={setFile} placeholder="Drag 'n' drop your quick maturity assesment excel file" />
            </div>
            <Button className="rounded-lg gap-2 w-full" variant="primary" disabled={!isEnabled()} onClick={handleFileUpload}>
                {isUploadingFile && <Loader />}
                Upload
            </Button>
        </>
    )
}

export default ExcelUpload