// ChatBox.tsx
import React, { useEffect, useRef } from "react"; // React + hooks
import { Card } from "@/components/ui/card"; // wrapper card
import { OptionButton } from "@/components/ui/OptionButton"; // inline option button
import { ChatInput } from "@/components/ui/ChatInput"; // bottom input
import { ChatMessage } from "@/components/ui/ChatMessage"; // message bubble component
import { useParams } from "react-router-dom"; // optional params
import { useSubmitChatResponseMutation } from "../../slice/nextGenAMSAPISlice"; // fallback RTK mutation
import { toast } from "@/components/ui/use-toast"; // toast notifications
import { saveAs } from "file-saver"; // helper to save blobs as files

// message interface (extended with optional structured incident field)
export interface Message {
  text: string; // textual content (used for normal bot/user messages)
  isBot: boolean; // true if message is from bot
  showOptions?: boolean; // whether inline options should be shown
  options?: string[]; // option list
  timestamps?: string; // optional timestamp
  isLast?: boolean; // optional final flag
  // optional structured incident container
  isIncident?: boolean;
  incident?: Record<string, any> | null;
}

// props for ChatBox
type ChatBoxProps = {
  prevMessage: Message[]; // canonical messages from parent
  onSendAnswer?: (answer: string) => void; // callback to parent to send answer
  isLoading?: boolean; // external loading flag
  isLast?: boolean; // external finished flag
  postmortemReport?: any; // final report data
  reqId?: string; // optional req id fallback
};

// ChatBox component (stateless w.r.t messages)
const ChatBox: React.FC<ChatBoxProps> = ({
  prevMessage,
  onSendAnswer,
  isLoading = false,
  isLast = false,
  postmortemReport = null,
  reqId,
}) => {
  const { reqId: paramReqId } = useParams<{ reqId?: string }>(); // fallback route param
  const messagesEndRef = useRef<HTMLDivElement | null>(null); // used to scroll to bottom

  // fallback mutation (used only when ChatBox is reused standalone)
  const [submit, submissionResponse] = useSubmitChatResponseMutation();

  // scroll to bottom when messages change or loading state updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [prevMessage, submissionResponse.isLoading]);

  // handle a single option click
  const handleSingleSelect = (option: string) => {
    const res = option === "Begin Assessment" ? "yes" : option; // map label if needed
    if (onSendAnswer) {
      onSendAnswer(res); // prefer parent callback
      return;
    }
    // fallback submit if no parent handler
    submit({ req_id: reqId ?? paramReqId, answer: res });
  };

  // handle free text input
  const handleTextInput = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    if (onSendAnswer) {
      const res = trimmed === "Begin Assessment" ? "yes" : trimmed;
      onSendAnswer(res);
      return;
    }
    submit({ req_id: reqId ?? paramReqId, answer: trimmed === "Begin Assessment" ? "yes" : trimmed });
  };

  // monitor fallback submission response for errors (parent handles messages in the primary usage)
  useEffect(() => {
    const { error } = submissionResponse as any;
    if (error) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: "Failed to submit request",
      });
    }
  }, [submissionResponse]);

  // -------------------------
  // Structured rendering utilities
  // -------------------------

  // Convert a value (string/array/object) into readable JSX blocks
  function renderValueAsJSX(value: any): JSX.Element {
    // null or undefined
    if (value === null || value === undefined) {
      return <div className="text-sm text-muted-foreground">—</div>;
    }

    // array -> render as bullet list or mapped blocks
    if (Array.isArray(value)) {
      if (value.length === 0) return <div className="text-sm text-muted-foreground">No entries.</div>;
      return (
        <ul className="list-disc ml-5 space-y-1">
          {value.map((item, i) => (
            <li key={i} className="text-sm">
              {typeof item === "object" ? <pre className="whitespace-pre-wrap text-sm">{JSON.stringify(item, null, 2)}</pre> : String(item)}
            </li>
          ))}
        </ul>
      );
    }

    // object -> render key-value pairs in nested card
    if (typeof value === "object") {
      return (
        <div className="space-y-2">
          {Object.entries(value).map(([k, v]) => (
            <div key={k} className="p-2 border rounded text-sm">
              <div className="text-xs text-muted-foreground">{k}</div>
              <div className="mt-1">{renderValueAsJSX(v)}</div>
            </div>
          ))}
        </div>
      );
    }

    // fallback primitive (string/number/boolean)
    return <div className="text-sm whitespace-pre-wrap">{String(value)}</div>;
  }

  // Render the structured postmortem report (top-level)
  const renderPostmortemReport = (report: any) => {
    // no report
    if (report === null || report === undefined) return <div className="text-sm text-muted-foreground">No report provided.</div>;

    // If report is string that parses as JSON, convert it to object first
    if (typeof report === "string") {
      try {
        const parsed = JSON.parse(report);
        return renderPostmortemReport(parsed);
      } catch (e) {
        // not JSON: split into paragraphs by double newline and render
        const paragraphs = String(report).split(/\n\s*\n/).filter(Boolean);
        return (
          <div className="space-y-3">
            {paragraphs.map((p: string, idx: number) => (
              <div key={idx} className="p-2 rounded text-sm whitespace-pre-wrap border">
                {p}
              </div>
            ))}
          </div>
        );
      }
    }

    // If it's an object: render keys as labeled blocks, values rendered by renderValueAsJSX
    if (typeof report === "object") {
      // If the report looks like an array-of-steps, render each step
      if (Array.isArray(report)) {
        return (
          <div className="space-y-3">
            {report.map((item, idx) => (
              <div key={idx} className="p-3 rounded border">
                <div className="font-semibold text-sm">Step {idx + 1}</div>
                <div className="mt-2">{renderValueAsJSX(item)}</div>
              </div>
            ))}
          </div>
        );
      }

      // Otherwise standard object with keys
      return (
        <div className="space-y-3">
          {Object.entries(report).map(([k, v]) => (
            <div key={k} className="p-3 rounded border">
              <div className="font-semibold text-sm">{k}</div>
              <div className="mt-2">{renderValueAsJSX(v)}</div>
            </div>
          ))}
        </div>
      );
    }

    // fallback: show as text
    return <div className="text-sm">{String(report)}</div>;
  };

  // -------------------------
  // DOCX generation & download
  // -------------------------
  // This function dynamically imports 'docx' to keep bundle size lower and avoid server-side issues.
  async function downloadReportAsDocx(report: any, filename = "postmortem.docx") {
    try {
      // dynamic import of docx components we need
      const docx = await import("docx");
      const { Document, Packer, Paragraph, HeadingLevel, TextRun } = docx;

      // Helper to convert a value into docx paragraphs (recursive)
      const valueToParagraphs = (value: any): Paragraph[] => {
        // Nullish
        if (value === null || value === undefined) {
          return [new Paragraph({ children: [new TextRun({ text: "—" })] })];
        }

        // Array -> each item as a bullet paragraph (simple)
        if (Array.isArray(value)) {
          const paras: Paragraph[] = [];
          value.forEach((item) => {
            if (typeof item === "object") {
              paras.push(new Paragraph({ children: [new TextRun({ text: "- " + JSON.stringify(item) })] }));
            } else {
              paras.push(new Paragraph({ children: [new TextRun({ text: "- " + String(item) })] }));
            }
          });
          return paras;
        }

        // Object -> render key / nested value pairs (flatten a bit)
        if (typeof value === "object") {
          const paras: Paragraph[] = [];
          Object.entries(value).forEach(([subk, subv]) => {
            paras.push(new Paragraph({ children: [new TextRun({ text: `${subk}:` , bold: true })] }));
            const nested = valueToParagraphs(subv);
            nested.forEach((p) => paras.push(p));
          });
          return paras;
        }

        // primitive
        return [new Paragraph({ children: [new TextRun({ text: String(value) })] })];
      };

      // Build the docx document
      const doc = new Document({
        sections: [
          {
            properties: {},
            children: [
              new Paragraph({ text: "Postmortem Report", heading: HeadingLevel.HEADING_1 }),
              // if report is object, iterate keys
              ...(typeof report === "object" && !Array.isArray(report)
                ? Object.entries(report).flatMap(([k, v]) => {
                    const heading = new Paragraph({ children: [new TextRun({ text: String(k), bold: true })] });
                    const paras = valueToParagraphs(v);
                    return [heading, ...paras, new Paragraph({})]; // blank paragraph as separator
                  })
                : // else, if string or array
                  (() => {
                    const paras = valueToParagraphs(report);
                    return paras;
                  })()),
            ],
          },
        ],
      });

      // pack to blob
      const blob = await Packer.toBlob(doc);
      // use file-saver to trigger download (we imported saveAs at top)
      saveAs(blob, filename);
    } catch (err) {
      // show a friendly toast on error
      console.error("DOCX generation failed:", err);
      toast({
        variant: "destructive",
        title: "Export failed",
        description: "Could not generate the DOCX file.",
      });
    }
  }

  // render inline option buttons for bot message
  const renderInlineOptions = (msg: Message) => {
    if (!msg.showOptions) return null;
    return (
      <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
        {msg.options?.map((option) => (
          <OptionButton key={option} option={option} onClick={() => handleSingleSelect(option)} />
        ))}
      </div>
    );
  };

  // render the structured incident card for messages that carry an incident object
  const renderIncidentCard = (incident: Record<string, any> | null) => {
    if (!incident) {
      return <div className="text-sm text-muted-foreground">No incident details available.</div>;
    }

    // pull common fields with fallbacks
    const ticket = incident.ticket_number ?? incident.number ?? incident.sys_id ?? "—";
    const shortDesc = incident.short_desc ?? incident.short_description ?? incident.title ?? "";
    const configItem = incident.config_item ?? incident.cmdb_ci ?? "";
    const description = incident.description ?? "";
    const journal = Array.isArray(incident.journal) ? incident.journal : incident.work_notes ?? [];

    // extract date if present in description
    let dateStr = "";
    try {
      const match = String(description).match(/occurred on\s*([A-Za-z0-9\-/ :,.]+)/i);
      if (match && match[1]) dateStr = match[1].split(",")[0];
    } catch (e) {
      dateStr = "";
    }

    // structured card
    return (
      <div className="border rounded-lg p-4 shadow-sm">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="text-xs text-muted-foreground">Ticket</div>
            <div className="font-medium">{ticket}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Date</div>
            <div className="font-medium">{dateStr || "Unknown"}</div>
          </div>
          <div className="col-span-2">
            <div className="text-xs text-muted-foreground">Short Description</div>
            <div className="mt-1 text-sm">{shortDesc}</div>
          </div>
          <div className="col-span-2">
            <div className="text-xs text-muted-foreground">Config Item</div>
            <div className="mt-1 text-sm">{configItem}</div>
          </div>
        </div>

        {/* timeline / journal */}
        <div className="mt-3">
          <div className="text-xs text-muted-foreground mb-2">Timeline / Journal</div>
          <div className="space-y-2 max-h-36 overflow-auto">
            {journal.length === 0 ? (
              <div className="text-sm text-muted-foreground">No timeline entries.</div>
            ) : (
              journal.map((entry: any, idx: number) => {
                const when = entry.sys_created_on ?? entry.created_on ?? entry.time ?? "";
                const val = (entry.value ?? entry.note ?? entry.short_description ?? entry.comment ?? "").toString().replace(/\r\n/g, " ");
                return (
                  <div key={idx} className="text-sm p-2 rounded border">
                    <div className="text-xs text-muted-foreground">{when}</div>
                    <div className="mt-1">{val}</div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  };

  // main render
  return (
    <Card className="flex flex-col rounded-xl h-full"> {/* fill parent's height to avoid causing shrink */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 min-h-[320px]"> {/* messages area with min height */}
        {prevMessage?.map((msg, idx) => (
          <div key={idx}>
            {/* If this message is a structured incident, render the incident card */}
            {msg.isIncident ? (
              <div className="mb-3">
                <div className="text-xs text-muted-foreground mb-2">Incident Details</div>
                {renderIncidentCard(msg.incident ?? null)}
              </div>
            ) : (
              // normal message bubble
              <>
                <ChatMessage message={msg.text} isBot={msg.isBot} />
                {/* render inline options for bot messages */}
                {msg.isBot && msg.showOptions && renderInlineOptions(msg)}
              </>
            )}
          </div>
        ))}

        {/* loading indicator */}
        {(isLoading || submissionResponse.isLoading) && (
          <div className="rounded-2xl border bg-chat-bubble-assistant px-4 py-3 shadow-chat w-fit">
            <div className="flex items-center gap-2">
              <div className="flex space-x-1">
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]"></div>
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]"></div>
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary"></div>
              </div>
              <span className="text-sm text-muted-foreground">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      <div ref={messagesEndRef} />

      {/* footer: show input when active, show completion + structured report when finished */}
      <div className="border-t bg-muted/20 p-4">
        {!isLast ? (
          // input when conversation is active
          <ChatInput onSubmit={(text: string) => handleTextInput(text)} placeholder="Type your own response..." />
        ) : (
          // finished view: show completion notice, structured report, and download button
          <div className="space-y-4">
            <div className="p-3 rounded bg-emerald-50 text-emerald-800 font-medium">Postmortem Conversation Complete!</div>

            {/* structured final report */}
            <div className="bg-slate-50 p-4 rounded max-h-[260px] overflow-auto">
              {renderPostmortemReport(postmortemReport)}
            </div>

            {/* action buttons row - download docx */}
            <div className="flex gap-3">
              <button
                className="rounded-md bg-blue-600 text-white py-2 px-4"
                onClick={() => downloadReportAsDocx(postmortemReport, "postmortem_report.docx")}
              >
                Download DOCX
              </button>

              {/* optional: also allow download JSON for debugging */}
              <button
                className="rounded-md bg-gray-200 text-black py-2 px-4"
                onClick={() => {
                  const blob = new Blob([JSON.stringify(postmortemReport ?? {}, null, 2)], { type: "application/json" });
                  saveAs(blob, "postmortem_report.json");
                }}
              >
                Download JSON
              </button>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default ChatBox;
