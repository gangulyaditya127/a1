import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import {
    Select,
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectLabel,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import { Icon } from "@/components/ui/icon"
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks"
import { nextGenAMSAPI, useLazyUpdateRequestQuery } from "../../slice/nextGenAMSAPISlice"
import { useState } from "react"
import { Link } from "react-router-dom"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

type EditStatusProps = {
    req_num: string;
    created_by: string;
    account: string;
    created_at: string;
    state: string;
}

const EditStatus = ({ req_num, created_by, account, created_at, state }: EditStatusProps) => {
    const [status, setStatus] = useState(state);
    const [open, setOpen] = useState(false)
    const dispatch = useAppDispatch();
    const [trigger, data] = useLazyUpdateRequestQuery();
    const { isLoading } = data
    const userDetails = useAppSelector(state => state.auth.rawUserDetails)
    const handleClick = async () => {
        try {
            const res = await trigger({
                email: userDetails.email,
                empid: userDetails.empid,
                req_num,
                state: status
            })
            console.log({ res })
            setOpen(false)
            dispatch(nextGenAMSAPI.util.invalidateTags(['ams_req_status']))
        } catch (error) {
            console.error(error)
        }
    }

    return (
        <div className="flex flex-1 items-center">
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                    <Button variant='link' size='icon' onClick={() => setOpen(true)}>
                        <Icon name="pencil" className="h-4 w-4" />
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                        <DialogTitle>Edit request status</DialogTitle>
                        <DialogDescription>
                            Make changes to the request status. Click save when you're done.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="text-sm space-y-1">
                                <p className="font-medium text-muted-foreground">Request Number</p>
                                <p>{req_num}</p>
                            </div>
                            <div className="text-sm space-y-1">
                                <p className="font-medium text-muted-foreground">Initiated By</p>
                                <p>{created_by}</p>
                            </div>
                            <div className="text-sm space-y-1">
                                <p className="font-medium text-muted-foreground">Created on</p>
                                <p>{created_at}</p>
                            </div>
                            <div className="text-sm space-y-1">
                                <p className="font-medium text-muted-foreground">Account</p>
                                <p>{account}</p>
                            </div>
                        </div>
                        <Select defaultValue={state} onValueChange={setStatus} value={status}>
                            <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectGroup>
                                    <SelectLabel>Status</SelectLabel>
                                    <SelectItem value="New Request">New Request</SelectItem>
                                    <SelectItem value="Briefing Complete">Briefing Complete</SelectItem>
                                    <SelectItem value="Assessment WIP">Assessment WIP</SelectItem>
                                    <SelectItem value="Assessment Complete">Assessment Complete</SelectItem>
                                    <SelectItem value="Offering / Solution Fitment">Offering / Solution Fitment</SelectItem>
                                    <SelectItem value="Customer Presentation">Customer Presentation</SelectItem>
                                    <SelectItem value="Implementation">Implementation</SelectItem>
                                </SelectGroup>
                            </SelectContent>
                        </Select>
                    </div>
                    <DialogFooter>
                        <Button disabled={isLoading} type="submit" variant='primary' className="gap-1" onClick={handleClick}>
                            {isLoading && <Icon name="loader" className="animate-spin h-4 w-4" />}
                            Save
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Link to={`/help/admin/maturity-result/${req_num}`}>
                            <Icon name="eye" className="h-4 w-4" />
                        </Link>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>View maturity assesment result</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            {/* sdfsdfdsf */}
        </div>
    )
}
export default EditStatus