import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";

export interface Tool {
    name: string;
    link: string;
}

export interface AssessmentResultItem {
    kpi: string;
    score: number;
    standard: number;
    gap: number;
    tools: Tool[];
}

interface Props {
    result: AssessmentResultItem;
}

const MaturityAssessmentResultCard: React.FC<Props & { id?: string }> = ({ result, id }) => {
    return (
        <Card id={id} className="rounded-xl flex flex-col bg-secondary/20 h-[400px]">
            {/* Header */}
            <CardHeader className="pb-4 h-24 flex flex-col justify-center">
                <CardTitle className="text-md break-word">
                    {result.kpi}
                </CardTitle>
                <CardDescription className="text-sm text-muted-foreground -translate-y-2">
                    Performance metrics and recommendations
                </CardDescription>
            </CardHeader>

            <CardContent className="flex-1 flex flex-col">
                {/* Scores */}
                <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                        <CardDescription className="text-gray-700 dark:text-gray-300">
                            Your Score
                        </CardDescription>
                        <span className="font-bold text-green-600 dark:text-green-400">
                            {result.score}
                        </span>
                    </div>
                    <Progress
                        value={(result.score / result.standard) * 100}
                        className="h-2 bg-gray-200 dark:bg-gray-700 [&>div]:bg-green-500"
                    />

                    <div className="flex justify-between text-sm mt-2">
                        <CardDescription className="text-gray-700 dark:text-gray-300">
                            Industry Standard
                        </CardDescription>
                        <span className="font-bold text-blue-600 dark:text-blue-400">
                            {result.standard}
                        </span>
                    </div>
                    <Progress value={100} className="h-2 bg-gray-200 dark:bg-gray-700 [&>div]:bg-blue-500" />

                    {/* Gap */}
                    <div className="pt-5">
                        <div
                            className={`
                                flex justify-between items-center w-full 
                                rounded-md px-4 py-2 text-xs font-medium
                                ${result.gap < 3
                                    ? 'bg-[#e6f7f8] text-[#007a7a] dark:bg-[#001f24] dark:text-[#4fd1c5]'
                                    : 'bg-[#fdf6e3] text-[#8b6f00] dark:bg-[#2a1a00] dark:text-[#d4a017]'}
                            `}
                        >
                            <span className="text-sm">Gap from Standard:</span>
                            <span className="text-sm font-bold">{result.gap}</span>
                        </div>
                    </div>
                </div>

                <div className="mt-4">
                    <p className="text-sm font-medium mb-2 text-gray-800 dark:text-gray-200">
                        Recommended Tools
                    </p>
                    <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 text-sm">
                        {result.tools.map((tool, index) => (
                            <li key={index}>
                                <Link
                                    to={tool.link}
                                    target="_blank"
                                    className="hover:underline"
                                >{tool.name}</Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </CardContent>
        </Card>
    );
};

export default MaturityAssessmentResultCard;