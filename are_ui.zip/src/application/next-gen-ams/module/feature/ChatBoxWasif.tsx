import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { OptionButton } from "@/components/ui/OptionButton";
import { ChatInput } from "@/components/ui/ChatInput";
import { ChatMessage } from "@/components/ui/ChatMessage";
import { useParams } from "react-router-dom";
import { useSubmitChatResponseMutation } from "../../slice/nextGenAMSAPISlice";
import { toast } from "@/components/ui/use-toast";

export interface Message {
    text: string;
    isBot: boolean;
    showOptions?: boolean;
    options?: string[];
    timestamps?: string;
    isLast?: boolean;
}

const ChatBox = ({ prevMessage }: { prevMessage: Message[] }) => {
    const { reqId } = useParams()
    const [messages, setMessages] = useState<Message[]>([]);
    const [submit, submissionResponse] = useSubmitChatResponseMutation()
    const messagesEndRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        setMessages(prevMessage)
    }, [prevMessage])

    const handleSingleSelect = (option: string) => {
        // Hide options for current question
        setMessages((prev) =>
            prev.map((msg, idx) =>
                idx === prev.length - 1 ? { ...msg, showOptions: false } : msg
            )
        );

        // Add user response to messages

        setMessages((prev) => [...prev, { text: option, isBot: false }]);

        let res = ""
        if (option == "Begin Assessment") {
            res = "yes"
        } else {
            res = option
        }
        const payload = {
            req_id: reqId,
            answer: res,
        }
        submit(payload)
    };

    const handleTextInput = (text: string) => {
        const trimmedText = text.trim();

        // Hide options for current question
        setMessages((prev) =>
            prev.map((m, idx) =>
                idx === prev.length - 1 ? { ...m, showOptions: false } : m
            )
        );

        // Add user response to messages
        setMessages((prev) => [...prev, { text: trimmedText, isBot: false }]);


        const payload = {
            req_id: reqId,
            answer: trimmedText === "Begin Assessment" ? "yes" : trimmedText,
        };
        submit(payload);
    };

    useEffect(() => {
        const { data, error } = submissionResponse
        if (error) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
            return;
        }
        if (data) {
            setMessages((prev) => [
                ...prev,
                { text: data.question, isBot: true, showOptions: data.isoptions, options: data.listOfOptions, isLast: data.isLast }
            ]);
        }
    }, [submissionResponse])

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const renderInlineOptions = (msg: Message, showOptions: boolean) => {
        if (!showOptions) return null;

        return (
            <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
                {msg.options?.map((option) => (
                    <OptionButton
                        key={option}
                        option={option}
                        onClick={() => handleSingleSelect(option)}
                    />
                ))}
            </div>
        );
    };

    return (
        <Card className="flex  flex-col rounded-xl h-[450px] max-h-[450px]">
            {/* Messages */}
            <div className="flex-1 max-h-[650px] overflow-y-auto p-6 space-y-4">
                {messages?.map((msg, idx) => (
                    <div key={idx}>
                        <ChatMessage message={msg.text} isBot={msg.isBot} />
                        {msg.isBot && msg.showOptions && renderInlineOptions(msg, true)}
                    </div>
                ))}
                {submissionResponse.isLoading && (
                    <div className="rounded-2xl border bg-chat-bubble-assistant px-4 py-3 shadow-chat w-fit">
                        <div className="flex items-center gap-2">
                            <div className="flex space-x-1">
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]"></div>
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]"></div>
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary"></div>
                            </div>
                            <span className="text-sm text-muted-foreground">Thinking...</span>
                        </div>
                    </div>
                )}
            </div>
            <div ref={messagesEndRef} />
            <div className="border-t bg-muted/20">
                <ChatInput
                    onSubmit={(text) => handleTextInput(text)}
                    placeholder="Type your own response..."
                />
            </div>
        </Card>
    )
}

export default ChatBox