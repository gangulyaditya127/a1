import { useEffect, useRef, useState } from "react";
import { chatFlow, ChatFlowNode } from "@/application/next-gen-ams/module/data/chatFlow";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { OptionButton } from "@/components/ui/OptionButton";
import { OptionChip } from "@/components/ui/OptionChip";
import { ArrowRight } from "lucide-react";
import { ChatInput } from "@/components/ui/ChatInput";
import { ChatMessage } from "@/components/ui/ChatMessage";
import { useNavigate, useParams } from "react-router-dom";
import { useLazyFetchChatHistoryQuery } from "../../slice/nextGenAMSAPISlice";
import Loader from "@/components/ui/loader";

interface Message {
    text: string;
    isBot: boolean;
    showOptions?: boolean;
    options?: string[];
    timestamps?: string;
}

interface UserResponse {
    question?: string;
    req_id?: string;
    answer: string | string[];
}

const ChatBox = () => {
    const { reqId } = useParams<{ reqId: string }>();
    const [messages, setMessages] = useState<Message[]>([]);
    // const [currentNodeId, setCurrentNodeId] = useState<string>("start");
    const [currentNode, setCurrentNode] = useState<ChatFlowNode>(chatFlow.start);
    const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
    const [responses, setResponses] = useState<UserResponse[]>([]);

    const [chatHistory, setChatHistory] = useState<Message[]>([])
    const [currentQuestion, setCurrentQuestion] = useState<Message>()
    const [isAssessmentStarted, setIsAssessmentStarted] = useState(true)

    const messagesEndRef = useRef<HTMLDivElement>(null);

    const [triggerChatHistory, { data: responseChatHistory, isLoading: chatHistoryLoading }] = useLazyFetchChatHistoryQuery();

    const navigate = useNavigate()

    useEffect(() => {
        triggerChatHistory({ req_id: reqId })
    }, [])

    useEffect(() => {
        if (responseChatHistory) {
            if (responseChatHistory.chatHistory.length > 0) {
                setIsAssessmentStarted(false)
            }
            // setChatHistory(responseChatHistory.chatHistory)
            const formattedHistory = responseChatHistory.chatHistory.map((text: string, idx: number) => ({
        text,
        isBot: idx % 2 === 0,
      }));
            console.log(responseChatHistory.chatHistory)
        }
    }, [responseChatHistory])

    useEffect(() => {
        // Add initial bot message
        setMessages([{ text: currentNode.message, isBot: true, showOptions: true }]);
    }, []);

    const handleSingleSelect = (option: string) => {
        // Hide options for current question
        setMessages((prev) =>
            prev.map((msg, idx) =>
                idx === prev.length - 1 ? { ...msg, showOptions: false } : msg
            )
        );

        // Add user response to messages
        setTimeout(() => {
            setMessages((prev) => [...prev, { text: option, isBot: false }]);
        }, 100);

        // Store response
        setResponses((prev) => [
            ...prev,
            { question: currentNode.message, answer: option },
        ]);

        // Move to next question
        setTimeout(() => {
            moveToNextNode(option);
        }, 400);
    };

    const handleMultiSelectToggle = (option: string) => {
        setSelectedOptions((prev) =>
            prev.includes(option)
                ? prev.filter((o) => o !== option)
                : [...prev, option]
        );
    };

    const handleMultiSelectConfirm = () => {
        if (selectedOptions.length === 0) return;

        // Hide options for current question
        setMessages((prev) =>
            prev.map((msg, idx) =>
                idx === prev.length - 1 ? { ...msg, showOptions: false } : msg
            )
        );

        // Add user response to messages
        const responseText = selectedOptions.join(", ");
        setTimeout(() => {
            setMessages((prev) => [...prev, { text: responseText, isBot: false }]);
        }, 100);

        // Store response
        setResponses((prev) => [
            ...prev,
            { question: currentNode.message, answer: selectedOptions },
        ]);

        // Move to next question
        setTimeout(() => {
            moveToNextNode();
            setSelectedOptions([]);
        }, 400);
    };

    const handleTextInput = (text: string) => {
        // If current node is single-select or multi-select, validate input
        if ((currentNode.type === "single-select" || currentNode.type === "multi-select") && currentNode.options) {
            const isValid = currentNode.options.includes(text.trim());

            if (!isValid) {
                // Show user's invalid input
                setMessages((prev) => [
                    ...prev,
                    { text: text.trim(), isBot: false },
                    {
                        text: `Invalid response. Please select one of the valid options:`,
                        isBot: true,
                        showOptions: true
                    }
                ]);
                return;
            }
        }



        // Hide options for current question
        setMessages((prev) =>
            prev.map((msg, idx) =>
                idx === prev.length - 1 ? { ...msg, showOptions: false } : msg
            )
        );

        // Add user response to messages
        setTimeout(() => {
            setMessages((prev) => [...prev, { text, isBot: false }]);
        }, 100);

        // Store response
        setResponses((prev) => [
            ...prev,
            { question: currentNode.message, answer: text },
        ]);

        // Move to next question
        setTimeout(() => {
            moveToNextNode(text);
        }, 400);
    };

    const moveToNextNode = (selectedOption?: string) => {
        let nextNodeId: string | undefined;

        if (typeof currentNode.next === "string") {
            nextNodeId = currentNode.next;
        } else if (typeof currentNode.next === "object" && selectedOption) {
            nextNodeId = currentNode.next[selectedOption];
        }

        if (!nextNodeId || !chatFlow[nextNodeId]) {
            console.error("Next node not found");
            return;
        }

        const nextNode = chatFlow[nextNodeId];
        // setCurrentNodeId(nextNodeId);
        setCurrentNode(nextNode);

        // Add bot message with options
        setTimeout(() => {
            setMessages((prev) => [...prev, { text: nextNode.message, isBot: true, showOptions: true }]);
        }, 500);
    };

    const renderInlineOptions = (node: ChatFlowNode, showOptions: boolean) => {
        if (!showOptions) return null;

        if (node.type === "end") {
            return (
                <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
                    <Card className="p-4 bg-accent/10 border-accent">
                        <h3 className="font-semibold text-accent-foreground mb-2">Assessment Complete</h3>
                        <p className="text-sm text-muted-foreground">
                            We've recorded {responses.length} responses across various dimensions.
                        </p>
                    </Card>
                    <div className="flex flex-col w-fit gap-2">
                        <Button
                            onClick={() => {
                                setMessages([{ text: chatFlow.start.message, isBot: true, showOptions: true }]);
                                // setCurrentNodeId("start");
                                setCurrentNode(chatFlow.start);
                                setResponses([]);
                            }}
                            className=""
                        >
                            Start New Assessment
                        </Button>
                        <Button
                            onClick={() => {
                                // setMessages([{ text: chatFlow.start.message, isBot: true, showOptions: true }]);
                                // // setCurrentNodeId("start");
                                // setCurrentNode(chatFlow.start);
                                // setResponses([]);
                                navigate("/help/mock/result")
                            }}
                            className=""
                        >
                            View Result
                        </Button>
                    </div>
                </div>
            );
        }

        if (node.type === "single-select" && node.options) {
            return (
                <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
                    {node.options.map((option) => (
                        <OptionButton
                            key={option}
                            option={option}
                            onClick={() => handleSingleSelect(option)}
                        />
                    ))}
                </div>
            );
        }

        if (node.type === "multi-select" && node.options) {
            return (
                <div className="mt-3 space-y-3 animate-fade-in max-w-[80%]">
                    <div className="flex flex-wrap gap-2">
                        {node.options.map((option) => (
                            <OptionChip
                                key={option}
                                option={option}
                                isSelected={selectedOptions.includes(option)}
                                onClick={() => handleMultiSelectToggle(option)}
                            />
                        ))}
                    </div>
                    <Button
                        onClick={handleMultiSelectConfirm}
                        disabled={selectedOptions.length === 0}
                        className="gap-2"
                    >
                        Continue
                        <ArrowRight className="h-4 w-4" />
                    </Button>
                </div>
            );
        }

        return null;
    };

    if (chatHistoryLoading) {
        return <Loader />
    }


    return (
        <Card className="flex  flex-col rounded-xl h-[450px] max-h-[450px]">
            {/* Messages */}
            <div className="flex-1 max-h-[650px] overflow-y-auto p-6 space-y-4">
                {messages.map((msg, idx) => (
                    <div key={idx}>
                        <ChatMessage message={msg.text} isBot={msg.isBot} />
                        {msg.isBot && msg.showOptions && renderInlineOptions(currentNode, true)}
                    </div>
                ))}

            </div>
            <div ref={messagesEndRef} />
            {/* Text Input */}
            {currentNode.type !== "end" && (
                <div className="border-t bg-muted/20">
                    <ChatInput
                        onSubmit={handleTextInput}
                        placeholder="Type your own response..."
                    />
                </div>
            )}
        </Card>
    )
}

export default ChatBox