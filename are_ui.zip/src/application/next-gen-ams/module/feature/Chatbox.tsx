// ChatBox.tsx
import React, { useEffect, useRef } from "react"; // React and hooks
import { Card } from "@/components/ui/card"; // Card wrapper component
import { OptionButton } from "@/components/ui/OptionButton"; // inline option button UI
import { ChatInput } from "@/components/ui/ChatInput"; // bottom input component
import { ChatMessage } from "@/components/ui/ChatMessage"; // message bubble UI
import { useParams } from "react-router-dom"; // optional route params
import { useSubmitChatResponseMutation } from "../../slice/nextGenAMSAPISlice"; // fallback RTK mutation
import { toast } from "@/components/ui/use-toast"; // toast notifications

// Message interface with optional structured incident payload
export interface Message {
  text: string;
  isBot: boolean;
  showOptions?: boolean;
  options?: string[];
  timestamps?: string;
  isLast?: boolean;
  isIncident?: boolean;
  incident?: Record<string, any> | null;
}

// Props for ChatBox (note: no postmortemReport prop anymore)
type ChatBoxProps = {
  prevMessage: Message[]; // parent-owned message array
  onSendAnswer?: (answer: string) => void; // callback to parent to handle user's answers
  isLoading?: boolean; // external loading flag
  isLast?: boolean; // external conversation finished flag
  reqId?: string; // optional session id fallback
};

// Stateless ChatBox focused only on chat UI and input
const ChatBox: React.FC<ChatBoxProps> = ({ prevMessage, onSendAnswer, isLoading = false, isLast = false, reqId }) => {
  const { reqId: paramReqId } = useParams<{ reqId?: string }>(); // optional route param fallback
  const messagesEndRef = useRef<HTMLDivElement | null>(null); // anchor used to scroll to bottom

  // fallback mutation if ChatBox used outside parent-managed flow
  const [submit, submissionResponse] = useSubmitChatResponseMutation();

  // scroll to bottom whenever messages change or the fallback submission loading changes
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [prevMessage, submissionResponse.isLoading]);

  // handle clicking an inline option
  const handleSingleSelect = (option: string) => {
    const res = option === "Begin Assessment" ? "yes" : option; // map label if needed
    if (onSendAnswer) {
      onSendAnswer(res); // delegate to parent (preferred)
      return;
    }
    // fallback behaviour when parent callback not supplied
    submit({ req_id: reqId ?? paramReqId, answer: res });
  };

  // handle text input submission
  const handleTextInput = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return; // ignore empty
    if (onSendAnswer) {
      const res = trimmed === "Begin Assessment" ? "yes" : trimmed;
      onSendAnswer(res); // delegate to parent
      return;
    }
    // fallback mutation
    submit({ req_id: reqId ?? paramReqId, answer: trimmed === "Begin Assessment" ? "yes" : trimmed });
  };

  // watch fallback submission response for errors and show toast if any
  useEffect(() => {
    const { error } = submissionResponse as any;
    if (error) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: "Failed to submit request",
      });
    }
  }, [submissionResponse]);

  // render inline options for a bot message
  const renderInlineOptions = (msg: Message) => {
    if (!msg.showOptions) return null;
    return (
      <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
        {msg.options?.map((option) => (
          <OptionButton key={option} option={option} onClick={() => handleSingleSelect(option)} />
        ))}
      </div>
    );
  };

  // render structured incident card when parent supplied an incident object as a message
  const renderIncidentCard = (incident: Record<string, any> | null) => {
    if (!incident) {
      return <div className="text-sm text-muted-foreground">No incident details available.</div>;
    }

    // pick common fields with fallbacks
    const ticket = incident.ticket_number ?? incident.number ?? incident.sys_id ?? "—";
    const shortDesc = incident.short_desc ?? incident.short_description ?? incident.title ?? "";
    const configItem = incident.config_item ?? incident.cmdb_ci ?? "";
    const description = incident.description ?? "";
    const journal = Array.isArray(incident.journal) ? incident.journal : incident.work_notes ?? [];

    // try to extract a date from description (best-effort)
    let dateStr = "";
    try {
      const match = String(description).match(/occurred on\s*([A-Za-z0-9\-/ :,.]+)/i);
      if (match && match[1]) dateStr = match[1].split(",")[0];
    } catch (e) {
      dateStr = "";
    }

    // structured card (keeps styling consistent)
    return (
      <div className="border rounded-lg p-4 shadow-sm">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="text-xs text-muted-foreground">Ticket</div>
            <div className="font-medium">{ticket}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Date</div>
            <div className="font-medium">{dateStr || "Unknown"}</div>
          </div>

          <div className="col-span-2">
            <div className="text-xs text-muted-foreground">Short Description</div>
            <div className="mt-1 text-sm">{shortDesc}</div>
          </div>

          <div className="col-span-2">
            <div className="text-xs text-muted-foreground">Config Item</div>
            <div className="mt-1 text-sm">{configItem}</div>
          </div>
        </div>

        {/* timeline / journal */}
        <div className="mt-3">
          <div className="text-xs text-muted-foreground mb-2">Timeline / Journal</div>
          <div className="space-y-2 max-h-36 overflow-auto">
            {journal.length === 0 ? (
              <div className="text-sm text-muted-foreground">No timeline entries.</div>
            ) : (
              journal.map((entry: any, idx: number) => {
                const when = entry.sys_created_on ?? entry.created_on ?? entry.time ?? "";
                const val = (entry.value ?? entry.note ?? entry.short_description ?? entry.comment ?? "").toString().replace(/\r\n/g, " ");
                return (
                  <div key={idx} className="text-sm p-2 rounded border">
                    <div className="text-xs text-muted-foreground">{when}</div>
                    <div className="mt-1">{val}</div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  };

  // main render of ChatBox: messages + input/completion notice (no report UI here)
  return (
    <Card className="flex flex-col rounded-xl h-full">
      <div className="flex-1 overflow-y-auto p-6 space-y-4 min-h-[320px]">
        {prevMessage?.map((msg, idx) => (
          <div key={idx}>
            {msg.isIncident ? (
              <div className="mb-3">
                <div className="text-xs text-muted-foreground mb-2">Incident Details</div>
                {renderIncidentCard(msg.incident ?? null)}
              </div>
            ) : (
              <>
                <ChatMessage message={msg.text} isBot={msg.isBot} />
                {msg.isBot && msg.showOptions && renderInlineOptions(msg)}
              </>
            )}
          </div>
        ))}

        {/* loading indicator */}
        {(isLoading || submissionResponse.isLoading) && (
          <div className="rounded-2xl border bg-chat-bubble-assistant px-4 py-3 shadow-chat w-fit">
            <div className="flex items-center gap-2">
              <div className="flex space-x-1">
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
                <div className="h-2 w-2 animate-bounce rounded-full bg-primary" />
              </div>
              <span className="text-sm text-muted-foreground">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      <div ref={messagesEndRef} />

      {/* footer: show input when active, show completion notice when finished (report moved out) */}
      <div className="border-t bg-muted/20 p-4">
        {!isLast ? (
          <ChatInput onSubmit={(text: string) => handleTextInput(text)} placeholder="Type your own response..." />
        ) : (
          <div className="p-3 rounded bg-emerald-50 text-emerald-800 font-medium">Postmortem Conversation Complete!</div>
        )}
      </div>
    </Card>
  );
};

export default ChatBox;
