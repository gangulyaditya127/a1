// ChatBox.tsx
import React, { useEffect, useRef } from "react"; // React and hooks
import { Card } from "@/components/ui/card"; // Card wrapper
import { OptionButton } from "@/components/ui/OptionButton"; // option button component
import { ChatInput } from "@/components/ui/ChatInput"; // chat input component
import { ChatMessage } from "@/components/ui/ChatMessage"; // single message bubble UI
import { useParams } from "react-router-dom"; // optional param fallback
import { useSubmitChatResponseMutation } from "../../slice/nextGenAMSAPISlice"; // fallback RTK mutation
import { toast } from "@/components/ui/use-toast"; // toast notifications

// Message interface to keep types consistent
export interface Message {
    text: string; // message text
    isBot: boolean; // true if from bot
    showOptions?: boolean; // whether to render options for this bot message
    options?: string[]; // option list if any
    timestamps?: string; // optional timestamp
    isLast?: boolean; // optional flag when message marks last
}

// Props for ChatBox
type ChatBoxProps = {
    prevMessage: Message[]; // canonical message list from parent
    onSendAnswer?: (answer: string) => void; // callback to parent to handle answer
    isLoading?: boolean; // parent's loading flag
    isLast?: boolean; // parent's finished flag
    postmortemReport?: any; // final report data, string or object
    reqId?: string; // optional reqId fallback
};

// ChatBox component (stateless w.r.t. messages)
const ChatBox: React.FC<ChatBoxProps> = ({
    prevMessage,
    onSendAnswer,
    isLoading = false,
    isLast = false,
    postmortemReport = null,
    reqId
}) => {
    const { reqId: paramReqId } = useParams<{ reqId?: string }>(); // optional route param as fallback
    const [submit, submissionResponse] = useSubmitChatResponseMutation(); // fallback mutation if ChatBox used standalone
    const messagesEndRef = useRef<HTMLDivElement | null>(null); // ref to scroll to bottom

    // scroll to bottom when messages or loading changes
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); // smooth scroll
    }, [prevMessage, submissionResponse.isLoading]);

    // handle selecting an inline option
    const handleSingleSelect = (option: string) => {
        const res = option === "Begin Assessment" ? "yes" : option; // map label if needed

        // prefer parent callback if provided (keeps parent canonical state in control)
        if (onSendAnswer) {
            onSendAnswer(res); // parent will append user message and submit
            return;
        }

        // fallback: call local RTK mutation with req id
        submit({ req_id: reqId ?? paramReqId, answer: res });
    };

    // handle free text input submission
    const handleTextInput = (text: string) => {
        const trimmedText = text.trim(); // normalize
        if (!trimmedText) return; // ignore empty

        if (onSendAnswer) {
            const res = trimmedText === "Begin Assessment" ? "yes" : trimmedText;
            onSendAnswer(res); // parent will process
            return;
        }

        // fallback local submit
        submit({ req_id: reqId ?? paramReqId, answer: trimmedText === "Begin Assessment" ? "yes" : trimmedText });
    };

    // watch fallback submission response to show errors (we do not append messages here since parent should own messages)
    useEffect(() => {
        const { error } = submissionResponse as any;
        if (error) {
            // show error toast for fallback mode
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
        }
    }, [submissionResponse]);

    // render inline option buttons for a bot message
    const renderInlineOptions = (msg: Message) => {
        if (!msg.showOptions) return null; // nothing to render
        return (
            <div className="mt-3 space-y-2 animate-fade-in max-w-[80%]">
                {msg.options?.map((option) => (
                    <OptionButton key={option} option={option} onClick={() => handleSingleSelect(option)} />
                ))}
            </div>
        );
    };

    // utility to render the final postmortem report as structured HTML
    const renderPostmortemReport = (report: any) => {
        // if null/undefined, render nothing
        if (report === null || report === undefined) return null;

        // if it's already an object, try to render key-value pairs
        if (typeof report === "object") {
            // if it's an array of steps or paragraphs, render each item
            if (Array.isArray(report)) {
                return (
                    <div className="space-y-2">
                        {report.map((item, idx) => (
                            <div key={idx} className="p-2 bg-white rounded shadow-sm">
                                {/* if item is object, stringify keys; otherwise render as text */}
                                {typeof item === "object" ? (
                                    <pre className="whitespace-pre-wrap text-sm">{JSON.stringify(item, null, 2)}</pre>
                                ) : (
                                    <div className="text-sm">{String(item)}</div>
                                )}
                            </div>
                        ))}
                    </div>
                );
            }

            // Otherwise, report is a plain object mapping titles to values
            return (
                <div className="space-y-3">
                    {Object.entries(report).map(([k, v]) => (
                        <div key={k} className="p-3 bg-white rounded shadow-sm">
                            <div className="font-semibold text-sm">{k}</div>
                            {/* if value is object/array, pretty-print with line breaks; else show text */}
                            {typeof v === "object" ? (
                                <pre className="mt-1 whitespace-pre-wrap text-sm">{JSON.stringify(v, null, 2)}</pre>
                            ) : (
                                <div className="mt-1 text-sm">{String(v)}</div>
                            )}
                        </div>
                    ))}
                </div>
            );
        }

        // if report is a string, try to interpret it:
        // 1) If it's JSON text, parse and render as object
        try {
            const maybe = JSON.parse(report);
            return renderPostmortemReport(maybe); // recursive render
        } catch (e) {
            // 2) Not JSON: split into paragraphs by double newline or single newline
            const paragraphs = String(report).split(/\n\s*\n/).filter(Boolean); // split at empty lines
            return (
                <div className="space-y-3">
                    {paragraphs.map((p, idx) => (
                        <div key={idx} className="p-2 bg-white rounded shadow-sm text-sm whitespace-pre-wrap">
                            {p}
                        </div>
                    ))}
                </div>
            );
        }
    };

    // main render
    return (
        // card that fills parent's height so the ChatBox never causes parent to shrink
        <Card className="flex flex-col rounded-xl h-full"> 
            {/* messages area: flex-1 ensures it grows and shrinks inside the card but won't collapse below min-h */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 min-h-[320px]"> 
                {/* render each message from parent-owned prevMessage */}
                {prevMessage?.map((msg, idx) => (
                    <div key={idx}>
                        <ChatMessage message={msg.text} isBot={msg.isBot} /> {/* message bubble */}
                        {/* render inline options only for bot messages that have them */}
                        {msg.isBot && msg.showOptions && renderInlineOptions(msg)}
                    </div>
                ))}

                {/* loading indicator: either from parent or fallback submissionResponse */}
                {(isLoading || submissionResponse.isLoading) && (
                    <div className="rounded-2xl border bg-chat-bubble-assistant px-4 py-3 shadow-chat w-fit">
                        <div className="flex items-center gap-2">
                            <div className="flex space-x-1">
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]"></div>
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]"></div>
                                <div className="h-2 w-2 animate-bounce rounded-full bg-primary"></div>
                            </div>
                            <span className="text-sm text-muted-foreground">Thinking...</span>
                        </div>
                    </div>
                )}
            </div>

            {/* anchor for scrolling */}
            <div ref={messagesEndRef} />

            {/* footer area: when not finished, show input; when finished show completion + structured report */}
            <div className="border-t bg-muted/20 p-4"> 
                {!isLast ? (
                    // show ChatInput when conversation is still active
                    <ChatInput onSubmit={(text: string) => handleTextInput(text)} placeholder="Type your own response..." />
                ) : (
                    // when finished, show a non-collapsing completion box and structured report below
                    <div className="space-y-4">
                        <div className="p-3 rounded bg-emerald-50 text-emerald-800 font-medium">Postmortem Conversation Complete!</div>
                        {/* structured final report area */}
                        <div className="bg-slate-50 p-4 rounded max-h-[260px] overflow-auto">
                            {/* call helper to render pretty report */}
                            {renderPostmortemReport(postmortemReport)}
                        </div>
                    </div>
                )}
            </div>
        </Card>
    );
};

export default ChatBox; // export
