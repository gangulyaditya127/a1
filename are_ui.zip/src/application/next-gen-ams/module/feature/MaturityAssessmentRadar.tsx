import { PolarAngleAxis, PolarGrid, Radar, RadarChart } from "recharts";
import {
    Card,
    CardContent,
} from "@/components/ui/card";
import {
    ChartConfig,
    ChartContainer,
    ChartTooltip,
} from "@/components/ui/chart";
import { ASSESSMENT_RESULT } from "../data/maturityAssessmentResult";

const chartData = ASSESSMENT_RESULT.map(item => ({
    kpi: item.kpi,
    score: item.score,
    standard: item.standard,
}));

const chartConfig = {
    score: {
        label: "Your Score",
        color: "hsl(var(--chart-1))",
    },
} satisfies ChartConfig;

export function MaturityAssessmentRadar() {
    return (
        <Card className="rounded-xl border-none px-4">
            <CardContent className="pb-0 pl-0 col-span-3">
                <ChartContainer
                    config={chartConfig}
                    className="w-full aspect-square max-h-[300px]"
                >
                    <RadarChart data={chartData}>
                        {/*  Custom Tooltip */}
                        <ChartTooltip
                            cursor={false}
                            content={({ payload }) => {
                                if (!payload || !payload.length) return null;
                                const { kpi, score, standard } = payload[0].payload;

                                return (
                                    <div className="rounded-md border bg-popover p-3 text-popover-foreground shadow-md">
                                        <p className="text-sm font-semibold">{kpi}</p>
                                        <div className="mt-2 space-y-1 text-xs">
                                            <p>
                                                <span className="font-medium">Your Score:</span> {score}
                                            </p>
                                            <p>
                                                <span className="font-medium">Industry Standard:</span> {standard}
                                            </p>
                                        </div>
                                    </div>
                                );
                            }}
                        />
                        <PolarGrid gridType="circle" />
                        <PolarAngleAxis
                            dataKey="kpi"
                            tick={({ payload, x, y, textAnchor }) => (
                                <text
                                    x={x}
                                    y={y}
                                    textAnchor={textAnchor}
                                    className="cursor-pointer text-xs hover:fill-blue-500 transition-colors"
                                    fill="hsl(var(--muted-foreground))" // Tailwind variable for muted foreground
                                    onClick={() => {
                                        const card = document.getElementById(`card-${payload.value}`);
                                        if (card) {
                                            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                        }
                                    }}
                                >
                                    {payload.value}
                                </text>
                            )}
                        />
                        <Radar
                            name="Your Score"
                            dataKey="score"
                            stroke="var(--color-score)"
                            fill="var(--color-score)"
                            fillOpacity={0.6}
                            dot={{ r: 3, fillOpacity: 1 }}
                        />
                    </RadarChart>
                </ChartContainer>
            </CardContent>
        </Card>
    );
}