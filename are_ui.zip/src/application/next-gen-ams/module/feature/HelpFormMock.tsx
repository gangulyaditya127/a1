import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { helpFormSchemaMock } from "../schema/helpFormSchema";
import { z } from 'zod'
import { Button } from "@/components/ui/button"
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { SelectOption, SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useLazyFetchAccountsQuery, useLazyFetchBusinessGroupsQuery, useLazyFetchISUQuery, useLazyFetchSubISUQuery, useSubmitRequestMockMutation } from "../../slice/nextGenAMSAPISlice";
import { useAppSelector } from "@/lib/redux/hooks";
// import { updateHelpForm } from "../../slice/areAssessment";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
// import { ACCOUNT_LIST, BUSINESS_GROUP_LIST, ISU_LIST, SUB_ISU_LIST } from "../data/helpForm";
import { useEffect, useState } from "react";

const HelpFormMock = () => {
    const { toast } = useToast()
    const navigate = useNavigate()
    // const dispatch = useAppDispatch()


    const [businessGroups, setBusinessGroups] = useState<SelectOption[]>([]);
    const [isuList, setIsuList] = useState<SelectOption[]>([]);
    const [subIsuList, setSubIsuList] = useState<SelectOption[]>([]);
    const [accountsList, setAccountsList] = useState<SelectOption[]>([]);

    const [submit, submissionResponse] = useSubmitRequestMockMutation()
    const rawUserDetails = useAppSelector((state) => state.auth.rawUserDetails)
    const form = useForm<z.infer<typeof helpFormSchemaMock>>({
        resolver: zodResolver(helpFormSchemaMock),
        defaultValues: {
        }
    });

    const [triggerBU, { data: responseBU, isFetching: isFetchingBU }] = useLazyFetchBusinessGroupsQuery();
    const [triggerISU, { data: responseISU, isFetching: isFetchingISU }] = useLazyFetchISUQuery();
    const [triggerSubISU, { data: responseSubISU, isFetching: isFetchingSubISU }] = useLazyFetchSubISUQuery();
    const [triggerAccounts, { data: responseAccounts, isFetching: isFetchingAccounts }] = useLazyFetchAccountsQuery();


    // GET BU
    useEffect(() => {
        if (rawUserDetails) {
            triggerBU();
        }
    }, [rawUserDetails, triggerBU]);
    useEffect(() => {
        if (responseBU && responseBU.length > 0) {
            // setRowData(response.data as HelpSubmissions[]);
            const options: SelectOption[] = responseBU.map((item: string) => ({
                value: item,
                label: item,
            }));
            setBusinessGroups(options)

            setIsuList([]);
            setSubIsuList([]);
            setAccountsList([]);

            form.setValue("isu", "");
            form.setValue("subIsu", "");
            form.setValue("account", "");
        }
    }, [responseBU]);

    // GET ISU
    useEffect(() => {
        if (responseBU && responseBU.length > 0) {
            triggerISU({ businessGroup: form.watch("businessGroup") });
        }
    }, [form.watch("businessGroup"), triggerISU]);

    useEffect(() => {
        if (responseISU && responseISU.length > 0) {
            // setRowData(response.data as HelpSubmissions[]);
            const options: SelectOption[] = responseISU.map((item: string) => ({
                value: item,
                label: item,
            }));
            setIsuList(options)

            setSubIsuList([]);
            setAccountsList([]);

            form.setValue("subIsu", "");
            form.setValue("account", "");
        }
    }, [responseISU]);

    // Get Sub ISU
    useEffect(() => {
        if (responseISU && responseISU.length > 0) {
            triggerSubISU({ businessGroup: form.watch("businessGroup"), isu: form.watch("isu") });
        }
    }, [form.watch("isu"), triggerSubISU]);

    useEffect(() => {
        if (responseSubISU && responseSubISU.length > 0) {
            // setRowData(response.data as HelpSubmissions[]);
            const options: SelectOption[] = responseSubISU.map((item: string) => ({
                value: item,
                label: item,
            }));
            setSubIsuList(options)

            setAccountsList([]);

            form.setValue("account", "");
        }
    }, [responseSubISU]);

    // Get Accounts
    useEffect(() => {
        if (responseSubISU && responseSubISU.length > 0) {
            triggerAccounts({ businessGroup: form.watch("businessGroup"), isu: form.watch("isu"), subIsu: form.watch("subIsu") });
        }
    }, [form.watch("subIsu"), triggerAccounts]);

    useEffect(() => {
        if (responseAccounts && responseAccounts.length > 0) {
            // setRowData(response.data as HelpSubmissions[]);
            const options: SelectOption[] = responseAccounts.map((item: string) => ({
                value: item,
                label: item,
            }));
            setAccountsList(options)
        }
    }, [responseAccounts]);

    function onSubmit(values: z.infer<typeof helpFormSchemaMock>) {
        submit({
            userId: rawUserDetails?.empid ?? 0,
            // email: rawUserDetails?.email ?? '',
            businessGroup: values.businessGroup,
            isu: values.isu,
            subIsu: values.subIsu,
            account: values.account,
        })
        // navigate("/help/mock/chat")
    }

    useEffect(() => {
        const { data, error } = submissionResponse
        if (error) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
            return;
        }
        if (data) {
            // const currentValues = form.getValues();
            toast({
                title: "Request Submitted Successfully"
            })
            // dispatch(updateHelpForm({ ...currentValues, req_id: data.RequestId }));
            navigate(`/help/mock/kpis/${data.RequestId}`)
        }
    }, [submissionResponse])


    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {/* Business Group (BG) */}
                <FormField
                    control={form.control}
                    name="businessGroup"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel className='flex gap-2'>
                                <span>Business Group (BG) <span className="text-red-500">*</span></span>
                            </FormLabel>
                            <FormControl>
                                <SingleSelectCombobox
                                    optionList={businessGroups}
                                    field="Business Group"
                                    setValue={field.onChange}
                                    value={field.value}
                                    placeholder="Select Business Group"
                                    widthClass="w-full"
                                    loading={isFetchingBU}
                                />
                            </FormControl>
                            <FormDescription>
                                Enter your business group e.g. BFSI
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                {/* ISU */}
                <FormField
                    control={form.control}
                    name="isu"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel className='flex gap-2'>
                                ISU <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                                <SingleSelectCombobox
                                    optionList={isuList}
                                    field="ISU"
                                    setValue={field.onChange}
                                    value={field.value}
                                    placeholder="Select ISU"
                                    widthClass="w-full"
                                    loading={isFetchingISU}
                                />
                            </FormControl>
                            <FormDescription>
                                Enter your ISU
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                {/* Sub ISU */}
                <FormField
                    control={form.control}
                    name="subIsu"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel className='flex gap-2'>
                                Sub ISU <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                                <SingleSelectCombobox
                                    optionList={subIsuList}
                                    field="Sub ISU"
                                    setValue={field.onChange}
                                    value={field.value}
                                    placeholder="Select SUB ISU"
                                    widthClass="w-full"
                                    loading={isFetchingSubISU}
                                />
                            </FormControl>
                            <FormDescription>
                                Enter your Sub ISU
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                {/* Account */}
                <FormField
                    control={form.control}
                    name="account"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Account <span className="text-red-500">*</span></FormLabel>
                            <FormControl>
                                <SingleSelectCombobox
                                    optionList={accountsList}
                                    field="Account"
                                    setValue={field.onChange}
                                    value={field.value}
                                    placeholder="Select Account"
                                    widthClass="w-full"
                                    loading={isFetchingAccounts}
                                />
                            </FormControl>
                            <FormDescription>
                                Enter your account e.g. Citi
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <Button type="submit" className="w-full rounded-lg bg-[#2469BC] hover:bg-blue-700 text-white">Submit</Button>
            </form>
        </Form>
    )
}

export default HelpFormMock