import { X } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { Dispatch, SetStateAction, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";

const FileUploader = ({
    files,
    setFiles,
    placeholder
}: {
    files: File[],
    setFiles: Dispatch<SetStateAction<File[]>>
    placeholder: string
}) => {
    const removeFile = (index: number) => {
        setFiles(prevFiles => {
            const newFiles = prevFiles.filter((_, i) => i !== index)
            return newFiles
        })
    }
    const { toast } = useToast()
    const {
        acceptedFiles,
        fileRejections,
        getRootProps,
        getInputProps,
        isFocused,
        isDragActive,
    } = useDropzone({
        accept: {
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx', '.xls']
        }
    });
    useEffect(() => {
        if (acceptedFiles?.length) {
            setFiles(acceptedFiles?.filter((_, i) => i < 1))
        }
        if (fileRejections?.length) {
            toast({
                variant: 'destructive',
                title: "Uh oh! Something went wrong.",
                description: fileRejections?.[0]?.errors?.[0]?.message ?? ''
            })
        }
    }, [acceptedFiles, fileRejections])

    return (
        <div>
            <div {...getRootProps({ className: `${(isDragActive || isFocused) ? 'bg-secondary/80  border-dashed border-blue-400' : 'bg-secondary/40 border-transparent'} border rounded-xl grid place-items-center h-60 w-full cursor-pointer text-center` })}>
                <input
                    {...getInputProps()}
                />
                <div className="text-muted-foreground space-y-2">
                    <p>{placeholder}</p>
                    <p className="text-sm">(Upload the files only with specified template)</p>
                </div>
            </div>
            {
                files.length > 0 && (
                    <ul className='space-y-2 mt-6'>
                        <p className="text-sm text-muted-foreground">Selected File</p>
                        {
                            files.map((file, index) => (
                                <li className="flex items-center text-muted-foreground text-sm justify-between p-1 px-4  rounded-lg bg-secondary/40">
                                    <span>{file.name}</span>
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-7 w-6"
                                        onClick={() => removeFile(index)}
                                    >
                                        <X className="h-4 w-4" />
                                    </Button>
                                </li>
                            ))
                        }
                    </ul>
                )
            }
        </div>
    )
}

export default FileUploader