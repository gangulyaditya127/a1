import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { helpFormSchema } from "../schema/helpFormSchema";
import { z } from 'zod'
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useLazyFetchRequestSingleRowQuery, useLazySubmitRequestQuery } from "../../slice/nextGenAMSAPISlice";
import { useAppSelector } from "@/lib/redux/hooks";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ENGAGEMENT_LIST, NEW_LOGO_LIST, OPPORTUNITY_LIST } from "../data/helpForm";


type HelpFormProps = {
    // rowData?: Partial<z.infer<typeof helpFormSchema>>;
    reqNum?: string;
    onSuccess?: () => void;
};


function HelpForm({ reqNum, onSuccess }: HelpFormProps) {
    const { toast } = useToast()
    const navigate = useNavigate()
    const [submit, submissionResponse] = useLazySubmitRequestQuery()
    const [trigger, response] = useLazyFetchRequestSingleRowQuery();
    const rawUserDetails = useAppSelector((state) => state.auth.rawUserDetails)
    const [requestedRowDetails, setRequestedRowDetails] = useState<Partial<z.infer<typeof helpFormSchema>>>()


    useEffect(() => {
        if (rawUserDetails && reqNum) {
            trigger({
                empid: rawUserDetails.empid,
                isAdmin: 'N',
                req_num: reqNum
            });
        }
    }, [rawUserDetails, reqNum]);



    useEffect(() => {
        if (response?.data) {
            const normalizedData = { ...response.data[0] };
            // Converting from string to number
            [
                'totalInc', 'totalSR', 'totalP1Inc', 'totalP2Inc', 'totalP3Inc', 'totalP4Inc',
                'totalP1SR', 'totalP2SR', 'totalP3SR', 'totalP4SR'
            ].forEach(key => {
                if (normalizedData[key] !== undefined && normalizedData[key] !== null) {
                    normalizedData[key] = Number(normalizedData[key]);
                }
            });
            setRequestedRowDetails(normalizedData);
        }
    }, [response]);


    const form = useForm<z.infer<typeof helpFormSchema>>({
        resolver: zodResolver(helpFormSchema),
        defaultValues: {}
    });

    useEffect(() => {
        if (requestedRowDetails) {
            form.reset({
                ...requestedRowDetails,
                engagement:
                    requestedRowDetails.engagement &&
                        ENGAGEMENT_LIST.some(opt => opt.value === requestedRowDetails.engagement)
                        ? requestedRowDetails.engagement
                        : "Others",
                opportunity:
                    requestedRowDetails.opportunity &&
                        OPPORTUNITY_LIST.some(opt => opt.value === requestedRowDetails.opportunity)
                        ? requestedRowDetails.opportunity
                        : "Others"
            });
        }
    }, [requestedRowDetails, form]);


    function onSubmit(values: z.infer<typeof helpFormSchema>) {
        const payload = {
            empid: rawUserDetails?.empid ?? 0,
            email: rawUserDetails?.email ?? '',
            bu: values.bu,
            isu: values.isu,
            sub_isu: values.sub_isu,
            account: values.account,
            engagement: values.engagement,
            opportunity: values.opportunity,
            amslob: values.amslob || '-',
            teamSize: values.teamSize || '-',
            techStack: values.techStack || '-',
            locations: values.locations || '-',
            totalInc: values.totalInc?.toString() || '0',
            totalSR: values.totalSR?.toString() || '0',
            contract_id: values.contract_id || '-',
            contract_start_date: values.contract_start_date || '-',
            contract_end_date: values.contract_end_date || '-',
            new_logo: values.new_logo || '-',
            totalP1Inc: values.totalP1Inc || 0,
            totalP2Inc: values.totalP2Inc || 0,
            totalP3Inc: values.totalP3Inc || 0,
            totalP4Inc: values.totalP4Inc || 0,
            totalP1SR: values.totalP1SR || 0,
            totalP2SR: values.totalP2SR || 0,
            totalP3SR: values.totalP3SR || 0,
            totalP4SR: values.totalP4SR || 0,
            req_num: reqNum || null
        };
        submit(payload);
    }

    useEffect(() => {
        const { data, error } = submissionResponse
        if (error) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
            return;
        }
        if (data) {
            toast({
                title: "Request Submitted Successfully"
            })
            // if (rowData?.req_num) {
            //     return;
            // }

            if (onSuccess) {
                onSuccess();
            }

            navigate('/help/submission')
        }
    }, [submissionResponse])


    return (
        <Form {...form}>
            <>
                <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-2 gap-6 items-start" noValidate>
                    <FormField
                        control={form.control}
                        name="bu"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className='flex gap-2'>
                                    <span>Business Group (BG)<span className="text-red-500 ml-1">*</span></span>
                                </FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your business group name" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter your business group e.g. BFSI
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="isu"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className='flex gap-2'>
                                    ISU <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your ISU name" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter your ISU
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="sub_isu"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className='flex gap-2'>
                                    Sub ISU <span className="text-red-500">*</span>
                                </FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your Sub ISU name" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter your Sub ISU
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="account"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Account <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your Account Name" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter your account e.g. Citi
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="engagement"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Engagement Type <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox
                                        optionList={ENGAGEMENT_LIST}
                                        field="Engagement Type"
                                        setValue={field.onChange}
                                        value={field.value} // ✅ Controlled by form
                                        placeholder="Select Engagement"
                                        widthClass="w-full"
                                    />
                                </FormControl>
                                <FormDescription>Enter engagement type of your account</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    <FormField
                        control={form.control}
                        name="opportunity"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Opportunity Type <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox
                                        optionList={OPPORTUNITY_LIST}
                                        field="Opportunity Type"
                                        setValue={field.onChange}
                                        value={field.value} // ✅ Controlled by form
                                        placeholder="Select Opportunity"
                                        widthClass="w-full"
                                    />
                                </FormControl>
                                <FormDescription>Enter opportunity type of your account</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="amslob"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>AMS LoB</FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your AMS LoB " {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter AMS LoB e.g. Life Insurance - Sales and Service
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="teamSize"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Team size (if existing)</FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your team size" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter your team size
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="techStack"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Tech Stack (predominant ones)</FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your tech stack" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Enter predominant tech stacks used in your project
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="locations"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Location(s)</FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter your locations" {...field} />
                                </FormControl>
                                <FormDescription>
                                    Select your project location(s)
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    {/* Incident Count */}
                    <FormField
                        control={form.control}
                        name="totalInc"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Incident count</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Incident count " {...field} />
                                </FormControl>
                                <FormDescription>
                                    Total Number of prioritywise incidents per month
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* Newly Added */}
                    <FormField
                        control={form.control}
                        name="totalSR"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Service request count</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Service request count " {...field} />
                                </FormControl>
                                <FormDescription>
                                    Total Number of service requests per month
                                </FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* Contract ID */}
                    <FormField
                        control={form.control}
                        name="contract_id"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Contract ID</FormLabel>
                                <FormControl>
                                    <Input placeholder="Enter Contract ID" {...field} />
                                </FormControl>
                                <FormDescription>Contract ID</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* Contract Start Date */}
                    <FormField
                        control={form.control}
                        name="contract_start_date"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Contract Start Date</FormLabel>
                                <FormControl>
                                    <Input placeholder="DD-MM-YYYY" {...field} />
                                </FormControl>
                                <FormDescription>Contract Start Date</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* Contract End Date */}
                    <FormField
                        control={form.control}
                        name="contract_end_date"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Contract End Date</FormLabel>
                                <FormControl>
                                    <Input placeholder="DD-MM-YYYY" {...field} />
                                </FormControl>
                                <FormDescription>Contract End Date</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* New Logo */}
                    <FormField
                        control={form.control}
                        name="new_logo"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>New Logo</FormLabel>
                                <FormControl>
                                    <SingleSelectCombobox
                                        optionList={NEW_LOGO_LIST}
                                        field="New Logo"
                                        setValue={field.onChange}
                                        value={field.value}
                                        placeholder="Select New Logo"
                                        widthClass="w-full"
                                    />
                                </FormControl>
                                <FormDescription>Is this a new logo engagement?</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P1 Incidents */}
                    <FormField
                        control={form.control}
                        name="totalP1Inc"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P1 Incidents</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P1 incidents" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P1 incidents per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P2 Incidents */}
                    <FormField
                        control={form.control}
                        name="totalP2Inc"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P2 Incidents</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P2 incidents" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P2 incidents per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P3 Incidents */}
                    <FormField
                        control={form.control}
                        name="totalP3Inc"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P3 Incidents</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P3 incidents" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P3 incidents per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P4 Incidents */}
                    <FormField
                        control={form.control}
                        name="totalP4Inc"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P4 Incidents</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P4 incidents" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P4 incidents per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P1 Service Requests */}
                    <FormField
                        control={form.control}
                        name="totalP1SR"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P1 Service Requests</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P1 service requests" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P1 service requests per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P2 Service Requests */}
                    <FormField
                        control={form.control}
                        name="totalP2SR"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P2 Service Requests</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P2 service requests" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P2 service requests per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P3 Service Requests */}
                    <FormField
                        control={form.control}
                        name="totalP3SR"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P3 Service Requests</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P3 service requests" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P3 service requests per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* P4 Service Requests */}
                    <FormField
                        control={form.control}
                        name="totalP4SR"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>P4 Service Requests</FormLabel>
                                <FormControl>
                                    <Input type={"number"} placeholder="Number of P4 service requests" {...field} />
                                </FormControl>
                                <FormDescription>Total Number of P4 service requests per month</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    <div className="col-span-2">
                        <Button
                            type="submit"
                            className="w-full rounded-lg bg-[#2469BC] hover:bg-blue-700 text-white"
                        >
                            Submit
                        </Button>
                    </div>
                </form>

            </>
        </Form>
    )


}

export default HelpForm