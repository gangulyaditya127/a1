import { z } from 'zod';

export const helpFormSchema = z.object({
    bu: z.string().min(1, { message: "Business unit is required" }),
    isu: z.string().min(1, { message: "ISU is required" }),
    sub_isu: z.string().min(1, { message: "Sub ISU is required" }),
    account: z.string().min(1, { message: "Account is required" }),
    engagement: z.string().min(1, { message: "Engagement type is required" }),
    opportunity: z.string().min(1, { message: "Opportunity type is required" }),
    teamSize: z.string().optional(),
    techStack: z.string().optional(),
    locations: z.string().optional(),
    amslob: z.string().optional(),
    totalInc: z.coerce.number().optional(),
    totalSR: z.coerce.number().optional(),

    // Newly added fields
    req_num: z.string().optional(),
    contract_id: z.string().optional(),
    contract_start_date: z.string().optional(),
    contract_end_date: z.string().optional(),
    new_logo: z.string().optional(),

    totalP1Inc: z.coerce.number().optional(),
    totalP2Inc: z.coerce.number().optional(),
    totalP3Inc: z.coerce.number().optional(),
    totalP4Inc: z.coerce.number().optional(),
    totalP1SR: z.coerce.number().optional(),
    totalP2SR: z.coerce.number().optional(),
    totalP3SR: z.coerce.number().optional(),
    totalP4SR: z.coerce.number().optional(),

    // Additional fields from API
    created_at: z.string().optional(),
    id: z.string().optional(),
    state: z.string().optional(),
    created_by: z.string().optional()
});

export const helpFormSchemaMock = z.object({
    businessGroup: z.string().min(1, { message: "Business unit needs to be selected" }),
    isu: z.string().min(1, { message: "ISU needs to be selected" }),
    subIsu: z.string().min(1, { message: "Sub ISU needs to be selected" }),
    account: z.string().min(1, { message: "Account needs to be selected" }),
})