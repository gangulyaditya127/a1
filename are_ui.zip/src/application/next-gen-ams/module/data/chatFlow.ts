export type QuestionType = "single-select" | "multi-select" | "free-text" | "end";

export interface ChatFlowNode {
    message: string;
    type: QuestionType;
    options?: string[];
    next?: string | { [key: string]: string };
}

export interface ChatFlow {
    [key: string]: ChatFlowNode;
}

export const chatFlow: ChatFlow = {
    start: {
        message: "Welcome to the AMS Maturity Assessment Assistant! I’ll guide you through a quick evaluation to understand where your account stands and recommend areas for improvement.",
        type: "single-select",
        options: ["Begin Assessment"],
        next: "it_service_mgmt",
    },
    it_service_mgmt: {
        message: "Do you use any Tool to maintain CMDB?",
        type: "single-select",
        options: ["Yes", "No", "Partial", "NA"],
        next: "observability",
    },
    observability: {
        message: "Do you have mechanism for automatic failovers/recovery?",
        type: "single-select",
        options: ["Yes", "No", "Partial", "NA"],
        next: "ticket_assignment",
    },
    ticket_assignment: {
        message: "Do tickets get auto-assigned to service engineers or is it manual?",
        type: "single-select",
        options: ["Yes", "No", "Partial", "NA"],
        next: "incident_management",
    },
    incident_management: {
        message: "Do you have mechanisms to automatically perform impact assessment?",
        type: "single-select",
        options: ["Yes", "No", "Partial", "NA"],
        next: "service_requests",
    },
    service_requests: {
        message: "Are users provided with chatbots to raise their requests?",
        type: "single-select",
        options: ["Yes", "No", "Partial", "NA"],
        next: "end",
    },
    end: {
        message: "Thank you for completing the assessment. Your responses will help us determine your AMS maturity level.",
        type: "end",
    },
};