import { FormData } from "../../features/DynamicForm";

export const MATURITY_QUES: FormData = {
  "pageData": {
    "Page 1": [
      {
        "title": "Areas of Concern",
        "fields": [
          {
            "id": 1,
            "fieldName": "MTTR high",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 2,
            "fieldName": "SLAs not met",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 3,
            "fieldName": "System Availability",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 4,
            "fieldName": "Costs high",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 5,
            "fieldName": "Lack of Automation",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 6,
            "fieldName": "Other",
            "type": "text",
            "options": "",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Interest Areas of customer",
        "fields": [
          {
            "id": 7,
            "fieldName": "Observability",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 8,
            "fieldName": "SRE",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 9,
            "fieldName": "Business-IT Alignment",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 10,
            "fieldName": "AI Ops",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 11,
            "fieldName": "Explore Gen AI",
            "type": "select",
            "options": "Y,N",
            "hasRemarks": "Y"
          },
          {
            "id": 12,
            "fieldName": "Other",
            "type": "text",
            "options": "",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "List Top 5 Root Causes for Incidents",
        "fields": [
          {
            "id": 13,
            "fieldName": "",
            "type": "top5freetext",
            "options": "",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "List Top 5 activities that are time taking",
        "fields": [
          {
            "id": 14,
            "fieldName": "",
            "type": "top5freetext",
            "options": "",
            "hasRemarks": "N"
          }
        ]
      }
    ],
    "Page 2": [
      {
        "title": "IT Service Mgmt",
        "fields": [
          {
            "id": 15,
            "fieldName": "ITSM Tool",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 16,
            "fieldName": "ITSM Tool Version",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 17,
            "fieldName": "What is Quality of Data entered in ITSM - Ticket desc, Resolution desc, Root cause categorization etc.",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 18,
            "fieldName": "Do you use any Tool to maintain CMDB?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 19,
            "fieldName": "Is your CMDB regularly updated with relationship built between Application and Infra",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Observability",
        "fields": [
          {
            "id": 20,
            "fieldName": "Monitoring Tools for Distributed Systems",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 21,
            "fieldName": "Analytics Tools",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 22,
            "fieldName": "AIOps Tools",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 23,
            "fieldName": "Alert/event corelation mechanism/Noise suppresion ",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 24,
            "fieldName": "User Exp Monitoring Tools",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 25,
            "fieldName": "Business Process Monitoring",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 26,
            "fieldName": "Batch Monitoring/ Scheduling",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "Y"
          },
          {
            "id": 27,
            "fieldName": "How much % of batch jobs are configured for automatic execution through standard schedulers?",
            "type": "textPercent",
            "options": "",
            "hasRemarks": "N"
          },
          {
            "id": 28,
            "fieldName": "Do you have alerting for job delay and failure?. Does it trigger autoticket for such scenarios?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 29,
            "fieldName": "Is batch completion checks performed proactively on the critical path of the batch stream?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 30,
            "fieldName": "Do you have automated File Transfer tracking mechanism?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 31,
            "fieldName": "Do you have mechanism for automatic failovers/recovery",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Ticket Assignment & Acceptance",
        "fields": [
          {
            "id": 32,
            "fieldName": "Do all tickets get logged into ticketing tool? Or do they come in as calls/ emails",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 33,
            "fieldName": "Do tickets get auto assigned to service engineer or is it manual?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 34,
            "fieldName": "Are we meeting SLA in ticket acceptance?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Incident Management",
        "fields": [
          {
            "id": 35,
            "fieldName": "Are we meeting SLAs for ticket resolution?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 36,
            "fieldName": "Do you have mechanisms to automatically perform impact assessment?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 37,
            "fieldName": "During major incidents, do you automatically bring all impacted stakeholders into common collaboration forum?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 38,
            "fieldName": "Do we use tools for analysing logs?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 39,
            "fieldName": "Do we have tools to analyze the ticket and suggest/ recommend solutions?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Service Requests Fulfilment",
        "fields": [
          {
            "id": 40,
            "fieldName": "What % of Service Requests is non-ticketed?",
            "type": "textPercent",
            "options": "",
            "hasRemarks": "N"
          },
          {
            "id": 41,
            "fieldName": "Are users provided with chatbots to raise their requests?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 42,
            "fieldName": "Do users have self help portals?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 43,
            "fieldName": "What % of SRs are handled manually?",
            "type": "textPercent",
            "options": "",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Knowledge Management",
        "fields": [
          {
            "id": 44,
            "fieldName": "Are SOPs, Runbooks maintained?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 45,
            "fieldName": "Do you use tools to search knowledge database and extract required information?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "Metrics & Governance",
        "fields": [
          {
            "id": 46,
            "fieldName": "Do we have a real time view of our SLA compliance for tickets?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 47,
            "fieldName": "Do we have notifications when SLAs are about to be missed?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 48,
            "fieldName": "Do we have automatic reporting of our performance?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 49,
            "fieldName": "If yes to above, are they ITSM tools used OR custom BI solutions adopted?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "People Management",
        "fields": [
          {
            "id": 50,
            "fieldName": "Is attrition a problem in your AMS engagement?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 51,
            "fieldName": "Do you have programs to recognize/ motivate associates in AMS?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 52,
            "fieldName": "Are you interesting in implementing Gamification solution in AMS?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      },
      {
        "title": "DevOps & Others",
        "fields": [
          {
            "id": 53,
            "fieldName": "Do you have mechanism for tracking system performance and transaction volume?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 54,
            "fieldName": "Do you have mechanism to project/predict for system performance and transaction volume?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 55,
            "fieldName": "Do you have mechanism for automated Infra Capacity projections?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 56,
            "fieldName": "Do you leverage any mechanism for automated capacity provisioning?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 57,
            "fieldName": "Do you track security cerfificates  and Licences automatically? (expiry dates/renewal)`",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 58,
            "fieldName": "Do you leverage any tools for code build/testing?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 59,
            "fieldName": "Do you have mechanism for automatic deployment?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 60,
            "fieldName": "Do you have automated mechanism for change review and approval?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          },
          {
            "id": 61,
            "fieldName": "Do you have automated mechanism for Ready to business checks after change?",
            "type": "select",
            "options": "Y,N,Partial,NA",
            "hasRemarks": "N"
          }
        ]
      }
    ]
  }
}