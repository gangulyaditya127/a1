export const BUSINESS_GROUP_LIST = [
    { label: "BFSI", value: "BFSI" },
    { label: "SSG", value: "SSG" },
    { label: "CMI", value: "SMI" },
    { label: "LSHC", value: "LSHC" },
]

export const ISU_LIST = [
    { label: "Banking, Financial Services & Insurance", value: "BFSI" },
    { label: "Retail & Consumer Goods", value: "Retail" },
    { label: "Telecom, Media & Information Services", value: "TMIS" },
    { label: "Manufacturing", value: "Manufacturing" },
    { label: "Life Sciences & Healthcare", value: "LSHC" },
    { label: "Energy, Resources & Utilities", value: "ERU" },
    { label: "Public Services", value: "PublicServices" },
];

export const SUB_ISU_LIST = [
    { label: "Insurance", value: "Insurance" },
    { label: "Retail Banking", value: "RetailBanking" },
    { label: "Pharmaceuticals", value: "Pharmaceuticals" },
    { label: "Healthcare Providers", value: "HealthcareProviders" },
    { label: "Telecom Operators", value: "TelecomOperators" },
    { label: "Consumer Packaged Goods", value: "ConsumerPackagedGoods" },
    { label: "Utilities", value: "Utilities" },
];

export const ACCOUNT_LIST = [
    { label: "Citi", value: "Citi" },
    { label: "Walmart", value: "Walmart" },
    { label: "Vodafone", value: "Vodafone" },
    { label: "Pfizer", value: "Pfizer" },
    { label: "Unilever", value: "Unilever" },
    { label: "Shell", value: "Shell" },
    { label: "NHS UK", value: "NHS_UK" },
];

export const NEW_LOGO_LIST = [
    { label: "Yes", value: 'Yes' },
    { label: "No", value: 'No' },
]


export const OPPORTUNITY_LIST = [
    { label: "New Oppurtunity", value: 'New Oppurtunity' },
    { label: "Existing Opportunity", value: 'Existing Opportunity' },
    { label: "Renewal", value: 'Renewal' },
    { label: "Others", value: 'Others' },
]

export const ENGAGEMENT_LIST = [
    { label: "Fixed Price", value: 'Fixed Price' },
    { label: "Time and Material", value: 'Time and Material' },
    { label: "Others", value: 'Others' },
]