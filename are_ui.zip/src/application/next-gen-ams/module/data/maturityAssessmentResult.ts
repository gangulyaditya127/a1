export const ASSESSMENT_RESULT = [
    {
        kpi: "IT Service Mgmt",
        score: 7.2,
        standard: 8.1,
        gap: 0.9,
        tools: [
            { name: "Data Quality Agent", link: '/doc/data-quality' }
        ]
    },
    {
        kpi: "Observability",
        score: 5.1,
        standard: 9.0,
        gap: 3.9,
        tools: [
            { name: "Observability dashboard", link: '/doc/observability-dashboard' },
        ]
    },
    {
        kpi: "Ticket Assignment and Acceptance",
        score: 6.4,
        standard: 7.8,
        gap: 1.4,
        tools: [
            { name: "Ticket Assignment Agent​​", link: '/doc/ticket-assign' },
            { name: "Intelligent SLA management​", link: '/doc/isla' },
        ]
    },
    {
        kpi: "Incident Management",
        score: 4.9,
        standard: 8.5,
        gap: 3.6,
        tools: [
            { name: "Intelligent Major Incident Briefing Paper", link: '/doc/imbp' },
            { name: "Root Cause Analysis Agent", link: '/doc/rca' },
            { name: "Ticket Log Collection Agent​", link: '/doc/ticket-log-collection' },
        ]
    },
    {
        kpi: "Service Request Fulfillment",
        score: 6.8,
        standard: 7.9,
        gap: 1.1,
        tools: [
            { name: "Change Density Calculator", link: '/agentic-are/change-density-calculator' },
            { name: "Service Managenement/L1 Dashbaord", link: 'doc/l1-dashboard' },
        ]
    },
    {
        kpi: "Knowledge Management",
        score: 5.3,
        standard: 9.2,
        gap: 3.9,
        tools: [
            { name: "Knowledge Assistant", link: '/agentic-are/knowledge-assistant' },
            { name: "Runbook Creator", link: '/agentic-are/runbook-creator' },
        ]
    },
    {
        kpi: "Metrics & Governance",
        score: 6.1,
        standard: 7.4,
        gap: 1.3,
        tools: [
            { name: "SLAMonitor", link: '/agentic-are/slamonitor' }
        ]
    },
    {
        kpi: "People Management",
        score: 4.8,
        standard: 8.3,
        gap: 3.5,
        tools: [
            { name: "Gamification", link: '/doc/gamification' }
        ]
    },
    {
        kpi: "DevOps & Others",
        score: 6.2,
        standard: 7.6,
        gap: 1.4,
        tools: [
            { name: "Containerized Code Analyzer - KubeDiagnostix", link: "/agentic-are/containerized-code-analyzer-kubediagnostix" },
            { name: "Inefficient Query/Code Analyzer", link: "/agentic-are/inefficient-query-code-analyzer" },

        ]
    }
];
