import { Outlet } from "react-router-dom";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
export default function HelpLayout() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(
            updateSideBarNavigation({
                hasSideBar: false,
                sideBarNavList: [],
                bottomNavList: [],
            }),
        );
        dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
    }, []);
    return (
        <div className="grid min-h-screen mt-16">
            <Outlet />
            {/* <Footer/> //grid-rows-[1fr_50px]*/}
        </div>
    );
}