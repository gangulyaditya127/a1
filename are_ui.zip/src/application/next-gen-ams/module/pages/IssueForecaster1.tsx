import React, { useEffect, useRef, useState } from "react";

type LLMResponse = {
  issue_summary?: string;
  risk_level?: string;
  reasoning?: string;
  recommended_actions?: string[] | string;
};

type ForecasterResponse = {
  total_logs?: number;
  error_count?: number;
  error_threshold?: number;
  status?: "normal" | "alert" | string;
  forecast_triggered?: boolean;
  llm_response?: LLMResponse | null;
};

const DEFAULT_API = import.meta.env.VITE_ISSUE_FORECASTER_API ?? "http://localhost:8080/issue-forecaster";

const humanDate = (iso?: string | Date) => {
  if (!iso) return "-";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleString();
};

const Badge: React.FC<{ children?: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold ${className}`}>{children}</span>
);

export const IssueForecaster: React.FC = () => {
  const [data, setData] = useState<ForecasterResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [intervalMs, setIntervalMs] = useState<number>(120000); // default 2 minutes
  const [autoPoll, setAutoPoll] = useState<boolean>(true);

  const timerRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const API_URL = DEFAULT_API;

  //const toApiFormat = (d: Date) => d.toISOString().split('.')[0]; // -> "YYYY-MM-DDTHH:MM:SS"
  const toApiFormat = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, "0");
    const Y = d.getFullYear();
    const M = pad(d.getMonth() + 1);
    const D = pad(d.getDate());
    const h = pad(d.getHours());
    const m = pad(d.getMinutes());
    const s = pad(d.getSeconds());
    return `${Y}-${M}-${D}T${h}:${m}:${s}`;
  };

  const fetchData = async (from?: string, to?: string) => {
    setIsLoading(true);
    setError(null);
    // cancel previous request (if any)
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    // optional params: if you want later, you can add start/end
    //const params = new URLSearchParams();
    // If you want to pass defaults from UI, add params here (start, end)

    const now = new Date();
    const defaultTo = toApiFormat(now);
    const defaultFrom = toApiFormat(new Date(now.getTime() - intervalMs));

    const startParam = from ?? defaultFrom;
    const endParam = to ?? defaultTo;

    const params = new URLSearchParams();
    params.append('start', startParam);
    params.append('end', endParam);



    const url = `${API_URL}?${params.toString()}`;

    try {
      const res = await fetch(url, { signal: ac.signal });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} ${text}`);
      }
      const payload = (await res.json()) as ForecasterResponse;
      setData(payload);
      setLastUpdated(new Date());
    } catch (e: any) {
      if (e?.name === "AbortError") {
        // aborted: ignore
      } else {
        console.error("IssueForecaster fetch error:", e);
        setError(String(e?.message ?? e));
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Start / restart polling
  const startPolling = () => {
    // clear existing
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    // immediate fetch
    fetchData();

    if (autoPoll) {
      // use window.setInterval returns number
      timerRef.current = window.setInterval(() => {
        fetchData();
      }, intervalMs) as unknown as number;
    }
  };

  const stopPolling = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    abortRef.current?.abort();
  };

  // start once when mounted
  useEffect(() => {
    startPolling();
    return () => {
      stopPolling();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, autoPoll]);

  // Derived UI helpers
  const isAlert = Boolean(data?.forecast_triggered) || data?.status === "alert";
  const total = data?.total_logs ?? 0;
  const errors = data?.error_count ?? 0;
  const threshold = data?.error_threshold ?? 0;
  const pct = threshold > 0 ? Math.min(100, Math.round((errors / threshold) * 100)) : Math.min(100, Math.round((errors / Math.max(1, total || 1)) * 100));

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      {/* Header */}
      <header className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Issue Forecaster</h1>
          <p className="text-sm text-slate-500">Automatic forecasting & reasoning for potential outages — updates every {Math.round(intervalMs / 1000)}s</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-sm text-slate-600">Auto Poll</label>
            <input type="checkbox" checked={autoPoll} onChange={(e) => setAutoPoll(e.target.checked)} className="h-4 w-4" />
          </div>

          <select
            value={String(intervalMs)}
            onChange={(e) => setIntervalMs(Number(e.target.value))}
            className="px-3 py-1 border rounded"
            title="Polling interval"
          >
            <option value={30000}>30s</option>
            <option value={60000}>60s</option>
            <option value={120000}>120s</option>
            <option value={300000}>5m</option>
          </select>

          <button
            onClick={() => fetchData()}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-4 py-2 rounded bg-slate-800 text-white hover:opacity-90 disabled:opacity-60"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" strokeOpacity="0.2" />
                  <path d="M22 12a10 10 0 00-10-10" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
                Refreshing...
              </>
            ) : (
              "Refresh"
            )}
          </button>
        </div>
      </header>

      {/* Main cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Status card */}
        <div className={`p-4 rounded-xl shadow ${isAlert ? "bg-gradient-to-br from-red-50 to-red-100 border border-red-200" : "bg-white border"}`}>
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className={`text-lg font-semibold ${isAlert ? "text-red-700" : "text-slate-800"}`}>Current Status</h2>
              <p className="text-sm text-slate-500 mt-1">{isAlert ? "Outage detected" : "Normal"}</p>
            </div>
            <div>
              {isAlert ? (
                <Badge className="bg-red-600 text-white">ALERT</Badge>
              ) : (
                <Badge className="bg-emerald-100 text-emerald-800">OK</Badge>
              )}
            </div>
          </div>

          <div className="mt-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-500">Total Logs</div>
                <div className="text-xl font-bold">{total}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Errors</div>
                <div className="text-xl font-bold text-red-600">{errors}</div>
              </div>
            </div>

            <div className="mt-4">
              <div className="text-xs text-slate-500 mb-1">Threshold</div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div
                  className={`h-3 ${isAlert ? "bg-red-500" : "bg-emerald-500"}`}
                  style={{ width: `${Math.min(100, threshold > 0 ? (errors / Math.max(1, threshold)) * 100 : pct)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                <div>Threshold: {threshold}</div>
                <div>{Math.round(pct)}%</div>
              </div>
            </div>
          </div>

          <div className="mt-4 text-xs text-slate-500">
            <div>Last updated: {lastUpdated ? humanDate(lastUpdated) : "Never"}</div>
            {error && <div className="text-rose-600 mt-2">Error: {error}</div>}
          </div>
        </div>

        {/* Forecast / LLM card */}
        <div className={`col-span-1 md:col-span-2 p-4 rounded-xl shadow ${isAlert ? "border border-red-200 bg-red-50" : "bg-white border"}`}>
          <div className="flex items-center justify-between">
            <h2 className={`text-lg font-semibold ${isAlert ? "text-red-700" : "text-slate-800"}`}>Issue Forecast & Reasoning</h2>
            <div className="text-sm text-slate-500">Forecast Used: {data?.forecast_triggered ? "Yes" : "No"}</div>
          </div>

          {!data ? (
            <div className="mt-6 text-sm text-slate-500">No data yet. Waiting for first poll...</div>
          ) : !data?.forecast_triggered ? (
            <div className="mt-6 text-sm text-slate-600">No outage predicted for the selected window.</div>
          ) : (
            <div className="mt-4 space-y-4">
              {/* Summary */}
              <div>
                <div className="text-xs text-slate-500">Summary</div>
                <div className="mt-1 text-base font-medium text-slate-800">{data.llm_response?.issue_summary ?? "—"}</div>
              </div>

              {/* Risk & reasoning */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 rounded bg-white border">
                  <div className="text-xs text-slate-500">Risk Level</div>
                  <div className="mt-1 font-semibold">{data.llm_response?.risk_level ?? "Unknown"}</div>
                </div>
                <div className="p-3 rounded bg-white border md:col-span-2">
                  <div className="text-xs text-slate-500">Reasoning</div>
                  <div className="mt-1 text-sm text-slate-700 whitespace-pre-wrap">{data.llm_response?.reasoning ?? "—"}</div>
                </div>
              </div>

              {/* Actions */}
              <div>
                <div className="text-xs text-slate-500">Recommended Actions</div>
                <div className="mt-2 space-y-2">
                  {Array.isArray(data.llm_response?.recommended_actions)
                    ? (data.llm_response!.recommended_actions as string[]).map((a, i) => (
                        <div key={i} className="p-3 bg-white border rounded text-sm">
                          <div className="font-medium">#{i + 1}</div>
                          <div className="mt-1 text-slate-700">{a}</div>
                        </div>
                      ))
                    : data.llm_response?.recommended_actions ? (
                        <div className="p-3 bg-white border rounded text-sm">{String(data.llm_response.recommended_actions)}</div>
                      ) : (
                        <div className="text-sm text-slate-500">No actions recommended.</div>
                      )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Timeline / small history + raw payload */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border shadow col-span-1">
          <h3 className="font-semibold mb-2 text-sm">Recent Snapshot</h3>
          <div className="text-sm text-slate-600">
            <div>
              <span className="font-medium">Status:</span> {data?.status ?? "–"}
            </div>
            <div>
              <span className="font-medium">Forecast Used:</span> {String(data?.forecast_triggered ?? false)}
            </div>
            <div>
              <span className="font-medium">Total Logs:</span> {total}
            </div>
            <div>
              <span className="font-medium">Error Count:</span> {errors}
            </div>
            <div>
              <span className="font-medium">Threshold:</span> {threshold}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border shadow col-span-2 overflow-auto">
          <h3 className="font-semibold mb-3 text-sm">Raw Payload</h3>
          <pre className="text-xs max-h-48 overflow-auto bg-slate-50 p-3 rounded">{JSON.stringify(data ?? {}, null, 2)}</pre>
        </div>
      </div>

      {/* Footer / hints */}
      <footer className="text-xs text-slate-500">
        <div>
          Tip: use the Auto Poll toggle to enable periodic checks. Ensure the API server allows CORS from your frontend origin.
        </div>
      </footer>
    </div>
  );
};

export default IssueForecaster;
