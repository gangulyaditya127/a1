import Container from '@/components/ui/container'
import { NavigateBackButton } from '@/components/ui/navigate-back-button'
import { MaturityAssessmentRadar } from '../feature/MaturityAssessmentRadar'
// import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { ASSESSMENT_RESULT } from '../data/maturityAssessmentResult'
import MaturityAssessmentResultCard from '../feature/MaturityAssessmentResultCard'

const HelpResultMock = () => {
    const calculateAverageScore = () => {
        const totalScore = ASSESSMENT_RESULT.reduce((sum, item) => sum + item.score, 0);
        const average = totalScore / ASSESSMENT_RESULT.length;
        return average.toFixed(2);
    };

    const avgScore = calculateAverageScore();

    return (
        <Container className="mt-4 mb-12 max-w-7xl mx-auto px-6">
            {/* Back Button */}
            <NavigateBackButton />

            {/* Summary Header */}
            <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">
                Application Maturity Assessment
            </h2>
            <h3 className="mb-6 text-sm text-muted-foreground">
                Comprehensive evaluation of your application across key pillars
            </h3>

            <div className="grid gap-6 grid-cols-5 relative">
                {/* Sticky Radar */}
                <div className="sticky top-16 col-span-2 h-screen">
                    <div className="border rounded-xl">
                        <div className="grid grid-cols-2 gap-12 border-b justify-between items-center bg-secondary/20 rounded-xl mb-8">
                            <div className="py-8 px-4">
                                <h3 className="text-xs uppercase tracking-wider text-muted-foreground">
                                    Overall Maturity Score
                                </h3>
                                <div className="flex items-baseline gap-1">
                                    <p className="text-2xl font-bold text-primary leading-none">{avgScore}</p>
                                    <span className="text-sm text-muted-foreground leading-none">/10</span>
                                </div>
                            </div>  
                            <div className=" text-white h-full rounded-xl py-8 px-4 grid">
                                <div className="">
                                    <p className='text-xs uppercase tracking-wider text-muted-foreground'>Maturity Level</p>
                                    <p className='text-2xl font-medium'>Intermediate</p>
                                </div>
                            </div>
                        </div>
                        <MaturityAssessmentRadar />
                    </div>
                </div>

                <div className="col-span-3">

                    <div className="grid grid-cols-2 gap-6 " id='result-cards'>
                        {ASSESSMENT_RESULT.map((result, index) => (
                            <MaturityAssessmentResultCard key={index} result={result} id={`card-${result.kpi}`} />
                        ))}
                    </div>
                </div>


            </div>
        </Container>
    );
};

export default HelpResultMock;