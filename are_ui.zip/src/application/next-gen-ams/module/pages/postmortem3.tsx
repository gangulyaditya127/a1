import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import Container from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import ChatBox, { Message } from "@/application/next-gen-ams/module/feature/ChatBox"; // Assuming ChatBox is reusable
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import Loader from "@/components/ui/loader";
import { useFetchPostmortemInitMutation, useSubmitPostmortemConversationMutation } from "../../slice/nextGenAMSAPISlice"; // New hooks to be added
import { toast } from "@/components/ui/use-toast";

type IncidentData = Record<string, any> | null;

const Postmortem = () => {
  const { reqId: routeReqId } = useParams<{ reqId?: string }>(); // Optional if routed
  const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009";

  // Session state
  const [reqId, setReqId] = useState<string>(routeReqId || "");
  const [incidentInitiated, setIncidentInitiated] = useState<boolean>(false);
  const [incidentNo, setIncidentNo] = useState<string>("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLast, setIsLast] = useState<boolean>(false);
  const [postmortemReport, setPostmortemReport] = useState<any>(null);
  const [incidentData, setIncidentData] = useState<IncidentData>(null);
  const [apiDebug, setApiDebug] = useState<any>(null);

  // RTK Query hooks (to be added to nextGenAMSAPISlice.ts)
//   const [triggerInit, { data: initData, isLoading: initLoading, error: initError }] = useLazyFetchPostmortemInitQuery();
//   const [submitConv, { data: convData, isLoading: convLoading, error: convError }] = useSubmitPostmortemConversationMutation();

  const [triggerInit, { data: initData, isLoading: initLoading, error: initError }] = useFetchPostmortemInitMutation();  // ← Changed

  const [submitConv, { data: convData, isLoading: convLoading, error: convError }] = useSubmitPostmortemConversationMutation();

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, convLoading]);

  // Handle init response
  useEffect(() => {
    if (initData) {
      setReqId(initData.req_id || reqId);
      setIncidentInitiated(true);
      setIsLast(Boolean(initData.isLast));
      setIncidentData(initData.incident ?? null);
      const formatted = formatIncident(initData.incident ?? null);
      setMessages([
        { text: formatted, isBot: true, showOptions: false }, // System as bot for simplicity
        { text: initData.question ?? "", isBot: true, showOptions: false }
      ]);
      setApiDebug({ init: initData });
    }
    if (initError) {
      toast({
        variant: "destructive",
        title: "Init Error",
        description: initError?.data?.detail || "Failed to start session",
      });
    }
  }, [initData, initError]);

  // Handle conversation response
  useEffect(() => {
    if (convData) {
      setIsLast(Boolean(convData.isLast));
      setMessages((prev) => [
        ...prev,
        { text: convData.question ?? "", isBot: true, showOptions: false } // Add options if needed
      ]);
      if (convData.isLast && convData.postmortem) setPostmortemReport(convData.postmortem);
      setApiDebug((prev) => ({ ...prev, conv: convData }));
    }
    if (convError) {
      setMessages((prev) => [
        ...prev,
        { text: `Error: ${convError?.data?.detail || "Conversation failed"}`, isBot: true }
      ]);
      toast({
        variant: "destructive",
        title: "Conversation Error",
        description: "Failed to send answer",
      });
    }
  }, [convData, convError]);

  function formatIncident(incident: IncidentData) {
    if (!incident) return "No incident details found.";
    const lines: string[] = [];
    lines.push(`Ticket Number: ${incident.ticket_number ?? ""}`);
    lines.push(`Short Description: ${incident.short_desc ?? ""}`);
    const description: string = incident.description ?? "";
    let dateStr = "";
    if (description.includes("occurred on")) {
      try {
        const parts = description.split("occurred on ");
        if (parts.length > 1) dateStr = parts[1].split(",")[0];
      } catch (e) {}
    }
    lines.push(`Date: ${dateStr}`);
    lines.push(`Config Item: ${incident.config_item ?? ""}`);
    lines.push("Timeline / Journal:");
    const journal = Array.isArray(incident.journal) ? incident.journal : [];
    journal.forEach((entry: any) => {
      const when = entry.sys_created_on ?? "";
      const val = (entry.value ?? "").replace(/\r\n/g, " ");
      lines.push(`- ${when}: ${val}`);
    });
    return lines.join("\n");
  }

  function startSession() {
    if (!incidentNo.trim()) {
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please enter a valid Incident Number.",
      });
      return;
    }
    const newReqId = routeReqId || (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
    setReqId(newReqId);
    triggerInit({ req_id: newReqId, incident_no: incidentNo.trim() });
  }

  function sendAnswer(answer: string) {
    if (!reqId || !answer.trim()) return;
    setMessages((prev) => [...prev, { text: answer, isBot: false }]);
    submitConv({ req_id: reqId, answer, incident: incidentData });
  }

  function restartSession() {
    setReqId(routeReqId || "");
    setIncidentInitiated(false);
    setIncidentNo("");
    setMessages([]);
    setIsLast(false);
    setPostmortemReport(null);
    setIncidentData(null);
    setApiDebug(null);
  }

  if (initLoading) {
    return <Loader />;
  }

  return (
    <Container className="gap-12 pb-12 mt-8">
      <NavigateBackButton />
      <div className="flex gap-2 items-center mb-5">
        <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">
          AI Postmortem Conversation Bot
        </h2>
      </div>
      <Container className="grid grid-cols-3 gap-5 md:pl-0">
        {/* Session Controls (Left Column) */}
        <Card className="rounded-xl w-full h-fit border-none p-0">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Postmortem Session</h3>
            {!incidentInitiated ? (
              <div className="space-y-3">
                <label className="block text-sm font-medium">Incident Number</label>
                <input
                  className="w-full rounded-md border px-3 py-2"
                  value={incidentNo}
                  onChange={(e) => setIncidentNo(e.target.value)}
                  placeholder="Enter Incident Number"
                  disabled={initLoading}
                />
                <button
                  className="w-full rounded-md bg-blue-600 text-white py-2 disabled:opacity-60"
                  onClick={startSession}
                  disabled={initLoading}
                >
                  {initLoading ? "Starting..." : "Start Session"}
                </button>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <div className="text-muted-foreground">Incident Number:</div>
                <div className="font-medium">{incidentNo}</div>
                <div className="text-muted-foreground mt-2">Session ID:</div>
                <div className="font-mono text-xs">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>
                <button
                  className="mt-4 w-full rounded-md bg-amber-500 text-white py-2"
                  onClick={() => navigator.clipboard?.writeText(reqId)}
                >
                  Copy Session ID
                </button>
                <button
                  className="mt-2 w-full rounded-md bg-red-500 text-white py-2"
                  onClick={restartSession}
                >
                  Restart
                </button>
              </div>
            )}
            {apiDebug && (
              <div className="mt-6 border-t pt-3 text-xs text-muted-foreground">
                <div className="font-semibold">API Debug</div>
                <pre className="max-h-48 overflow-auto text-xs bg-muted p-2 rounded mt-2">
                  {JSON.stringify(apiDebug, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Chat Area (Right Columns) */}
        <div className="flex col-span-2 flex-col h-[500px]">
          {!incidentInitiated ? (
            <Card className="rounded-xl p-6">
              <p className="text-center text-muted-foreground">
                Start a new session from the sidebar by entering an Incident Number.
              </p>
            </Card>
          ) : (
            <>
              <ChatBox
                prevMessage={messages}
                onSendAnswer={sendAnswer} // Custom prop for handling answers
                isLoading={convLoading}
                isLast={isLast}
                postmortemReport={postmortemReport}
              />
            </>
          )}
        </div>
      </Container>
    </Container>
  );
};

export default Postmortem;