import Container from "@/components/ui/container";
import { Link } from "react-router-dom";
import { Icon } from "@/components/ui/icon";
import { useAppSelector } from "@/lib/redux/hooks";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import HelpForm from "../feature/HelpForm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ExcelUpload from "../feature/ExcelUpload";


export default function HelpNeeded() {
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails)
    return (
        <Container className="grid grid-cols-3 gap-16 pb-12 mt-8">
            <div className="col-span-2">
                <NavigateBackButton />
                <h1 className="text-4xl font-tcs-title mb-6">Reach out to us with your request</h1>
                <Tabs defaultValue="automated" className="w-full">
                    <TabsList className="grid grid-cols-2 w-[400px]">
                        <TabsTrigger value="manual">Manual</TabsTrigger>
                        <TabsTrigger value="automated">Automated</TabsTrigger>
                    </TabsList>
                    <TabsContent value="manual" className="mt-6">
                        <HelpForm />
                    </TabsContent>
                    <TabsContent value="automated" className="mt-6">
                        <ExcelUpload />
                    </TabsContent>
                </Tabs>

            </div>
            <div className="space-y-4 mt-8">
                <Link
                    to='submission'
                    className="bg-secondary/20 p-4 border  w-full flex gap-4 items-center rounded-lg text-sm"
                >
                    <div className="grid size-10 place-items-center rounded-lg bg-gradient-to-br from-blue-700 to-blue-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-blue-600 dark:to-blue-400">
                        <Icon name="lightbulb" className="size-5 fill-white text-white/80" />
                    </div>
                    <p>
                        Recent Submissions
                    </p>
                </Link>
                {/* Just for demo purpose only Link Tag*/}
                {/* <Link
                    to='mock'
                    className="bg-secondary/20 p-4 border  w-full flex gap-4 items-center rounded-lg text-sm"
                >
                    <div className="grid size-10 place-items-center rounded-lg bg-gradient-to-br from-blue-700 to-blue-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-blue-600 dark:to-blue-400">
                        <Icon name="lightbulb" className="size-5 fill-white text-white/80" />
                    </div>
                    <p>
                        Mock
                    </p>
                </Link> */}
                {userDetails?.isAdmin == 'Y' && <Link
                    to='/help/admin'
                    className="bg-secondary/20 p-4 border  w-full flex gap-4 items-center rounded-lg text-sm"
                >
                    <div className="grid size-10 place-items-center rounded-lg bg-gradient-to-br from-blue-700 to-blue-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-blue-600 dark:to-blue-400">
                        <Icon name="lock-keyhole" className="size-5 text-white/80" />
                    </div>
                    <p>
                        Admin Dashboard
                    </p>
                </Link>}
            </div>
        </Container>
    )
}