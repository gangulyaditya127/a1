// Postmortem.tsx
import React, { useEffect, useRef, useState } from "react"; // React + hooks
import { useParams } from "react-router-dom"; // optionally read reqId from route
import Container from "@/components/ui/container"; // layout wrapper
import { Card, CardContent } from "@/components/ui/card"; // card components
import ChatBox, { Message } from "@/application/next-gen-ams/module/feature/ChatBox"; // ChatBox component
import { NavigateBackButton } from "@/components/ui/navigate-back-button"; // back button component
import Loader from "@/components/ui/loader"; // loader spinner
import { useFetchPostmortemInitMutation, useSubmitPostmortemConversationMutation } from "../../slice/nextGenAMSAPISlice"; // RTK hooks
import { toast } from "@/components/ui/use-toast"; // toast notifications
import { Input } from "@/components/ui/input";

// Incident data flexible typing
type IncidentData = Record<string, any> | null;

// Component
const Postmortem: React.FC = () => {
  const { reqId: routeReqId } = useParams<{ reqId?: string }>(); // optional route reqId
  const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"; // base URL (unused directly)

  // Parent-owned UI/session state
  const [reqId, setReqId] = useState<string>(routeReqId || ""); // session id
  const [incidentInitiated, setIncidentInitiated] = useState<boolean>(false); // session started flag
  const [incidentNo, setIncidentNo] = useState<string>(""); // user-entered incident number
  const [messages, setMessages] = useState<Message[]>([]); // canonical message list (parent owns)
  const [isLast, setIsLast] = useState<boolean>(false); // conversation completion flag
  const [postmortemReport, setPostmortemReport] = useState<any>(null); // final report data
  const [incidentData, setIncidentData] = useState<IncidentData>(null); // structured incident payload
  const [apiDebug, setApiDebug] = useState<any>(null); // debug info container

  // parent scroll anchor (optional)
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // RTK mutation hooks: initialize session and submit conversation
  const [triggerInit, { data: initData, isLoading: initLoading, error: initError }] =
    useFetchPostmortemInitMutation();

  const [submitConv, { data: convData, isLoading: convLoading, error: convError }] =
    useSubmitPostmortemConversationMutation();

  // parent scrolling on messages/convLoading change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, convLoading]);

  // When initData arrives from server, create structured messages: incident object + first question
  useEffect(() => {
    if (initData) {
      setReqId(initData.req_id || reqId); // adopt req id if server returned one
      setIncidentInitiated(true); // mark session started
      setIsLast(Boolean(initData.isLast)); // set isLast
      setIncidentData(initData.incident ?? null); // store incident

      // Instead of a formatted string, push a structured incident message object so ChatBox can render it nicely
      setMessages([
        { text: "", isBot: true, showOptions: false, isIncident: true, incident: initData.incident ?? null }, // structured incident message
        { text: initData.question ?? "", isBot: true, showOptions: Boolean(initData.isoptions), options: initData.listOfOptions ?? [] } // server question
      ]);

      setApiDebug({ init: initData }); // keep debug info for display
    }

    if (initError) {
      toast({
        variant: "destructive",
        title: "Init Error",
        description: (initError as any)?.data?.detail || "Failed to start session",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initData, initError]);

  // When conversation responses arrive, append next bot prompt and capture final report if present
  useEffect(() => {
    if (convData) {
      setIsLast(Boolean(convData.isLast)); // update final flag

      // Append next question/prompt from server
      setMessages((prev) => [
        ...prev,
        { text: convData.question ?? "", isBot: true, showOptions: Boolean(convData.isoptions), options: convData.listOfOptions ?? [], isLast: convData.isLast }
      ]);

      // If conversation completed and server returned postmortem data, store it
      if (convData.isLast && convData.postmortem) setPostmortemReport(convData.postmortem);

      setApiDebug((prev) => ({ ...prev, conv: convData })); // update debug object
    }

    if (convError) {
      setMessages((prev) => [
        ...prev,
        { text: `Error: ${(convError as any)?.data?.detail || "Conversation failed"}`, isBot: true }
      ]);
      toast({
        variant: "destructive",
        title: "Conversation Error",
        description: "Failed to send answer",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [convData, convError]);

  // Helper: start session by calling triggerInit with req_id and incident_no
  function startSession() {
    if (!incidentNo.trim()) {
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please enter a valid Incident Number.",
      });
      return;
    }

    const newReqId = routeReqId || (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
    setReqId(newReqId);
    triggerInit({ req_id: newReqId, incident_no: incidentNo.trim() });
  }

  // sendAnswer is called by ChatBox when a user replies; parent appends the user's message and calls submitConv
  function sendAnswer(answer: string) {
    if (!reqId || !answer.trim()) return;

    setMessages((prev) => [...prev, { text: answer.trim(), isBot: false }]); // append user message
    submitConv({ req_id: reqId, answer: answer.trim(), incident: incidentData }); // submit to backend
  }

  // restart reset parent state
  function restartSession() {
    setReqId(routeReqId || "");
    setIncidentInitiated(false);
    setIncidentNo("");
    setMessages([]);
    setIsLast(false);
    setPostmortemReport(null);
    setIncidentData(null);
    setApiDebug(null);
  }

  // loader while initializing
  if (initLoading) {
    return <Loader />;
  }

  // Render
  return (
    <Container className="gap-12 pb-12 mt-8">
      <NavigateBackButton />
      <div className="flex gap-2 items-center mb-5">
        <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">AI Postmortem Conversation Bot</h2>
      </div>

      {/* Grid: left controls, right chat (stable height) */}
      <Container className="grid grid-cols-3 gap-5 md:pl-0">
        {/* Left controls */}
        <Card className="rounded-xl w-full h-fit border-none p-0">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Postmortem Session</h3>

            {!incidentInitiated ? (
              <div className="space-y-3">
                <label className="block text-sm font-medium">Incident Number</label>
                {/* <input
                  className="w-full rounded-md border px-3 py-2"
                  value={incidentNo}
                  onChange={(e) => setIncidentNo(e.target.value)}
                  placeholder="Enter Incident Number"
                  disabled={initLoading}
                /> */}
                <Input
                value={incidentNo}
                  onChange={(e) => setIncidentNo(e.target.value)}
                  placeholder="Enter Incident Number"
                  disabled={initLoading}
                />
                <button
                  className="w-full rounded-md bg-blue-600 text-white py-2 disabled:opacity-60"
                  onClick={startSession}
                  disabled={initLoading}
                >
                  {initLoading ? "Starting..." : "Start Session"}
                </button>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <div className="text-muted-foreground">Incident Number:</div>
                <div className="font-medium">{incidentNo}</div>
                <div className="text-muted-foreground mt-2">Session ID:</div>
                <div className="font-mono text-xs">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>
                <button className="mt-4 w-full rounded-md bg-amber-500 text-white py-2" onClick={() => navigator.clipboard?.writeText(reqId)}>Copy Session ID</button>
                <button className="mt-2 w-full rounded-md bg-red-500 text-white py-2" onClick={restartSession}>Restart</button>
              </div>
            )}

            {/* debug area */}
            {apiDebug && (
              <div className="mt-6 border-t pt-3 text-xs text-muted-foreground">
                <div className="font-semibold">API Debug</div>
                <pre className="max-h-48 overflow-auto text-xs bg-muted p-2 rounded mt-2">{JSON.stringify(apiDebug, null, 2)}</pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right chat column - keep stable height so footer doesn't collapse messages area */}
        <div className="flex col-span-2 flex-col h-[640px]">
          {!incidentInitiated ? (
            <Card className="rounded-xl p-6 h-full">
              <p className="text-center text-muted-foreground">Start a new session from the sidebar by entering an Incident Number.</p>
            </Card>
          ) : (
            <ChatBox
              prevMessage={messages} // parent-owned messages
              onSendAnswer={sendAnswer} // callback to submit answers
              isLoading={convLoading} // pass conversation loading state
              isLast={isLast} // pass finish flag
              postmortemReport={postmortemReport} // final report data
              reqId={reqId} // pass reqId for fallback usage
            />
          )}
        </div>
      </Container>

      <div ref={chatEndRef} />
    </Container>
  );
};

export default Postmortem;
