import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Container from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ASSESSMENT_RESULT } from "../data/maturityAssessmentResult";
import { useLazyFetchMaturityAssessmentDataQuery, useSubmitKPIMockMutation } from "../../slice/nextGenAMSAPISlice";
import { toast } from "@/components/ui/use-toast";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import Loader from "@/components/ui/loader";

const HelpSelectKPI = () => {
    const { reqId } = useParams<{ reqId: string }>();

    const [kpiRatings, setKpiRatings] = useState<Record<string, number>>({});
    const [submit, submissionResponse] = useSubmitKPIMockMutation();
    const [trigger, { data: response, isLoading }] = useLazyFetchMaturityAssessmentDataQuery();
    const navigate = useNavigate();

    const [parsedKPIs, setParsedKPIs] = useState<Record<string, number>>({});

    useEffect(() => {
        if (reqId) {
            trigger({ reqId });
        }
    }, [reqId, trigger]);

    useEffect(() => {
        if (response?.STRUGGLING_KPIS && response.STRUGGLING_KPIS.length > 0) {
            try {
                // navigate(`/help/mock/chat/${response.REQ_ID}`)
                const parsed = JSON.parse(response.STRUGGLING_KPIS);
                setParsedKPIs(parsed);
            } catch (error) {
                console.error("Error parsing KPIs:", error);
                setParsedKPIs({});
            }
        }
    }, [response]);

    useEffect(() => {
        if (Object.keys(parsedKPIs).length > 0) {
            setKpiRatings(parsedKPIs);
        }
    }, [parsedKPIs]);

    const handleSliderChange = (kpi: string, value: number[]) => {
        setKpiRatings(prev => ({ ...prev, [kpi]: value[0] }));
    };

    const handleSubmit = () => {
        const filteredRatings = Object.fromEntries(
            Object.entries(kpiRatings).filter(([_, value]) => value > 0)
        );

        submit({
            requestId: reqId,
            kpis: filteredRatings
        });
    };

    useEffect(() => {
        const { data, error } = submissionResponse;
        if (error) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to submit request",
            });
            return;
        }
        if (data) {
            toast({ title: "KPI Submitted Successfully" });
            navigate(`/help/mock/chat/${reqId}`);
        }
    }, [submissionResponse]);

    if (isLoading) {
        return <Loader />;
    }

    return (
        <Container className="gap-12 pb-12 mt-8">
            <NavigateBackButton />
            <h2 className="text-4xl font-tcs-title">Select KPI Importance</h2>
            <p className="text-muted-foreground mb-6">Rate the importance of each KPI for this assessment (Req ID: {reqId})</p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {ASSESSMENT_RESULT.map(item => (
                    <Card key={item.kpi} className="rounded-xl border shadow-sm hover:shadow-md transition">
                        <CardContent className="p-6 flex flex-col justify-between gap-2">
                            <h3 className="text-lg font-semibold mb-2">{item.kpi}</h3>

                            <Slider
                                value={[kpiRatings[item.kpi] ?? parsedKPIs[item.kpi] ?? 0]}
                                max={5}
                                step={1}
                                onValueChange={(value) => handleSliderChange(item.kpi, value)}
                                className="mb-2 cursor-pointer"
                            />

                            <div className="flex justify-between text-xs text-gray-500 mt-1">
                                {[0, 1, 2, 3, 4, 5].map(num => (<span key={num}>{num}</span>))}
                            </div>

                            <p className="text-sm text-muted-foreground">Importance: <span className="font-medium">{kpiRatings[item.kpi] ?? parsedKPIs[item.kpi] ?? 0}</span> / 5</p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="mt-8 flex justify-end">
                <Button size="lg" onClick={handleSubmit}>Submit</Button>
            </div>
        </Container>
    );
};

export default HelpSelectKPI;