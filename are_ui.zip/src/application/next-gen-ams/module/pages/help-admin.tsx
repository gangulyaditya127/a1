import {
    useEffect,
    useMemo,
    useState,
} from "react";
import Container from "@/components/ui/container";
import { CustomCellRendererProps } from "ag-grid-react";

import {
    ColDef,
    SizeColumnsToContentStrategy,
    SizeColumnsToFitGridStrategy,
    SizeColumnsToFitProvidedWidthStrategy,
} from "ag-grid-community";

import { useAppSelector } from "@/lib/redux/hooks";
import { useLazyFetchRequestListQuery } from "../../slice/nextGenAMSAPISlice";
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";

import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import EditStatus from "../feature/EditStatus";
import { Icon } from "@/components/ui/icon";
import DataGrid from "@/components/ui/data-grid";

export type HelpSubmissions = {
    req_num: string;
    engagement: string;
    sub_isu: string;
    opportunity: string;
    created_at: string;
    isu: string;
    created_by: string;
    bu: string;
    techStack: string;
    teamSize: string;
    locations: string;
    id: string;
    state: string;
    account: string;
}

const HelpAdmin = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const [trigger, response] = useLazyFetchRequestListQuery()
    const [rowData, setRowData] = useState<HelpSubmissions[]>([]);
    const [columnDefs] = useState<ColDef[]>([
        // { field: "req_num", headerName: 'Req No.', filter: 'agTextColumnFilter' },
        { headerName: 'Req No.', pinned: 'left', cellRenderer: MaturityGrid, width: 20, suppressSizeToFit: true },
        { field: "created_by", headerName: 'Initiated By', filter: 'agTextColumnFilter' },
        { field: "account", headerName: 'Account', filter: 'agTextColumnFilter' },
        { field: "state", headerName: 'Current Status', filter: 'agTextColumnFilter' },
        { field: "opportunity", filter: 'agTextColumnFilter' },
        { field: "engagement", filter: 'agTextColumnFilter' },
        { field: "sub_isu", headerName: 'Sub ISU', filter: 'agTextColumnFilter' },
        { field: "isu", headerName: 'ISU', filter: 'agTextColumnFilter' },
        { field: "bu", headerName: 'BU', filter: 'agTextColumnFilter' },
        { field: "techStack", headerName: 'Tech Stack', filter: 'agTextColumnFilter' },
        { field: "teamSize", headerName: 'Team Size', filter: 'agTextColumnFilter' },
        { field: "created_at", headerName: 'Created At', filter: 'agTextColumnFilter' },
        { headerName: 'Edit', pinned: 'right', cellRenderer: EditGrid, width: 20, suppressSizeToFit: true }
    ]);

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);

    useEffect(() => {
        if (userDetails) {
            trigger({
                empid: userDetails.empid,
                isAdmin: userDetails.isAdmin
            })
        }
    }, [userDetails])

    useEffect(() => {
        if (response?.data) {
            setRowData((response.data as HelpSubmissions[]))
        }
    }, [response])
    const autoSizeStrategy = useMemo<
        | SizeColumnsToFitGridStrategy
        | SizeColumnsToFitProvidedWidthStrategy
        | SizeColumnsToContentStrategy
    >(() => {
        return {
            type: "fitCellContents",
            defaultMinWidth: 100,
        };
    }, []);

    return <Container>
        <Link to='/help' className="text-xs text-muted-foreground flex items-center gap-1 my-4">
            <Icon name="move-left" className="size-4" />
            <span>Go Back</span>
        </Link>
        <Breadcrumb>
            <BreadcrumbList>
                <BreadcrumbItem>
                    <Link to="/">ARE</Link>
                </BreadcrumbItem>
                <BreadcrumbSeparator>
                    <SlashIcon />
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                    <BreadcrumbPage>Help Submission</BreadcrumbPage>
                </BreadcrumbItem>
            </BreadcrumbList>
        </Breadcrumb>
        <div className="mt-4">
            <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">Help Requests</h2>
            <div className="h-[400px]">
                <div
                    style={gridStyle}
                >
                    <DataGrid
                        autoSizeStrategy={autoSizeStrategy}
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={defaultColDef}
                        masterDetail={true}
                    />
                </div>
            </div>
        </div>
    </Container>
}
const EditGrid = ({ data }: CustomCellRendererProps) => {
    return (
        <EditStatus
            req_num={data.req_num}
            created_at={data.created_by}
            account={data.account}
            created_by={data.created_by}
            state={data.state}
        />
    )
}
const MaturityGrid = ({ data }: CustomCellRendererProps) => {
    if (data.state === 'New Request' || data.state === 'Briefing Complete') {
        return <p className="text-sm w-full h-full grid place-items-center">{data.req_num}</p>;
    }
    return (
        <Link to={`maturity-assesment/${data.req_num}`} className="text-sm w-full h-full hover:underline grid place-items-center">{data.req_num}</Link>
    )
}
export default HelpAdmin;