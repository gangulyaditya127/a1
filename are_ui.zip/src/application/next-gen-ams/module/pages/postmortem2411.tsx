// Postmortem.tsx
import React, { useEffect, useRef, useState } from "react"; // React + hooks
import { useParams } from "react-router-dom"; // optional URL params
import Container from "@/components/ui/container"; // layout container
import { Card, CardContent } from "@/components/ui/card"; // UI card components
import ChatBox, { Message } from "@/application/next-gen-ams/module/feature/ChatBox"; // stateless ChatBox component
import { NavigateBackButton } from "@/components/ui/navigate-back-button"; // back navigation button
import Loader from "@/components/ui/loader"; // spinner/loader component
import { useFetchPostmortemInitMutation, useSubmitPostmortemConversationMutation } from "../../slice/nextGenAMSAPISlice"; // RTK hooks (ensure names match your slice)
import { toast } from "@/components/ui/use-toast"; // toast notifications

// Incident data typing (flexible)
type IncidentData = Record<string, any> | null;

// main component
const Postmortem: React.FC = () => {
  const { reqId: routeReqId } = useParams<{ reqId?: string }>(); // read optional reqId from route
  const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009"; // base API URL (unused directly here)

  // -----------------------
  // Parent-owned state
  // -----------------------
  const [reqId, setReqId] = useState<string>(routeReqId || ""); // session id
  const [incidentInitiated, setIncidentInitiated] = useState<boolean>(false); // started flag
  const [incidentNo, setIncidentNo] = useState<string>(""); // input incident number
  const [messages, setMessages] = useState<Message[]>([]); // canonical message list stored here
  const [isLast, setIsLast] = useState<boolean>(false); // conversation completion flag
  const [postmortemReport, setPostmortemReport] = useState<any>(null); // final report data (object/string)
  const [incidentData, setIncidentData] = useState<IncidentData>(null); // structured incident info
  const [apiDebug, setApiDebug] = useState<any>(null); // debug info for display

  // a parent-owned scroll anchor if needed (kept for parity)
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // -----------------------
  // RTK Query / Mutation hooks
  // -----------------------
  const [triggerInit, { data: initData, isLoading: initLoading, error: initError }] =
    useFetchPostmortemInitMutation(); // mutation to initialize session

  const [submitConv, { data: convData, isLoading: convLoading, error: convError }] =
    useSubmitPostmortemConversationMutation(); // mutation to submit user's answer

  // ensure scroll to bottom when messages or convLoading changes (optional)
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); // scroll anchor into view
  }, [messages, convLoading]);

  // -----------------------
  // Handle init response
  // -----------------------
  useEffect(() => {
    if (initData) { // when server returns init data
      setReqId(initData.req_id || reqId); // adopt server-provided req id if present
      setIncidentInitiated(true); // mark session started
      setIsLast(Boolean(initData.isLast)); // reflect completion flag
      setIncidentData(initData.incident ?? null); // store incident object

      // format incident as readable multi-line text
      const formatted = formatIncident(initData.incident ?? null);

      // parent-owned canonical messages: incident details + initial question from server
      setMessages([
        { text: formatted, isBot: true, showOptions: false }, // system/bot incident details
        { text: initData.question ?? "", isBot: true, showOptions: Boolean(initData.isoptions), options: initData.listOfOptions ?? [] } // first question
      ]);

      setApiDebug({ init: initData }); // save debug info to display in UI
    }

    if (initError) { // notify user on init failure
      toast({
        variant: "destructive",
        title: "Init Error",
        description: (initError as any)?.data?.detail || "Failed to start session",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initData, initError]);

  // -----------------------
  // Handle conversation response (server's follow-ups)
  // -----------------------
  useEffect(() => {
    if (convData) { // when server responds with next question or postmortem
      setIsLast(Boolean(convData.isLast)); // update complete flag

      // append next bot prompt to canonical message list
      setMessages((prev) => [
        ...prev,
        { text: convData.question ?? "", isBot: true, showOptions: Boolean(convData.isoptions), options: convData.listOfOptions ?? [], isLast: convData.isLast }
      ]);

      // when conversation finished and server returned a postmortem, store it
      if (convData.isLast && convData.postmortem) setPostmortemReport(convData.postmortem);

      // update debug info for UI inspection
      setApiDebug((prev) => ({ ...prev, conv: convData }));
    }

    if (convError) { // handle conv errors
      setMessages((prev) => [
        ...prev,
        { text: `Error: ${(convError as any)?.data?.detail || "Conversation failed"}`, isBot: true }
      ]);
      toast({
        variant: "destructive",
        title: "Conversation Error",
        description: "Failed to send answer",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [convData, convError]);

  // -----------------------
  // Utility: formatIncident (best-effort pretty string)
  // -----------------------
  function formatIncident(incident: IncidentData) {
    if (!incident) return "No incident details found."; // guard

    const lines: string[] = []; // store lines to join later
    lines.push(`Ticket Number: ${incident.ticket_number ?? ""}`); // add ticket
    lines.push(`Short Description: ${incident.short_desc ?? ""}`); // add short desc

    // attempt to extract a date from description via regex
    const description: string = incident.description ?? "";
    let dateStr = "";
    try {
      const match = description.match(/occurred on\s*([A-Za-z0-9\-/ :,.]+)/i);
      if (match && match[1]) dateStr = match[1].split(",")[0];
    } catch (e) {
      // ignore parse errors
    }
    lines.push(`Date: ${dateStr}`); // add date line
    lines.push(`Config Item: ${incident.config_item ?? ""}`); // add config item
    lines.push("Timeline / Journal:"); // add header for timeline

    // iterate over journal entries if present
    const journal = Array.isArray(incident.journal) ? incident.journal : [];
    journal.forEach((entry: any) => {
      const when = entry.sys_created_on ?? ""; // timestamp
      const val = (entry.value ?? "").replace(/\r\n/g, " "); // flatten newlines
      lines.push(`- ${when}: ${val}`); // add each journal entry as a line
    });

    return lines.join("\n"); // join lines with newline for display
  }

  // -----------------------
  // Actions: startSession, sendAnswer, restartSession
  // -----------------------
  function startSession() {
    if (!incidentNo.trim()) { // validate incident number
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please enter a valid Incident Number.",
      });
      return;
    }

    // generate a request id if not coming from route or server
    const newReqId = routeReqId || (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
    setReqId(newReqId); // set local state
    triggerInit({ req_id: newReqId, incident_no: incidentNo.trim() }); // call backend to init session
  }

  function sendAnswer(answer: string) {
    if (!reqId || !answer.trim()) return; // guard: need reqId and non-empty answer

    // append user's message to canonical messages immediately for responsive UI
    setMessages((prev) => [...prev, { text: answer.trim(), isBot: false }]);

    // submit conversation turn to backend; backend should return next question via convData
    submitConv({ req_id: reqId, answer: answer.trim(), incident: incidentData });
  }

  function restartSession() {
    setReqId(routeReqId || ""); // reset reqId to route or empty
    setIncidentInitiated(false); // mark not initiated
    setIncidentNo(""); // clear input
    setMessages([]); // clear messages
    setIsLast(false); // reset completion flag
    setPostmortemReport(null); // clear report data
    setIncidentData(null); // clear incident object
    setApiDebug(null); // clear debug view
  }

  // show a loader while initial start is in progress
  if (initLoading) {
    return <Loader />;
  }

  // -----------------------
  // Render: NOTE layout sizes chosen to prevent chat shrink
  // -----------------------
  return (
    <Container className="gap-12 pb-12 mt-8"> {/* outer layout container */}
      <NavigateBackButton /> {/* back navigation */}
      <div className="flex gap-2 items-center mb-5">
        <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">
          AI Postmortem Conversation Bot
        </h2>
      </div>

      {/* Grid: left column controls (1/3), right columns chat (2/3) */}
      <Container className="grid grid-cols-3 gap-5 md:pl-0">
        {/* Left: controls */}
        <Card className="rounded-xl w-full h-fit border-none p-0">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Postmortem Session</h3>

            {!incidentInitiated ? (
              <div className="space-y-3">
                <label className="block text-sm font-medium">Incident Number</label>
                <input
                  className="w-full rounded-md border px-3 py-2"
                  value={incidentNo} // two-way bind input
                  onChange={(e) => setIncidentNo(e.target.value)} // update state
                  placeholder="Enter Incident Number"
                  disabled={initLoading} // disable when starting
                />
                <button
                  className="w-full rounded-md bg-blue-600 text-white py-2 disabled:opacity-60"
                  onClick={startSession} // start click handler
                  disabled={initLoading}
                >
                  {initLoading ? "Starting..." : "Start Session"} {/* show state */}
                </button>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <div className="text-muted-foreground">Incident Number:</div>
                <div className="font-medium">{incidentNo}</div>

                <div className="text-muted-foreground mt-2">Session ID:</div>
                <div className="font-mono text-xs">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>

                <button
                  className="mt-4 w-full rounded-md bg-amber-500 text-white py-2"
                  onClick={() => navigator.clipboard?.writeText(reqId)} // copy id
                >
                  Copy Session ID
                </button>

                <button
                  className="mt-2 w-full rounded-md bg-red-500 text-white py-2"
                  onClick={restartSession} // restart session
                >
                  Restart
                </button>
              </div>
            )}

            {/* API debug area - optional */}
            {apiDebug && (
              <div className="mt-6 border-t pt-3 text-xs text-muted-foreground">
                <div className="font-semibold">API Debug</div>
                <pre className="max-h-48 overflow-auto text-xs bg-muted p-2 rounded mt-2">
                  {JSON.stringify(apiDebug, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: Chat area - make this column a stable height so it doesn't shrink */}
        <div className="flex col-span-2 flex-col h-[640px]"> {/* fixed height container to avoid shrink */} 
          {!incidentInitiated ? (
            <Card className="rounded-xl p-6 h-full"> {/* full height placeholder */}
              <p className="text-center text-muted-foreground">
                Start a new session from the sidebar by entering an Incident Number.
              </p>
            </Card>
          ) : (
            <>
              {/* ChatBox receives messages and remains layout-stable */}
              <ChatBox
                prevMessage={messages} // parent-owned messages
                onSendAnswer={sendAnswer} // callback to handle answer
                isLoading={convLoading} // pass loading state
                isLast={isLast} // pass finished flag
                postmortemReport={postmortemReport} // final report
                reqId={reqId} // pass reqId for fallback
              />
            </>
          )}
        </div>
      </Container>

      {/* optional scroll anchor used by parent */}
      <div ref={chatEndRef} />
    </Container>
  );
};

export default Postmortem; // export default
