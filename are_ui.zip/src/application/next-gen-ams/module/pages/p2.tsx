import React, { useEffect, useRef, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

// shadcn/ui components (assumed available in the project)
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
//import { Separator } from "@/components/ui/separator";

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------

type Message = {
  id: string;
  sender: "user" | "bot" | "system";
  text: string;
  ts?: string;
};

type Incident = {
  ticket_number?: string;
  short_desc?: string;
  description?: string;
  config_item?: string;
  journal?: Array<{ sys_created_on?: string; value?: string }>;
  [k: string]: any;
};

// ------------------------------------------------------------------
// Utilities: localStorage hook
// ------------------------------------------------------------------

function useLocalStorage<T>(key: string, initialValue: T) {
  const [state, setState] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initialValue;
    } catch (e) {
      console.warn("useLocalStorage parse error", e);
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (e) {
      console.warn("useLocalStorage set error", e);
    }
  }, [key, state]);

  return [state, setState] as const;
}

// ------------------------------------------------------------------
// Format incident (same logic as Streamlit)
// ------------------------------------------------------------------

const formatIncident = (incident?: Incident) => {
  if (!incident) return "No incident details found.";
  const lines: string[] = [];
  lines.push(`**Ticket Number:** ${incident.ticket_number ?? ""}`);
  lines.push(`**Short Description:** ${incident.short_desc ?? ""}`);
  const description = incident.description ?? "";
  let dateStr = "";
  if (description.includes("occurred on")) {
    const parts = description.split("occurred on ");
    if (parts.length > 1) dateStr = parts[1].split(",")[0];
  }
  lines.push(`**Date:** ${dateStr}`);
  lines.push(`**Config Item:** ${incident.config_item ?? ""}`);
  lines.push(`**Timeline / Journal:**`);
  const journal = Array.isArray(incident.journal) ? incident.journal : [];
  journal.forEach((entry) => {
    const when = entry.sys_created_on ?? "";
    const val = (entry.value ?? "").replace(/\\r\\n/g, " ").replace(/\\n/g, " ");
    lines.push(`- ${when}: ${val}`);
  });
  return lines.join("\n");
};

// ------------------------------------------------------------------
// ChatMessage component (small, reusable)
// ------------------------------------------------------------------

const ChatMessage: React.FC<{ message: Message }> = ({ message }) => {
  const base = "p-3 rounded-lg max-w-[80%] whitespace-pre-wrap";
  if (message.sender === "system") {
    return (
      <div className="bg-gray-50 text-sm text-gray-800 p-3 rounded-md shadow-sm">
        {message.text.split("\n").map((ln, i) => (
          <div key={i} className="mb-1">
            {ln.startsWith("**") ? (
              <span dangerouslySetInnerHTML={{ __html: ln.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") }} />
            ) : (
              <span>{ln}</span>
            )}
          </div>
        ))}
      </div>
    );
  }
  if (message.sender === "bot") {
    return (
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -6 }}
        className={`self-start bg-white border border-gray-200 ${base}`}
      >
        {message.text}
      </motion.div>
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 6 }}
      className={`self-end bg-primary text-white ${base}`}
    >
      {message.text}
    </motion.div>
  );
};

// ------------------------------------------------------------------
// Main Component: PostmortemChat
// ------------------------------------------------------------------

const API_URL = process.env.REACT_APP_POSTMORTEM_API ?? "http://localhost:8009";

const PostmortemChat: React.FC = () => {
  const navigate = useNavigate();

  // Persisted session-like state
  const [reqId, setReqId] = useLocalStorage<string | null>("pm:reqId", null);
  const [incidentInitiated, setIncidentInitiated] = useLocalStorage<boolean>("pm:initiated", false);
  const [incidentNo, setIncidentNo] = useLocalStorage<string | null>("pm:incidentNo", null);
  const [messages, setMessages] = useLocalStorage<Message[]>("pm:messages", []);
  const [lastQuestion, setLastQuestion] = useLocalStorage<string | null>("pm:lastQuestion", "");
  const [isLast, setIsLast] = useLocalStorage<boolean>("pm:isLast", false);
  const [postmortemReport, setPostmortemReport] = useLocalStorage<any | null>("pm:report", null);
  const [incidentData, setIncidentData] = useLocalStorage<Incident | null>("pm:incident", null);

  // ephemeral UI state
  const [incidentInput, setIncidentInput] = useState<string>(incidentNo ?? "");
  const [answerInput, setAnswerInput] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // auto-scroll when messages update
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  // Start session -> POST /postmortem/init
  const startSession = async () => {
    setError(null);
    if (!incidentInput.trim()) return setError("Please enter a valid Incident Number.");
    const generatedReqId = uuidv4();
    setLoading(true);
    try {
      const resp = await fetch(`${API_URL}/postmortem/init`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ req_id: generatedReqId, incident_no: incidentInput.trim() }),
      });
      const data = await resp.json();
      if (resp.ok) {
        setReqId(generatedReqId);
        setIncidentNo(incidentInput.trim());
        setIncidentInitiated(true);
        setIsLast(Boolean(data?.isLast));
        setLastQuestion(data?.question ?? "");
        setIncidentData(data?.incident ?? null);
        const formatted = formatIncident(data?.incident);
        const initialMessages: Message[] = [
          { id: uuidv4(), sender: "system", text: formatted },
          { id: uuidv4(), sender: "bot", text: data?.question ?? "" },
        ];
        setMessages(initialMessages);
        // push route for deep-linking (optional)
        navigate(`/postmortem/${generatedReqId}`, { replace: true });
      } else {
        setError(data?.detail ?? `Init Error: ${resp.statusText}`);
      }
    } catch (e: any) {
      setError(`Failed to connect to API: ${String(e?.message ?? e)}`);
    } finally {
      setLoading(false);
    }
  };

  // Send answer -> POST /postmortem/conversation
  const sendAnswer = async (answer: string) => {
    if (!answer.trim() || !reqId) return;
    setError(null);
    setLoading(true);
    const userMsg: Message = { id: uuidv4(), sender: "user", text: answer, ts: new Date().toISOString() };
    setMessages((m) => [...m, userMsg]);

    try {
      const payload = { req_id: reqId, answer: answer, incident: incidentData };
      const resp = await fetch(`${API_URL}/postmortem/conversation`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await resp.json();
      console.debug("API response:", data);
      if (resp.ok && data && typeof data === "object" && "question" in data) {
        const botMsg: Message = { id: uuidv4(), sender: "bot", text: data?.question ?? "", ts: new Date().toISOString() };
        setMessages((m) => [...m, botMsg]);
        setIsLast(Boolean(data?.isLast));
        setLastQuestion(data?.question ?? "");
        if (Boolean(data?.isLast) && "postmortem" in data) setPostmortemReport(data.postmortem);
      } else {
        const detail = data?.detail ?? resp.statusText;
        const errMsg: Message = { id: uuidv4(), sender: "bot", text: `Error: ${detail}` };
        setMessages((m) => [...m, errMsg]);
      }
    } catch (e: any) {
      const errMsg: Message = { id: uuidv4(), sender: "bot", text: `Failed to connect to API: ${String(e?.message ?? e)}` };
      setMessages((m) => [...m, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const answer = answerInput.trim();
    if (!answer) return;
    setAnswerInput("");
    await sendAnswer(answer);
  };

  const restartSession = () => {
    setReqId(null);
    setIncidentInitiated(false);
    setIncidentNo(null);
    setMessages([]);
    setLastQuestion("");
    setIsLast(false);
    setPostmortemReport(null);
    setIncidentData(null);
    setIncidentInput("");
    setAnswerInput("");
    navigate(`/postmortem`, { replace: true });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-[320px_1fr] gap-6">
        {/* Sidebar */}
        <Card>
          <CardContent>
            <h3 className="text-lg font-semibold mb-3">Postmortem Session</h3>

            {!incidentInitiated ? (
              <div className="space-y-3">
                <Label>Incident Number</Label>
                <Input value={incidentInput} onChange={(e) => setIncidentInput(e.target.value)} placeholder="Enter Incident Number" />
                <div className="flex gap-2">
                  <Button onClick={startSession} disabled={loading}>
                    {loading ? "Starting..." : "Start Session"}
                  </Button>
                </div>
                {error && <div className="text-sm text-red-600">{error}</div>}
                <p className="text-xs text-muted-foreground mt-2">This creates a session and fetches the first bot question.</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-sm text-muted-foreground">Incident Number</div>
                <div className="font-medium">{incidentNo}</div>
                <div className="text-sm text-muted-foreground mt-2">Session ID</div>
                <div className="font-mono text-sm">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>
                <div className="pt-3">
                  <Button variant="destructive" onClick={restartSession} disabled={loading}>
                    Restart
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main area */}
        <div className="flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold">🕵️‍♂️ AI Postmortem Conversation Bot</h2>
            <div className="text-sm text-muted-foreground">Connected: <span className="font-mono">{API_URL}</span></div>
          </div>

          {!incidentInitiated ? (
            <Card>
              <CardContent>
                <div className="text-center text-muted-foreground">Start a new session from the sidebar by entering an Incident Number.</div>
              </CardContent>
            </Card>
          ) : (
            <div className="flex flex-col h-[70vh]">
              <Card className="flex-1 overflow-hidden">
                <CardContent className="p-0 h-full flex flex-col">
                  <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-gray-100 to-white">
                    <AnimatePresence initial={false} mode="popLayout">
                      {messages.map((msg) => (
                        <motion.div key={msg.id} layout>
                          <div className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}> 
                            <ChatMessage message={msg} />
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  <div className="p-4 border-t">
                    {isLast ? (
                      <div className="space-y-3">
                        <div className="text-green-700 font-medium">Postmortem Conversation Complete!</div>
                        {postmortemReport ? (
                          <pre className="text-sm bg-gray-50 p-3 rounded overflow-auto">{JSON.stringify(postmortemReport, null, 2)}</pre>
                        ) : (
                          <div className="text-sm text-muted-foreground">No postmortem report returned.</div>
                        )}
                      </div>
                    ) : (
                      <form onSubmit={handleSubmit} className="flex gap-3 items-end">
                        <div className="flex-1">
                          <Label>Answer the bot</Label>
                          <Textarea value={answerInput} onChange={(e) => setAnswerInput(e.target.value)} placeholder="Your answer (press Ctrl+Enter to send)" rows={3} />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Button type="submit" disabled={loading || !answerInput.trim()}>
                            {loading ? "Sending..." : "Send"}
                          </Button>
                        </div>
                      </form>
                    )}
                  </div>
                </CardContent>
              </Card>

              <div className="mt-3 text-xs text-muted-foreground">
                <Separator />
                <div className="pt-2">*This UI connects to the same FastAPI endpoints used by your Streamlit app.</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PostmortemChat;
