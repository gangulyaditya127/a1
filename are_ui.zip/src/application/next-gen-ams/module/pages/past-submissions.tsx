import {
    useEffect,
    useMemo,
    useState,
} from "react";
import { CustomCellRendererProps } from 'ag-grid-react';
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { EditIcon, SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import {
    ColDef,
    ICellRendererParams,
    SizeColumnsToContentStrategy,
    SizeColumnsToFitGridStrategy,
    SizeColumnsToFitProvidedWidthStrategy,
} from "ag-grid-community";
import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { useAppSelector } from "@/lib/redux/hooks";
import { useLazyFetchRequestListQuery } from "../../slice/nextGenAMSAPISlice";
import DataGrid from "@/components/ui/data-grid";
import DialogEditForm from "../feature/DialogEditForm";
import { Tooltip } from "@/components/ui/tooltip";

export type HelpSubmissions = {
    req_num: string;
    engagement: string;
    sub_isu: string;
    opportunity: string;
    created_at: string;
    isu: string;
    created_by: string;
    bu: string;
    techStack: string;
    teamSize: string;
    locations: string;
    id: string;
    state: string;
    account: string;
};

const PastSubmissions = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const [trigger, response] = useLazyFetchRequestListQuery();
    const [rowData, setRowData] = useState<HelpSubmissions[]>([]);
    const [openEditForm, setOpenEditForm] = useState(false);
    const [selectedRow, setSelectedRow] = useState<HelpSubmissions | null>(null);

    const handleEditClick = (row: HelpSubmissions) => {
        setSelectedRow(row);
        setOpenEditForm(true);
    };

    const columnDefs: ColDef[] = [
        { field: "req_num", headerName: 'Req No.', filter: 'agTextColumnFilter' },
        { field: "created_by", headerName: 'Initiated By', filter: 'agTextColumnFilter' },
        { field: "account", headerName: 'Account', filter: 'agTextColumnFilter' },
        { field: "state", headerName: 'Current Status', filter: 'agTextColumnFilter' },
        { field: "opportunity", filter: 'agTextColumnFilter' },
        { field: "engagement", filter: 'agTextColumnFilter' },
        { field: "sub_isu", headerName: 'Sub ISU', filter: 'agTextColumnFilter' },
        { field: "isu", headerName: 'ISU', filter: 'agTextColumnFilter' },
        { field: "bu", headerName: 'BU', filter: 'agTextColumnFilter' },
        // { field: "techStack", headerName: 'Tech Stack', filter: 'agTextColumnFilter' },
        // { field: "teamSize", headerName: 'Team Size', filter: 'agTextColumnFilter' },
        { field: "created_at", headerName: 'Created At', filter: 'agTextColumnFilter' },

        {
            headerName: 'Maturity Assessment',
            pinned: 'right',
            cellRenderer: (params: ICellRendererParams) => (
                <EditGrid {...params} onEditClick={() => handleEditClick(params.data)} />
            ),
            width: 120,
            suppressSizeToFit: true
        }
    ];

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);


    const refreshGrid = () => {
        if (userDetails) {
            trigger({ empid: userDetails.empid, isAdmin: 'N' });
        }
    };


    useEffect(() => {
        if (userDetails) {
            trigger({
                empid: userDetails.empid,
                isAdmin: 'N'
            });
        }
    }, [userDetails]);

    useEffect(() => {
        if (response?.data) {
            setRowData(response.data as HelpSubmissions[]);
        }
    }, [response]);

    const autoSizeStrategy = useMemo<
        | SizeColumnsToFitGridStrategy
        | SizeColumnsToFitProvidedWidthStrategy
        | SizeColumnsToContentStrategy
    >(() => {
        return {
            type: "fitCellContents",
            defaultMinWidth: 100,
        };
    }, []);

    return (
        <section>
            <Container className="mt-4">
                <Link to="/help" className="text-xs py-2 flex gap-1 text-muted-foreground hover:text-foreground">
                    <Icon name="move-left" className="size-4" />
                    <span>Go Back</span>
                </Link>
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/">ARE</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Help Submission</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <div className="mt-4">
                    <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
                        Your Help Requests
                    </h2>
                    <div className="h-[400px]">
                        <div style={gridStyle}>
                            <DataGrid
                                autoSizeStrategy={autoSizeStrategy}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                masterDetail={true}
                            />
                        </div>
                    </div>
                </div>
            </Container>

            {/* Dialog for Edit Form */}
            <DialogEditForm
                open={openEditForm}
                setOpen={setOpenEditForm}
                onSuccess={() => {
                    setOpenEditForm(false);
                    refreshGrid();
                }}
                selectedRow={selectedRow} />
        </section>
    );
};

type EditGridProps = CustomCellRendererProps & {
    onEditClick: () => void;
};

const EditGrid = ({ data, onEditClick }: EditGridProps) => {
    if (data.state === 'New Request' || data.state === 'Briefing Complete') {
        return null;
    }
    return (
        <div className="flex gap-2 items-center h-full">
            <Link
                to={`/help/maturity-assesment/${data.req_num}`}
                className="text-sm w-16 h-8 hover:underline flex items-center justify-center"
            >
                [Ques]
            </Link>

            <Link
                to={`/help/maturity-result/${data.req_num}`}
                className="text-sm w-16 h-8 hover:underline flex items-center justify-center"
            >
                [Res]
            </Link>

            <button
                title="Edit Row"
                onClick={onEditClick}
                className="flex items-center justify-center cursor-pointer hover:underline"
            >
                <EditIcon className="w-4 h-4" />
            </button>
        </div>
    );
};

export default PastSubmissions;