import React, { useEffect, useRef, useState } from "react";

// Single-file React + Tailwind TSX component that replicates the Streamlit UI/behavior
// - Sidebar: start session with Incident Number -> calls POST /postmortem/init
// - Main: conversation view with System (incident summary), bot messages, user messages
// - Chat input: send answers to POST /postmortem/conversation
// - Shows thinking/loading states, API debug response, and final postmortem JSON
// - Restart button to clear session

type Message = {
  sender: "user" | "bot" | "system";
  text: string;
};

type IncidentData = Record<string, any> | null;

export default function PostmortemBot() {
  const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009";

  // Session-state equivalents
  const [reqId, setReqId] = useState<string>("");
  const [incidentInitiated, setIncidentInitiated] = useState<boolean>(false);
  const [incidentNo, setIncidentNo] = useState<string>("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [lastQuestion, setLastQuestion] = useState<string>("");
  const [isLast, setIsLast] = useState<boolean>(false);
  const [postmortemReport, setPostmortemReport] = useState<any>(null);
  const [incidentData, setIncidentData] = useState<IncidentData>(null);

  // UI state
  const [initLoading, setInitLoading] = useState<boolean>(false);
  const [convLoading, setConvLoading] = useState<boolean>(false);
  const [apiDebug, setApiDebug] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, convLoading]);

  function formatIncident(incident: IncidentData) {
    if (!incident) return "No incident details found.";

    const lines: string[] = [];
    lines.push(`Ticket Number: ${incident.ticket_number ?? ""}`);
    lines.push(`Short Description: ${incident.short_desc ?? ""}`);

    const description: string = incident.description ?? "";
    let dateStr = "";
    if (description.includes("occurred on")) {
      try {
        const parts = description.split("occurred on ");
        if (parts.length > 1) dateStr = parts[1].split(",")[0];
      } catch (e) {
        // ignore
      }
    }
    lines.push(`Date: ${dateStr}`);
    lines.push(`Config Item: ${incident.config_item ?? ""}`);
    lines.push("Timeline / Journal:");
    const journal = Array.isArray(incident.journal) ? incident.journal : [];
    journal.forEach((entry: any) => {
      const when = entry.sys_created_on ?? "";
      const val = (entry.value ?? "").replace(/\r\n/g, " ");
      lines.push(`- ${when}: ${val}`);
    });

    return lines.join("\n");
  }

  async function startSession() {
    setErrorMessage(null);
    if (!incidentNo.trim()) {
      setErrorMessage("Please enter a valid Incident Number.");
      return;
    }

    const newReqId = typeof crypto !== "undefined" && (crypto as any).randomUUID
      ? (crypto as any).randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

    setInitLoading(true);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const resp = await fetch(`${API_URL}/postmortem/init`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ req_id: newReqId, incident_no: incidentNo.trim() }),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      const data = await resp.json().catch(() => null);
      setApiDebug({ init: data, status: resp.status });

      if (resp.ok && data) {
        setReqId(newReqId);
        setIncidentInitiated(true);
        setIsLast(Boolean(data.isLast));
        setLastQuestion(data.question ?? "");
        setIncidentData(data.incident ?? null);
        const formatted = formatIncident(data.incident ?? null);
        setMessages([{ sender: "system", text: formatted }, { sender: "bot", text: data.question ?? "" }]);
      } else {
        setErrorMessage(`Init Error: ${data?.detail ?? resp.statusText ?? "Unknown error"}`);
      }
    } catch (err: any) {
      if (err.name === "AbortError") setErrorMessage("Request timed out (30s)");
      else setErrorMessage(`Failed to connect to API: ${String(err)}`);
    } finally {
      setInitLoading(false);
    }
  }

  async function sendAnswer(answer: string) {
    setErrorMessage(null);
    if (!reqId) {
      setErrorMessage("Missing session id. Start a session first.");
      return;
    }
    if (!answer.trim()) return;

    // append user message (optimistic)
    setMessages((m) => [...m, { sender: "user", text: answer }]);
    setConvLoading(true);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const payload = { req_id: reqId, answer, incident: incidentData };
      const resp = await fetch(`${API_URL}/postmortem/conversation`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      const data = await resp.json().catch(() => null);
      setApiDebug({ conv: data, status: resp.status });

      if (resp.ok && data && "question" in data) {
        setIsLast(Boolean(data.isLast));
        setLastQuestion(String(data.question ?? ""));
        setMessages((m) => [...m, { sender: "bot", text: String(data.question ?? "") }]);
        if (data.isLast && data.postmortem) setPostmortemReport(data.postmortem);
      } else {
        setMessages((m) => [...m, { sender: "bot", text: `Error: ${data?.detail ?? resp.statusText ?? resp.status}` }]);
      }
    } catch (err: any) {
      if (err.name === "AbortError") setMessages((m) => [...m, { sender: "bot", text: "Failed: request timed out (30s)" }]);
      else setMessages((m) => [...m, { sender: "bot", text: `Failed to connect to API: ${String(err)}` }]);
    } finally {
      setConvLoading(false);
    }
  }

  function restartSession() {
    setReqId("");
    setIncidentInitiated(false);
    setIncidentNo("");
    setMessages([]);
    setLastQuestion("");
    setIsLast(false);
    setPostmortemReport(null);
    setIncidentData(null);
    setApiDebug(null);
    setErrorMessage(null);
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar */}
        <aside className="md:col-span-1 bg-white rounded-lg border p-4 shadow-sm">
          <h2 className="text-lg font-semibold">Postmortem Session</h2>
          {!incidentInitiated ? (
            <div className="mt-4 space-y-3">
              <label className="block text-sm font-medium">Incident Number</label>
              <input
                className="w-full rounded-md border px-3 py-2"
                value={incidentNo}
                onChange={(e) => setIncidentNo(e.target.value)}
                placeholder="Enter Incident Number"
                disabled={initLoading}
              />

              <button
                className="w-full rounded-md bg-blue-600 text-white py-2 disabled:opacity-60"
                onClick={startSession}
                disabled={initLoading}
              >
                {initLoading ? "Starting..." : "Start Session"}
              </button>

              {errorMessage && <div className="text-sm text-red-600">{errorMessage}</div>}
            </div>
          ) : (
            <div className="mt-4 space-y-2 text-sm">
              <div className="text-muted">Incident Number:</div>
              <div className="font-medium">{incidentNo}</div>
              <div className="text-muted mt-2">Session ID:</div>
              <div className="font-mono text-xs">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>

              <button className="mt-4 w-full rounded-md bg-amber-500 text-white py-2" onClick={() => navigator.clipboard?.writeText(reqId)}>
                Copy Session ID
              </button>
            </div>
          )}

          <div className="mt-6 border-t pt-3 text-xs text-slate-500">
            <div className="font-semibold">API Debug</div>
            <pre className="max-h-48 overflow-auto text-xs bg-slate-100 p-2 rounded mt-2">{JSON.stringify(apiDebug, null, 2)}</pre>
          </div>
        </aside>

        {/* Main */}
        <main className="md:col-span-3 bg-white rounded-lg border p-4 flex flex-col">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold">🕵️‍♂️ AI Postmortem Conversation Bot</h1>
            <div className="text-sm text-slate-500">Connected to: {API_URL}</div>
          </div>

          {!incidentInitiated ? (
            <div className="mt-8 text-center text-slate-600">
              Start a new session from the sidebar by entering an Incident Number.
            </div>
          ) : (
            <>
              <div className="mt-4 flex-1 overflow-auto" style={{ maxHeight: 520 }}>
                <div className="space-y-4">
                  {messages.map((msg, idx) => (
                    <div key={idx}>
                      {msg.sender === "system" ? (
                        <div className="whitespace-pre-line bg-slate-50 border rounded p-3 text-sm text-slate-700">{msg.text}</div>
                      ) : msg.sender === "bot" ? (
                        <div className="w-fit max-w-[80%] bg-sky-50 border border-sky-100 rounded-2xl p-3 shadow-sm">
                          <div className="text-sm">{msg.text}</div>
                        </div>
                      ) : (
                        <div className="flex justify-end">
                          <div className="w-fit max-w-[80%] bg-emerald-50 border border-emerald-100 rounded-2xl p-3">
                            <div className="text-sm">{msg.text}</div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}

                  {convLoading && (
                    <div className="w-fit max-w-[80%] bg-slate-100 rounded-2xl p-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 animate-bounce rounded-full bg-slate-400"></div>
                        <div className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]"></div>
                        <div className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]"></div>
                        <span className="text-sm text-slate-600">Thinking...</span>
                      </div>
                    </div>
                  )}

                  <div ref={chatEndRef} />
                </div>
              </div>

              <div className="mt-4 border-t pt-3">
                {!isLast ? (
                  <ChatInput onSubmit={async (text: string) => await sendAnswer(text)} disabled={convLoading} />
                ) : (
                  <div>
                    <div className="p-3 rounded bg-emerald-50 text-emerald-800">Postmortem Conversation Complete!</div>

                    {postmortemReport && (
                      <div className="mt-4">
                        <h3 className="font-semibold">Final Postmortem Report</h3>
                        <pre className="mt-2 max-h-64 overflow-auto bg-slate-50 p-3 rounded">{JSON.stringify(postmortemReport, null, 2)}</pre>
                      </div>
                    )}

                    <div className="mt-4 flex gap-2">
                      <button
                        className="rounded bg-red-500 text-white px-4 py-2"
                        onClick={restartSession}
                      >
                        Restart
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}

// Small ChatInput child component (keeps the file single-file friendly)
function ChatInput({ onSubmit, disabled = false }: { onSubmit: (text: string) => Promise<void> | void; disabled?: boolean }) {
  const [text, setText] = useState("");

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const t = text.trim();
    if (!t) return;
    setText("");
    await onSubmit(t);
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="flex-1 rounded border px-3 py-2"
        placeholder="Your answer (press Enter or click Submit to send)"
        disabled={disabled}
      />
      <button
        type="submit"
        className="rounded bg-blue-600 text-white px-4 py-2 disabled:opacity-60"
        disabled={disabled}
      >
        Send
      </button>
    </form>
  );
}
