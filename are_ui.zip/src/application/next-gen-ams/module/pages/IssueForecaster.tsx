// IssueForecaster.tsx
import React, { useEffect, useRef, useState } from "react";
import { AlertTriangle, RefreshCw, Clock, Layers } from "lucide-react";
import Container from "@/components/ui/container";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/tailwind.utils";

type LLMResponse = {
  issue_summary?: string;
  risk_level?: string;
  reasoning?: string;
  recommended_actions?: string[] | string;
};

type CollatedItem = {
  fields: Record<string, string>;
  example_log: string;
  count: number;
  first_seen?: string | null;
  last_seen?: string | null;
};

type ForecasterResponse = {
  total_logs?: number;
  error_count?: number;
  error_threshold?: number;
  status?: "normal" | "alert" | string;
  forecast_triggered?: boolean;
  llm_response?: LLMResponse | null;
  risk_level?: string | null;
  collated_logs?: CollatedItem[];
  logs?: string[]; // raw error log lines
};

const DEFAULT_API = import.meta.env.VITE_ISSUE_FORECASTER_API ?? "http://localhost:8080/issue-forecaster";

const humanDate = (iso?: string | Date) => {
  if (!iso) return "-";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleString();
};

const SmallBadge: React.FC<{ children?: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${className}`}>{children}</span>
);

export const IssueForecaster: React.FC = () => {
  const [data, setData] = useState<ForecasterResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [intervalMs, setIntervalMs] = useState<number>(120000);
  const [autoPoll, setAutoPoll] = useState<boolean>(true);

  const timerRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const API_URL = DEFAULT_API;

  const toApiFormat = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, "0");
    const Y = d.getFullYear();
    const M = pad(d.getMonth() + 1);
    const D = pad(d.getDate());
    const h = pad(d.getHours());
    const m = pad(d.getMinutes());
    const s = pad(d.getSeconds());
    return `${Y}-${M}-${D}T${h}:${m}:${s}`;
  };

  const fetchData = async (from?: string, to?: string) => {
    setIsLoading(true);
    setError(null);
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    try {
      const now = new Date();
      const defaultTo = toApiFormat(now);
      const defaultFrom = toApiFormat(new Date(now.getTime() - intervalMs));
      const startParam = from ?? defaultFrom;
      const endParam = to ?? defaultTo;

      const params = new URLSearchParams();
      params.append("start", startParam);
      params.append("end", endParam);

      const url = `${API_URL}?${params.toString()}`;
      const res = await fetch(url, { signal: ac.signal });
      if (!res.ok) {
        const txt = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} ${txt}`);
      }
      const payload = (await res.json()) as ForecasterResponse;
      setData(payload);
      setLastUpdated(new Date());
    } catch (e: any) {
      if (e?.name === "AbortError") {
        // ignore
      } else {
        console.error("IssueForecaster fetch error:", e);
        setError(String(e?.message ?? e));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const startPolling = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    fetchData();
    if (autoPoll) {
      timerRef.current = window.setInterval(() => {
        fetchData();
      }, intervalMs) as unknown as number;
    }
  };

  const stopPolling = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    abortRef.current?.abort();
  };

  useEffect(() => {
    startPolling();
    return () => stopPolling();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, autoPoll]);

  // UI derived
  const isAlert = Boolean(data?.forecast_triggered) || data?.status === "alert";
  const errors = data?.error_count ?? 0;
  const threshold = data?.error_threshold ?? 0;
  const pct = threshold > 0 ? Math.min(100, Math.round((errors / threshold) * 100)) : 0;

  const risk = data?.risk_level ?? data?.llm_response?.risk_level ?? null;
  const riskBadgeClass = (r?: string | null) => {
    if (!r) return "bg-gray-100 text-slate-700";
    const rr = String(r).toLowerCase();
    if (rr.includes("very")) return "bg-rose-700 text-white";
    if (rr.includes("high")) return "bg-red-600 text-white";
    if (rr.includes("medium")) return "bg-amber-500 text-white";
    if (rr.includes("low")) return "bg-emerald-100 text-emerald-800";
    return "bg-gray-100 text-slate-700";
  };

  const collated = data?.collated_logs ?? [];

  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);

  return (
    <Container>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Issue Forecaster</h1>
            <p className="text-sm text-slate-500">Analyze recent error logs and surface the most frequent signatures.</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-sm text-slate-600">Auto Poll</label>
              <input type="checkbox" checked={autoPoll} onChange={(e) => setAutoPoll(e.target.checked)} className="h-4 w-4" />
            </div>

            <select
              value={String(intervalMs)}
              onChange={(e) => setIntervalMs(Number(e.target.value))}
              className="px-3 py-1 border rounded"
              title="Polling interval"
            >
              <option value={30000}>30s</option>
              <option value={60000}>60s</option>
              <option value={120000}>120s</option>
              <option value={300000}>5m</option>
            </select>

            <button
              onClick={() => fetchData()}
              disabled={isLoading}
              className={cn(
                "inline-flex items-center gap-2 px-4 py-2 rounded border bg-white hover:bg-slate-50",
                isLoading ? "opacity-60 cursor-not-allowed" : ""
              )}
            >
              <RefreshCw className="h-4 w-4" />
              <span className="text-sm">{isLoading ? "Refreshing..." : "Refresh"}</span>
            </button>
          </div>
        </div>

        {/* Top row: status + summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Status card */}
          <div className={cn("p-4 rounded-lg border shadow-sm", isAlert ? "bg-red-50 border-red-200" : "bg-white")}>
            <div className="flex items-center justify-between">
              <div>
                <div className={cn("text-sm font-medium", isAlert ? "text-red-700" : "text-slate-800")}>
                  {isAlert ? "Outage Forecasted" : "Normal"}
                </div>
                <div className="text-xs text-slate-500 mt-1">Errors in window</div>
              </div>

              <div className="flex items-center gap-2">
                <div className={cn("px-3 py-1 rounded-md text-sm font-semibold", isAlert ? "bg-red-600 text-white" : "bg-emerald-100 text-emerald-800")}>
                  {isAlert ? <AlertTriangle className="inline h-4 w-4 mr-1" /> : <Layers className="inline h-4 w-4 mr-1" />}
                  {isAlert ? "ALERT" : "OK"}
                </div>
                <SmallBadge className={riskBadgeClass(risk)}>{risk ?? "Unknown"}</SmallBadge>
              </div>
            </div>

            <div className="mt-4">
              <div className="text-xs text-slate-500">Errors</div>
              <div className="text-2xl font-bold text-red-600">{errors}</div>
            </div>

            <div className="mt-4">
              <div className="text-xs text-slate-500 mb-1">Threshold</div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div className={cn("h-2", isAlert ? "bg-red-500" : "bg-emerald-500")} style={{ width: `${Math.min(100, pct)}%` }} />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                <div>Threshold: {threshold}</div>
                <div>{pct}%</div>
              </div>
            </div>

            <div className="mt-4 text-xs text-slate-500">
              <div>Last updated: {lastUpdated ? humanDate(lastUpdated) : "Never"}</div>
              {error && <div className="text-rose-600 mt-2">Error: {error}</div>}
            </div>
          </div>

          {/* Forecast / LLM summary */}
          <div className="md:col-span-2 p-4 rounded-lg border bg-white shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium">{data?.llm_response?.issue_summary ?? "No forecast yet"}</div>
                <div className="text-xs text-slate-500 mt-1">Issue summary</div>
              </div>
              <div className="text-sm text-slate-500">Forecast Used: {data?.forecast_triggered ? "Yes" : "No"}</div>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded border">
                <div className="text-xs text-slate-500">Risk Level</div>
                <div className="mt-1 text-sm font-semibold">{risk ?? "Unknown"}</div>
              </div>

              <div className="col-span-2 p-3 bg-slate-50 rounded border">
                <div className="text-xs text-slate-500">Reasoning</div>
                <div className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">
                  {isLoading ? <Skeleton className="h-6 w-full" /> : data?.llm_response?.reasoning ?? "—"}
                </div>
              </div>
            </div>

            <div className="mt-4">
              <div className="text-xs text-slate-500">Recommended Actions</div>
              <div className="mt-2 space-y-2">
                {data?.llm_response?.recommended_actions ? (
                  Array.isArray(data.llm_response.recommended_actions) ? (
                    (data.llm_response.recommended_actions as string[]).map((a, i) => (
                      <div key={i} className="p-3 bg-white border rounded text-sm">
                        <div className="font-medium">#{i + 1}</div>
                        <div className="mt-1 text-slate-700">{a}</div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 bg-white border rounded text-sm">{String(data.llm_response.recommended_actions)}</div>
                  )
                ) : (
                  <div className="text-sm text-slate-500">No actions recommended.</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Collated signatures + raw payload */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-2 p-4 rounded-lg border bg-white shadow-sm overflow-auto">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold">Top Collated Error Signatures</div>
              <div className="text-xs text-slate-500">Showing top {Math.min(10, collated.length)}</div>
            </div>

            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : collated.length === 0 ? (
              <div className="text-sm text-slate-500">No error signatures in the selected window.</div>
            ) : (
              <div className="space-y-3">
                {collated.slice(0, 10).map((item, idx) => {
                  const expanded = expandedIdx === idx;
                  return (
                    <div key={idx} className="p-3 rounded border bg-slate-50">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <div className="text-sm font-medium">#{idx + 1}</div>
                            <div className="text-xs text-slate-500">Count: <span className="font-semibold text-slate-700 ml-1">{item.count}</span></div>
                            <div className="text-xs text-slate-400 ml-3">First: {item.first_seen ? humanDate(item.first_seen) : "-"}</div>
                            <div className="text-xs text-slate-400 ml-3">Last: {item.last_seen ? humanDate(item.last_seen) : "-"}</div>
                          </div>

                          <div className="mt-2 flex flex-wrap gap-2">
                            {Object.entries(item.fields).map(([k, v]) => (
                              <SmallBadge key={k} className="bg-white border text-slate-700">
                                <span className="text-xs font-semibold mr-1">{k}</span>
                                <span className="text-xs text-slate-600">{v}</span>
                              </SmallBadge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <button
                            onClick={() => setExpandedIdx(expanded ? null : idx)}
                            className="text-xs px-2 py-1 rounded border bg-white hover:bg-slate-100"
                          >
                            {expanded ? "Hide example" : "Show example"}
                          </button>
                        </div>
                      </div>

                      {expanded && (
                        <pre className="mt-3 p-2 bg-black text-white rounded text-xs font-mono whitespace-pre-wrap max-h-40 overflow-auto">
                          {item.example_log}
                        </pre>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="p-4 rounded-lg border bg-white shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold">Raw Payload</div>
              <div className="text-xs text-slate-500">Debug</div>
            </div>

            <div className="text-xs max-h-80 overflow-auto bg-slate-50 p-3 rounded">
              <pre>{JSON.stringify(data ?? {}, null, 2)}</pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-xs text-slate-500">Tip: use Auto Poll to enable periodic checks. Ensure backend CORS allows this origin.</div>
      </div>
    </Container>
  );
};

export default IssueForecaster;
