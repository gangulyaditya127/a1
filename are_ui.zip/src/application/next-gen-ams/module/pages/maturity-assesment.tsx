import Container from "@/components/ui/container"
import { Link, useParams } from "react-router-dom"
import DynamicForm from "../../features/DynamicForm"
import { useLazyFetchMaturityAssesmentQuery } from "../../slice/nextGenAMSAPISlice";
import { useEffect } from "react";
import { Loader } from "lucide-react";
import { Icon } from "@/components/ui/icon";
import { useAppSelector } from "@/lib/redux/hooks";


export default function MaturityAssesment() {
    const { id } = useParams()
    const [trigger, response] = useLazyFetchMaturityAssesmentQuery()
    const userDetails = useAppSelector(state => state.auth.rawUserDetails);
    useEffect(() => {
        trigger({ req_num: id, empid: userDetails.empid, isAdmin: 'N' })
    }, [])
    return (<Container className="max-w-4xl">
        <Link to='/help/submission' className="text-xs text-muted-foreground flex items-center gap-1 my-4">
            <Icon name="move-left" className="size-4" />
            <span>Go Back</span>
        </Link>
        <div className="mb-6 flex gap-2 items-baseline" id="maturity_assesment_ques_#1">
            <h1 className="text-3xl">Maturity Assesment Questionnaire</h1>
            <FormStatus status={
                response?.data?.isDraft == 'Y' ? 'Draft' :
                    response?.data?.isDraft == 'N' ? 'Submitted' : 'Pristine'
            } />
        </div>
        {
            response?.data ? <DynamicForm initialData={response?.data} disabled={response?.data?.isDraft == 'N' || response?.data?.empid != userDetails?.empid} isAdmin={false} isSubmitted={response?.data?.isDraft == 'N'} /> :
                response?.isFetching ?
                    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 translate-y-1/2">
                        <Loader className="animate-spin" />
                    </div> :
                    <Error />
        }
    </Container>)
}

const FormStatus = ({ status }: { status: string }) => (
    <div className="relative flex items-center gap-1">
        <span className={`inline-flex h-2 w-2 rounded-full ${status == 'Submitted' ? 'bg-green-400' : status == 'Draft' ? 'bg-sky-400' : 'bg-red-400'}`}></span>
        <span className="text-xs text-muted-foreground">
            {status}
        </span>
    </div>
)

const Error = () => {
    return (
        <div className="border-red-800 border p-6 rounded bg-red-800/10 ">
            <h2 className='text-lg text-primary/80'>Failed to fetch maturity assesment</h2>
            <p className="text-sm text-primary/80">Please try after sometime. if the error persist please check with admin</p>
        </div>
    )
}