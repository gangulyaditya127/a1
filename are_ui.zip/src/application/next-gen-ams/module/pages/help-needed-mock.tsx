import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import HelpFormMock from "../feature/HelpFormMock";
import { Icon } from "@/components/ui/icon";
import { Link } from "react-router-dom";

export default function HelpNeeded() {
    return (
        <Container className="grid grid-cols-3 gap-16 pb-12 mt-8">
            <div className="col-span-2">
                <NavigateBackButton />
                <h1 className="text-4xl font-tcs-title mb-6">Reach out to us with your request</h1>
                <HelpFormMock />
            </div>
            <div className="space-y-4 mt-8">
                <Link
                    to='past-result'
                    className="bg-secondary/20 p-4 border  w-full flex gap-4 items-center rounded-lg text-sm"
                >
                    <div className="grid size-10 place-items-center rounded-lg bg-gradient-to-br from-blue-700 to-blue-500 group-hover/task:shadow-[rgba(182,153,255,0.3)_0px_10px_20px] dark:from-blue-600 dark:to-blue-400">
                        <Icon name="lightbulb" className="size-5 fill-white text-white/80" />
                    </div>
                    <p>
                        Recent Submissions
                    </p>
                </Link>
            </div>
        </Container>
    )
}