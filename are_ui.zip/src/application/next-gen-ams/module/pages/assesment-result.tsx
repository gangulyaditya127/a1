import Container from "@/components/ui/container";
import DataGrid from "@/components/ui/data-grid";
import { ColDef, ExcelStyle } from "ag-grid-charts-enterprise";
import { forwardRef, LegacyRef, memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MaturityTable, useGetMaturityAssessmentResultQuery, useUpdateMaturityResultMutation } from "../../slice/nextGenAMSAPISlice";
import { useAppSelector } from "@/lib/redux/hooks";
import {  useParams } from "react-router-dom";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import Loader from "@/components/ui/loader";
import { useToast } from "@/components/ui/use-toast";
import { AgGridReact } from "ag-grid-react";
import { Icon } from "@/components/ui/icon";
export default function AssesmentResult() {
    const { id: requestNumber } = useParams();
    const [payload, setPayload] = useState(null);
    const isEdited = !!payload;
    const [reset, setReset] = useState<boolean>(false);
    const btnRef = useRef<HTMLButtonElement>(null)
    const [trigger, response] = useUpdateMaturityResultMutation();
    const { isLoading, isError, isSuccess } = response;
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const gridRef = useRef<AgGridReact<any>>(null);
    const { toast } = useToast()
    const handleEditChange = useCallback((value: any) => {
        setPayload(value)
    }, []);
    const handleUpdate = () => {
        btnRef.current?.focus();
        trigger(payload);
    }
    const resetChange = () => {
        setReset((v) => !v)
    }

    useEffect(() => {
        if (isError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "There was a problem while submitting response.",
            })
            setPayload(null)
        }
        if (isSuccess) {
            toast({
                variant: "default",
                title: "Assessment details updated successfully",
            })
            setPayload(null)
        }
    }, [isError, isSuccess])

    const exportExcel = useCallback(() => {
        gridRef.current!.api.exportDataAsExcel(
            {
                sheetName: "Maturity Assesment Result",
                fileName: `Maturity_Assesment_Result_${requestNumber}`,
            }
        );
    }, []);

    return (
        <Container className="mt-4 mb-12">
            <NavigateBackButton />
            <div className="flex justify-between items-center">
                <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">Maturity assessment result for - {requestNumber}</h2>
                <div className="flex items-center gap-1">
                    {userDetails.isAdmin == "Y" && isEdited && <>
                        <Button disabled={isLoading} onClick={resetChange} variant="destructive" size="sm" className="rounded-lg gap-2 h-8 text-xs font-normal font-baseline">Discard</Button>
                        <Button disabled={isLoading} onClick={handleUpdate} ref={btnRef} variant="primary" size="sm" className="rounded-lg gap-2 h-8 text-xs font-normal font-baseline">
                            {isLoading && <Loader className="h-3.5 w-3.5" />}
                            Update
                        </Button>
                    </>}
                    <Button onClick={exportExcel} className="rounded-lg gap-2 text-xs font-normal font-baseline h-[34px]" variant={"outline"} size={"sm"}>
                        <Icon name="download" className="h-4 w-4" />
                        <p>Export</p>
                    </Button>
                </div>
            </div>
            <MEMOMaturityResultDataTable ref={gridRef} reqNumber={requestNumber} handleEditChange={handleEditChange} reset={reset} />
        </Container>
    )
}

function MaturityWithoutRef({
    reqNumber,
    handleEditChange,
    reset
}: {
    reqNumber?: string,
    handleEditChange: (val: any) => void,
    reset: boolean
}, gridRef: LegacyRef<AgGridReact<any>>) {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    // const gridRef = useRef<AgGridReact>(null);
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const { data, isLoading, isError } = useGetMaturityAssessmentResultQuery({
        empid: userDetails.empid ?? "",
        isAdmin: "Y",
        req_num: reqNumber ?? ""
    }, {
        skip: !reqNumber && !userDetails.empid && !userDetails.isAdmin
    });
    console.log({ data, isLoading, isError, userDetails })
    const rowData: MaturityTable[] = structuredClone(data?.tableData ?? []);

    const [columnDefs] = useState<ColDef[]>([
        {
            field: "Group Name", rowGroup: true, hide: true, showRowGroup: false, rowGroupIndex: 0,
        },
        {
            field: "Question", editable: false, cellClass: 'border-x bg-blue-500/10 blueBackground',
            headerClass: 'bg-blue-500/20'
        },
        {
            field: "Answer", editable: false, cellClass: 'border-x bg-blue-500/10 blueBackground',
            headerClass: 'bg-blue-500/20'
        },
        {
            field: "Remarks", editable: false, cellClass: 'border-x bg-blue-500/10 blueBackground',
            headerClass: 'bg-blue-500/20'
        },
        { field: "Category" },
        { field: "Observation", cellEditor: "agLargeTextCellEditor", },
        { field: "ARE Solution", cellEditor: "agLargeTextCellEditor", },
        { field: "Software", cellEditor: "agLargeTextCellEditor", },
        { field: "Hardware", cellEditor: "agLargeTextCellEditor", },
        { field: "Connectivity Needed", cellEditor: "agLargeTextCellEditor", },
        { field: "Time Frame", cellEditor: "agLargeTextCellEditor", },
        { field: "Associates Required", cellEditor: "agLargeTextCellEditor", },
        { field: "Map Remarks", cellEditor: "agLargeTextCellEditor", wrapText: false },
        { field: "Benefits", cellEditor: "agLargeTextCellEditor", },
    ]);

    const handleCellEditStopped = () => {
        handleEditChange({
            reqNum: data?.reqNum,
            tableData: rowData
        })
    }

    const excelStyles = useMemo<ExcelStyle[]>(() => {
        return [
            {
                id: "header",
                font: {
                    bold: true,
                },
                interior: {
                    color: "#FFFF00",
                    pattern: "Solid",
                },
            },
            {
                id: "bg-blue-500/10",
                interior: {
                    color: "#ebf2fe",
                    pattern: "Solid"
                }
            },
            {
                id: "rowGroupStyle",
                interior: {
                    color: "#FFFF00",
                    pattern: "Solid",
                },
            },
            {
                id: "blueBackground",
                interior: {
                    color: "#ebf2fe",
                    pattern: "Solid",
                },
            },
        ]
    }, [])
    const defaultColDef = useMemo<ColDef>(() => {
        return ({
            wrapText: true,
            resizable: true,
            minWidth: 300,
            editable: userDetails.isAdmin == "Y" ? true : false,
            groupDefaultExpanded: -1,
            cellEditorPopup: true,
            cellEditorParams: {
                maxLength: 4000
            }
        });
    }, [userDetails]);
    if (isError) {
        return <Error />
    }
    if (isLoading) {
        return (
            <>
                <Skeleton className="w-full h-8" />
                <Skeleton className="w-full h-44 mt-2" />
            </>
        )
    }
    if (rowData.length == 0) {
        return <StateNotReached />
    }
    return (
        <div className="">
            {reset}
            <div
                style={gridStyle}
            >
                <DataGrid
                    rowData={rowData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    masterDetail={true}
                    rowGroupPanelShow={"always"}
                    groupDisplayType="multipleColumns"
                    domLayout='autoHeight'
                    ref={gridRef}
                    onCellEditingStopped={handleCellEditStopped}
                    maintainColumnOrder={true}
                    groupMaintainOrder={true}
                    stopEditingWhenCellsLoseFocus={true}
                    excelStyles={excelStyles}
                />
                {/* onFirstDataRendered={onFirstDataRendered} */}
            </div>
        </div>)
}


const MaturityResultDataTable = forwardRef(MaturityWithoutRef)

const MEMOMaturityResultDataTable = memo(MaturityResultDataTable)


{/*
     
    onCellValueChanged={handleCellValueChange} */ }
const StateNotReached = () => {
    return (
        <div className="border-red-800 border p-6 rounded bg-red-800/10 ">
            <h2 className='text-lg text-primary/80'>User has not filled maturity assesment</h2>
            <p className="text-sm text-primary/80">Plese follow up with the user. The maturity result will get generated post submission</p>
        </div>
    )
}

const Error = () => {
    return (
        <div className="border-red-800 border p-6 rounded bg-red-800/10 ">
            <h2 className='text-lg text-primary/80'>Failed to fetch maturity assesment results</h2>
            <p className="text-sm text-primary/80">Please try after sometime. if the error persist please check with ARE Dev Team</p>
        </div>
    )
}