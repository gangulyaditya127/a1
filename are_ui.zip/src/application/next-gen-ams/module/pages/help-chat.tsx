import { useEffect, useState } from "react";
import ChatBox, { Message } from "@/application/next-gen-ams/module/feature/ChatBox";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import Container from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate, useParams } from "react-router-dom";
import { useFetchChatHistoryQuery, useLazyFetchMaturityAssessmentDataQuery } from "../../slice/nextGenAMSAPISlice";
import Loader from "@/components/ui/loader";

const HelpChat = () => {
    const { reqId } = useParams<{ reqId: string }>();
    const [trigger, { data: response, isLoading }] = useLazyFetchMaturityAssessmentDataQuery();
    const navigate = useNavigate();
    // const [chatHistory, setChatHistory] = useState<string[]>()
    const [parsedKPIs, setParsedKPIs] = useState<Record<string, number>>({});

    const { data: chatHistoryRaw, isLoading: isLoadingChat, isSuccess } = useFetchChatHistoryQuery({
        req_id: reqId
    }, {
        skip: !reqId
    });

    const [prevMessage, setPrevMessage] = useState<Message[]>([])

    /**
      text: string;
      isBot: boolean;
      showOptions?: boolean;
      options?: string[];
      timestamps?: string;
     */

    useEffect(() => {
        // console.log({ chatHistoryRaw, val: isSuccess && chatHistoryRaw.chatHistory.length == 0 })
        if (isLoadingChat) return;

        if (isSuccess && chatHistoryRaw.chatHistory.length == 0) {
            setPrevMessage(() => [
                {
                    text: "Welcome to the AMS Maturity Assessment Assistant! I’ll guide you through a quick evaluation to understand where your account stands and recommend areas for improvement.",
                    isBot: true,
                    showOptions: true,
                    options: ["Begin Assessment"]
                }
            ])
            return;
        }
        setPrevMessage(() => (([
            {
                text: "Welcome to the AMS Maturity Assessment Assistant! I’ll guide you through a quick evaluation to understand where your account stands and recommend areas for improvement.",
                isBot: true,
                showOptions: false,
                options: []
            },
            ...chatHistoryRaw?.chatHistory?.map((el: any, index: number, arr: any[]) => ({
                text: el?.response ?? "",
                isBot: el.isBot,
                showOptions: index === arr.length - 1 ? true : false,
                options: index === arr.length - 1 ? el.options : [],

                timestamps: el?.timestamp
            }))
        ])))

    }, [chatHistoryRaw, isLoadingChat, isSuccess])


    useEffect(() => {
        if (reqId) {
            trigger({ reqId });
        }
    }, [reqId, trigger]);

    useEffect(() => {
        if (response?.STRUGGLING_KPIS) {
            try {
                const parsed = JSON.parse(response.STRUGGLING_KPIS);
                // const parsedHistory = Array.isArray(response.CHAT_HISTORY)
                //     ? response.CHAT_HISTORY
                //     : JSON.parse(response.CHAT_HISTORY);

                // setChatHistory(parsedHistory);
                setParsedKPIs(parsed);
            } catch (error) {
                console.error("Error parsing KPIs:", error);
                setParsedKPIs({});
            }
        }
    }, [response]);

    if (isLoading) {
        return (
            <Loader />
        );
    }

    if (!response) {
        return (
            <Container className="flex items-center justify-center h-screen">
                <p className="text-red-500 text-lg">No data found for Req ID: {reqId}</p>
            </Container>
        );
    }

    return (
        <Container className="gap-12 pb-12 mt-8">
            <NavigateBackButton />
            <div className="flex gap-2 items-center mb-5">
                <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">
                    Application Maturity Assessment
                </h2>
                <span
                    onClick={() => navigate(`/help/mock/result/${reqId}`)}
                    className="text-muted-foreground text-xs hover:underline cursor-pointer"
                >
                    [View Result]
                </span>
            </div>
            <Container className="grid grid-cols-3 gap-5 md:pl-0">
                {/* Summary Card */}
                <Card className="rounded-xl w-full h-fit border-none p-0">
                    <CardContent className="p-0">
                        <ul className="text-base grid grid-cols-2 gap-4">
                            <li className="flex flex-col">
                                <span className="font-medium text-muted-foreground">Business Group</span> {response.BU}
                            </li>
                            <li className="flex flex-col">
                                <span className="font-medium text-muted-foreground">ISU</span> {response.ISU}
                            </li>
                            <li className="flex flex-col">
                                <span className="font-medium text-muted-foreground">Sub ISU</span> {response.SUB_ISU}
                            </li>
                            <li className="flex flex-col">
                                <span className="font-medium text-muted-foreground">Account</span> {response.ACCOUNT}
                            </li>
                        </ul>

                        {/* Show KPIs */}
                        {Object.keys(parsedKPIs).length > 0 && (
                            <div className="mt-4">
                                <h3 className="font-semibold text-muted-foreground">Selected KPIs</h3>
                                <ul className="list-disc pl-5">
                                    {Object.entries(parsedKPIs).map(([kpi, value]) => (
                                        <li key={kpi}>
                                            {kpi} <span className="text-sm text-muted-foreground">(Importance: {value})</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Chat Section */}
                <div className="flex col-span-2 flex-col h-[500px]">
                    {/* {JSON.stringify(prevMessage, null, 2)} */}
                    <ChatBox prevMessage={prevMessage} />
                </div>
            </Container>
        </Container>
    );
};

export default HelpChat;