// Postmortem.tsx
import React, { useEffect, useRef, useState } from "react"; // React + hooks
import { useParams } from "react-router-dom"; // optional route params
import Container from "@/components/ui/container"; // layout wrapper
import { Card, CardContent } from "@/components/ui/card"; // UI card components
import ChatBox, { Message } from "@/application/next-gen-ams/module/feature/ChatBox"; // ChatBox component
import { NavigateBackButton } from "@/components/ui/navigate-back-button"; // back button UI
import Loader from "@/components/ui/loader"; // loader spinner
import { useFetchPostmortemInitMutation, useSubmitPostmortemConversationMutation } from "../../slice/nextGenAMSAPISlice"; // RTK hooks
import { toast } from "@/components/ui/use-toast"; // toast notifications
import { Input } from "@/components/ui/input"; // input component
import { saveAs } from "file-saver"; // for JSON download
// Quick HTML render imports (sanitized)
import parse from "html-react-parser";
//import DOMPurify from "dompurify";
// Optional: if your API sends escaped entities (&lt; &gt;), decode them
import { decode } from "html-entities"; // npm i html-entities

// flexible typing for incident data
type IncidentData = Record<string, any> | null;

// Main Postmortem component
const Postmortem: React.FC = () => {
  const { reqId: routeReqId } = useParams<{ reqId?: string }>(); // optional route reqId
  //const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "http://localhost:8009/postmortem"; // not used here directly
  const API_URL = import.meta.env.VITE_POSTMORTEM_API ?? "https://api/python_mcp/postmortem"; // not used here directly
  // Parent-owned state
  const [reqId, setReqId] = useState<string>(routeReqId || "");
  const [incidentInitiated, setIncidentInitiated] = useState<boolean>(false);
  const [incidentNo, setIncidentNo] = useState<string>("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLast, setIsLast] = useState<boolean>(false);
  const [postmortemReport, setPostmortemReport] = useState<any>(null); // final report moved to parent
  const [incidentData, setIncidentData] = useState<IncidentData>(null);
  const [apiDebug, setApiDebug] = useState<any>(null);

  // optional scroll anchor
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // RTK mutations
  const [triggerInit, { data: initData, isLoading: initLoading, error: initError }] =
    useFetchPostmortemInitMutation();
  const [submitConv, { data: convData, isLoading: convLoading, error: convError }] =
    useSubmitPostmortemConversationMutation();

  // scroll when messages or loading changes
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, convLoading]);

  // handle init response and push structured incident message + first question
  useEffect(() => {
    if (initData) {
      setReqId(initData.req_id || reqId);
      setIncidentInitiated(true);
      setIsLast(Boolean(initData.isLast));
      setIncidentData(initData.incident ?? null);

      // push structured incident message (parent owns it)
      setMessages([
        { text: "", isBot: true, showOptions: false, isIncident: true, incident: initData.incident ?? null },
        { text: initData.question ?? "", isBot: true, showOptions: Boolean(initData.isoptions), options: initData.listOfOptions ?? [] },
      ]);

      setApiDebug({ init: initData });
    }

    if (initError) {
      toast({
        variant: "destructive",
        title: "Init Error",
        description: (initError as any)?.data?.detail || "Failed to start session",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initData, initError]);

  // handle conversation responses (append next prompt, capture final report)
  useEffect(() => {
    if (convData) {
      setIsLast(Boolean(convData.isLast));

      // append next question/prompt
      setMessages((prev) => [
        ...prev,
        { text: convData.question ?? "", isBot: true, showOptions: Boolean(convData.isoptions), options: convData.listOfOptions ?? [], isLast: convData.isLast },
      ]);

      // store final postmortem on completion
      if (convData.isLast && convData.postmortem) setPostmortemReport(convData.postmortem);

      setApiDebug((prev) => ({ ...prev, conv: convData }));
    }

    if (convError) {
      setMessages((prev) => [
        ...prev,
        { text: `Error: ${(convError as any)?.data?.detail || "Conversation failed"}`, isBot: true },
      ]);
      toast({
        variant: "destructive",
        title: "Conversation Error",
        description: "Failed to send answer",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [convData, convError]);

  // start session with server
  function startSession() {
    if (!incidentNo.trim()) {
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please enter a valid Incident Number.",
      });
      return;
    }

    const newReqId = routeReqId || (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`);
    setReqId(newReqId);
    triggerInit({ req_id: newReqId, incident_no: incidentNo.trim() });
  }

  // send answer from ChatBox (parent appends user's message then calls API)
  function sendAnswer(answer: string) {
    if (!reqId || !answer.trim()) return;
    setMessages((prev) => [...prev, { text: answer.trim(), isBot: false }]);
    submitConv({ req_id: reqId, answer: answer.trim(), incident: incidentData });
  }

  // restart session
  function restartSession() {
    setReqId(routeReqId || "");
    setIncidentInitiated(false);
    setIncidentNo("");
    setMessages([]);
    setIsLast(false);
    setPostmortemReport(null);
    setIncidentData(null);
    setApiDebug(null);
  }

  // -------------------------
  // Structured report rendering utilities (moved to parent)
  // -------------------------

  // Render value (string/number/object/array) as JSX blocks for structured display
  function renderValueAsJSX(value: any): JSX.Element {
    if (value === null || value === undefined) {
      return <div className="text-sm text-muted-foreground">—</div>;
    }

    if (Array.isArray(value)) {
      if (value.length === 0) return <div className="text-sm text-muted-foreground">No entries.</div>;
      return (
        <ul className="list-disc ml-5 space-y-1">
          {value.map((item, i) => (
            <li key={i} className="text-sm">
              {typeof item === "object" ? <pre className="whitespace-pre-wrap text-sm">{JSON.stringify(item, null, 2)}</pre> : String(item)}
            </li>
          ))}
        </ul>
      );
    }

    if (typeof value === "object") {
      return (
        <div className="space-y-2">
          {Object.entries(value).map(([k, v]) => (
            <div key={k} className="p-2 border rounded text-sm">
              <div className="text-xs text-muted-foreground">{k}</div>
              <div className="mt-1">{renderValueAsJSX(v)}</div>
            </div>
          ))}
        </div>
      );
    }

    return <div className="text-sm whitespace-pre-wrap">{String(value)}</div>;
  }

  // Render the top-level postmortem report as structured blocks
  const renderPostmortemReport = (report: any) => {
    if (report === null || report === undefined) return <div className="text-sm text-muted-foreground">No report provided.</div>;

    if (typeof report === "string") {
      try {
        const parsed = JSON.parse(report);
        return renderPostmortemReport(parsed);
      } catch (e) {
        const paragraphs = String(report).split(/\n\s*\n/).filter(Boolean);
        return (
          <div className="space-y-3">
            {paragraphs.map((p: string, idx: number) => (
              <div key={idx} className="p-2 rounded text-sm whitespace-pre-wrap border">
                {p}
              </div>
            ))}
          </div>
        );
      }
    }

    if (typeof report === "object") {
      if (Array.isArray(report)) {
        return (
          <div className="space-y-3">
            {report.map((item, idx) => (
              <div key={idx} className="p-3 rounded border">
                <div className="font-semibold text-sm">Step {idx + 1}</div>
                <div className="mt-2">{renderValueAsJSX(item)}</div>
              </div>
            ))}
          </div>
        );
      }

      return (
        <div className="space-y-3">
          {Object.entries(report).map(([k, v]) => (
            <div key={k} className="p-3 rounded border">
              <div className="font-semibold text-sm">{k}</div>
              <div className="mt-2">{renderValueAsJSX(v)}</div>
            </div>
          ))}
        </div>
      );
    }

    return <div className="text-sm">{String(report)}</div>;
  };

  // -------------------------
  // DOCX generator and download (parent-side)
  // -------------------------
  async function downloadReportAsDocx(report: any, filename = "postmortem_report.docx") {
    try {
      // dynamic import keeps bundle smaller
      const docx = await import("docx");
      const { Document, Packer, Paragraph, HeadingLevel, TextRun } = docx;

      // convert a value to docx paragraphs (recursive)
      const valueToParagraphs = (value: any): any[] => {
        if (value === null || value === undefined) {
          return [new Paragraph({ children: [new TextRun({ text: "—" })] })];
        }
        if (Array.isArray(value)) {
          const paras: any[] = [];
          value.forEach((item) => {
            if (typeof item === "object") {
              paras.push(new Paragraph({ children: [new TextRun({ text: "- " + JSON.stringify(item) })] }));
            } else {
              paras.push(new Paragraph({ children: [new TextRun({ text: "- " + String(item) })] }));
            }
          });
          return paras;
        }
        if (typeof value === "object") {
          const paras: any[] = [];
          Object.entries(value).forEach(([subk, subv]) => {
            paras.push(new Paragraph({ children: [new TextRun({ text: `${subk}:`, bold: true })] }));
            const nested = valueToParagraphs(subv);
            nested.forEach((p) => paras.push(p));
          });
          return paras;
        }
        return [new Paragraph({ children: [new TextRun({ text: String(value) })] })];
      };

      // build document
      const doc = new Document({
        sections: [
          {
            properties: {},
            children: [
              new Paragraph({ text: "Postmortem Report", heading: HeadingLevel.HEADING_1 }),
              ...(typeof report === "object" && !Array.isArray(report)
                ? Object.entries(report).flatMap(([k, v]) => {
                    const heading = new Paragraph({ children: [new TextRun({ text: String(k), bold: true })] });
                    const paras = valueToParagraphs(v);
                    return [heading, ...paras, new Paragraph({})];
                  })
                : (() => {
                    const paras = valueToParagraphs(report);
                    return paras;
                  })()),
            ],
          },
        ],
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, filename);
    } catch (err) {
      console.error("DOCX generation failed:", err);
      toast({
        variant: "destructive",
        title: "Export failed",
        description: "Could not generate the DOCX file.",
      });
    }
  }

  

async function downloadReportAsDocxFromHtml(reportHtml: string, filename = "postmortem_report.docx") {
  try {
    const HtmlToDocx = (await import("@turbodocx/html-to-docx")).default;

    // If the API response is entity-escaped (as in your example), decode it first
    const decodedHtml = decode(reportHtml);

    // Wrap in a minimal HTML document to help converters
    const wrapped = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"></head><body>${decodedHtml}</body></html>`;

    // Convert: returns Blob in browser
    const docxBlob = await HtmlToDocx(wrapped, /* headerHtml */ null, {
      title: "Postmortem Report",
      pageNumber: true,
      table: { row: { cantSplit: true } }, // better list/table handling
      margins: { top: 1440, right: 1440, bottom: 1440, left: 1440 }, // 1" margins
    });

    saveAs(docxBlob, filename);
  } catch (err) {
    console.error("DOCX export failed:", err);
    toast({
      variant: "destructive",
      title: "Export failed",
      description: "Could not generate the DOCX file.",
    });
  }
}

  // JSON download helper
  function downloadReportAsJson(report: any, filename = "postmortem_report.json") {
    const blob = new Blob([JSON.stringify(report ?? {}, null, 2)], { type: "application/json" });
    saveAs(blob, filename);
  }

  // show loader during init
  if (initLoading) {
    return <Loader />;
  }

  // -------------------------
  // Render UI
  // -------------------------
  return (
    <Container className="gap-12 pb-12 mt-8">
      <NavigateBackButton />
      <div className="flex gap-2 items-center mb-5">
        <h2 className="text-md font-medium text-muted-foreground uppercase tracking-wide">Blameless Postmortem Agent</h2>
      </div>

      {/* grid: left controls, right chat */}
      <Container className="grid grid-cols-3 gap-5 md:pl-0">
        {/* left: session controls */}
        <Card className="rounded-xl w-full h-fit border-none p-0">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Postmortem Session</h3>

            {!incidentInitiated ? (
              <div className="space-y-3">
                <label className="block text-sm font-medium">Incident Number</label>
                <Input value={incidentNo} onChange={(e) => setIncidentNo(e.target.value)} placeholder="Enter Incident Number" disabled={initLoading} />
                <button className="w-full rounded-md bg-blue-600 text-white py-2 disabled:opacity-60" onClick={startSession} disabled={initLoading}>
                  {initLoading ? "Starting..." : "Start Session"}
                </button>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <div className="text-muted-foreground">Incident Number:</div>
                <div className="font-medium">{incidentNo}</div>
                <div className="text-muted-foreground mt-2">Session ID:</div>
                <div className="font-mono text-xs">{reqId ? `${reqId.slice(0, 8)}...` : "-"}</div>
                <button className="mt-4 w-full rounded-md bg-amber-500 text-white py-2" onClick={() => navigator.clipboard?.writeText(reqId)}>
                  Copy Session ID
                </button>
                <button className="mt-2 w-full rounded-md bg-red-500 text-white py-2" onClick={restartSession}>
                  Restart
                </button>
              </div>
            )}

            {/* API debug */}
            {apiDebug && (
              <div className="mt-6 border-t pt-3 text-xs text-muted-foreground">
                <div className="font-semibold">API Debug</div>
                <pre className="max-h-48 overflow-auto text-xs bg-muted p-2 rounded mt-2">{JSON.stringify(apiDebug, null, 2)}</pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* right: chat area */}
        <div className="flex col-span-2 flex-col h-[640px]">
          {!incidentInitiated ? (
            <Card className="rounded-xl p-6 h-full">
              <p className="text-center text-muted-foreground">Start a new session from the sidebar by entering an Incident Number.</p>
            </Card>
          ) : (
            <ChatBox prevMessage={messages} onSendAnswer={sendAnswer} isLoading={convLoading} isLast={isLast} reqId={reqId} />
          )}
        </div>
      </Container>

      {/* anchor for parent scroll */}
      <div ref={chatEndRef} />

      {/* ------------------------------------------------
          NEW: Postmortem report area shown BELOW the chat
         ------------------------------------------------ */}
      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4">Final Postmortem Report</h3>

        {/* If no report yet, show helpful message */}
        {!postmortemReport ? (
          <Card className="p-6">
            <div className="text-sm text-muted-foreground">Postmortem will appear here once the conversation completes.</div>
          </Card>
        ) : (
          <Card className="p-6">
            {/* structured view of the report */}
            {/* <div className="mb-4">{renderPostmortemReport(postmortemReport)}</div> */}
            <div className="mb-4">{parse(postmortemReport)}</div>
            {/* Quick sanitized HTML render using html-react-parser + DOMPurify */}
            {/* <div className="mb-4">
            {postmortemReport ? (
                // sanitize first, then parse into React nodes
                parseHtml(DOMPurify.sanitize(typeof postmortemReport === "string" ? postmortemReport : JSON.stringify(postmortemReport)))
            ) : (
                <div className="text-sm text-muted-foreground">No postmortem content to render.</div>
            )}
            </div> */}

            {/* action buttons: DOCX and JSON download */}
            <div className="flex gap-3">
              {/* <button className="rounded-md bg-blue-600 text-white py-2 px-4" onClick={() => downloadReportAsDocx(postmortemReport, "postmortem_report.docx")}>
                Download Report
              </button> */}
              
            <button
            className="rounded-md bg-blue-600 text-white py-2 px-4"
            onClick={() => downloadReportAsDocxFromHtml(postmortemReport, "postmortem_report.docx")}
            >
            Download Report
            </button>


              {/* <button className="rounded-md bg-gray-200 text-black py-2 px-4" onClick={() => downloadReportAsJson(postmortemReport, "postmortem_report.json")}>
                Download JSON
              </button> */}
            </div>
          </Card>
        )}
      </div>
    </Container>
  );
};

export default Postmortem;
