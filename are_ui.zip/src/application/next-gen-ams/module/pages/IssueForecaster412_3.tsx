import React, { useEffect, useRef, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

type LLMResponse = {
  issue_summary?: string;
  risk_level?: string;
  reasoning?: string;
  recommended_actions?: string[] | string;
};

type ForecasterResponse = {
  total_logs?: number;
  error_count?: number;
  error_threshold?: number;
  status?: "normal" | "alert" | string;
  forecast_triggered?: boolean;
  llm_response?: LLMResponse | null;
  risk_level?: string | null;
  start_time?: string;
  end_time?: string;
};

const API_URL = import.meta.env.VITE_ISSUE_FORECASTER_API ?? "http://localhost:8080/issue-forecaster";

const toApiFormat = (d: Date) => {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
};

const IssueForecaster: React.FC = () => {
  const [data, setData] = useState<ForecasterResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [intervalMs, setIntervalMs] = useState<number>(120000);
  const [autoPoll, setAutoPoll] = useState<boolean>(true);
  const timerRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    const now = new Date();
    const end = toApiFormat(now);
    const start = toApiFormat(new Date(now.getTime() - intervalMs));
    const url = `${API_URL}?start=${start}&end=${end}`;

    try {
      const res = await fetch(url, { signal: ac.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = (await res.json()) as ForecasterResponse;
      setData(payload);
      setLastUpdated(new Date());
    } catch (e: any) {
      if (e.name !== "AbortError") {
        console.error("Fetch error:", e);
        setError(String(e?.message ?? e));
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    if (autoPoll) {
      timerRef.current = window.setInterval(fetchData, intervalMs);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      abortRef.current?.abort();
    };
  }, [intervalMs, autoPoll]);

  const risk = data?.risk_level ?? data?.llm_response?.risk_level;
  const getRiskBadge = () => {
    if (!risk) return <Badge variant="outline">Unknown</Badge>;
    const r = risk.toLowerCase();
    if (r.includes("very")) return <Badge variant="destructive">Very High</Badge>;
    if (r.includes("high")) return <Badge variant="destructive">High</Badge>;
    if (r.includes("medium")) return <Badge variant="secondary">Medium</Badge>;
    if (r.includes("low")) return <Badge>Low</Badge>;
    return <Badge variant="outline">{risk}</Badge>;
  };

  return (
    <Card className="max-w-5xl mx-auto mt-6">
      <CardHeader>
        <CardTitle>Issue Forecaster</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading && <div className="text-muted-foreground text-sm">Fetching data...</div>}

        {error && (
          <Alert variant="destructive">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {data && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-4">
              <div>
                <div className="text-xs text-muted-foreground">Status</div>
                <Badge variant={data.status === "alert" ? "destructive" : "default"}>
                  {data.status === "alert" ? "ALERT" : "Normal"}
                </Badge>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Errors</div>
                <div className="text-sm font-semibold text-destructive">{data.error_count ?? 0}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Threshold</div>
                <div className="text-sm">{data.error_threshold}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Forecast</div>
                <Badge variant={data.forecast_triggered ? "secondary" : "outline"}>
                  {data.forecast_triggered ? "Used" : "Not used"}
                </Badge>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Risk</div>
                {getRiskBadge()}
              </div>
            </div>

            {data.llm_response && data.forecast_triggered && (
              <div className="space-y-3 mt-4">
                <div>
                  <div className="text-xs text-muted-foreground">Issue Summary</div>
                  <div className="font-medium">{data.llm_response.issue_summary ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Reasoning</div>
                  <div className="text-sm whitespace-pre-wrap">{data.llm_response.reasoning ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Recommended Actions</div>
                  {Array.isArray(data.llm_response.recommended_actions) ? (
                    <ul className="list-disc ml-4 text-sm space-y-1">
                      {data.llm_response.recommended_actions.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  ) : (
                    <div className="text-sm">{String(data.llm_response.recommended_actions ?? "—")}</div>
                  )}
                </div>
              </div>
            )}

            <div>
              <div className="text-xs text-muted-foreground mb-1">Raw Payload</div>
              <ScrollArea className="h-[250px] w-full rounded-md border p-2 bg-muted/40">
                <pre className="text-xs whitespace-pre-wrap">
                  {JSON.stringify(data, null, 2)}
                </pre>
              </ScrollArea>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="justify-between">
        <div className="text-xs text-muted-foreground">
          Last updated: {lastUpdated?.toLocaleString() ?? "Never"}
        </div>
        <Button onClick={fetchData} disabled={isLoading}>
          {isLoading ? "Refreshing..." : "Refresh"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default IssueForecaster;
