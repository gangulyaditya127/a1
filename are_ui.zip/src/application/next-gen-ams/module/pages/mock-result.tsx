import {
    useEffect,
    useMemo,
    useState,
} from "react";
import { CustomCellRendererProps } from 'ag-grid-react';
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbSeparator,
    BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import {
    ColDef,
    ICellRendererParams,
    SizeColumnsToContentStrategy,
    SizeColumnsToFitGridStrategy,
    SizeColumnsToFitProvidedWidthStrategy,
} from "ag-grid-community";
import Container from "@/components/ui/container";
import { useAppSelector } from "@/lib/redux/hooks";
import { useLazyFetchMaturityAssessmentAllDataQuery } from "../../slice/nextGenAMSAPISlice";
import DataGrid from "@/components/ui/data-grid";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
// import DialogEditForm from "../feature/DialogEditForm";

export type HelpResultMockResponse = {
    req_id: string;
    // engagement: string;
    sub_isu: string;
    // opportunity: string;
    // created_at: string;
    isu: string;
    // created_by: string;
    bu: string;
    // techStack: string;
    // teamSize: string;
    // locations: string;
    // id: string;
    // state: string;
    account: string;
};

const MockResult = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const [trigger, response] = useLazyFetchMaturityAssessmentAllDataQuery();
    const [rowData, setRowData] = useState<HelpResultMockResponse[]>([]);
    // const [openEditForm, setOpenEditForm] = useState(false);
    // const [selectedRow, setSelectedRow] = useState<HelpResultMockResponse | null>(null);

    // const handleEditClick = (row: HelpResultMockResponse) => {
    //     setSelectedRow(row);
    //     setOpenEditForm(true);
    // };

    const columnDefs: ColDef[] = [
        { field: "REQ_ID", headerName: "Req ID", filter: "agTextColumnFilter", minWidth: 100 },
        { field: "BU", headerName: "BU", filter: "agTextColumnFilter", },
        { field: "ISU", headerName: "ISU", filter: "agTextColumnFilter", },
        { field: "SUB_ISU", headerName: "Sub ISU", filter: "agTextColumnFilter", },
        { field: "ACCOUNT", headerName: "Account", filter: "agTextColumnFilter", },
        {
            headerName: "Actions",
            pinned: "right",
            cellRenderer: (params: ICellRendererParams) => <EditGrid {...params} />,
            width: 150,
            suppressSizeToFit: true
        }
    ];

    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);



    // const refreshGrid = () => {
    //     if (userDetails) {
    //         trigger();
    //     }
    // };


    useEffect(() => {
        if (userDetails) {
            trigger();
        }
    }, [userDetails]);

    useEffect(() => {
        if (response?.data) {
            setRowData(response.data as HelpResultMockResponse[]);
        }
    }, [response]);

    const autoSizeStrategy = useMemo<
        | SizeColumnsToFitGridStrategy
        | SizeColumnsToFitProvidedWidthStrategy
        | SizeColumnsToContentStrategy
    >(() => {
        return {
            type: "fitCellContents",
            defaultMinWidth: 100,
        };
    }, []);

    return (
        <section>
            <Container className="mt-4">
                <NavigateBackButton />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <BreadcrumbLink>
                                <Link to="/">ARE</Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <SlashIcon />
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>Help Submission</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <div className="mt-4">
                    <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
                        Your Help Requests
                    </h2>
                    <div className="h-[400px]">
                        <div style={gridStyle}>
                            <DataGrid
                                autoSizeStrategy={autoSizeStrategy}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                masterDetail={true}
                            />
                        </div>
                    </div>
                </div>
            </Container>

            {/* Dialog for Edit Form */}
            {/* <DialogEditForm
                open={openEditForm}
                setOpen={setOpenEditForm}
                onSuccess={() => {
                    setOpenEditForm(false);
                    refreshGrid();
                }}
                selectedRow={selectedRow}
            /> */}
        </section>
    );
};

type EditGridProps = CustomCellRendererProps & {
    onEditClick?: () => void;
};

const EditGrid = ({ data }: EditGridProps) => {
    if (data.state === 'New Request' || data.state === 'Briefing Complete') {
        return null;
    }
    console.log(data)
    return (
        <div className="flex gap-2 items-center h-full">
            <Link
                to={`/help/mock/chat/${data.REQ_ID}`}
                className="text-sm w-16 h-8 hover:underline flex items-center justify-center"
            >
                [CHAT]
            </Link>

            <Link
                to={`/help/mock/result/${data.REQ_ID}`}
                className="text-sm w-16 h-8 hover:underline flex items-center justify-center"
            >
                [RES]
            </Link>

            {/* <button
                title="Edit Row"
                onClick={onEditClick}
                className="flex items-center justify-center cursor-pointer hover:underline"
            >
                <EditIcon className="w-4 h-4" />
            </button> */}
        </div>
    );
};

export default MockResult;