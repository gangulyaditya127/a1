import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";

export default function AutoAssignmentHandbook() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(
            updateSideBarNavigation({
                hasSideBar: false,
                sideBarNavList: [],
                bottomNavList: [],
            }),
        );
        dispatch(updateTopNavigation({ navList: [], isIsmartHome: true }));
    }, []);
    return (
        <Container className="mt-24 max-w-4xl">
            <NavigateBackButton />
            <section className="prose prose-stone max-w-none dark:prose-invert prose-code:rounded-lg prose-code:px-2 ">
                <h2>Development Guidebook: Auto Assignment Bot</h2>

                <h3>1. Planning Phase</h3>
                <h4>Define Requirements</h4>
                <p>e.g.</p>
                <ul>
                    <li><strong>Purpose:</strong> Automate the assignment of ServiceNow incidents.</li>
                    <li><strong>Inputs:</strong> Login credentials, Open Incident Report, Roster.</li>
                    <li><strong>Outputs:</strong> Updated incidents with round robin assignment.</li>
                </ul>

                {/* <h4>Define Rules for Assignment</h4>
                <p>Use property files, JSON, or a database to define assignment rules. Example rules:</p>
                <ul>
                    <li><code>Priority=High → Assign to Team A</code></li>
                    <li><code>Category=Network → Assign to Network Support Team</code></li>
                </ul> */}

                <h3>2. Setup Phase</h3>
                <h4>Tools and Libraries</h4>
                <ul>
                    <li><strong>Programming Language:</strong> Java</li>
                    <li><strong>Libraries:</strong>
                        <ul>
                            <li>Selenium WebDriver</li>
                            <li>Apache POI (for Excel integration)</li>
                            <li>Log4j (for logging)</li>
                        </ul>
                    </li>
                    <li><strong>Browser Drivers:</strong> ChromeDriver</li>
                </ul>

                <h3>3. Development Phase</h3>
                <h4>Step 0: Download the starter template</h4>
                <ul>
                    <li>
                    <a href="https://tcscomprod.sharepoint.com/:f:/r/sites/SEBLTransformation/Shared%20Documents/General/Portal%20Development/ARE/Code/SNOW%20Automation%20Bot/autoassignment?csf=1&web=1&e=KSpJKX">Starter Code</a>
                    </li>
                    <li>
                        The above starter code has below functionalities
                        <ul>
                            <li>Round Robin assignment of SNOW incidents based on the Roster</li>
                        </ul>
                    </li>
                </ul>
                <h4>Step 1: Login Automation</h4>
                <pre>
                    <code>
                        {`
public static boolean loginToSNOW(WebDriver driver, String userName, String password) throws Exception {
		try {
			WebElement errorElement ;
			logger.info("Login SNOW - Max wait time 120s");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
			driver.get(Main.baseUrl);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("user_name"))))
				.sendKeys(userName);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("user_password"))))
				.sendKeys(password);
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("sysverb_login"))))
				.click();
			WebDriverWait errorWait = new WebDriverWait(driver, Duration.ofSeconds(5));
			
			try {
				errorElement = errorWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.outputmsg_text")));
				System.out.println(errorElement);
				return false;
			} catch (Exception e) {
				logger.error("Error while fetching error message");
			}
			
			logger.info("Login Successfull");
			return true;
		} catch (Exception e) {
			logger.error("failed while logging in");
			logger.error(e.toString());
			// TODO: handle exception
			throw new Exception(e); 
		}
	}
`}
                    </code>
                </pre>

                <h4>Step 2: Incident Retrieval</h4>
                <pre>
                    <code>{`
public static List<Incident> getIncidentList(WebDriver driver) throws InterruptedException{
    List<Incident> incidentList=new ArrayList<>();
    logger.info("Loading Report");
    driver.get(Main.reportUrl);
    logger.info("Sleep for 5s");
    Thread.sleep(5*1000);
    logger.info("Load Incidents - Max wait time 120s");
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("incident_table"))));
    List<WebElement> incidentRow=driver.findElements(By.xpath("//*[contains(@id,\"row_incident_\")]"));
    for(WebElement row:incidentRow) {
        try {
            WebElement anchor=row.findElement(By.xpath(".//td[3]/a"));
            incidentList.add(new Incident(anchor.getText(),anchor.getAttribute("href")));
        } catch (Exception e) {
            logger.error("Failed to extract incident");
            // TODO: handle exception
        }
    }
    
    return incidentList;
}
	                    
`}
                    </code>
                </pre>

                <h4>Step 3: Assignment</h4>
                <pre>
                    <code>
                        {`
public static void assignTicket(WebDriver driver,String incidentUrl, String assignee,String incidentNumber) {
    try {
        logger.info("Assign "+incidentNumber+" to "+assignee);
        driver.get(incidentUrl);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("incident.state")));
        Select stateSelect = new Select(driver.findElement(By.id("incident.state")));
        stateSelect.selectByVisibleText("In Progress");
        wait.until(ExpectedConditions.elementToBeClickable(By.id("sys_display.incident.assigned_to")))
            .sendKeys(assignee);
        Thread.sleep(1000*1);
        wait.until(ExpectedConditions.elementToBeClickable(By.id("activity-stream-work_notes-textarea")))
            .sendKeys("Acknowledged by TCS ARE Autoassignment bot");
        
        logger.info("Update Assignee");
        wait.until(ExpectedConditions.elementToBeClickable(By.id("sysverb_update")))
            .click();
        logger.info("Sleep for 2 sec");
        Thread.sleep(1000*2);
    } catch (Exception e) {
        // TODO: handle exception
        logger.error("Failed to assign incident "+incidentNumber+" will try again after some time");
        logger.error(e.toString());
    }
}
                        
`}
                    </code>
                </pre>
                <h3>5. Deployment Phase</h3>
                <ul>
                    <li>Package the project as a JAR/WAR file.</li>
                    <li>Schedule the bot using Windows Task Scheduler or Linux Cron jobs.</li>
                    <li>Deploy browser drivers and rule files with the bot.</li>
                </ul>

                <h3>6. Maintenance</h3>
                <ul>
                    <li>Regularly update rules.</li>
                    <li>Monitor logs for issues.</li>
                    <li>Upgrade Selenium and browser drivers as needed.</li>
                </ul>
            </section>
        </Container>
    )
}