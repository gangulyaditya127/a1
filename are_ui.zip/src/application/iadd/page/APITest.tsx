import { useEffect, useState } from "react";

const APITest = () => {
  const [apiData, setApiData] = useState<any>([]);
  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    console.log({env:import.meta.env})
    let data = await fetch(`${import.meta.env.VITE_SPRING_BASE_URL}/iadd/getSectorRegionList`);
    data = await data.json();
    setApiData(data);
  };
  return <pre>{JSON.stringify(apiData)}</pre>;
};

export default APITest;
