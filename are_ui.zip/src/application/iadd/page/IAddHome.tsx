import Container from "@/components/ui/container";
import IAddFilters from "../features/IAddFilters";
import IAddDashboardTable from "../features/IAddDashboardTable";

function IAddHome() {
  return (
    <section className="p-2">
      <Container>
        <div className="pb-4 mt-4">
          <IAddFilters />
        </div>
        <IAddDashboardTable />
      </Container>
    </section>
  );
}
export default IAddHome;
