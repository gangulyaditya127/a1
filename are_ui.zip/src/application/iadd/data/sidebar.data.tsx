import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Home",
          icon: "home",
          route: "/iadd",
        },
      ],
    },
  ],
  bottomNavList: [
    // {
    //   key: "7",
    //   content: "Help",
    //   icon: "life-buoy",
    //   route: ".",
    // },
  ],
};

export default SIDEBAR_DATA;
