import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "Integrated Application Dependency Dashboard",
    route: "/iadd",
    key: "1",
  },
];
