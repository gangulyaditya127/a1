const MOCK_DATA = [
  {
    application: "Customer Onboarding System",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: [],
        gold: [
          {
            application: "Mobile Banking App",
            Status: "R",
          },
          {
            application: "Loan Application System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Online Account Opening",
            Status: "A",
          },
          {
            application: "Branch Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "ATM Network Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking",
            tier_1_app: [
              {
                application: "Mobile Banking App",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "R",
              },
              {
                application: "Loan Application System",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Online Account Opening",
                contact: {
                  name: "Mike Johnson",
                  mail: "mike.johnson@tcs.com",
                  phone: "+1-555-555-6666",
                },
                Status: "A",
              },
              {
                application: "Branch Management System",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
              {
                application: "ATM Network Management",
                Status: "R",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
              },
            ],
            overallStatus: "R",
          },
          {
            portfolioName: "Wealth waves",
            tier_1_app: [
              {
                application: "Mobile Banking App",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "R",
              },
            ],
            tier_2_app: [
              {
                application: "ATM Network Management",
                Status: "R",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
              },
            ],
            overallStatus: "R",
          },
          {
            portfolioName: "Cashflow",
            tier_1_app: [
              {
                application: "Loan Application System",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Online Account Opening",
                contact: {
                  name: "Mike Johnson",
                  mail: "mike.johnson@tcs.com",
                  phone: "+1-555-555-6666",
                },
                Status: "A",
              },
              {
                application: "Branch Management System",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            overallStatus: "A",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: ["Customer Onboarding System"],
        gold: [
          {
            application: "Trade Finance Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Credit Risk Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Invoice Processing System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Trade Finance Platform",
                contact: {
                  name: "Chris Lee",
                  mail: "chris.lee@tcs.com",
                  phone: "+1-555-999-0000",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Credit Risk Management",
                contact: {
                  name: "Sara Wilson",
                  mail: "sara.wilson@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Investment Portfolio Tracker",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Retirement Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Wealth Advisory System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Investment Portfolio Tracker",
                contact: {
                  name: "Bob Martin",
                  mail: "bob.martin@tcs.com",
                  phone: "+1-555-444-5555",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Retirement Planning Tool",
                contact: {
                  name: "Nancy Hall",
                  mail: "nancy.hall@tcs.com",
                  phone: "+1-555-666-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Commercial Banking",
        application: [],
        gold: [
          {
            application: "Treasury Management System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Corporate Payment Hub",
            Status: "A",
          },
          {
            application: "Merchant Services Platform",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Credit Underwriting System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Commercial Banking ",
            tier_1_app: [
              {
                application: "Treasury Management System",
                contact: {
                  name: "Tom Brown",
                  mail: "tom.brown@tcs.com",
                  phone: "+1-555-888-9999",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Corporate Payment Hub",
                contact: {
                  name: "Lisa Clark",
                  mail: "lisa.clark@tcs.com",
                  phone: "+1-555-222-3333",
                },
                Status: "A",
              },
              {
                application: "Merchant Services Platform",
                contact: {
                  name: "James Taylor",
                  mail: "james.taylor@tcs.com",
                  phone: "+1-555-444-6666",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Insurance",
        application: [],
        gold: [
          {
            application: "Claims Processing System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Policy Management System",
            Status: "A",
          },
          {
            application: "Fraud Detection System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Service Portal",
            Status: "R",
          },
          {
            application: "Underwriting Analysis Tool",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Insurance ",
            tier_1_app: [
              {
                application: "Claims Processing System",
                contact: {
                  name: "Steve White",
                  mail: "steve.white@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Policy Management System",
                contact: {
                  name: "Karen Moore",
                  mail: "karen.moore@tcs.com",
                  phone: "+1-555-111-4444",
                },
                Status: "A",
              },
              {
                application: "Fraud Detection System",
                contact: {
                  name: "Greg Wright",
                  mail: "greg.wright@tcs.com",
                  phone: "+1-555-333-5555",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Equity Trading Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Compliance Monitoring System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Equity Trading Platform",
                contact: {
                  name: "Diana Scott",
                  mail: "diana.scott@tcs.com",
                  phone: "+1-555-999-2222",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Management System",
                contact: {
                  name: "Robert King",
                  mail: "robert.king@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Private Banking",
        application: [],
        gold: [
          {
            application: "High Net Worth Client Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Private Wealth Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Exclusive Offers Portal",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Private Banking ",
            tier_1_app: [
              {
                application: "High Net Worth Client Management",
                contact: {
                  name: "Alice Cooper",
                  mail: "alice.cooper@tcs.com",
                  phone: "+1-555-222-4444",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Private Wealth Planning Tool",
                contact: {
                  name: "David Beckham",
                  mail: "david.beckham@tcs.com",
                  phone: "+1-555-333-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Account Management System",
    region: "Europe",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Account Management System"],
        gold: [
          {
            application: "Mobile Banking App",
            Status: "A",
          },
          {
            application: "Loan Application System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Online Account Opening",
            Status: "A",
          },
          {
            application: "Branch Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "ATM Network Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Mobile Banking App",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "A",
              },
              {
                application: "Loan Application System",
                contact: {
                  name: "Jane Smith",
                  mail: "jane.smith@tcs.com",
                  phone: "+1-555-333-4444",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Online Account Opening",
                contact: {
                  name: "Mike Johnson",
                  mail: "mike.johnson@tcs.com",
                  phone: "+1-555-555-6666",
                },
                Status: "A",
              },
              {
                application: "Branch Management System",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            overallStatus: "A",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Trade Finance Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Credit Risk Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Invoice Processing System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Trade Finance Platform",
                contact: {
                  name: "Chris Lee",
                  mail: "chris.lee@tcs.com",
                  phone: "+1-555-999-0000",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Credit Risk Management",
                contact: {
                  name: "Sara Wilson",
                  mail: "sara.wilson@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Investment Portfolio Tracker",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Retirement Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Wealth Advisory System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Investment Portfolio Tracker",
                contact: {
                  name: "Bob Martin",
                  mail: "bob.martin@tcs.com",
                  phone: "+1-555-444-5555",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Retirement Planning Tool",
                contact: {
                  name: "Nancy Hall",
                  mail: "nancy.hall@tcs.com",
                  phone: "+1-555-666-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Commercial Banking",
        application: [],
        gold: [
          {
            application: "Treasury Management System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Corporate Payment Hub",
            Status: "A",
          },
          {
            application: "Merchant Services Platform",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Credit Underwriting System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Commercial Banking ",
            tier_1_app: [
              {
                application: "Treasury Management System",
                contact: {
                  name: "Tom Brown",
                  mail: "tom.brown@tcs.com",
                  phone: "+1-555-888-9999",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Corporate Payment Hub",
                contact: {
                  name: "Lisa Clark",
                  mail: "lisa.clark@tcs.com",
                  phone: "+1-555-222-3333",
                },
                Status: "A",
              },
              {
                application: "Merchant Services Platform",
                contact: {
                  name: "James Taylor",
                  mail: "james.taylor@tcs.com",
                  phone: "+1-555-444-6666",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Insurance",
        application: [],
        gold: [
          {
            application: "Claims Processing System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Policy Management System",
            Status: "A",
          },
          {
            application: "Fraud Detection System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Service Portal",
            Status: "R",
          },
          {
            application: "Underwriting Analysis Tool",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Insurance ",
            tier_1_app: [
              {
                application: "Claims Processing System",
                contact: {
                  name: "Steve White",
                  mail: "steve.white@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Policy Management System",
                contact: {
                  name: "Karen Moore",
                  mail: "karen.moore@tcs.com",
                  phone: "+1-555-111-4444",
                },
                Status: "A",
              },
              {
                application: "Fraud Detection System",
                contact: {
                  name: "Greg Wright",
                  mail: "greg.wright@tcs.com",
                  phone: "+1-555-333-5555",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Equity Trading Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Compliance Monitoring System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Equity Trading Platform",
                contact: {
                  name: "Diana Scott",
                  mail: "diana.scott@tcs.com",
                  phone: "+1-555-999-2222",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Management System",
                contact: {
                  name: "Robert King",
                  mail: "robert.king@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Private Banking",
        application: [],
        gold: [
          {
            application: "High Net Worth Client Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Private Wealth Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Exclusive Offers Portal",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Private Banking ",
            tier_1_app: [
              {
                application: "High Net Worth Client Management",
                contact: {
                  name: "Alice Cooper",
                  mail: "alice.cooper@tcs.com",
                  phone: "+1-555-222-4444",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Private Wealth Planning Tool",
                contact: {
                  name: "David Beckham",
                  mail: "david.beckham@tcs.com",
                  phone: "+1-555-333-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Payment Processing System",
    region: "Asia",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Payment Processing System"],
        gold: [
          {
            application: "Mobile Banking App",
            Status: "A",
          },
          {
            application: "Loan Application System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Online Account Opening",
            Status: "A",
          },
          {
            application: "Branch Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "ATM Network Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Mobile Banking App",
                contact: {
                  name: "Sudhanshu Singh",
                  mail: "singh.sudhanshu@tcs.com",
                  phone: "+1-555-111-2222",
                },
                Status: "A",
              },
              {
                application: "Loan Application System",
                contact: {
                  name: "Jane Smith",
                  mail: "jane.smith@tcs.com",
                  phone: "+1-555-333-4444",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Online Account Opening",
                contact: {
                  name: "Mike Johnson",
                  mail: "mike.johnson@tcs.com",
                  phone: "+1-555-555-6666",
                },
                Status: "A",
              },
              {
                application: "Branch Management System",
                contact: {
                  name: "Emily Davis",
                  mail: "emily.davis@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            overallStatus: "A",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Trade Finance Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Credit Risk Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Invoice Processing System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Trade Finance Platform",
                contact: {
                  name: "Chris Lee",
                  mail: "chris.lee@tcs.com",
                  phone: "+1-555-999-0000",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Credit Risk Management",
                contact: {
                  name: "Sara Wilson",
                  mail: "sara.wilson@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Investment Portfolio Tracker",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Retirement Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Wealth Advisory System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Investment Portfolio Tracker",
                contact: {
                  name: "Bob Martin",
                  mail: "bob.martin@tcs.com",
                  phone: "+1-555-444-5555",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Retirement Planning Tool",
                contact: {
                  name: "Nancy Hall",
                  mail: "nancy.hall@tcs.com",
                  phone: "+1-555-666-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Commercial Banking",
        application: [],
        gold: [
          {
            application: "Treasury Management System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Corporate Payment Hub",
            Status: "A",
          },
          {
            application: "Merchant Services Platform",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Credit Underwriting System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Commercial Banking ",
            tier_1_app: [
              {
                application: "Treasury Management System",
                contact: {
                  name: "Tom Brown",
                  mail: "tom.brown@tcs.com",
                  phone: "+1-555-888-9999",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Corporate Payment Hub",
                contact: {
                  name: "Lisa Clark",
                  mail: "lisa.clark@tcs.com",
                  phone: "+1-555-222-3333",
                },
                Status: "A",
              },
              {
                application: "Merchant Services Platform",
                contact: {
                  name: "James Taylor",
                  mail: "james.taylor@tcs.com",
                  phone: "+1-555-444-6666",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Insurance",
        application: [],
        gold: [
          {
            application: "Claims Processing System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Policy Management System",
            Status: "A",
          },
          {
            application: "Fraud Detection System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Service Portal",
            Status: "R",
          },
          {
            application: "Underwriting Analysis Tool",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Insurance ",
            tier_1_app: [
              {
                application: "Claims Processing System",
                contact: {
                  name: "Steve White",
                  mail: "steve.white@tcs.com",
                  phone: "+1-555-777-8888",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Policy Management System",
                contact: {
                  name: "Karen Moore",
                  mail: "karen.moore@tcs.com",
                  phone: "+1-555-111-4444",
                },
                Status: "A",
              },
              {
                application: "Fraud Detection System",
                contact: {
                  name: "Greg Wright",
                  mail: "greg.wright@tcs.com",
                  phone: "+1-555-333-5555",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Equity Trading Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Compliance Monitoring System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Equity Trading Platform",
                contact: {
                  name: "Diana Scott",
                  mail: "diana.scott@tcs.com",
                  phone: "+1-555-999-2222",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Management System",
                contact: {
                  name: "Robert King",
                  mail: "robert.king@tcs.com",
                  phone: "+1-555-111-3333",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Private Banking",
        application: [],
        gold: [
          {
            application: "High Net Worth Client Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Private Wealth Planning Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Exclusive Offers Portal",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Private Banking ",
            tier_1_app: [
              {
                application: "High Net Worth Client Management",
                contact: {
                  name: "Alice Cooper",
                  mail: "alice.cooper@tcs.com",
                  phone: "+1-555-222-4444",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Private Wealth Planning Tool",
                contact: {
                  name: "David Beckham",
                  mail: "david.beckham@tcs.com",
                  phone: "+1-555-333-7777",
                },
                Status: "A",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Loan Origination System",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Loan Origination System"],
        gold: [
          {
            application: "Credit Underwriting System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Loan Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Service Platform",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Credit Underwriting System",
                contact: {
                  name: "Alice Smith",
                  mail: "alice.smith@tcs.com",
                  phone: "+1-555-101-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Loan Management System",
                contact: {
                  name: "Bob Johnson",
                  mail: "bob.johnson@tcs.com",
                  phone: "+1-555-202-3030",
                },
                Status: "A",
              },
              {
                application: "Customer Service Platform",
                contact: {
                  name: "Carol Williams",
                  mail: "carol.williams@tcs.com",
                  phone: "+1-555-303-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Corporate Lending Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Cash Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Trade Finance System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Corporate Lending Platform",
                contact: {
                  name: "David Brown",
                  mail: "david.brown@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Cash Management System",
                contact: {
                  name: "Eva Davis",
                  mail: "eva.davis@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Trade Finance System",
                contact: {
                  name: "Frank Clark",
                  mail: "frank.clark@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Equity Trading Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Compliance Monitoring System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Equity Trading Platform",
                contact: {
                  name: "George White",
                  mail: "george.white@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Management System",
                contact: {
                  name: "Hannah Martin",
                  mail: "hannah.martin@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Compliance Monitoring System",
                contact: {
                  name: "Ian Lewis",
                  mail: "ian.lewis@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Portfolio Management System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Client Reporting System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Financial Planning Tool",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Portfolio Management System",
                contact: {
                  name: "Jackie Harris",
                  mail: "jackie.harris@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Client Reporting System",
                contact: {
                  name: "Karen Thompson",
                  mail: "karen.thompson@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Financial Planning Tool",
                contact: {
                  name: "Liam Walker",
                  mail: "liam.walker@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Customer Relationship Management",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Customer Relationship Management"],
        gold: [
          {
            application: "Customer Data Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Marketing Automation Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Feedback System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Customer Data Platform",
                contact: {
                  name: "Mia Green",
                  mail: "mia.green@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Marketing Automation Tool",
                contact: {
                  name: "Noah Martinez",
                  mail: "noah.martinez@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Customer Feedback System",
                contact: {
                  name: "Olivia Wilson",
                  mail: "olivia.wilson@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Customer Experience Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Customer Analytics Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Client Feedback Portal",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Customer Experience Platform",
                contact: {
                  name: "Parker Smith",
                  mail: "parker.smith@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Customer Analytics Tool",
                contact: {
                  name: "Quinn Brown",

                  mail: "quinn.brown@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Client Feedback Portal",
                contact: {
                  name: "Riley Johnson",
                  mail: "riley.johnson@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Client Relationship Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Client Reporting Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Client Feedback Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Client Relationship Management",
                contact: {
                  name: "Samantha White",
                  mail: "samantha.white@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Client Reporting Tool",
                contact: {
                  name: "Tyler Davis",
                  mail: "tyler.davis@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Client Feedback Management",
                contact: {
                  name: "Uma Martin",
                  mail: "uma.martin@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Client Relationship System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Client Communication Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Client Feedback Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Client Relationship System",
                contact: {
                  name: "Victoria Harris",
                  mail: "victoria.harris@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Client Communication Tool",
                contact: {
                  name: "William Thompson",
                  mail: "william.thompson@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Client Feedback Analysis",
                contact: {
                  name: "Xander Walker",
                  mail: "xander.walker@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Risk Assessment Platform",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Risk Assessment Platform"],
        gold: [
          {
            application: "Credit Risk Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Monitoring System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Customer Risk Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Credit Risk Management",
                contact: {
                  name: "Yasmine Davis",
                  mail: "yasmine.davis@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Monitoring System",
                contact: {
                  name: "Zachary Brown",
                  mail: "zachary.brown@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Customer Risk Analysis",
                contact: {
                  name: "Aaron Johnson",
                  mail: "aaron.johnson@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Operational Risk Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Market Risk Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Regulatory Risk Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Operational Risk Management",
                contact: {
                  name: "Bella Clark",
                  mail: "bella.clark@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Market Risk Management",
                contact: {
                  name: "Carter Smith",
                  mail: "carter.smith@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Regulatory Risk Management",
                contact: {
                  name: "Dylan Brown",
                  mail: "dylan.brown@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Trading Risk Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Liquidity Risk Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Counterparty Risk Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Trading Risk Management",
                contact: {
                  name: "Ethan Davis",
                  mail: "ethan.davis@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Liquidity Risk Management",
                contact: {
                  name: "Faith Johnson",
                  mail: "faith.johnson@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Counterparty Risk Management",
                contact: {
                  name: "Grace Brown",
                  mail: "grace.brown@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Portfolio Risk Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Client Risk Assessment",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Financial Risk Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Portfolio Risk Management",
                contact: {
                  name: "Henry White",
                  mail: "henry.white@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Client Risk Assessment",
                contact: {
                  name: "Ivy Green",
                  mail: "ivy.green@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Financial Risk Analysis",
                contact: {
                  name: "Jake Martinez",
                  mail: "jake.martinez@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Trade Finance Platform",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Trade Finance Platform"],
        gold: [
          {
            application: "Documentary Credit System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Documentary Collections",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Bank Guarantees System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Documentary Credit System",
                contact: {
                  name: "Lily Thompson",
                  mail: "lily.thompson@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Documentary Collections",
                contact: {
                  name: "Max Martinez",
                  mail: "max.martinez@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Bank Guarantees System",
                contact: {
                  name: "Nina Harris",
                  mail: "nina.harris@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Export Finance System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Trade Loan Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Import Finance System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Export Finance System",
                contact: {
                  name: "Owen Brown",
                  mail: "owen.brown@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Trade Loan Management",
                contact: {
                  name: "Penny Clark",
                  mail: "penny.clark@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Import Finance System",
                contact: {
                  name: "Quinn Smith",
                  mail: "quinn.smith@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Commodity Trade Finance",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Trade Credit Insurance",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Trade Asset Management",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Commodity Trade Finance",
                contact: {
                  name: "Rachel Martinez",
                  mail: "rachel.martinez@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Trade Credit Insurance",
                contact: {
                  name: "Sophie Johnson",
                  mail: "sophie.johnson@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Trade Asset Management",
                contact: {
                  name: "Toby Brown",
                  mail: "toby.brown@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Trade Investment Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Trade Portfolio Management",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Trade Risk Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Trade Investment Platform",
                contact: {
                  name: "Ursula Davis",
                  mail: "ursula.davis@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Trade Portfolio Management",
                contact: {
                  name: "Victor Clark",
                  mail: "victor.clark@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Trade Risk Analysis",
                contact: {
                  name: "Wendy Brown",
                  mail: "wendy.brown@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Payment Processing System",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Payment Processing System"],
        gold: [
          {
            application: "Payment Gateway",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Fraud Detection System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Payment Reconciliation",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Payment Gateway",
                contact: {
                  name: "Xander Wilson",
                  mail: "xander.wilson@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Fraud Detection System",
                contact: {
                  name: "Yasmine Martinez",
                  mail: "yasmine.martinez@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Payment Reconciliation",
                contact: {
                  name: "Zachary Harris",
                  mail: "zachary.harris@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Corporate Payment Platform",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Treasury Management System",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Bulk Payment Processing",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Corporate Payment Platform",
                contact: {
                  name: "Ava Davis",
                  mail: "ava.davis@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Treasury Management System",
                contact: {
                  name: "Ben Clark",
                  mail: "ben.clark@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Bulk Payment Processing",
                contact: {
                  name: "Cara Smith",
                  mail: "cara.smith@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Securities Payment System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Capital Markets Payment",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Investment Fund Payment",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Securities Payment System",
                contact: {
                  name: "David Wilson",
                  mail: "david.wilson@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Capital Markets Payment",
                contact: {
                  name: "Evelyn Martinez",
                  mail: "evelyn.martinez@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Investment Fund Payment",
                contact: {
                  name: "Frank Harris",
                  mail: "frank.harris@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Wealth Payment Processing",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Advisory Fee Payment",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Wealth Transfer Payment",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Wealth Payment Processing",
                contact: {
                  name: "Grace Clark",
                  mail: "grace.clark@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Advisory Fee Payment",
                contact: {
                  name: "Hank Smith",
                  mail: "hank.smith@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Wealth Transfer Payment",
                contact: {
                  name: "Ivy Davis",
                  mail: "ivy.davis@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Portfolio Management System",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Portfolio Management System"],
        gold: [
          {
            application: "Client Portfolio Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Portfolio Reporting Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Investment Portfolio Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "Client Portfolio Management",
                contact: {
                  name: "Jack Wilson",
                  mail: "jack.wilson@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Portfolio Reporting Tool",
                contact: {
                  name: "Kate Martinez",
                  mail: "kate.martinez@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Investment Portfolio Analysis",
                contact: {
                  name: "Leo Harris",
                  mail: "leo.harris@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Corporate Portfolio Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Portfolio Risk Reporting",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Financial Portfolio Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Corporate Portfolio Management",
                contact: {
                  name: "Mia Clark",
                  mail: "mia.clark@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Portfolio Risk Reporting",
                contact: {
                  name: "Nina Wilson",
                  mail: "nina.wilson@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Financial Portfolio Analysis",
                contact: {
                  name: "Oscar Martinez",
                  mail: "oscar.martinez@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Investment Portfolio Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Portfolio Analysis Tool",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Equity Portfolio Analysis",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Investment Portfolio Management",
                contact: {
                  name: "Paul Davis",
                  mail: "paul.davis@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Portfolio Analysis Tool",
                contact: {
                  name: "Quincy Brown",
                  mail: "quincy.brown@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Equity Portfolio Analysis",
                contact: {
                  name: "Ryan Johnson",
                  mail: "ryan.johnson@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Wealth Portfolio Management",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Portfolio Performance Analysis",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Risk Analysis Tool",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Wealth Portfolio Management",
                contact: {
                  name: "Sophie Martinez",
                  mail: "sophie.martinez@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Portfolio Performance Analysis",
                contact: {
                  name: "Tom Harris",
                  mail: "tom.harris@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Risk Analysis Tool",
                contact: {
                  name: "Uma Wilson",
                  mail: "uma.wilson@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {
    application: "Compliance Management System",
    region: "North America",
    sector: "BFSI",
    dependencyDashboard: [
      {
        lob: "Retail Banking",
        application: ["Compliance Management System"],
        gold: [
          {
            application: "AML Monitoring",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "KYC Verification",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Regulatory Reporting",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Retail Banking ",
            tier_1_app: [
              {
                application: "AML Monitoring",
                contact: {
                  name: "Vera Clark",
                  mail: "vera.clark@tcs.com",
                  phone: "+1-555-010-2020",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "KYC Verification",
                contact: {
                  name: "Will Martinez",
                  mail: "will.martinez@tcs.com",
                  phone: "+1-555-020-3030",
                },
                Status: "A",
              },
              {
                application: "Regulatory Reporting",
                contact: {
                  name: "Xena Harris",
                  mail: "xena.harris@tcs.com",
                  phone: "+1-555-030-4040",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Corporate Banking",
        application: [],
        gold: [
          {
            application: "Corporate Compliance Tool",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Risk Assessment Module",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Audit Trail System",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Corporate Banking ",
            tier_1_app: [
              {
                application: "Corporate Compliance Tool",
                contact: {
                  name: "Yara Davis",
                  mail: "yara.davis@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Risk Assessment Module",
                contact: {
                  name: "Zane Clark",
                  mail: "zane.clark@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Audit Trail System",
                contact: {
                  name: "Amy Wilson",
                  mail: "amy.wilson@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Investment Banking",
        application: [],
        gold: [
          {
            application: "Trade Compliance",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Market Surveillance",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Regulatory Filing",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Investment Banking ",
            tier_1_app: [
              {
                application: "Trade Compliance",
                contact: {
                  name: "Brian Martinez",
                  mail: "brian.martinez@tcs.com",
                  phone: "+1-555-707-8080",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Market Surveillance",
                contact: {
                  name: "Claire Harris",
                  mail: "claire.harris@tcs.com",
                  phone: "+1-555-808-9090",
                },
                Status: "A",
              },
              {
                application: "Regulatory Filing",
                contact: {
                  name: "David Johnson",
                  mail: "david.johnson@tcs.com",
                  phone: "+1-555-909-0101",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
      {
        lob: "Wealth Management",
        application: [],
        gold: [
          {
            application: "Wealth Compliance System",
            Status: "A",
          },
        ],
        silver: [
          {
            application: "Client Due Diligence",
            Status: "A",
          },
        ],
        bronze: [
          {
            application: "Compliance Reporting",
            Status: "R",
          },
        ],
        affectedPortfolioData: [
          {
            portfolioName: "Wealth Management ",
            tier_1_app: [
              {
                application: "Wealth Compliance System",
                contact: {
                  name: "Eva Clark",
                  mail: "eva.clark@tcs.com",
                  phone: "+1-555-404-5050",
                },
                Status: "A",
              },
            ],
            tier_2_app: [
              {
                application: "Client Due Diligence",
                contact: {
                  name: "Fiona Martinez",
                  mail: "fiona.martinez@tcs.com",
                  phone: "+1-555-505-6060",
                },
                Status: "A",
              },
              {
                application: "Compliance Reporting",
                contact: {
                  name: "George Wilson",
                  mail: "george.wilson@tcs.com",
                  phone: "+1-555-606-7070",
                },
                Status: "R",
              },
            ],
            overallStatus: "R",
          },
        ],
      },
    ],
  },
  {'application': 'DAHC', 'region': 'SEAL', 'sector': 'BFSI', 'dependencyDashboard': [{'lob': 'Agentic AMS', 'application': ['DAHC'], 'goldCount': 2, 'gold': [{'application': 'Batch Analyzer', 'Status': 'R'}, {'application': 'ICERT', 'Status': 'A'}], 'silverCount': 1, 'silver': [{'application': 'Triage Bot', 'Status': 'A'}], 'bronze': [{'application': 'IRR', 'Status': 'R'}], 'affectedPortfolioData': [{'portfolioName': 'Agentic AMS', 'tier_1_app': [{'application': 'Batch Analyzer', 'contact': {'name': 'Sudhanshu Singh', 'mail': 'singh.sudhanshu@tcs.com', 'phone': '+1-555-111-2222'}, 'Status': 'R'}, {'application': 'ICERT', 'contact': {'name': 'Sudhanshu Singh', 'mail': 'singh.sudhanshu@tcs.com', 'phone': '+1-555-111-2222'}, 'Status': 'A'}], 'tier_2_app': [{'application': 'Triage Bot', 'contact': {'name': 'Mike Johnson', 'mail': 'mike.johnson@tcs.com', 'phone': '+1-555-555-6666'}, 'Status': 'A'}, {'application': 'IRR', 'Status': 'R', 'contact': {'name': 'Emily Davis', 'mail': 'emily.davis@tcs.com', 'phone': '+1-555-777-8888'}}], 'overallStatus': 'R'}]}]}
];

export const getSector = () => {
  return [...new Set(MOCK_DATA.map((el) => el.sector))].map((el) => ({
    value: el,
    label: el,
  }));
};

export const getRegion = (sectorName: string) => {
  return [
    ...new Set(
      MOCK_DATA.filter((el) => el.sector == sectorName).map((el) => el.region),
    ),
  ].map((el) => ({ value: el, label: el }));
};

export const getApplication = (regionName: string) => {
  return [
    ...new Set(
      MOCK_DATA.filter((el) => el.region == regionName).map(
        (el) => el.application,
      ),
    ),
  ].map((el) => ({ value: el, label: el }));
};

export const getDependencyDashboardData = (appName: string) => {
  return MOCK_DATA.filter((el) => el.application == appName)?.[0]
    .dependencyDashboard;
};

export const getPortfolioDependencyData = (appName: string, lob: string) => {
  return MOCK_DATA.filter(
    (el) => el.application == appName,
  )?.[0].dependencyDashboard.filter((el) => el.lob == lob)?.[0]
    .affectedPortfolioData;
};
