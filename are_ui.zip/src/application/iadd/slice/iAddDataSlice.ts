import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { getRegion, getSector, getApplication, getDependencyDashboardData } from "../data/mockup.data";

type IAddSliceDataType = {
  sector: string;
  region: string;
  application: string;
  dependencyData: any[];
  portfolioDependencyData: any[];
};

const initialState: IAddSliceDataType = {
  sector: getSector()?.[0]?.value,
  region: getRegion(getSector()?.[0]?.value)?.[3]?.value,
  application: getApplication(getRegion(getSector()?.[0]?.value)?.[3]?.value)?.[0]?.value,
  dependencyData: getDependencyDashboardData(getApplication(getRegion(getSector()?.[0]?.value)?.[3]?.value)?.[0]?.value),
  portfolioDependencyData: [],
};

const iAddDataSlice = createSlice({
  name: "iAddDataSlice",
  initialState,
  reducers: {
    updateSector: (state, action: PayloadAction<string>) => {
      const { payload } = action;
      state.sector = payload;
      state.region = "";
      state.application = "";
      state.dependencyData = [];
    },
    updateRegion: (state, action: PayloadAction<string>) => {
      const { payload } = action;
      state.region = payload;
      state.application = "";
      state.dependencyData = [];
    },
    updateApplication: (state, action: PayloadAction<string>) => {
      const { payload } = action;
      state.application = payload;
      state.dependencyData = [];
    },
    updateDependencyData: (state, action) => {
      const { payload } = action;
      state.dependencyData = payload;
    },
    updatePorfolioDependencyData: (state, action) => {
      state.portfolioDependencyData = action.payload;
    },
  },
});

export const {
  updateApplication,
  updateDependencyData,
  updateRegion,
  updateSector,
  updatePorfolioDependencyData,
} = iAddDataSlice.actions;

export default iAddDataSlice.reducer;
