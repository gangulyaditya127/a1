import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Icon } from "@/components/ui/icon";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import IAddSubPortfolioDashboard from "./IAddSubPortfolioDashboard";
import { updatePorfolioDependencyData } from "../slice/iAddDataSlice";
import { getPortfolioDependencyData } from "../data/mockup.data";
import { cn } from "@/lib/tailwind.utils";
const IAddDashboardTable = () => {
  const dashboardData = useAppSelector(
    (state) => state.iAddData.dependencyData,
  );
  const app = useAppSelector((state) => state.iAddData.application);
  const dispatch = useAppDispatch();

  const updatePortfolioDependency = (appData: any[]) => {
    dispatch(updatePorfolioDependencyData(appData));
  };

  const totalValues = dashboardData?.reduce(
    (acc, el) => {
      return {
        gold: acc.gold + el.gold.length,
        silver: acc.silver + el.silver.length,
        bronze: acc.bronze + el.bronze.length,
      };
    },
    { gold: 0, silver: 0, bronze: 0 },
  );

  return (
    <ScrollArea className="h-[65vh] overflow-auto border">
      <Table className="overflow-auto">
        {dashboardData?.length > 0 ? (
          <TableHeader className="sticky top-0 z-20 bg-black dark:bg-secondary [&_tr]:border-0">
            <TableRow className="border-0 border-b-0 hover:bg-black">
              <TableHead className="w-[200px] p-0 text-center">
                <div className="dark: grid h-full place-items-center text-neutral-50">
                  Line of Business
                </div>
              </TableHead>
              <TableHead className="border-x border-neutral-900 p-0 text-center dark:border-neutral-700">
                <div className="dark: grid h-full place-items-center text-neutral-50">
                  Application
                </div>
              </TableHead>
              <TableHead className="p-0 text-center">
                <div className="dark: flex h-full items-center justify-center">
                  <div className="flex gap-2">
                    <Icon
                      name="crown"
                      className="size-5 fill-yellow-400 text-yellow-400"
                    />
                    <div className="text-yellow-400">
                      <span>Gold</span>
                      {totalValues?.gold ? (
                        <span> ({totalValues.gold})</span>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </TableHead>
              <TableHead className="border-x border-neutral-900 p-0 dark:border-neutral-700">
                <div className="dark: flex h-full items-center justify-center">
                  <div className="flex gap-2">
                    <Icon
                      name="crown"
                      className="size-5 fill-zinc-400 text-zinc-400 dark:fill-zinc-200 dark:text-zinc-200"
                    />
                    <div className="text-zinc-400 dark:text-zinc-200">
                      <span>Silver</span>
                      {totalValues?.silver ? (
                        <span> ({totalValues.silver})</span>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </TableHead>
              <TableHead className="p-0">
                <div className="dark: flex h-full items-center justify-center">
                  <div className="flex gap-2">
                    <Icon
                      name="crown"
                      className="size-5 fill-amber-600 text-amber-600"
                    />
                    <div className="text-amber-600">
                      <span>Bronze</span>
                      {totalValues?.bronze ? (
                        <span> ({totalValues.bronze})</span>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </TableHead>
            </TableRow>
          </TableHeader>
        ) : (
          ""
        )}
        <TableBody className="h-[50vh] overflow-auto">
          {!(dashboardData?.length > 0) ? (
            <EmptyDataContainer />
          ) : (
            dashboardData?.map((el, i) => {
              return (
                <TableRow
                  key={i}
                  className={cn(`${i % 2 == 0 ? "bg-muted/20" : ""}`)}
                >
                  <Dialog>
                    <DialogTrigger asChild>
                      <TableCell
                        className="cursor-pointer gap-2 text-center font-medium"
                        onClick={() =>
                          updatePortfolioDependency(
                            getPortfolioDependencyData(app, el.lob),
                          )
                        }
                      >
                        <div className="flex items-center justify-items-center gap-2">
                          <span>{el.lob}</span>
                          <Icon
                            name="square-arrow-out-up-right"
                            className="size-4"
                          />
                        </div>
                      </TableCell>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-3xl">
                      <IAddSubPortfolioDashboard />
                    </DialogContent>
                  </Dialog>
                  <TableCell className="border-x">
                    {el.application.join("")}
                  </TableCell>
                  <TableCell className=" ">
                    <AffectedAppList el={el?.gold} />
                  </TableCell>
                  <TableCell className="border-x">
                    <AffectedAppList el={el?.silver} />
                  </TableCell>
                  <TableCell className="text-right">
                    <AffectedAppList el={el?.bronze} />
                  </TableCell>
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>
    </ScrollArea>
  );
};

const AffectedAppList = ({ el }: { el: any[] }) => (
  <div className="group relative p-4 py-6">
    <ScrollArea className="h-20">
      <div className="flex flex-col gap-2">
        {el?.map(({ application, Status: status }: any) => (
          <Badge
            key={application}
            variant="secondary"
            className={cn(
              `text-ellipsis text-neutral-800 dark:text-neutral-100`,
              status == "R"
                ? "bg-red-300 dark:bg-red-600"
                : status == "A"
                  ? "bg-amber-300 dark:bg-amber-600"
                  : status == "G"
                    ? "bg-green-300 dark:bg-green-600"
                    : "",
            )}
          >
            {application}
          </Badge>
        ))}
      </div>
    </ScrollArea>
    {el?.length > 0 && (
      <div className="absolute bottom-1 right-[15px] hidden text-xs text-muted-foreground group-hover:block">
        <span>Count </span>
        <span>{el?.length}</span>
      </div>
    )}
  </div>
);

const EmptyDataContainer = () => {
  const application = useAppSelector((state) => state.iAddData.application);
  return (
    <tr className="h-full w-full">
      <td colSpan={5}>
        <div className="grid h-full place-items-center gap-4">
          <Icon
            name="package-open"
            strokeWidth={1.2}
            className="size-28 text-muted-foreground"
          />
          <div className="grid place-items-center text-muted-foreground">
            <p>Oops! It looks like no data is available</p>
            {application?.length == 0 ? (
              <div className="mt-2">
                <span>Please select a</span>
                <kbd className="pointer-events-none mx-2 inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
                  <span className="text-xs">Application</span>
                </kbd>
                <span>to view its dependency</span>
              </div>
            ) : (
              ""
            )}
          </div>
        </div>
      </td>
    </tr>
  );
};

export default IAddDashboardTable;
