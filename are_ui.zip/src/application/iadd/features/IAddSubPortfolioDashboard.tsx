import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import { cn } from "@/lib/tailwind.utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Icon } from "@/components/ui/icon";
import { useAppSelector } from "@/lib/redux/hooks";
import { Separator } from "@/components/ui/seperator";
const IAddSubPortfolioDashboard = () => {
  const [activeTab, setActiveTab] = useState("");
  const portfolioDependency = useAppSelector(
    (state) => state.iAddData.portfolioDependencyData,
  );
  useEffect(() => {
    setActiveTab(portfolioDependency?.[0]?.portfolioName);
  }, portfolioDependency);
  return (
    <Tabs
      defaultValue="account"
      value={activeTab}
      onValueChange={setActiveTab}
      className="grid min-h-96 w-full grid-cols-[170px_auto] gap-4"
      orientation="vertical"
    >
      <TabsList className="flex h-full w-full flex-col items-start justify-items-start bg-background bg-muted">
        <div className="relative w-full overflow-hidden">
          {portfolioDependency?.map(
            ({ portfolioName, overallStatus: status }: any, i) => (
              <TabsTrigger
                value={portfolioName}
                className={`${i !== 0 ? "ml-4 mr-4 w-[90%]" : "w-full"}`}
              >
                <div className="flex w-full items-center justify-between truncate">
                  <div>{portfolioName}</div>
                </div>
                <StatusBadge
                  status={status}
                  isActive={activeTab == portfolioName}
                  portfolioName={portfolioName}
                />
                {i == 0 && (
                  <Separator
                    orientation="vertical"
                    className={cn(
                      "opacity-7 absolute left-4 top-[1.8rem] h-96 bg-neutral-300 dark:bg-neutral-950",
                    )}
                  />
                )}
              </TabsTrigger>
            ),
          )}
        </div>
      </TabsList>
      {portfolioDependency?.map((el) => (
        <TabsContent value={el?.portfolioName}>
          <ScrollArea className="max-h-[80vh] overflow-auto">
            <div className="grid gap-2">
              <AppList appList={el?.tier_1_app} title="Tier 1" />
              <AppList appList={el?.tier_2_app} title="Tier 2" />
            </div>
          </ScrollArea>
        </TabsContent>
      ))}
    </Tabs>
  );
};

const AppList = ({ appList, title }: { appList: any[]; title: string }) => {
  return (
    <div className="">
      <h5 className="mb-1 text-xs uppercase">{title}</h5>
      <div className="grid gap-x-2 gap-y-4 sm:grid-cols-2">
        {appList?.map(({ application, contact, Status: status }: any) => (
          <HoverCard key={application}>
            <HoverCardTrigger asChild>
              <Button
                variant="secondary"
                className="flex justify-between truncate px-4 text-sm"
              >
                <div className="">
                  {application.length > 20
                    ? `${application.substr(0, 20)}..`
                    : application}
                </div>
                <StatusBadge status={status} isActive={true} />
              </Button>
            </HoverCardTrigger>
            <HoverCardContent className="w-80">
              <AppHoverCard appName={application} contact={contact} />
            </HoverCardContent>
          </HoverCard>
        ))}
      </div>
    </div>
  );
};

const AppHoverCard = ({ appName, contact }: any) => {
  return (
    <div>
      <h4 className="text-sm font-semibold">{appName}</h4>
      <div className="mt-4 flex space-x-4">
        <Avatar>
          <AvatarFallback className="uppercase">
            {contact.name?.substr(0, 2)}
          </AvatarFallback>
        </Avatar>
        <div className="space-y-1">
          <p className="text-sm">{contact.name}</p>
          <div className="flex items-center gap-1">
            <Icon name="at-sign" className="color-muted size-3" />
            <span className="text-xs text-muted-foreground">
              {contact.mail}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Icon name="phone" className="color-muted size-3" />
            <span className="text-xs text-muted-foreground">
              {contact.phone}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatusBadge = ({ status, isActive }: any) => (
  <Badge
    className={cn(
      "px-[2px] py-0 text-[0.6rem] text-neutral-800 dark:text-neutral-100",
      status == "R"
        ? isActive
          ? "bg-red-200 dark:bg-red-600"
          : "bg-red-100 dark:bg-red-500"
        : status == "A"
          ? isActive
            ? "bg-amber-200 dark:bg-amber-600"
            : "bg-amber-100 dark:bg-amber-500"
          : status == "G"
            ? isActive
              ? "bg-green-200 dark:bg-green-600"
              : "bg-green-100 dark:bg-green-500"
            : "",
    )}
    variant="destructive"
  >
    {status}
  </Badge>
);

export default IAddSubPortfolioDashboard;
