import { Label } from "@/components/ui/label";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import {
  updateApplication,
  updateDependencyData,
  updateRegion,
  updateSector,
} from "../slice/iAddDataSlice";
import {
  getApplication,
  getDependencyDashboardData,
  getRegion,
  getSector,
} from "../data/mockup.data";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";

type Option = {
  value: string;
  label: string;
};

const IAddFilters = () => {
  const sector = useAppSelector((state) => state.iAddData.sector);
  const region = useAppSelector((state) => state.iAddData.region);
  const application = useAppSelector((state) => state.iAddData.application);

  const [regionList, setRegionList] = useState<Option[]>([]);
  const [appList, setAppList] = useState<Option[]>([]);

  const dispatch = useAppDispatch();
  const setSector = (sector: string) => {
    dispatch(updateSector(sector));
  };

  const setRegion = (region: string) => {
    dispatch(updateRegion(region));
  };

  const setApplication = (application: string) => {
    dispatch(updateApplication(application));
    dispatch(updateDependencyData(getDependencyDashboardData(application)));
  };

  useEffect(() => {
    sector ? setRegionList(getRegion(sector)) : setRegionList([]);
  }, [sector]);

  useEffect(() => {
    region ? setAppList(getApplication(region)) : setAppList([]);
  }, [region]);

  return (
    <div className="flex items-center">
      <div className="flex gap-6">
        <div className="flex flex-col gap-2">
          <Label>Sector</Label>
          <SingleSelectCombobox
            value={sector}
            field="Sector"
            setValue={setSector}
            optionList={getSector()}
            placeholder="Select sector"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label>Region</Label>
          <SingleSelectCombobox
            value={region}
            field="Region"
            setValue={setRegion}
            optionList={regionList}
            placeholder="Select region"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label>Application</Label>
          <SingleSelectCombobox
            value={application}
            setValue={setApplication}
            optionList={appList}
            widthClass="w-fit min-w-[200px]"
            field="Application"
            placeholder="Select application"
          />
        </div>
        {application?.length ? (
          <div className="mt-auto flex">
            <Button variant="secondary" className="gap-2">
              <Icon name="message-circle-more" />
              <span>Initiate Group Chat</span>
            </Button>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default IAddFilters;
