import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Gen AI Playground",
        route: "/gen-ai",
        key: "1",
    },
];
