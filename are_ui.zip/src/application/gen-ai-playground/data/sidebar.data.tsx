import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Home",
          icon: "home",
          route: "/gen-ai/home",
        },
        {
          key: "2",
          content: "Lab",
          icon: "square-terminal",
          route: "/gen-ai/x-lab",
        },
      ],
    },
  ],
  bottomNavList: [
  ],
};

export default SIDEBAR_DATA;
