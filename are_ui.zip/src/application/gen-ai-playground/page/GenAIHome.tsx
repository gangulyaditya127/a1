import Container from "@/components/ui/container";
import { GlowingStarsBackgroundCard, GlowingStarsDescription, GlowingStarsTitle } from "@/components/ui/glowing-stars";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { Link } from "react-router-dom";

export default function GenAIHome() {
    return (
        <section>
            <Container>
                <p className={cn(
                    "relative my-4 text-sm text-muted-foreground uppercase",
                )}>Playground</p>
                <Link to="/gen-ai/x-lab" className="">
                    <GlowingStarsBackgroundCard illustrationClass="h-32">
                        <GlowingStarsTitle className="text-md mt-4">GenX Lab</GlowingStarsTitle>
                        <div className="flex justify-between items-end">
                            <GlowingStarsDescription className="text-sm text-muted-foreground">
                                Your own lab for effortless experiment with the potential of generative AI
                            </GlowingStarsDescription>
                            <div className="h-8 w-8 rounded-full bg-[hsla(0,0%,100%,.1)] flex items-center justify-center">
                                <Icon name='move-right' className="h-4 w-4" />
                            </div>
                        </div>
                    </GlowingStarsBackgroundCard>
                </Link>
            </Container>
        </section>
    )
}