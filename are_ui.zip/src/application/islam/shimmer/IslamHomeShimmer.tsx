import { Skeleton } from "@/components/ui/skeleton";
import Container from "@/components/ui/container";
export const IslamHomeShimmer = () => (
    <Container className="mt-6">
        <div className="flex gap-4 mb-4">
            <Skeleton className="h-9 rounded-lg w-32" />
            <Skeleton className="h-9 rounded-lg w-32" />
            <Skeleton className="h-9 rounded-lg w-32" />
        </div>
        <Skeleton className="h-[400px] rounded-lg" />
    </Container>
)