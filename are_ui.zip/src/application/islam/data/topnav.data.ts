import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
  {
    content: "Intelligent SLA management​",
    route: "/islam",
    key: "1",
  },
];
