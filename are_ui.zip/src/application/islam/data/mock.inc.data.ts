import {  getNthMinuteDate } from "@/lib/date.utils";

export const POTENTIAL_SLA_MISS=[
    {
        incNumber:"INC01406173",
        assignmentGroup:"TCS NA 2T US WEB SUPPORT",
        priority:2,
        assignee:"Sudhanshu Singh",
        slaEndTime:getNthMinuteDate(33),
    },
    {
        incNumber:"INC01212463",
        assignmentGroup:"TCS NA 2T US WEB SUPPORT",
        priority:3,
        assignee:"Debashis Das",
        slaEndTime:getNthMinuteDate(44),
    },
    {
        incNumber:"INC01434738",
        assignmentGroup:"TCS NA 2T US WEB SUPPORT",
        priority:2,
        assignee:"Sudhanshu Singh",
        slaEndTime:getNthMinuteDate(48),
    },
]