type Option={
    value:string,
    label:string
}
export const getProjectList=()=>{
    return new Promise<Option[]>((res)=>{
        setTimeout(()=>{
            res([
                {
                    value:"GPA",
                    label:"GPA"
                },
                {
                    value:"CTO",
                    label:"CTO"
                },
            ])
        },1000*10)
    })
}
