import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

export const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "0",
          content: "Home",
          icon: "home",
          route: "/islam/home",
        },
        {
          key: "1",
          content: "Upload Data",
          icon: "cloud-upload",
          route: "/islam/upload",
        },
      ],
    },
  ],
  bottomNavList: [
    {
      key: "8",
      content: "Logout",
      icon: "log-out",
      route: "/logout",
    },
  ],
};