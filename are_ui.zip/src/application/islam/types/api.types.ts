export type GetRawProjectDataProps={
    businessUnit:string,
    isu:string,
    account:string
    sub_isu?:string
}
export type GetRawSLATableDataProps={
    project:string,
    portfolio:string,
    resolver:string
}