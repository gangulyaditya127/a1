import { Icon } from "@/components/ui/icon";

const EmptyContainer = ({
    isPristine,
    lastField = 'Portfolio'
}: { isPristine?: boolean; lastField?: string }) => (
    <div className="grid h-full place-items-center text-sm">
        <div className="flex flex-col items-center gap-4">
            <Icon
                name="package-open"
                strokeWidth={1.2}
                className="size-28 text-muted-foreground"
            />
            <div className="grid place-items-center text-muted-foreground">
                <p>Oops! It looks like no data is available</p>
                {isPristine ? (
                    <div className="mt-2">
                        <span>Please select a</span>
                        <kbd className="pointer-events-none mx-2 inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
                            <span className="text-xs">{lastField}</span>
                        </kbd>
                        <span>to view its SLA Metrics</span>
                    </div>
                ) : (
                    ""
                )}
            </div>
        </div>
    </div>
)
export default EmptyContainer;