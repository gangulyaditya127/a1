
import { ExcelExportParams } from "ag-grid-charts-enterprise";
import { AgGridReact, CustomCellRendererProps } from "ag-grid-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CustomColDef, useSLATableData } from "../hooks/useSLATableData";
import { cn } from "@/lib/tailwind.utils";
import { Skeleton } from "@/components/ui/skeleton";
import EmptyContainer from "./EmptyContainer";
import ErrorContainer from "./ErrorContainer";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import '../style/table.css'
import DataGrid from "@/components/ui/data-grid";

const SLATable = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%", "--ag-header-column-separator-height": "100%", "--ag-header-column-resize-handle-height": "25%" }), []);
    const { rowData, colDef, isLoading, isPristine, isError, hasPortfolio } = useSLATableData();;
    const gridRef = useRef<AgGridReact<any>>(null);
    const [tableColDef, setTableColDef] = useState<CustomColDef[]>([])
    useEffect(() => {
        let tableDef = colDef?.map((el: any) => {
            if (el?.children?.length) {
                return ({
                    headerName: el.headerName,
                    children: el.children.map((child: any) => ({
                        ...child,
                        cellRenderer: SLATableCellRenderer,
                        cellRendererParams: { valueField: el.headerName },
                        valueGetter: (params: any) => params.data[el.field ?? '']?.value
                    }))
                })
            }
            return ({
                ...el,
                cellRenderer: SLATableCellRenderer,
                cellRendererParams: { valueField: el.headerName },
                valueGetter: (params: any) => params.data[el.field ?? '']?.value
            })
        })
        console.log({ tableDef, colDef })
        setTableColDef(tableDef)
    }, [colDef])
    const exportExcel = useCallback(() => {
        gridRef.current!.api.exportDataAsExcel();
    }, []);
    const defaultExcelExportParams = useMemo<ExcelExportParams>(() => {
        return {
            processCellCallback: (params) => {
                return params.value?.value
            },
            processHeaderCallback: (params) => {
                return params.column.getColId()
            },
            exportAsExcelTable: true,
            sheetName: 'ISLAM Report',

        }
    }, []);
    const defaultColDef = useMemo<CustomColDef>(() => {
        return {
            flex: 1,
        };
    }, []);

    if (isLoading) {
        return (
            <>
                <Skeleton className="h-[40px] mt-6 rounded-lg" />
                <Skeleton className="h-[350px] mt-[10px] rounded-lg mb-8" />
            </>
        )
    }

    if (isError) {
        return (
            <div className="h-[400px] mt-6 border border-1 rounded-lg mb-8">
                <ErrorContainer />
            </div>
        )
    }

    if (rowData?.length == 0) {
        return (
            <div className="h-[400px] mt-6 border border-1 rounded-lg mb-8">
                <EmptyContainer isPristine={isPristine} lastField={hasPortfolio ? 'Portfolio' : 'Project'} />
            </div>
        )
    }


    return (
        <div className="mt-6 mb-8">
            <div className="flex mb-4 items-center justify-between">
                <h2 className="text-xl ">SLA Dashboard</h2>
                <div className="flex gap-3 items-center">
                    <Button className="rounded-lg gap-2 text-xs font-normal	  font-baseline" variant={"outline"} size={"sm"}>
                        <Icon name="mail" className="h-4 w-4" />
                        <p>Trigger Mail</p>
                    </Button>
                    <Button onClick={exportExcel} className="rounded-lg gap-2 text-xs font-normal	 font-baseline" variant={"outline"} size={"sm"}>
                        <Icon name="download" className="h-4 w-4" />
                        <p>Export</p>
                    </Button>
                </div>
            </div>
            <div className="h-[400px]">
                <div
                    style={gridStyle}
                >
                    <DataGrid
                        rowData={rowData}
                        ref={gridRef}
                        defaultExcelExportParams={defaultExcelExportParams}
                        columnDefs={tableColDef}
                        defaultColDef={defaultColDef}
                    />
                </div>
            </div>
        </div>
    )
}

const getStatusClass = (val: string) => {
    if (val == "RED") {
        return 'bg-red-600 text-white dark:bg-red-600 dark:text-foreground'
    }
    if (val == "GREEN") {
        return 'bg-green-400 dark:bg-green-800'
    }
    if (val == "AMBER") {
        return 'bg-yellow-400 dark:bg-yellow-800'
    }
}

const Chip = ({ val }: { val: string }) => {
    return (
        <div className={cn(`w-fit rounded-lg bg-neutral-200 px-1 py-[2px] text-xs dark:bg-neutral-700`, getStatusClass(val))}>{
            val
        }</div>
    )
}

const SLATableCellRenderer = ({ data, colDef }: CustomCellRendererProps) => {
    const { value, flag } = data?.[colDef?.field ?? ''] ?? {
        value: '',
        flag: ''
    }
    return (<div className="h-full flex items-center gap-2">
        {value}
        {flag != "NA" && value != "-" && <Chip val={flag} />}
    </div>);
}




export default SLATable;
