import { Button } from "@/components/ui/button"
import { useLazyDownloadTicketTemplateQuery } from "../slice/ISLAMAPISlice"
import { Download, FileWarningIcon, Loader } from "lucide-react"

const TicketTemplateDownloader = () => {
    const [triggerDownload, { isLoading, isError }] = useLazyDownloadTicketTemplateQuery()
    const handleDownload = async () => {
        try {
            await triggerDownload({})
        } catch (err) {
            console.error(err)
        }
    }

    return (
        <Button variant={'outline'} className="text-muted-foreground w-[200px] gap-2" onClick={handleDownload} disabled={isLoading || isError}>
            {isError && <FileWarningIcon className="fill-red-800" />}
            {(isLoading) && <Loader className="animate-spin" />}
            {!isError && !isLoading && <Download className="h-4 w-4" />}
            Ticket Template
        </Button>)
}
export default TicketTemplateDownloader