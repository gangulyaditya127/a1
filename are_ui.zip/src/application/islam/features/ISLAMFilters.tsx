
import { Label } from "@/components/ui/label";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { updateAccount, updateISLAMPortfolioList, updatePortfolio, updateProject } from "../slice/ISLAMDataSlice";
import { cn } from "@/lib/tailwind.utils";
import TicketTemplateDownloader from "./TicketTemplateDownloader";
import SLATemplateDownloader from "./SLATemplateDownloader";
import { useEffect, useState } from "react";

const ISLAMFilters = ({
    isFileUpload
}: {
    isFileUpload?: boolean
}) => {
    const project = useAppSelector((state) => state.islamData.project);
    const projectList = useAppSelector((state) => state.islamData.projectList);
    const portfolio = useAppSelector((state) => state.islamData.portfolio);
    const account = useAppSelector((state) => state.islamData.account)
    const accountList = useAppSelector((state) => state.islamData.accountList)
    const portfolioList = useAppSelector((state) => state.islamData.portfolioList);
    const rawProjectData = useAppSelector((state) => state.islamData.rawProjectData);
    const [hasPortfolio, setHasPortfolio] = useState(false);
    const dispatch = useAppDispatch();
    const setAccount = (account: string) => {
        dispatch(updateAccount(account));
    }
    const setProject = (project: string) => {
        dispatch(updateProject(project));
        let updatedPortfolioOptions = rawProjectData.filter((el) => el.project == project)
            ?.[0]?.portfolio
            ?.split(',')
            ?.map((el: string) => ({ value: el, label: el }))
        dispatch(updateISLAMPortfolioList(updatedPortfolioOptions))
        setPortfolio("")
    };
    const setPortfolio = (portfolio: string) => {
        dispatch(updatePortfolio(portfolio));
    };

    useEffect(() => {
        if (!project || (portfolioList?.length == 1 && portfolioList[0]?.value === project)) {
            setHasPortfolio(false);
            setPortfolio(project);
        } else {
            setHasPortfolio(true)
        }
    }, [project])

    return (
        <div className={cn("flex items-center gap-4 mt-4", isFileUpload ? 'justify-between items-end' : '')}>
            <div className="flex flex-col gap-2">
                <Label>Account</Label>
                <SingleSelectCombobox
                    value={account}
                    field="Account"
                    setValue={setAccount}
                    optionList={accountList}
                    placeholder="Select Account"
                />
            </div>
            <div className="flex flex-col gap-2">
                <Label>Project</Label>
                <SingleSelectCombobox
                    value={project}
                    field="Project"
                    setValue={setProject}
                    optionList={projectList}
                    placeholder="Select Project"
                />
            </div>
            {hasPortfolio && <div className="flex flex-col gap-2">
                <Label>Portfolio</Label>
                <SingleSelectCombobox
                    value={portfolio}
                    field="Portfolio"
                    setValue={setPortfolio}
                    optionList={portfolioList}
                    placeholder="Select Portfolio"
                />
            </div>}
            {
                isFileUpload && (
                    <>
                        <TicketTemplateDownloader />
                        <SLATemplateDownloader />
                    </>
                )
            }
        </div>
    )
}
export default ISLAMFilters