import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks";
import { useInitilizeFields } from "../hooks/useInitilizeFields"
import { updateAccount, updateProject } from "../slice/ISLAMDataSlice";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { Label } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

const ISLAMFileUploadFilters = () => {
    const [_, isError, isLoading] = useInitilizeFields()
    const project = useAppSelector((state) => state.islamData.project);
    const projectList = useAppSelector((state) => state.islamData.projectList);
    const account = useAppSelector((state) => state.islamData.account)
    const accountList = useAppSelector((state) => state.islamData.accountList)
    const dispatch = useAppDispatch();
    // const rawProjectData = useAppSelector((state) => state.islamData.rawProjectData)
    console.log({ isError })
    const setAccount = (account: string) => {
        dispatch(updateAccount(account));
        setProject("")
    }
    const setProject = (project: string) => {
        dispatch(updateProject(project));
    };
    if (isLoading) {
        return <div className="flex items-center gap-4 mt-4">
            <Skeleton className="h-9 rounded-lg w-32" />
            <Skeleton className="h-9 rounded-lg w-32" />
        </div>
    }
    return (
        <div className="flex items-center gap-4 mt-4">
            <div className="flex flex-col gap-2">
                <Label>Account</Label>
                <SingleSelectCombobox
                    value={account}
                    field="Account"
                    setValue={setAccount}
                    optionList={accountList}
                    placeholder="Select Account"
                />
            </div>
            <div className="flex flex-col gap-2">
                <Label>Project</Label>
                <SingleSelectCombobox
                    value={project}
                    field="Project"
                    setValue={setProject}
                    optionList={projectList}
                    placeholder="Select Project"
                />
            </div>
        </div>
    )
}

export default ISLAMFileUploadFilters