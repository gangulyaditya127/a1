import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { ColDef, ExcelExportParams } from "ag-grid-charts-enterprise";
import { AgGridReact } from "ag-grid-react";
import { useEffect, useMemo, useRef, useState } from "react";
// import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { Label } from "@/components/ui/label";
import { useAppSelector } from "@/lib/redux/hooks";
import { useGetPotentialSLAMissQuery } from "../slice/ISLAMAPISlice";
import DataGrid from "@/components/ui/data-grid";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton";

/**
  <div className="mb-6 w-[200px] space-y-2">
                <Label>Timeframe</Label>
                <Select value={timeSpan + ''} onValueChange={(value) => setTimeSpan(+value)} >
                    <SelectTrigger>
                        <SelectValue placeholder="Select Timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectLabel>Status</SelectLabel>
                            <SelectItem value="30">0-30 Minutes</SelectItem>
                            <SelectItem value="60">0-1 hour</SelectItem>
                            <SelectItem value="120">0-2 hours</SelectItem>
                            <SelectItem value="240">0-4 hours</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </div>
 */


const PotentialSLAMiss = () => {
    // const theme = useDerivedTheme()
    return (
        <div className="mt-6 mb-8 min-h-[440px]">
            <div className="flex mb-4 items-center justify-between">
                <h2 className="text-xl ">Potential SLA Miss</h2>
                <div className="flex gap-3 items-center">
                    <Button className="rounded-lg gap-2 text-xs font-normal	  font-baseline" variant={"outline"} size={"sm"}>
                        <Icon name="mail" className="h-4 w-4" />
                        <p>Trigger Mail</p>
                    </Button>
                    <Button onClick={() => null} className="rounded-lg gap-2 text-xs font-normal	 font-baseline" variant={"outline"} size={"sm"}>
                        <Icon name="download" className="h-4 w-4" />
                        <p>Export</p>
                    </Button>
                </div>
            </div>
            <Tabs defaultValue="240" className="w-full">
                <TabsList>
                    <TabsTrigger value="30">0-30 Minutes</TabsTrigger>
                    <TabsTrigger value="60">0-1 hour</TabsTrigger>
                    <TabsTrigger value="120">0-2 hours</TabsTrigger>
                    <TabsTrigger value="240">0-4 hours</TabsTrigger>
                </TabsList>
                <TabsContent value="30">
                    <PotentialSLAMissTable timeSpan={30} />
                </TabsContent>
                <TabsContent value="60">
                    <PotentialSLAMissTable timeSpan={60} />
                </TabsContent>
                <TabsContent value="120">
                    <PotentialSLAMissTable timeSpan={120} />
                </TabsContent>
                <TabsContent value="240">
                    <PotentialSLAMissTable timeSpan={240} />
                </TabsContent>
            </Tabs>
        </div>
    )

}


const PotentialSLAMissTable = ({ timeSpan = 240 }: { timeSpan?: number }) => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData, setRowData] = useState([]);
    const gridRef = useRef<AgGridReact<any>>(null);
    const project = useAppSelector((state) => state.islamData.project);
    const portfolio = useAppSelector((state) => state.islamData.portfolio);
    const { isLoading, isError, data } = useGetPotentialSLAMissQuery({
        project,
        portfolio,
        timeparam: timeSpan
    }, {
        skip: (!project || !portfolio || !timeSpan),
        pollingInterval: 1000 * 60,
        skipPollingIfUnfocused: true
    })
    const [tableColDef] = useState<ColDef[]>([
        { field: "incNumber", headerName: 'Incident Number', filter: 'agTextColumnFilter' },
        { field: "assignmentGroup", filter: 'agTextColumnFilter' },
        { field: "priority", filter: 'agTextColumnFilter', width: 10 },
        { field: "assignee", filter: 'agSetColumnFilter' },
        { field: "sla_going_to_miss", headerName: 'SLA Miss In (Min)', filter: 'agNumberFilter' },
    ]);
    useEffect(() => {
        if (data) {
            setRowData(data)
        }
    }, [data])

    // const exportExcel = useCallback(() => {
    //     gridRef.current!.api.exportDataAsExcel();
    // }, []);

    const defaultExcelExportParams = useMemo<ExcelExportParams>(() => {
        return {
            processCellCallback: (params) => {
                return params.value?.value
            },
            processHeaderCallback: (params) => {
                return params.column.getColId()
            },
            exportAsExcelTable: true,
            sheetName: 'ISLAM Report',

        }
    }, []);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
        };
    }, []);
    return (
        <div className="mt-6 mb-8">

            {
                isError ? 'ERROR' :
                    isLoading ? <Skeleton className="h-[400px]" /> :
                        <div className="h-[400px]">
                            <div
                                style={gridStyle}
                            >
                                <DataGrid
                                    rowData={rowData}
                                    ref={gridRef}
                                    defaultExcelExportParams={defaultExcelExportParams}
                                    columnDefs={tableColDef}
                                    defaultColDef={defaultColDef}
                                />
                            </div>
                        </div>
            }
        </div>
    )
}

export default PotentialSLAMiss;