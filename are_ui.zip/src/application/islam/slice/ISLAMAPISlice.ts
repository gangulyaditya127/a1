import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { GetRawProjectDataProps, GetRawSLATableDataProps } from '../types/api.types'

export const islamAPI = createApi({
    reducerPath: 'islamAPI',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/islam/` }),
    tagTypes: ['sla_data'],
    endpoints: ({ query, mutation }) => ({
        getRawProjectData: query<any, GetRawProjectDataProps>({
            query: (queryParams) => ({ url: `getLoadPortfolio`, params: queryParams }),
        }),
        getRawSLATableData: query<any, GetRawSLATableDataProps>({
            query: (queryParams) => ({ url: `getViewTableData`, params: queryParams }),
            providesTags: ['sla_data']
        }),
        getAccountData: query<any, any>({
            query: (queryParams) => ({ url: `getLoadAccount`, params: queryParams })
        }),
        getPotentialSLAMiss:query<any,any>({
            query:(queryParams)=>({url:'getPotentialMissSLAIncident',params: queryParams})
        }),
        uploadTicketData: mutation({
            query: (body) => (
                {
                    url: 'submit-ticket-sla-data',
                    body,
                    method: 'POST',
                }
            ),
            invalidatesTags: ['sla_data']
        }),
        downloadTicketTemplate: query<any, any>({
            query: () => (
                {
                    url: 'download-ticket-template',
                    responseHandler: async (response) => {
                        if (!response.ok) {
                            throw new Error('Error in API response')
                        }
                        const fileBlob = await response.blob()
                        const url = window.URL.createObjectURL(fileBlob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.setAttribute('download', 'ticket_template.xlsx')
                        document.body.appendChild(link)
                        link.click()
                        link.parentNode?.removeChild(link)
                        window.URL.revokeObjectURL(url)
                    }
                }
            )
        }),
        downloadSLATemplate: query<any, any>({
            query: () => (
                {
                    url: 'download-sla-template',
                    responseHandler: async (response) => {
                        if (!response.ok) {
                            throw new Error('Error in API response')
                        }
                        const fileBlob = await response.blob()
                        const url = window.URL.createObjectURL(fileBlob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.setAttribute('download', 'sla_template.xlsx')
                        document.body.appendChild(link)
                        link.click()
                        link.parentNode?.removeChild(link)
                        window.URL.revokeObjectURL(url)
                    }
                }
            )
        })
    }),
})

export const {
    useGetRawProjectDataQuery,
    useGetRawSLATableDataQuery,
    useLazyGetRawProjectDataQuery,
    useLazyGetRawSLATableDataQuery,
    useGetAccountDataQuery,
    useLazyGetAccountDataQuery,
    useLazyDownloadSLATemplateQuery,
    useLazyDownloadTicketTemplateQuery,
    useUploadTicketDataMutation,
    useGetPotentialSLAMissQuery
} = islamAPI