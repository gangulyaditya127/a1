import { PayloadAction, createSlice } from "@reduxjs/toolkit";

type Option = {
    value: string;
    label: string;
};
type ISLAMDataSliceType = {
    projectList: Option[],
    portfolioList: Option[],
    project: string,
    portfolio: string,
    rawProjectData: any[],
    accountList: Option[],
    account: string,
}
// let projectList: Option[] = []
// let portfolioList: Option[] = []
// let project: string | null = "";
// let portfolio: string | null = "";
// let rawProjectData:any=null;
const initialState: ISLAMDataSliceType = {
    projectList: [],
    portfolioList: [],
    project: "",
    portfolio: "",
    account: "",
    rawProjectData: [],
    accountList: []
}
const islamDataSlice = createSlice({
    name: "islamDataSlice",
    initialState,
    reducers: {
        updateRawProjectData: (state, action) => {
            state.rawProjectData = action.payload
            console.log({ payload: action.payload })

        },
        updateISLAMProjectList: (state, action) => {
            const { payload } = action;
            console.log({ projectPayload: payload })
            state.projectList = payload
        },
        updateISLAMPortfolioList: (state, action: PayloadAction<Option[]>) => {
            state.portfolioList = action.payload
        },
        updatePortfolio: (state, action: PayloadAction<string>) => {
            state.portfolio = action.payload
        },
        updateProject: (state, action: PayloadAction<string>) => {
            state.project = action.payload
        },
        updateAccountList: (state, action) => {
            const { payload } = action;
            state.accountList = payload
        },
        updateAccount: (state, action) => {
            const { payload } = action;
            state.account = payload
        }
    },
});

export const {
    updateISLAMProjectList,
    updateISLAMPortfolioList,
    updatePortfolio,
    updateProject,
    updateRawProjectData,
    updateAccountList,
    updateAccount
} = islamDataSlice.actions;

export default islamDataSlice.reducer;
