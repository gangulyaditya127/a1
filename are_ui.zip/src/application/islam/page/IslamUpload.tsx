import { Button } from "@/components/ui/button";
import Container from "@/components/ui/container";
import { useDropzone } from 'react-dropzone';
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Loader, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import ISLAMFilters from "../features/ISLAMFilters";
// import { useInitilizeFields } from "../hooks/useInitilizeFields";
import { useSyncFilters } from "../hooks/useSyncFilters";
import ErrorContainer from "../features/ErrorContainer";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppSelector } from "@/lib/redux/hooks";
import { useUploadTicketDataMutation } from "../slice/ISLAMAPISlice";
import { useNavigate } from "react-router-dom";
import { UserConsent } from "@/components/ui/consent-component";

export default function IslamUpload() {
    return (
        <Container className="mt-6 grid max-w-6xl space-y-6 mb-12">
            <h1 className=" text-muted-foreground uppercase">Upload your SLA Data</h1>
            <FileUploadForm />
            <UserConsent />
        </Container>
    )
}

const FileUploadForm = () => {
    const [hasError, isLoadingFilters] = useSyncFilters()
    const [incidentFiles, setIncidentFiles] = useState<File[]>([])
    const [slaFiles, setSLAFiles] = useState<File[]>([]);
    const account = useAppSelector((state) => state.islamData.account)
    const portfolio = useAppSelector((state) => state.islamData.portfolio)
    const project = useAppSelector((state) => state.islamData.project)
    const auth = useAppSelector((state) => state.auth.rawUserDetails)
    const { toast } = useToast()
    const [uploadFile, { isError: isFileUploadError, isLoading: isUploadingFile, isSuccess, error: fileUploadError }] = useUploadTicketDataMutation()
    const navigate = useNavigate()
    useEffect(() => {
        if (isFileUploadError) {
            toast({
                variant: "destructive",
                title: 'Uh no! Something went wrong',
                description: (fileUploadError as any)?.message ?? 'Unexpected Error from server'
            })
            return;
        }
        if (isSuccess) {
            toast({
                title: 'File uploaded successfully',
                description: ''
            })
            navigate('/islam/home')
            return;
        }
    }, [isSuccess, isFileUploadError])

    const handleFileUpload = () => {
        const formData = new FormData();
        formData.append('empid', auth?.rawUserDetails?.empid ?? auth?.empid)
        formData.append('project', project)
        formData.append('portfolio', portfolio)
        formData.append('resolver', 'Only TCS')
        formData.append('incidentFile', incidentFiles?.[0])
        formData.append('slaFile', slaFiles?.[0])
        uploadFile(formData)
    }
    const isEnabled = () => {
        return account?.length > 0 && portfolio?.length > 0 && project?.length > 0 && incidentFiles?.length == 1 && slaFiles?.length == 1
    }
    if (isLoadingFilters) {
        return (<>
            <div className="flex items-center justify-between gap-6 h-10">
                <Skeleton className="w-[200px] h-full rounded-md" />
                <Skeleton className="w-[200px] h-full rounded-md" />
                <Skeleton className="w-[200px] h-full rounded-md" />
                <Skeleton className="w-[200px] h-full rounded-md" />
                <Skeleton className="w-[200px] h-full rounded-md" />
            </div>
            <div className="grid grid-cols-2 gap-4 h-60">
                <Skeleton className="w-full h-full rounded-md" />
                <Skeleton className="w-full h-full rounded-md" />
            </div>
            <Skeleton className="h-8 w-full h-10 rounded-md" />
        </>)
    }
    return (
        <>
            {
                hasError ? <ErrorContainer /> :
                    <>
                        <ISLAMFilters isFileUpload={true} />
                        <div className="grid grid-cols-2 gap-4">
                            <FileUploader files={incidentFiles} setFiles={setIncidentFiles} placeholder="Drag 'n' drop Ticket file here, or click to select files" />
                            <FileUploader files={slaFiles} setFiles={setSLAFiles} placeholder="Drag 'n' drop SLA file here, or click to select files" />
                        </div>
                        <Button className="rounded-lg gap-2" variant="primary" disabled={!isEnabled()} onClick={handleFileUpload}>
                            {isUploadingFile && <Loader className="animate-spin" />}
                            Upload
                        </Button>
                    </>

            }

        </>
    )
}

const FileUploader = ({
    files,
    setFiles,
    placeholder
}: {
    files: File[],
    setFiles: Dispatch<SetStateAction<File[]>>
    placeholder: string
}) => {
    const removeFile = (index: number) => {
        setFiles(prevFiles => {
            const newFiles = prevFiles.filter((_, i) => i !== index)
            return newFiles
        })
    }
    const { toast } = useToast()
    const {
        acceptedFiles,
        fileRejections,
        getRootProps,
        getInputProps,
        isFocused,
        isDragActive,
    } = useDropzone({
        accept: {
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx', '.xls']
        }
    });
    useEffect(() => {
        if (acceptedFiles?.length) {
            setFiles(acceptedFiles?.filter((_, i) => i < 1))
        }
        if (fileRejections?.length) {
            toast({
                variant: 'destructive',
                title: "Uh oh! Something went wrong.",
                description: fileRejections?.[0]?.errors?.[0]?.message ?? ''
            })
        }
    }, [acceptedFiles, fileRejections])

    return (
        <div>
            <div {...getRootProps({ className: `${(isDragActive || isFocused) ? 'bg-secondary/80  border-dashed border-blue-400' : 'bg-secondary/40 border-transparent'} border rounded-xl grid place-items-center h-60 w-full cursor-pointer text-center` })}>
                <input
                    {...getInputProps()}
                />
                <div className="text-muted-foreground space-y-2">
                    <p>{placeholder}</p>
                    <p className="text-sm">(Upload the files only with specified template)</p>
                </div>
            </div>
            {
                files.length > 0 && (
                    <ul className='space-y-2 mt-6'>
                        <p>Uploaded Files</p>
                        {
                            files.map((file, index) => (
                                <li className="flex items-center text-muted-foreground text-sm justify-between p-1 px-4 bg-muted rounded-lg bg-secondary/40">
                                    <span>{file.name}</span>
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-7 w-6"
                                        onClick={() => removeFile(index)}
                                    >
                                        <X className="h-4 w-4" />
                                    </Button>
                                </li>
                            ))
                        }
                    </ul>
                )
            }
        </div>
    )
}