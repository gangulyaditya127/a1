import Container from "@/components/ui/container";
import ISLAMFilters from "../features/ISLAMFilters";
import SLATable from "../features/SLATable";
import ErrorContainer from "../features/ErrorContainer";
import { IslamHomeShimmer } from "../shimmer/IslamHomeShimmer";
import { useSyncFilters } from "../hooks/useSyncFilters";
import PotentialSLAMiss from "../features/PotentailSLAMiss";

const IslamHome = () => {
    const [hasError, isLoadingFilters] = useSyncFilters()
    if (isLoadingFilters) {
        return (
            <IslamHomeShimmer />
        )
    }
    return (
        <Container className="mt-6">
            <ISLAMFilters />
            {(!hasError) ? <SLATable /> : <ErrorContainer />}
            <PotentialSLAMiss/>
        </Container>
    )
}
export default IslamHome;
