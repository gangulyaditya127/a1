import { ColDef, ColGroupDef } from "ag-grid-charts-enterprise"
import { useEffect, useState } from "react"
import { useLazyGetRawSLATableDataQuery } from "../slice/ISLAMAPISlice"
import { useAppSelector } from "@/lib/redux/hooks"
export type CustomColDef = ColDef | ColGroupDef
export const useSLATableData = () => {
    const [colDef, setColDef] = useState<CustomColDef[]>([])
    const [rowData, setRowData] = useState<any>([])
    const [isError, setIsError] = useState<boolean>(false)
    const [isLoading, setIsLoading] = useState<boolean>(false)
    const portfolio = useAppSelector((state) => state.islamData.portfolio);
    const project = useAppSelector((state) => state.islamData.project);
    const account = useAppSelector(state => state.islamData.account)
    const [trigger, result] = useLazyGetRawSLATableDataQuery()
    useEffect(() => {
        if (portfolio?.length > 0 && project?.length > 0 && account?.length > 0) {
            trigger({
                portfolio,
                project,
                resolver: "Only TCS"
            })
        } else {
            setColDef([])
            setRowData([])
        }
    }, [portfolio, project, account])

    useEffect(() => {
        const { isError, data, isFetching } = result
        if (isFetching) {
            setIsLoading(true);
            return;
        }
        if (!!isError) {
            setIsLoading(false);
            setIsError(true)
            return;
        }
        if (!!data) {
            setIsLoading(false);
            setIsError(false)
            processRawData(data)
        }
    }, [result])
    const processRawData = (data: any) => {
        const headerDef: CustomColDef[] = [
            {
                field: "KPI Measure",
                pinned: 'left'
            },
            {
                field: "Obligation",
                pinned: 'left'
            }
        ]
        const headers = Object.keys(data?.[0] ?? {});
        const escapeKeys = [
            "KPI Measure",
            "Obligation",
            "Over All",
            portfolio
        ]

        headerDef.push(({
            headerName: project,
            field: 'Over All',
            cellClass: 'border-x bg-blue-500/10',
            headerClass: 'bg-blue-500/20'
            // pinned:'left'
        }))

        let header = 'Subportfolios'

        if (!project || project == portfolio) {
            header = 'Portfolios'
        } else {
            headerDef.push(({
                headerName: 'Portfolio',
                children: [
                    {
                        headerName: portfolio,
                        field: portfolio,

                    }
                ],

            }))
        }


        const subportfolios = headers.filter((header) => !escapeKeys.includes(header));

        headerDef.push(({
            headerName: `${portfolio} ${header}`,
            children: subportfolios.map(el => ({
                field: el,
                cellClass: 'border-x bg-amber-500/5',
                // headerClass: 'bg-sky-500/10'
            })),
        }))


        if (headers.length > 0) {
            console.log(headerDef)
            setColDef(headerDef)
        }
        setRowData(data)
    }
    return { colDef, rowData, isError, updateColDef: setColDef, updateRowDef: setRowData, isLoading, isPristine: !Boolean(portfolio?.length), hasPortfolio: portfolio != project }
}