import { useEffect, useState } from "react"
import { useGetAccountDataQuery } from "../slice/ISLAMAPISlice";
import { useAppDispatch } from "@/lib/redux/hooks";
import { updateAccountList } from "../slice/ISLAMDataSlice";

export const useInitilizeFields = () => {
    const [isInitilzed, setIsInitilized] = useState(false);
    const [hasError, setHasError] = useState(false)
    const dispatch = useAppDispatch()
    const { data: accountData, error: accountError, isLoading: accountLoading } = useGetAccountDataQuery({
        businessUnit: "BFSI",
        isu: "SEAL"
    }, {
        refetchOnFocus: true
    })

    useEffect(() => {
        if (!!accountError) {
            setIsInitilized(false);
            setHasError(true)
        }
        if (!!accountData) {
            setHasError(false);
            dispatch(updateAccountList(accountData?.map((el: string) => ({ value: el, label: el }))))
        }
    }, [accountData, accountError, accountLoading])


    return [isInitilzed, hasError, accountLoading];
}