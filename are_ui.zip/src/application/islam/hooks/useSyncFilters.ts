import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks"
import { useGetAccountDataQuery, useLazyGetRawProjectDataQuery } from "../slice/ISLAMAPISlice";
import { useEffect, useState } from "react";
import { updateAccount, updateAccountList, updateISLAMPortfolioList, updateISLAMProjectList, updatePortfolio, updateProject, updateRawProjectData } from "../slice/ISLAMDataSlice";

export const useSyncFilters = () => {
    const [hasError, setHasError] = useState(false)
    const account = useAppSelector((state) => state.islamData.account);
    const [trigger, { data, error, isFetching }] = useLazyGetRawProjectDataQuery()
    const dispatch = useAppDispatch();
    const userDetails=useAppSelector((state)=>state.auth.rawUserDetails);
    const { data: accountData, error: accountError, isLoading: accountLoading } = useGetAccountDataQuery({
        empid:userDetails?.empid
    }, {
        refetchOnFocus: true,
        skip:!userDetails?.empid,
    })

    useEffect(() => {
        dispatch(updateAccount(''))
    }, [])

    useEffect(() => {
        if (accountError) {
            setHasError(true);
            return;
        }
        if (accountData) {
            const filterValue = accountData?.map((el: string) => ({ value: el, label: el }))
            dispatch(updateAccountList(filterValue))
            dispatch(updateAccount(''))
        }
    }, [accountData, accountLoading, accountError])

    useEffect(() => {
        console.log({ account })
        if (account?.length > 0) {
            console.log('calling account api', account)
            trigger({
                account,
                isu:userDetails?.isu,
                sub_isu:userDetails?.sub_isu,
                businessUnit: userDetails?.bu
            })
            return;
        } else {
            dispatch(updateISLAMProjectList([]))
            dispatch(updateProject(''))
            dispatch(updateISLAMPortfolioList([]))
            dispatch(updatePortfolio(''))
        }

    }, [account])

    const setRawProjectData = (RAW_DATA: any) => {
        dispatch(updateRawProjectData(RAW_DATA?.projects ?? []))
        let projectList = RAW_DATA?.projects?.map((el: any) => ({
            label: el.project,
            value: el.project
        }))
        dispatch(updateISLAMProjectList(projectList))
        dispatch(updateProject(''))
        dispatch(updateISLAMPortfolioList([]))
        dispatch(updatePortfolio(''))
    }
    useEffect(() => {
        console.log({ dataE: data })
        if (!!error) {
            setHasError(true)
        }
        if (data) {
            setHasError(false)
            setRawProjectData(data)
        }
    }, [data, error, isFetching])

    return [hasError, isFetching];
}