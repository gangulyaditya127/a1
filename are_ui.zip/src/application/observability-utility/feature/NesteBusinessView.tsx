

import { hotkeysCoreFeature, syncDataLoaderFeature } from "@headless-tree/core"
import { useTree } from "@headless-tree/react"

import { Tree, TreeItem, TreeItemLabel } from "@/components/ui/tree"
import { NavLink, useParams } from "react-router-dom"
import { cn } from "@/lib/tailwind.utils"
import { ChevronDownIcon, ChevronRight, SearchIcon } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useAppSelector } from "@/lib/redux/hooks"
import { useEffect } from "react"

interface Item {
    name: string
    href?: string
    children?: string[]
    current?: boolean,
    status?: string
}

const items: Record<string, Item> = {
    main: { name: "Business Unit", children: ["Water and Waste Water Services"] },
    "Oil Products": {
        name: "Oil Products",
        status: '',
        children: ["Land Logistics"]
    },
    // "Shared Functions": {
    //     name: "Shared Functions",
    //     status: '',
    //     children: ["Finance"]
    // },
    "Marketing and Services": {
        name: "Marketing and Services",
        status: '',
        children: ["M&S Logistics"]
    },
    "Land Logistics": {
        name: "Land Logistics"
    },
    // "Finance": {
    //     name: "Finance"
    // },
    "M&S Logistics": {
        name: "M&S Logistics"
    },
    "Water and Waste Water Services": {
        name: "Water and Waste Water Services",
        status: 'red',
        children: [
            "Customer Service",
            "Field & Asset Service",
            "Azure Apps",
            "Capital Delivery",
            "Asset Performance",
        ],
        href: '/observability-utility'
    },

    "Asset Performance": {
        name: "Asset Performance",
        href: "d13",
        status: "green"
    },
    "Capital Delivery": {
        name: "Capital Delivery",
        href: "d12",
        status: "green"
    },

    "Azure Apps": {
        name: "Azure Apps",
        href: "d11",
        status: "amber"
    },
    "Customer Service": {
        name: "Customer Service",
        href: "d10",
        status: "green"
    },
    "Field & Asset Service": {
        name: "Field & Asset Service",
        href: "d09",
        status: "red"
    },




    "Renewable Production": {
        name: "Renewable Production",
        children: [
            "Production",
            "Inventory and Warehousing",
            "Manage and Maintain Assets"
        ],
        status: "red"
    },
    "Logistics Solution": {
        name: "Logistics Solution",
        children: [],
        status: "red"
    },
    "Production": {
        name: "Production",
        children: [],
        status: "red"
    },

    "Inventory and Warehousing": {
        name: "Inventory and Warehousing",
        children: [],
        status: "red"
    },
    "Manage and Maintain Assets": {
        name: "Manage and Maintain Assets",
        children: [],
        status: "red"
    },


    "Sales and SCM Solutions": {
        name: "Sales and SCM Solutions",
        status: 'red',
        children: [
            "Supply, Sales & Trading",
            "Sales & Counterparty experience",
            "Planning & Optimizing",
            "Supply Chain Compliance"
        ],
        href: "/observability-energy"
    },

    "Sales & Counterparty experience": {
        name: "Sales & Counterparty experience",
        href: "d10",
        status: "green"
    },
    "Planning & Optimizing": {
        name: "Planning & Optimizing",
        href: "d11",
        status: "amber"
    },
    "Supply Chain Compliance": {
        name: "Supply Chain Compliance",
        href: "d12",
        status: "green"
    },


}

const indent = 20

export default function Component() {
    const { id } = useParams();
    const isIssueFixed = (useAppSelector((state) => state.utilityObservability.currentActiveStep) == "documentation")

    const expandPath = (path: string[]) => {
        let currItem = tree.getItems();
        for (let i = 0; i < path.length; i++) {
            const targetName = path[i];

            const targetItem = currItem.find(item => item.getItemName() === targetName && item.getItemMeta().level === i);

            if (targetItem && targetItem.isFolder()) {
                targetItem.expand();
                currItem = tree.getItems();
            } else {
                break;
            }

        }
    }

    const tree = useTree<Item>({
        initialState: {
            expandedItems: [],
        },
        indent,
        rootItemId: "main",
        getItemName: (item) => item.getItemData().name,
        isItemFolder: (item) => (item.getItemData()?.children?.length ?? 0) > 0,
        dataLoader: {
            getItem: (itemId) => items[itemId],
            getChildren: (itemId) => items[itemId].children ?? [],
        },
        features: [syncDataLoaderFeature, hotkeysCoreFeature],
    })

    useEffect(() => {
        if (!id || !tree) return;
        expandPath(['Water and Waste Water Services'])
        // const item = tree.getItemInstance('Water and Waste Water Services')
        // if(item) item.expandAll()
    }, [id, tree])



    return (
        <div className="h-full">
            <div className="relative">
                <Input
                    className="peer ps-9 h-8 text-xs"
                    type="search"
                    placeholder="Search business process..."
                />
                <div className="text-muted-foreground/80 pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50">
                    <SearchIcon className="size-4" aria-hidden="true" />
                </div>

            </div>
            <div className="flex  flex-col gap-2 *:first:grow py-4">
                <Tree
                    indent={indent}
                    tree={tree}
                    className="relative before:absolute before:inset-0 before:-ms-1 before:bg-[linear-gradient(to_right,white_0,transparent_calc(var(--tree-indent)-1px),var(--border)_calc(var(--tree-indent)-1px),var(--border)_calc(var(--tree-indent)))]"
                >
                    {tree.getItems().map((item) => {
                        return (
                            <TreeItem
                                key={item.getId()}
                                item={item}
                                asChild={!!item.getItemData()?.href}
                            >
                                {item.getItemData()?.href ? (
                                    <NavLink
                                        to={item.getItemData().href ?? ""}
                                        data-current={item.getItemData().current}
                                        className="relative"
                                        end
                                    >
                                        {({ isActive }) => (
                                            <>
                                                {isActive && !item.isFolder() && <div className={cn("absolute h-[70%] top-1/2 -translate-y-1/2 w-1",
                                                    isIssueFixed ?
                                                        "bg-blue-500/80"
                                                        : item.getItemData()?.status == "red" ? "bg-red-500/80" : item.getItemData()?.status == "amber" ? "bg-amber-500/80" : "bg-blue-500/80"
                                                )}>
                                                </div>}
                                                {/* {true && isActive && <div className="absolute bg-red-400 inset-0"></div>} */}
                                                <TreeItemLabel className={cn("in-data-[current=true]:bg-accent in-data-[current=true]:text-accent-foreground ", !item.isFolder() && (item.getItemData()?.status == "red" && !isIssueFixed) ? "bg-red-500/10" : item.getItemData().status == "amber" ? "bg-amber-500/10" : "", isIssueFixed && isActive && "bg-blue-500/10")} >
                                                    <span className="flex items-center gap-2">
                                                        {
                                                            item.isFolder() ? (item.isExpanded() ?
                                                                (
                                                                    <ChevronDownIcon className="text-muted-foreground pointer-events-none size-4" />
                                                                ) : (
                                                                    <ChevronRight className="text-muted-foreground pointer-events-none size-4" />
                                                                ))
                                                                : ''
                                                        }
                                                        {item.getItemName()}
                                                    </span>
                                                </TreeItemLabel>
                                                {item.getItemData()?.status == "red" && !isIssueFixed && <div className="absolute right-2 text-xs p-0.5 bg-red-500 -translate-y-1/2 top-1/2 rounded-lg">R</div>}
                                                {item.getItemData()?.status == "amber" && <div className="absolute right-2 text-xs p-0.5 bg-amber-800 -translate-y-1/2 top-1/2 rounded-lg">A</div>}
                                                {item.getItemData()?.status == "red" && isIssueFixed && item.isFolder() && <div className="absolute right-2 text-xs p-0.5 bg-amber-800 -translate-y-1/2 top-1/2 rounded-lg">A</div>}

                                            </>

                                        )}


                                    </NavLink>
                                ) : (
                                    <TreeItemLabel className="before:bg-background relative before:absolute before:inset-x-0 before:-inset-y-0.5 before:-z-10">
                                        <span className="flex items-center gap-2">
                                            {
                                                item.isExpanded() ? (
                                                    <ChevronDownIcon className="text-muted-foreground pointer-events-none size-4" />
                                                ) : (
                                                    <ChevronRight className="text-muted-foreground pointer-events-none size-4" />
                                                )
                                            }
                                            {item.getItemName()}
                                        </span>
                                    </TreeItemLabel>
                                )}
                            </TreeItem>
                        )
                    })}
                </Tree>
            </div>
        </div>
    )
}
