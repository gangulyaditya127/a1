import { Icon } from "@/components/ui/icon"
import { Separator } from "@/components/ui/seperator"
import { useAppSelector } from "@/lib/redux/hooks"
import { cn } from "@/lib/tailwind.utils"

const Trend = ({ value, className }: { value: "up" | "down" | "nuteral" | string | any, className?: string }) => {
    if (value === 'up') return <Icon name="arrow-up-right" className={cn("size-4", className)} />
    if (value === 'down') return <Icon name="arrow-down-right" className={cn("size-4", className)} />
    return <Icon name="minus" className={cn("size-4", className)} />
}
export default function ObservabilityMetrics() {
    const isIssueFixed = useAppSelector((state) => state.utilityObservability.currentActiveStep) == "documentation";
    return (
        <div className="bg-secondary/40 border rounded-xl w-full mt-2">
            <div className="flex justify-between px-8 py-12">
                <div className="flex flex-col">
                    <p className="flex text-xs font-medium uppercase tracking-wider  items-center gap-2">
                        Major Incidents
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>
                    </p>
                    <p className="flex items-baseline gap-1 text-4xl font-medium ">
                        {new Intl.NumberFormat("en-IN").format(3)}
                    </p>
                    <div className="mt-auto flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="text-white">
                            2%
                        </p>
                        <Trend value={"up"} />
                        <p>from yesterday</p>
                    </div>
                </div>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] "
                />
                <div className="flex flex-col">
                    <p className="flex text-xs font-medium uppercase tracking-wider  items-center gap-2">
                        Critical alerts
                       {!isIssueFixed && <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>}
                       {isIssueFixed && <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                        </span>}
                    </p>
                    <p className="flex items-baseline gap-1 text-4xl font-medium ">
                       {!isIssueFixed ? 1 : 0}

                    </p>
                    {/* <div className="mt-auto flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="text-white">
                            15%
                        </p>
                        <Trend value={"up"} />
                        <p>from yesterday</p>
                    </div> */}
                </div>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] "
                />
                <div className="flex flex-col">
                    <p className="flex text-xs font-medium uppercase tracking-wider  items-center gap-2">
                        System Health
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
                        </span>
                    </p>
                    <p className="flex items-baseline gap-1 text-4xl font-medium ">
                        {!isIssueFixed ? new Intl.NumberFormat("en-IN").format(94.3) : new Intl.NumberFormat("en-IN").format(96.1)}
                        %

                    </p>
                    <div className="mt-auto flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="text-white">
                            2%
                        </p>
                        <Trend value={"up"} />
                        <p>from yesterday</p>
                    </div>
                </div>
                <Separator
                    orientation="vertical"
                    className="h-[5.2rem] "
                />
                <div className="flex flex-col">
                    <p className="flex text-xs font-medium uppercase tracking-wider  items-center gap-2">
                        Saturation
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                        </span>
                    </p>
                    <p className="flex items-baseline gap-1 text-4xl font-medium ">
                        {!isIssueFixed ? new Intl.NumberFormat("en-IN").format(61) : new Intl.NumberFormat("en-IN").format(57)}
                        %

                    </p>
                    <div className="mt-auto flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="text-white">
                            2%
                        </p>
                        <Trend value={"down"} />
                        <p>from yesterday</p>
                    </div>
                </div>
                

            </div>

        </div>
    )
}