import { Icon } from "@/components/ui/icon";

export default function UtilityItViewPlaceholder() {
    return (
        <div className="grid h-full place-items-center text-sm border border-secondary/50 bg-secondary/10">
            <div className="flex flex-col items-center gap-4">
                <Icon
                    name="package-open"
                    strokeWidth={1.2}
                    className="size-28 text-muted-foreground"
                />
                <div className="grid place-items-center text-muted-foreground">
                    {/* <p>Oops! It looks like no data is available</p> */}
                    <div className="mt-2">
                        <span>Please select a</span>
                        <kbd className="pointer-events-none mx-2 inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
                            <span className="text-xs">business process</span>
                        </kbd>
                        <span>to view its status breakdown</span>
                    </div>
                </div>
            </div>
        </div>
    )
}