import Container from "@/components/ui/container";
import NesteBusinessView from "../feature/NesteBusinessView";
import { Outlet, useNavigate } from "react-router-dom";
import ObservabilityDashboardHeader from "../feature/ObservabilityHeader";
import ObservabilityMetrics from "../feature/ObservabilityMetrics";
import { useEffect } from "react";


export default function ObservabilityUtilityHome() {
    const navigate=useNavigate();

    useEffect(()=>{
        navigate('/observability-utility/d09')
    },[])

    return (
        <Container className="my-6 mb-12 max-w-7xl">
            <ObservabilityDashboardHeader />
            <ObservabilityMetrics/>
            <div className="grid grid-cols-[370px_auto] gap-4 my-6 h-[60vh] pb-24">
                <NesteBusinessView />
                <Outlet />
            </div>
        </Container>
    )
}