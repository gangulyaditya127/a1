import { useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  CheckCircle,
  Clock, RefreshCw, ChevronDown,
  X
} from "lucide-react"
import { TextShimmer } from "@/components/ui/text-shimmer"
import { useAppDispatch, useAppSelector } from "@/lib/redux/hooks"
import { addLog, setAutoRunning, setCurrentActiveStep, StepStatus, updateStepStatus, WorkflowStep } from "../slice/utilityObservabilitySlice"

export default function IncidentResolutionDashboard() {
  const dispatch = useAppDispatch()
  const { steps, isAutoRunning, agents, logs } = useAppSelector((state) => state.utilityObservability)

  useEffect(() => {
    if (!isAutoRunning) return

    const processSteps = () => {
      const updatedSteps = steps.map((step, index) => {
        // Determine if this step should be active
        const shouldBeActive = index === 0 || steps[index - 1].status === "completed"

        if (step.status === "pending" && shouldBeActive) {
          dispatch(setCurrentActiveStep(step.id))
          return { ...step, status: "processing" as StepStatus }
        }

        if (step.status === "processing") {
          const newProgress = Math.min(step.progress + 1.5, 100)

          if (newProgress >= 100) {
            // Add completion log
            const completionLogs = {
              analysis: "Incident report #DB-2024-001 analyzed successfully",
              identification: "Root cause identified: Cluster disk failure",
              resolution: "Disk restart completed - SQL server restored",
              documentation: "Problem record PRB-2024-001 created and filed",
            }

            dispatch(
              addLog({
                id: `complete-${step.id}-${Date.now()}`,
                timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
                agent: step.agent.split(" ")[0],
                action: completionLogs[step.id as keyof typeof completionLogs],
                status: "complete",
              }),
            )

            return { ...step, progress: 100, status: "completed" as StepStatus }
          }

          return { ...step, progress: newProgress }
        }

        return step
      })

      dispatch(updateStepStatus(updatedSteps))
    }

    const interval = setInterval(processSteps, 80)
    return () => clearInterval(interval)
  }, [isAutoRunning, steps, dispatch])

  useEffect(() => {
    if (!isAutoRunning) return

    const generateProgressLogs = () => {
      steps.forEach((step) => {
        if (step.status === "processing" && step.progress > 20 && step.progress < 30) {
          const progressLogs = {
            analysis: "Fetching incident report from database...",
            identification: "Scanning cluster infrastructure status...",
            resolution: "Initiating automated disk restart sequence...",
            documentation: "Generating problem record template...",
          }

          const logId = `progress-${step.id}-${Math.floor(step.progress / 20)}`
          if (!logs.find((log) => log.id === logId)) {
            dispatch(
              addLog({
                id: logId,
                timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
                agent: step.agent.split(" ")[0],
                action: progressLogs[step.id as keyof typeof progressLogs],
                status: "in-progress",
              }),
            )
          }
        }
      })
    }

    generateProgressLogs()
  }, [steps, isAutoRunning, logs, dispatch])

  const startAutomatedFlow = () => {
    dispatch(setAutoRunning(true))
    // dispatch(resetSteps())
  }

  // const getOverallProgress = () => {
  //   const totalProgress = steps.reduce((sum, step) => sum + step.progress, 0)
  //   return totalProgress / steps.length
  // }

  useEffect(() => {
   setTimeout(startAutomatedFlow, 1000)
  }, [])


  const getStatusColor = (status: StepStatus) => {
    switch (status) {
      case "pending":
        return "text-muted-foreground"
      case "processing":
        return "text-blue-500"
      case "completed":
        return "text-green-500"
      case "error":
        return "text-red-500"
      default:
        return "text-muted-foreground"
    }
  }

  const getStatusBadge = (status: StepStatus) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="text-xs">
            Pending
          </Badge>
        )
      case "processing":
        return <Badge className="text-xs bg-blue-500">Processing</Badge>
      case "completed":
        return (
          <Badge variant="secondary" className="text-xs bg-green-500 text-white">
            Completed
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive" className="text-xs">
            Error
          </Badge>
        )
    }
  }

  const getStatusIcon = (step: WorkflowStep) => {
    switch (step.status) {
      case "pending":
        return <Clock className="h-4 w-4 text-muted-foreground" />
      case "processing":
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "error":
        return <X className="h-4 w-4 text-red-500" />
    }
  }


  return (
    <div className="h-screen bg-background overflow-y-scroll">
      <Card className="border-none ">
        <CardHeader>
          <CardTitle className="text-sm text-muted-foreground">
            System Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 -translate-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${steps.find((s) => s.id === "resolution")?.status === "completed" ? "bg-green-500" : "bg-red-500"
                  }`}
              />
              <span className="text-sm">Database Cluster</span>
            </div>
            <Badge
              variant={
                steps.find((s) => s.id === "resolution")?.status === "completed" ? "default" : "destructive"
              }
              className={steps.find((s) => s.id === "resolution")?.status === "completed" ? "bg-green-500" : "bg-red-500"}
            >
              {steps.find((s) => s.id === "resolution")?.status === "completed" ? "Online" : "Offline"}
            </Badge>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${steps.find((s) => s.id === "resolution")?.status === "completed" ? "bg-green-500" : "bg-red-500"
                  }`}
              />
              <span className="text-sm">SQL Server</span>
            </div>
            <Badge
              variant={
                steps.find((s) => s.id === "resolution")?.status === "completed" ? "default" : "destructive"
              }
              className={steps.find((s) => s.id === "resolution")?.status === "completed" ? "bg-green-500" : "bg-red-500"}
            >
              {steps.find((s) => s.id === "resolution")?.status === "completed" ? "Online" : "Offline"}
            </Badge>
          </div>
        </CardContent>
      </Card>
      <Card className="border-none p-0">
        <CardHeader>
          <CardTitle className="text-sm text-muted-foreground">
            {steps.at(-1)?.status != "completed" ? <TextShimmer>Processing tool call...</TextShimmer> : "Processed tool calls"}
          </CardTitle>
          <CardDescription className="-translate-y-1">Real-time execution status for all workflow steps</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {/* All steps visible simultaneously */}
          {steps.map((step, index) => (
            (index == 0 || steps[index - 1].status == "completed") && <div key={step.id} className="border border-border rounded-lg p-4 transition-all duration-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(step)}
                    <span className={`font-mono text-sm ${getStatusColor(step.status)}`}>{step.name}</span>
                  </div>
                  {getStatusBadge(step.status)}
                </div>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </div>

              {/* Step details */}
              <div className="mt-3 pl-6 space-y-2">
                <p className="text-sm text-muted-foreground">{step.description}</p>
                <p className="text-xs text-muted-foreground font-mono">{step.details}</p>
                <p className="text-xs text-muted-foreground">Agent: {step.agent}</p>

                {/* Progress bar for processing steps */}
                {step.status === "processing" && (
                  <div className="mt-2">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-muted-foreground">Progress</span>
                      <span className="text-xs text-muted-foreground">{Math.round(step.progress)}%</span>
                    </div>
                    <Progress value={step.progress} className="h-1" />
                  </div>
                )}

                {/* Completion details */}
                {step.status === "completed" && (
                  <div className="mt-2 p-2 bg-green-50 dark:bg-green-950/20 rounded text-xs text-green-700 dark:text-green-300">
                    ✓ Step completed successfully
                  </div>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card className="border-none">
          <CardHeader>
            <CardTitle className="text-sm text-muted-foreground">Active Agents</CardTitle>
            <CardDescription>Real-time collaboration status</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {agents.map((agent, index) => {
              const correspondingStep = steps[index]
              const agentStatus =
                correspondingStep?.status === "processing"
                  ? "active"
                  : correspondingStep?.status === "completed"
                    ? "complete"
                    : "waiting"

              return (
                <div key={agent.id} className="flex items-center gap-3">

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{agent.name}</span>
                      <Badge
                        variant={
                          agentStatus === "active"
                            ? "default"
                            : agentStatus === "complete"
                              ? "secondary"
                              : "outline"
                        }
                        className="text-xs"
                      >
                        {agentStatus === "active" ? "Active" : agentStatus === "complete" ? "Complete" : "Standby"}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{agent.role}</p>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>

        {/* System Status */}


        <Card className="border-none">
          <CardHeader className="">
            <CardTitle className="text-sm text-muted-foreground">Activity Log</CardTitle>
            <CardDescription>Live agent actions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {logs.slice(-8).map((log) => (
                <div key={log.id} className="flex items-start gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <span className="text-muted-foreground font-mono">{log.timestamp}</span>
                    <span className="font-medium">{log.agent}:</span>
                    <span className="text-muted-foreground">{log.action}</span>
                  </div>
                  {log.status === "in-progress" && (
                    <RefreshCw className="h-3 w-3 animate-spin text-primary flex-shrink-0" />
                  )}
                  {log.status === "complete" && <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
