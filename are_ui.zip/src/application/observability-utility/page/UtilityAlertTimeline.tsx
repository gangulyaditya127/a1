import Container from "@/components/ui/container"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"
import { Icon } from "@/components/ui/icon"
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
import { useAppSelector } from "@/lib/redux/hooks"
import { cn } from "@/lib/tailwind.utils"
import { Link } from "react-router-dom"

export default function UtilityAlertTimeline() {
    return (
        <Container className="mt-6">
            <NavigateBackButton />
            <div className="h-[80vh] grid place-items-center">
                <Timeline />
            </div>
        </Container>
    )
}
function Timeline() {
    const currentActiveStep = useAppSelector((state) => state.utilityObservability.currentActiveStep);

    return (
        <div className="flex items-center gap-4 ">
            <HoverCard>
                <HoverCardTrigger asChild>
                    <div className="grid place-items-center gap-2 cursor-pointer">
                        <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                            <Icon name="webhook" />
                        </div>
                        <p className="text-muted-foreground text-sm">Linked Application</p>
                    </div>
                </HoverCardTrigger>
                <HoverCardContent className="w-80">
                    <div className="flex flex-col rounded-lg text-sm text-muted-foreground justify-between gap-2">
                        {/* <p>SAP</p> */}

                    </div>
                </HoverCardContent>
            </HoverCard>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <HoverCard>
                <HoverCardTrigger asChild>
                    <div className="grid place-items-center gap-2 cursor-pointer">
                        <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                            <Icon name="server-cog" />
                        </div>
                        <p className="text-muted-foreground text-sm">Integrations</p>
                    </div>
                </HoverCardTrigger>
                <HoverCardContent className="w-80">
                    <div className="flex flex-col rounded-lg text-sm text-muted-foreground justify-between gap-2">
                       
                        
                    </div>
                </HoverCardContent>
            </HoverCard>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <HoverCard>
                <HoverCardTrigger asChild>
                    <div className="grid place-items-center gap-2 cursor-pointer">
                        <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                            <Icon name="layout-panel-top" />
                        </div>
                        <p className="text-muted-foreground text-sm">Platform</p>
                    </div>
                </HoverCardTrigger>
                <HoverCardContent className="w-80">
                    <div className="flex flex-col rounded-lg text-sm text-muted-foreground justify-between gap-2">
                        
                    </div>
                </HoverCardContent>
            </HoverCard>
            <Icon name="move-horizontal" className={cn("mb-6",currentActiveStep == "documentation" ? "text-green-500 " : "text-red-500 ")} />
            <HoverCard>
                <HoverCardTrigger asChild>
                    <Link to='/observability-utility/gis/details' className="grid place-items-center gap-2 cursor-pointer">
                        <div className={cn("size-16 grid place-items-center rounded-full", currentActiveStep == "documentation" ? "bg-green-600 " : "bg-red-600 ")}>
                            <Icon name="database" />
                        </div>
                        <p className="text-muted-foreground text-sm">Database</p>
                    </Link>
                </HoverCardTrigger>
                <HoverCardContent className="w-16">
                    <div className="flex flex-col rounded-lg text-sm text-muted-foreground justify-between gap-2">
                        <p>
                            SQL
                        </p>
                    </div>
                </HoverCardContent>
            </HoverCard>
            <Icon name="move-horizontal"  className={cn("mb-6",currentActiveStep == "documentation" ? "text-green-500 " : "text-red-500 ")}  />
            <HoverCard>
                <HoverCardTrigger asChild>
                    <div className="grid place-items-center gap-2 cursor-pointer">
                        <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                            <Icon name="user-round" />
                        </div>
                        <p className="text-muted-foreground text-sm">Interface</p>
                    </div>
                </HoverCardTrigger>
                <HoverCardContent className="w-24">
                    <div className="flex flex-col rounded-lg text-sm text-muted-foreground justify-between gap-2">
                        <p>
                            Citrix
                        </p>
                    </div>
                </HoverCardContent>
            </HoverCard>

        </div>
    )
}
