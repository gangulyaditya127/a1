export interface Certificate {
  id: string;
  commonName: string;
  san: string[];
  issuer: string;
  expiryDate: string;
  status: 'active' | 'expiring' | 'expired' | 'revoked';
  type: 'ssl' | 'code-signing' | 'client' | 'ca';
  keySize: number;
  serialNumber: string;
  owner: string;
  location: string;
  autoRenewal: boolean;
  lastDeployed?: string;
  nextRenewal?: string;
  daysUntilExpiry: number;
}

export interface CertificateStats {
  total: number;
  active: number;
  expiring: number;
  expired: number;
  autoManaged: number;
}

export interface DeploymentTarget {
  id: string;
  name: string;
  type: 'nginx' | 'apache' | 'tomcat' | 'weblogic' | 'keystore';
  host: string;
  status: 'online' | 'offline' | 'maintenance';
  lastDeployment?: string;
}