import { useState } from 'react';
import { Search, Radar, RefreshCw, Truck } from 'lucide-react';
import { StatsOverview } from '../features/StatsOverview';
import { Certificate } from '../types/certificate';
import { CertificateCharts } from '../features/CertificateCharts';
import { CertificateTable } from '../features/CertificateTable';
import { DeploymentTargets } from '../features/DeploymentTargets';
import { PhaseCard } from '../features/PhaseCard';

// import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DetailModal } from '../features/DetailModal';
import { PhaseDetailModal } from '../features/PhaseDetailModal';
import { mockCertificates, mockDeploymentTargets, mockStats } from '../data/DumpData';

const IcerticateFlow = () => {
    const [selectedModal, setSelectedModal] = useState<{
    open: boolean;
    title: string;
    certificates: Certificate[];
    description?: string;
  }>({
    open: false,
    title: '',
    certificates: [],
    description: ''
  });

  const [phaseModal, setPhaseModal] = useState<{
    open: boolean;
    phase: 'discover' | 'track' | 'renew' | 'deploy';
  }>({
    open: false,
    phase: 'discover'
  });

  const handleStatsCardClick = (title: string, certificates: Certificate[]) => {
    let description = '';
    switch (title) {
      case 'Total Certificates':
        description = 'All certificates currently managed by the system';
        break;
      case 'Active':
        description = 'Certificates that are currently valid and active';
        break;
      case 'Expiring Soon':
        description = 'Certificates that will expire within the next 30 days';
        break;
      case 'Expired':
        description = 'Certificates that have already expired and need immediate attention';
        break;
      case 'Auto-Managed':
        description = 'Certificates managed automatically through AWS/Azure or other cloud providers';
        break;
    }

    setSelectedModal({
      open: true,
      title,
      certificates,
      description
    });
  };

  const handlePhaseCardClick = (phase: 'discover' | 'track' | 'renew' | 'deploy') => {
    setPhaseModal({
      open: true,
      phase
    });
  };
  const phases = [
    {
      phase: 'Phase 1',
      title: 'Discover',
      description: 'Automatically scan all configured servers, keystores, and web endpoints to discover existing certificates. Catalog metadata including expiry dates, issuers, and owners.',
      icon: Search,
      status: 'completed' as const,
      metrics: [
        { label: 'Servers Scanned', value: '12' },
        { label: 'Certificates Found', value: '5' }
      ]
    },
    {
      phase: 'Phase 2',
      title: 'Track',
      description: 'Continuously monitor certificate lifecycles with proactive alerts at 30, 15, and 7 days before expiry. Visual insights for compliance and security policies.',
      icon: Radar,
      status: 'active' as const,
      metrics: [
        { label: 'Active Alerts', value: '3' },
        { label: 'Compliance Rate', value: '98%' }
      ]
    },
    {
      phase: 'Phase 3',
      title: 'Renew',
      description: 'Automated certificate renewal with CA integration (Let\'s Encrypt, DigiCert, PKI). Generate CSRs, renew certificates, and store securely without manual intervention.',
      icon: RefreshCw,
      status: 'active' as const,
      metrics: [
        { label: 'Auto Renewals', value: '3' },
        { label: 'Success Rate', value: '100%' }
      ]
    },
    {
      phase: 'Phase 4',
      title: 'Deploy',
      description: 'Automatically deploy renewed certificates to target servers via SSH. Support for NGINX, Apache, WebLogic, Tomcat, and Java keystores with service reloading.',
      icon: Truck,
      status: 'pending' as const,
      metrics: [
        { label: 'Deployments', value: '8' },
        { label: 'Target Servers', value: '4' }
      ]
    }
  ];
    return (
        <div className="min-h-screen bg-background">
            {/* Header */}
            {/* <header className="border-b bg-card bg-gray-800/25">
                <div className="container mx-auto px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3 ">
                            <div className="p-2  rounded-lg bg-blue-500/10 ">
                                <Shield className="h-6 w-6 text-blue-500 text-blue-500" />
                            </div>
                            <div>
                                <h1 className="text-2xl font-bold">Certificate Management</h1>
                                <p className="text-sm text-muted-foreground">Automated Lifecycle Management System</p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <Button className="rounded-lg" variant="outline" size="sm">
                                <Bell className="h-4 w-4 mr-2" />
                                Alerts (3)
                            </Button>
                            <Button className="bg-blue-600 rounded-lg text-white" size="sm">
                                <RefreshCw className="h-4 w-4 mr-2 " />
                                Scan Now
                            </Button>
                        </div>
                    </div>
                </div>
            </header> */}


            <main className="container mx-auto px-6 py-8 ">
                    {/* Statistics Overview */}
                    <StatsOverview 
                      stats={mockStats} 
                      certificates={mockCertificates}
                      onCardClick={handleStatsCardClick}
                    />
            
                    {/* 4-Phase Lifecycle */}
                    <div className="mb-8">
                      <h2 className="text-xl font-semibold mb-4">4-Phase Lifecycle Management</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {phases.map((phase) => (
                          <PhaseCard
                            key={phase.phase}
                            phase={phase.phase}
                            title={phase.title}
                            description={phase.description}
                            icon={phase.icon}
                            status={phase.status}
                            metrics={phase.metrics}
                            onClick={() => handlePhaseCardClick(phase.title.toLowerCase() as 'discover' | 'track' | 'renew' | 'deploy')}
                          />
                        ))}
                      </div>
                    </div>
            
                    {/* Main Content Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Certificate Table - Takes 2/3 of the space */}
                      <div className="lg:col-span-2">
                        <CertificateTable certificates={mockCertificates} />
                      </div>
            
                      {/* Deployment Targets - Takes 1/3 of the space */}
                      <div className="lg:col-span-1">
                        <DeploymentTargets targets={mockDeploymentTargets} />
                      </div>
                    </div>
                    
                    <CertificateCharts />
                  </main>
            
                  <DetailModal
                    open={selectedModal.open}
                    onOpenChange={(open: any) => setSelectedModal(prev => ({ ...prev, open }))}
                    title={selectedModal.title}
                    certificates={selectedModal.certificates}
                    description={selectedModal.description}
                  />
            
                  <PhaseDetailModal
                    open={phaseModal.open}
                    onOpenChange={(open: any) => setPhaseModal(prev => ({ ...prev, open }))}
                    phase={phaseModal.phase}
                  />




        </div>
    )
}
export default IcerticateFlow;