import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DeploymentTarget } from '../types/certificate';
import { Server, Globe, Database, Archive } from 'lucide-react';

interface DeploymentTargetsProps {
  targets: DeploymentTarget[];
}

export const DeploymentTargets = ({ targets }: DeploymentTargetsProps) => {
  const getTypeIcon = (type: DeploymentTarget['type']) => {
    switch (type) {
      case 'nginx':
      case 'apache':
        return Globe;
      case 'tomcat':
      case 'weblogic':
        return Server;
      case 'keystore':
        return Archive;
      default:
        return Database;
    }
  };

  const getStatusBadge = (status: DeploymentTarget['status']) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-green-500 text-white">Online</Badge>;
      case 'offline':
        return <Badge variant="destructive">Offline</Badge>;
      case 'maintenance':
        return <Badge className="bg-yellow-300 text-black">Maintenance</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <Card className='bg-gray-800/25'>
      <CardHeader>
        <CardTitle>Deployment Targets</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {targets.map((target) => {
            const Icon = getTypeIcon(target.type);
            return (
              <div key={target.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-full bg-blue-500/10">
                    <Icon className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <div className="font-medium">{target.name}</div>
                    <div className="text-sm text-muted-foreground">{target.host}</div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wide">
                      {target.type}
                    </div>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  {getStatusBadge(target.status)}
                  {target.lastDeployment && (
                    <div className="text-xs text-muted-foreground">
                      Last deployed: {new Date(target.lastDeployment).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};