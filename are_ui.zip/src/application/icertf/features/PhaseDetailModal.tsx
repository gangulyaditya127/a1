import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Search, Eye, RotateCcw, Rocket, CheckCircle, AlertTriangle, Clock, Server } from 'lucide-react';

interface PhaseDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  phase: 'discover' | 'track' | 'renew' | 'deploy';
}

const phaseData = {
  discover: {
    title: 'Discovery Phase',
    description: 'Scanning and discovering certificates across your infrastructure',
    icon: Search,
    stats: {
      scannedHosts: 147,
      foundCertificates: 23,
      newCertificates: 5,
      scanProgress: 85
    },
    activities: [
      { name: 'Network Scan', status: 'completed', host: 'prod-web-01.company.com', certificates: 3 },
      { name: 'API Discovery', status: 'in-progress', host: 'api-gateway.company.com', certificates: 2 },
      { name: 'Load Balancer Scan', status: 'pending', host: 'lb-cluster.company.com', certificates: 0 },
      { name: 'CDN Check', status: 'completed', host: 'cdn.company.com', certificates: 1 }
    ]
  },
  track: {
    title: 'Tracking Phase',
    description: 'Monitoring certificate health and expiration status',
    icon: Eye,
    stats: {
      trackedCertificates: 23,
      healthyCount: 18,
      warningCount: 3,
      criticalCount: 2
    },
    activities: [
      { name: 'Expiry Monitoring', status: 'active', description: 'Tracking 23 certificates', alerts: 5 },
      { name: 'Health Checks', status: 'active', description: 'Running validation tests', alerts: 2 },
      { name: 'Compliance Scan', status: 'scheduled', description: 'Next scan in 6 hours', alerts: 0 },
      { name: 'Performance Monitor', status: 'active', description: 'SSL handshake timing', alerts: 1 }
    ]
  },
  renew: {
    title: 'Renewal Phase',
    description: 'Automated certificate renewal and provisioning',
    icon: RotateCcw,
    stats: {
      scheduledRenewals: 8,
      successfulRenewals: 6,
      pendingRenewals: 2,
      renewalRate: 94
    },
    activities: [
      { name: 'Let\'s Encrypt Renewal', status: 'completed', certificate: 'www.example.com', nextRenewal: '2024-11-15' },
      { name: 'DigiCert Renewal', status: 'in-progress', certificate: 'api.company.com', nextRenewal: '2024-12-01' },
      { name: 'Internal CA Renewal', status: 'scheduled', certificate: 'internal.company.com', nextRenewal: '2024-11-20' },
      { name: 'Wildcard Renewal', status: 'pending', certificate: '*.company.com', nextRenewal: '2024-11-25' }
    ]
  },
  deploy: {
    title: 'Deployment Phase',
    description: 'Deploying renewed certificates to target infrastructure',
    icon: Rocket,
    stats: {
      deploymentTargets: 12,
      successfulDeployments: 10,
      failedDeployments: 1,
      pendingDeployments: 1
    },
    activities: [
      { name: 'Nginx Deployment', status: 'completed', target: 'prod-web-01', certificate: 'www.example.com' },
      { name: 'Load Balancer Update', status: 'in-progress', target: 'aws-alb-prod', certificate: 'api.company.com' },
      { name: 'Tomcat Keystore', status: 'failed', target: 'app-server-01', certificate: 'internal.company.com' },
      { name: 'CDN Update', status: 'pending', target: 'cloudflare', certificate: 'cdn.company.com' }
    ]
  }
};

export const PhaseDetailModal = ({ open, onOpenChange, phase }: PhaseDetailModalProps) => {
  const data = phaseData[phase];
  const IconComponent = data.icon;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
      case 'active':
        return <CheckCircle className="h-4 w-4 text-success" />;
      case 'in-progress':
        return <Clock className="h-4 w-4 text-warning" />;
      case 'failed':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      case 'pending':
      case 'scheduled':
        return <Clock className="h-4 w-4 text-muted-foreground" />;
      default:
        return <Server className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-success text-success-foreground">Completed</Badge>;
      case 'active':
        return <Badge className="bg-primary text-primary-foreground">Active</Badge>;
      case 'in-progress':
        return <Badge className="bg-warning text-warning-foreground">In Progress</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      case 'pending':
        return <Badge variant="outline">Pending</Badge>;
      case 'scheduled':
        return <Badge variant="secondary">Scheduled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <IconComponent className="h-5 w-5" />
            <span>{data.title}</span>
          </DialogTitle>
          <p className="text-sm text-muted-foreground">{data.description}</p>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Stats Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Phase Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(data.stats).map(([key, value]) => (
                  <div key={key} className="text-center">
                    <div className="text-2xl font-bold text-primary">{value}{key.includes('Rate') ? '%' : ''}</div>
                    <div className="text-sm text-muted-foreground capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </div>
                    {key.includes('Progress') || key.includes('Rate') ? (
                      <Progress value={value as number} className="mt-2" />
                    ) : null}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.activities.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(activity.status)}
                      <div>
                        <div className="font-medium">{activity.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {'host' in activity && `Host: ${activity.host}`}
                          {'target' in activity && `Target: ${activity.target}`}
                          {'certificate' in activity && `Certificate: ${activity.certificate}`}
                          {'description' in activity && activity.description}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(activity.status)}
                      {'certificates' in activity && activity.certificates > 0 && (
                        <Badge variant="outline">{activity.certificates} certs</Badge>
                      )}
                      {'alerts' in activity && activity.alerts > 0 && (
                        <Badge className="bg-warning text-warning-foreground">{activity.alerts} alerts</Badge>
                      )}
                      {'nextRenewal' in activity && (
                        <Badge variant="outline">Next: {activity.nextRenewal}</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};