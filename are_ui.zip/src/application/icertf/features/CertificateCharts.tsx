import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, Shield, Server } from 'lucide-react';

const statusData = [
  { name: 'Active', value: 2, color: '#10b981' },
  { name: 'Expiring', value: 2, color: '#f59e0b' },
  { name: 'Expired', value: 1, color: '#ef4444' }
];

const typeData = [
  { name: 'SSL/TLS', value: 4, color: '#3b82f6' },
  { name: 'Code Signing', value: 1, color: '#8b5cf6' }
];

const expiryTrendData = [
  { month: 'Oct', expiring: 3, renewed: 2 },
  { month: 'Nov', expiring: 2, renewed: 1 },
  { month: 'Dec', expiring: 1, renewed: 3 },
  { month: 'Jan', expiring: 4, renewed: 2 },
  { month: 'Feb', expiring: 2, renewed: 4 },
  { month: 'Mar', expiring: 3, renewed: 1 }
];

const deploymentData = [
  { target: 'Nginx', certificates: 8, percentage: 35 },
  { target: 'Apache', certificates: 6, percentage: 26 },
  { target: 'Tomcat', certificates: 4, percentage: 17 },
  { target: 'Keystore', certificates: 3, percentage: 13 },
  { target: 'Load Balancer', certificates: 2, percentage: 9 }
];

export const CertificateCharts = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 ">
      {/* Certificate Status Distribution */}
      <Card className='bg-gray-800/25'>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Certificate Status Distribution</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              active: { label: 'Active', color: '#10b981' },
              expiring: { label: 'Expiring', color: '#f59e0b' },
              expired: { label: 'Expired', color: '#ef4444' }
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Certificate Types */}
      <Card className='bg-gray-800/25'>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Certificate Types</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              ssl: { label: 'SSL/TLS', color: '#3b82f6' },
              codeSigni: { label: 'Code Signing', color: '#8b5cf6' }
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={typeData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <ChartTooltip content={<ChartTooltipContent />} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Expiry & Renewal Trend */}
      <Card className='bg-gray-800/25'>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5" />
            <span>Expiry & Renewal Trend</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              expiring: { label: 'Expiring', color: '#f59e0b' },
              renewed: { label: 'Renewed', color: '#10b981' }
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={expiryTrendData}>
                <XAxis dataKey="month" />
                <YAxis />
                <Area
                  type="monotone"
                  dataKey="expiring"
                  stackId="1"
                  stroke="#f59e0b"
                  fill="#f59e0b"
                  fillOpacity={0.6}
                />
                <Area
                  type="monotone"
                  dataKey="renewed"
                  stackId="1"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.6}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Deployment Targets */}
      <Card className='bg-gray-800/25'>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Server className="h-5 w-5" />
            <span>Certificates by Deployment Target</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              certificates: { label: 'Certificates', color: '#3b82f6' }
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deploymentData} layout="horizontal">
                <XAxis type="number" />
                <YAxis dataKey="target" type="category" width={80} />
                <Bar dataKey="certificates" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                <ChartTooltip content={<ChartTooltipContent />} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
};