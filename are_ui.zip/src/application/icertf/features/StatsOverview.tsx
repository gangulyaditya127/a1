import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, AlertTriangle, CheckCircle, Clock, Settings } from 'lucide-react';
import { CertificateStats, Certificate } from '../types/certificate';

interface StatsOverviewProps {
  stats: CertificateStats;
  certificates: Certificate[];
  onCardClick: (filter: string, certificates: Certificate[]) => void;
}

export const StatsOverview = ({ stats, certificates, onCardClick }: StatsOverviewProps) => {
  const getFilteredCertificates = (filter: string) => {
    switch (filter) {
      case 'total':
        return certificates;
      case 'active':
        return certificates.filter(cert => cert.status === 'active');
      case 'expiring':
        return certificates.filter(cert => cert.status === 'expiring');
      case 'expired':
        return certificates.filter(cert => cert.status === 'expired');
      case 'autoManaged':
        return certificates.filter(cert => cert.autoRenewal);
      default:
        return certificates;
    }
  };
  const statItems = [
    {
      title: 'Total Certificates',
      value: stats.total,
      icon: Shield,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
      filter: 'total'
    },
    {
      title: 'Active',
      value: stats.active,
      icon: CheckCircle,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
      filter: 'active'
    },
    {
      title: 'Expiring Soon',
      value: stats.expiring,
      icon: Clock,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
      filter: 'expiring'
    },
    {
      title: 'Expired',
      value: stats.expired,
      icon: AlertTriangle,
      color: 'text-red-500',
      bgColor: 'bg-red-500/10',
      filter: 'expired'
    },
    {
      title: 'Auto-Managed',
      value: stats.autoManaged,
      icon: Settings,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
      filter: 'autoManaged'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6 ">
      {statItems.map((item) => (
        <Card 
          key={item.title} 
          className="relative overflow-hidden cursor-pointer hover:shadow-lg transition-shadow bg-gray-800/25"
          onClick={() => onCardClick(item.title, getFilteredCertificates(item.filter))}
        >
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {item.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{item.value}</div>
              <div className={`p-2 rounded-full ${item.bgColor}`}>
                <item.icon className={`h-4 w-4 ${item.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};