import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LucideIcon } from 'lucide-react';

interface PhaseCardProps {
  phase: string;
  title: string;
  description: string;
  icon: LucideIcon;
  status: 'active' | 'completed' | 'pending';
  metrics?: { label: string; value: string }[];
  onClick?: () => void;
}

export const PhaseCard = ({ phase, title, description, icon: Icon, status, metrics, onClick }: PhaseCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-blue-500 text-white';
      case 'completed':
        return 'bg-green-500 text-white';
      case 'pending':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="relative bg-gray-800/25 overflow-hidden group hover:shadow-lg transition-shadow cursor-pointer" onClick={onClick}>
      <CardHeader className="pb-3 ">
        <div className="flex items-center justify-between ">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-full bg-primary/10">
              <Icon className="h-5 w-5 text-blue-500 " />
            </div>
            <div>
              <CardTitle className="text-lg">{title}</CardTitle>
              <Badge variant="outline" className="text-xs mt-1">
                {phase}
              </Badge>
            </div>
          </div>
          <Badge className={getStatusColor(status)}>
            {status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground leading-relaxed">
          {description}
        </p>
        {metrics && (
          <div className="grid grid-cols-2 gap-3 pt-2 border-t">
            {metrics.map((metric, index) => (
              <div key={index} className="text-center">
                <div className="text-lg font-semibold text-blue-500">{metric.value}</div>
                <div className="text-xs text-muted-foreground">{metric.label}</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-primary/20 to-primary opacity-0 group-hover:opacity-100 transition-opacity" />
    </Card>
  );
};