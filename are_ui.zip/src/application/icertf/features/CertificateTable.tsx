import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
// import { Certificate } from '@/types/certificate';
import { Shield, Calendar, MapPin, Eye } from 'lucide-react';
import { Certificate } from '../types/certificate';

interface CertificateTableProps {
  certificates: Certificate[];
}

export const CertificateTable = ({ certificates }: CertificateTableProps) => {
  const getStatusBadge = (status: Certificate['status'], daysUntilExpiry: number) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case 'expiring':
        return (
          <Badge className="bg-yellow-300 text-black">
            Expires in {daysUntilExpiry} days
          </Badge>
        );
      case 'expired':
        return <Badge className="bg-red-500 text-white" variant="destructive">Expired</Badge>;
      case 'revoked':
        return <Badge variant="destructive">Revoked</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getTypeBadge = (type: Certificate['type']) => {
    const typeColors = {
      ssl: 'bg-blue-100 text-blue-800',
      'code-signing': 'bg-purple-100 text-purple-800',
      client: 'bg-green-100 text-green-800',
      ca: 'bg-orange-100 text-orange-800'
    };

    return (
      <Badge variant="outline" className={typeColors[type]}>
        {type.toUpperCase()}
      </Badge>
    );
  };

  return (
    <Card className='bg-gray-800/25'>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 ">
          <Shield className="h-5 w-5" />
          <span>Certificate Inventory</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Certificate</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Issuer</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {certificates.map((cert) => (
              <TableRow key={cert.id} className="hover:bg-muted/50">
                <TableCell className="space-y-1">
                  <div className="font-medium">{cert.commonName}</div>
                  {cert.san.length > 0 && (
                    <div className="text-xs text-muted-foreground">
                      SAN: {cert.san.slice(0, 2).join(', ')}
                      {cert.san.length > 2 && ` +${cert.san.length - 2} more`}
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>Expires: {cert.expiryDate}</span>
                  </div>
                </TableCell>
                <TableCell>{getTypeBadge(cert.type)}</TableCell>
                <TableCell>{getStatusBadge(cert.status, cert.daysUntilExpiry)}</TableCell>
                <TableCell className="text-sm">{cert.issuer}</TableCell>
                <TableCell className="text-sm">
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span>{cert.location}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};