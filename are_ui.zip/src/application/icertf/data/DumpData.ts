import { Certificate, CertificateStats, DeploymentTarget } from '../types/certificate';
 
export const mockCertificates: Certificate[] = [
  {
    id: '1',
    commonName: 'www.example.com',
    san: ['example.com', 'api.example.com'],
    issuer: 'Let\'s Encrypt',
    expiryDate: '2024-12-15',
    status: 'expiring',
    type: 'ssl',
    keySize: 2048,
    serialNumber: '0A:1B:2C:3D:4E:5F',
    owner: 'DevOps Team',
    location: 'prod-web-01',
    autoRenewal: true,
    lastDeployed: '2024-09-15',
    nextRenewal: '2024-11-15',
    daysUntilExpiry: 27
  },
  {
    id: '2',
    commonName: 'api.internal.com',
    san: ['internal.com'],
    issuer: 'Internal CA',
    expiryDate: '2025-03-20',
    status: 'active',
    type: 'ssl',
    keySize: 4096,
    serialNumber: '1F:2E:3D:4C:5B:6A',
    owner: 'Security Team',
    location: 'prod-api-cluster',
    autoRenewal: true,
    lastDeployed: '2024-03-20',
    nextRenewal: '2025-02-20',
    daysUntilExpiry: 132
  },
  {
    id: '3',
    commonName: 'mail.company.com',
    san: ['smtp.company.com', 'imap.company.com'],
    issuer: 'DigiCert',
    expiryDate: '2024-11-25',
    status: 'expiring',
    type: 'ssl',
    keySize: 2048,
    serialNumber: '2G:3F:4E:5D:6C:7B',
    owner: 'IT Team',
    location: 'mail-server-01',
    autoRenewal: false,
    lastDeployed: '2023-11-25',
    daysUntilExpiry: 7
  },
  {
    id: '4',
    commonName: 'code-signing-cert',
    san: [],
    issuer: 'GlobalSign',
    expiryDate: '2025-01-10',
    status: 'active',
    type: 'code-signing',
    keySize: 2048,
    serialNumber: '3H:4G:5F:6E:7D:8C',
    owner: 'Development Team',
    location: 'build-server',
    autoRenewal: true,
    lastDeployed: '2024-01-10',
    nextRenewal: '2024-12-10',
    daysUntilExpiry: 53
  },
  {
    id: '5',
    commonName: 'legacy.oldapp.com',
    san: [],
    issuer: 'Self-Signed',
    expiryDate: '2024-10-30',
    status: 'expired',
    type: 'ssl',
    keySize: 1024,
    serialNumber: '4I:5H:6G:7F:8E:9D',
    owner: 'Legacy Team',
    location: 'legacy-server',
    autoRenewal: false,
    lastDeployed: '2023-10-30',
    daysUntilExpiry: -19
  }
];
 
export const mockStats: CertificateStats = {
  total: 5,
  active: 2,
  expiring: 2,
  expired: 1,
  autoManaged: 3
};
 
export const mockDeploymentTargets: DeploymentTarget[] = [
  {
    id: '1',
    name: 'Production Web Server',
    type: 'nginx',
    host: 'prod-web-01.company.com',
    status: 'online',
    lastDeployment: '2024-09-15T10:30:00Z'
  },
  {
    id: '2',
    name: 'API Gateway',
    type: 'apache',
    host: 'api-gateway.company.com',
    status: 'online',
    lastDeployment: '2024-10-01T14:20:00Z'
  },
  {
    id: '3',
    name: 'Application Server',
    type: 'tomcat',
    host: 'app-server-01.company.com',
    status: 'maintenance',
    lastDeployment: '2024-09-28T09:15:00Z'
  },
  {
    id: '4',
    name: 'Enterprise Java Store',
    type: 'keystore',
    host: 'java-keystore.company.com',
    status: 'online',
    lastDeployment: '2024-10-10T16:45:00Z'
  }
];