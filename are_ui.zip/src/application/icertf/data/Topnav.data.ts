import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "ICertificate Flow",
        route: "/icertificate-flow",
        key: "1",
    },
];