import Container from "@/components/ui/container";
import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, AlertTriangle, Search, Brain, BarChart3, Loader } from "lucide-react"
import { Separator } from "@/components/ui/seperator"
import { Textarea } from "@/components/ui/textarea"

interface AgentResult {
    name: string
    status: "pending" | "processing" | "completed"
    result?: any
    icon: React.ReactNode
}

const LogAnalyzerHome = () => {
    const [appName, setAppName] = useState("")
    const [issueDescription, setIssueDescription] = useState("")
    const [isAnalyzing, setIsAnalyzing] = useState(false)
    const [, setCurrentAgentIndex] = useState(-1)
    const [agents, setAgents] = useState<AgentResult[]>([
        {
            name: "Orchestrator Agent",
            status: "pending",
            icon: <Search className="h-4 w-4" />,
        },
        {
            name: "Incident Issue Category Agent",
            status: "pending",
            icon: <AlertTriangle className="h-4 w-4" />,
        },
        {
            name: "Knowledge Fabricator Agent",
            status: "pending",
            icon: <Brain className="h-4 w-4" />,
        },
        {
            name: "Log Analyzer Agent",
            status: "pending",
            icon: <BarChart3 className="h-4 w-4" />,
        },
    ])

    const mockResults = {
        orchestrator: {
            summary: "Analysis initiated for database connectivity issues in user service",
            logSources: [
                "/var/log/app/user-service.log",
                "/var/log/database/postgresql.log",
                "/var/log/app/connection-pool.log",
                "/var/log/nginx/error.log",
            ],
            timeRange: "2024-01-15 14:30:00 - 2024-01-15 15:45:00",
            totalEvents: 3247,
        },
        category: {
            category: "Database Connectivity Failure",
            severity: "Critical",
            confidence: 0.96,
            relatedPatterns: ["Connection timeout errors", "Database pool exhaustion", "TCP connection refused"],
        },
        knowledge: {
            knownIssues: [
                "PostgreSQL max_connections limit reached during peak traffic",
                "Connection pool configuration insufficient for current load",
                "Network latency causing database connection timeouts",
                "Database server running out of available file descriptors",
            ],
            recommendations: [
                "Increase PostgreSQL max_connections parameter",
                "Optimize connection pool size and timeout settings",
                "Implement connection retry logic with exponential backoff",
                "Monitor and tune database server resources",
            ],
            similarIncidents: 7,
        },
        analyzer: {
            rootCause: "PostgreSQL connection limit exceeded due to connection pool misconfiguration",
            affectedUsers: 2156,
            errorRate: "31.7%",
            resolution:
                "Increase max_connections to 200, optimize connection pool settings, and implement connection monitoring",
            evidence: [
                "PostgreSQL 'too many connections' errors: 1,247 occurrences",
                "Connection pool exhaustion warnings: 89 occurrences",
                "TCP connection timeout errors: 567 occurrences",
                "Database unavailable errors: 2,156 occurrences",
                "Connection refused by database server: 334 occurrences",
            ],
        },
    }

    const handleAnalyze = async () => {
        if (!appName.trim() || !issueDescription.trim()) return

        setIsAnalyzing(true)
        setCurrentAgentIndex(0)

        // Reset agents
        setAgents((prev) => prev.map((agent) => ({ ...agent, status: "pending", result: undefined })))

        // Simulate sequential agent processing
        for (let i = 0; i < agents.length; i++) {
            setCurrentAgentIndex(i)

            // Set current agent to processing
            setAgents((prev) => prev.map((agent, index) => (index === i ? { ...agent, status: "processing" } : agent)))

            // Simulate processing time
            await new Promise((resolve) => setTimeout(resolve, 2000))

            // Set result based on agent
            let result: any;
            switch (i) {
                case 0:
                    result = mockResults.orchestrator
                    break
                case 1:
                    result = mockResults.category
                    break
                case 2:
                    result = mockResults.knowledge
                    break
                case 3:
                    result = mockResults.analyzer
                    break
            }

            // Mark as completed with result
            setAgents((prev) => prev.map((agent, index) => (index === i ? { ...agent, status: "completed", result } : agent)))
        }

        setIsAnalyzing(false)
        setCurrentAgentIndex(-1)
    }

    const getStatusIcon = (status: string) => {
        switch (status) {
            case "completed":
                return <CheckCircle className="h-4 w-4 text-green-600" />
            case "processing":
                return <Loader className="h-4 w-4 text-primary animate-spin" />
            default:
                return <div className="h-4 w-4 rounded-full border-2 border-muted-foreground" />
        }
    }

    const completedAgents = agents.filter((agent) => agent.status === "completed").length
    const progress = (completedAgents / agents.length) * 100
    return (
        <Container className="py-12">
            <div className="max-w-2xl mx-auto">
                <h2 className="text-xl">Log Analysis configuration</h2>
                <p className="text-muted-foreground text-sm">
                    Enter your application details to begin the log analysis process
                </p>
                <div className="mt-4 space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="appName">App Name</Label>
                        <Input
                            id="appName"
                            placeholder="e.g., TCS ARE"
                            value={appName}
                            onChange={(e) => setAppName(e.target.value)}
                            disabled={isAnalyzing}
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="issueDescription">Issue Description</Label>
                        <Textarea
                            id="issueDescription"
                            placeholder="e.g., Users unable to login, getting timeout errors"
                            value={issueDescription}
                            onChange={(e) => setIssueDescription(e.target.value)}
                            disabled={isAnalyzing}
                        />
                    </div>
                    <Button
                        onClick={handleAnalyze}
                        disabled={!appName.trim() || !issueDescription.trim() || isAnalyzing}
                        className="w-full"
                        size="lg"
                        variant="primary"
                    >
                        {isAnalyzing ? "Analyzing..." : "Analyze Logs"}
                    </Button>
                </div>
                {/* Progress Section */}
                {(
                    <div className="w-full mt-6">
                        <h3 className="text-sm text-muted-foreground uppercase font-medium">Analysis Progress</h3>
                        <p className="text-muted-foreground">Sequential agent processing: {completedAgents} of {agents.length} completed</p>
                        <div className="space-y-4 mt-4">
                            <Progress value={progress} className="w-full h-1" indicatorClassName="bg-blue-600" />
                            <div className="grid gap-3">
                                {agents.map((agent, index) => (
                                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg border">
                                        {getStatusIcon(agent.status)}
                                        {agent.icon}
                                        <span className="font-medium">{agent.name}</span>
                                        <Badge
                                            variant={
                                                agent.status === "completed"
                                                    ? "default"
                                                    : agent.status === "processing"
                                                        ? "secondary"
                                                        : "outline"
                                            }
                                        >
                                            {agent.status}
                                        </Badge>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {/* Results Section */}
                {agents.some((agent) => agent.status === "completed") && (
                    <div className="space-y-6 mt-6">
                        <h2 className="text-sm uppercase text-muted-foreground font-medium">Analysis Results</h2>
                        <div className="grid gap-2">
                            {agents.map(
                                (agent, index) =>
                                    agent.result && (
                                        <Card key={index} className="h-fit">
                                            <CardHeader>
                                                <CardTitle className="flex items-center gap-2 text-md font-normal">
                                                    {agent.icon}
                                                    {agent.name}
                                                </CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-2">
                                                {index === 0 && agent.result && (
                                                    <div className="space-y-3 text-sm">
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground mb-1">SUMMARY</h4>
                                                            <p>{agent.result.summary}</p>
                                                        </div>
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground mb-1">LOG SOURCES</h4>
                                                            <div className="flex flex-wrap gap-1">
                                                                {agent.result.logSources.map((source: string, i: number) => (
                                                                    <Badge key={i} variant="outline">
                                                                        {source}
                                                                    </Badge>
                                                                ))}
                                                            </div>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                                            <div>
                                                                <span className="text-muted-foreground">Time Range:</span>
                                                                <p className="font-mono text-xs">{agent.result.timeRange}</p>
                                                            </div>
                                                            <div>
                                                                <span className="text-muted-foreground">Total Events:</span>
                                                                <p className="font-semibold">{agent.result.totalEvents.toLocaleString()}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}

                                                {index === 1 && agent.result && (
                                                    <div className="space-y-3">
                                                        <div className="flex items-center gap-2">
                                                            <Badge variant="destructive">{agent.result.category}</Badge>
                                                            <Badge variant="outline">Severity: {agent.result.severity}</Badge>
                                                        </div>
                                                        <div>
                                                            <span className="text-muted-foreground text-sm">Confidence: </span>
                                                            <span className="font-semibold">{(agent.result.confidence * 100).toFixed(1)}%</span>
                                                        </div>
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground">RELATED PATTERNS</h4>
                                                            <ul className="list-disc list-inside space-y-1 text-sm">
                                                                {agent.result.relatedPatterns.map((pattern: string, i: number) => (
                                                                    <li key={i}>{pattern}</li>
                                                                ))}
                                                            </ul>
                                                        </div>
                                                    </div>
                                                )}

                                                {index === 2 && agent.result && (
                                                    <div className="space-y-3">
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground">KNOWN ISSUES</h4>
                                                            <ul className="list-disc list-inside space-y-1 text-sm">
                                                                {agent.result.knownIssues.map((issue: string, i: number) => (
                                                                    <li key={i}>{issue}</li>
                                                                ))}
                                                            </ul>
                                                        </div>
                                                        <Separator />
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground">RECOMMENDATIONS</h4>
                                                            <ul className="list-disc list-inside space-y-1 text-sm">
                                                                {agent.result.recommendations.map((rec: string, i: number) => (
                                                                    <li key={i}>{rec}</li>
                                                                ))}
                                                            </ul>
                                                        </div>
                                                        <div className="text-sm">
                                                            <span className="text-muted-foreground">Similar Incidents: </span>
                                                            <Badge variant="secondary">{agent.result.similarIncidents}</Badge>
                                                        </div>
                                                    </div>
                                                )}

                                                {index === 3 && agent.result && (
                                                    <div className="space-y-3">
                                                        <div className="p-3 bg-destructive/10 rounded-lg">
                                                            <h4 className="font-semibold text-sm text-destructive">ROOT CAUSE</h4>
                                                            <p className="text-sm">{agent.result.rootCause}</p>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div>
                                                                <span className="text-muted-foreground text-sm">Affected Users:</span>
                                                                <p className="font-semibold text-lg">{agent.result.affectedUsers.toLocaleString()}</p>
                                                            </div>
                                                            <div>
                                                                <span className="text-muted-foreground text-sm">Error Rate:</span>
                                                                <p className="font-semibold text-lg text-destructive">{agent.result.errorRate}</p>
                                                            </div>
                                                        </div>
                                                        <div className="p-3 bg-secondary/10 rounded-lg">
                                                            <h4 className="font-semibold text-sm text-secondary">RESOLUTION</h4>
                                                            <p className="text-sm">{agent.result.resolution}</p>
                                                        </div>
                                                        <div>
                                                            <h4 className="font-semibold text-sm text-muted-foreground">SUPPORTING EVIDENCE</h4>
                                                            <ul className="list-disc list-inside space-y-1 text-sm">
                                                                {agent.result.evidence.map((evidence: string, i: number) => (
                                                                    <li key={i}>{evidence}</li>
                                                                ))}
                                                            </ul>
                                                        </div>
                                                    </div>
                                                )}
                                            </CardContent>
                                        </Card>
                                    ),
                            )}
                        </div>
                    </div>
                )}
            </div>
        </Container>
    )
}
export default LogAnalyzerHome;