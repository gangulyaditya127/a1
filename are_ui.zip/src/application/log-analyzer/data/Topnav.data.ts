import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Log Analyzer",
        route: "/log-analyzer",
        key: "1",
    },
];
