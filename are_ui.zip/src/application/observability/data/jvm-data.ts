export type JvmLog = {
    timestamp: string
    level: "INFO" | "WARN" | "ERROR"
    serviceInstance: string
    thread: string
    message: string
}

export type JvmGraphPoint = {
    t: string // formatted timestamp
    value: number
    // optional fields for multiseries
    threads?: number
    blocked?: number
}

export type JvmDetailView = {
    alert: {
        title: string
        subtitle: string
        status: "Critical"
        description: string
        affectedService: string
        endpoint: string
        errorRate: string
        firstSeen: string // e.g., "25 minutes ago"
        currentSeverity: "Critical"
        runbookSnippet: string[]
    }
    graphs: {
        responseTime: {
            points: JvmGraphPoint[]
            averageMs: number
            timeWindowLabel: string
        }
        heapUsage: {
            points: JvmGraphPoint[]
            timeWindowLabel: string
        }
        gcPauses: {
            points: JvmGraphPoint[]
            timeWindowLabel: string
            note: string
        }
        threads: {
            points: JvmGraphPoint[]
            timeWindowLabel: string
            highlight: string
        }
    }
    logs: JvmLog[]
    correlations: Array<{
        label: string
        value: string
        status: "normal" | "anomalous"
        timestamp: string
    }>
    actions: {
        primary: {
            label: string
            description: string
            whenToUse: string
        }
        secondary: Array<{ label: string; description: string }>
        quickActions: string[]
    }
}

// Helpers
// function formatReadable(ts: Date): string {
//     // "Tuesday, September 23, 2025 at 10:25:52 AM" style
//     const weekday = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(ts)
//     const month = new Intl.DateTimeFormat("en-US", { month: "long" }).format(ts)
//     const day = new Intl.DateTimeFormat("en-US", { day: "2-digit" }).format(ts)
//     const year = new Intl.DateTimeFormat("en-US", { year: "numeric" }).format(ts)
//     const time = new Intl.DateTimeFormat("en-US", {
//         hour: "numeric",
//         minute: "2-digit",
//         second: "2-digit",
//         hour12: true,
//     }).format(ts)
//     return `${time}`
// }
function formatReadable(ts: Date): string {
    return new Intl.DateTimeFormat("en-US", {
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
    }).format(ts);
}

function minutesAgoLabel(minutes: number): string {
    return `${minutes} seconds ago`
}

export function generateJvmDetailView(nowInput?: Date): JvmDetailView {
    const now = nowInput ? new Date(nowInput) : new Date()

    // Response time: points at -6h, -3h, now (fixed values to average 1173 ms)
    const rtTimes = [-6, -3, 0].map((h) => new Date(now.getTime() + h * 60 * 60 * 1000))
    const rtValues = [1792, 900, 827]
    const rtAvg = Math.round(rtValues.reduce((a, b) => a + b, 0) / rtValues.length) // 1173

    const responseTime = {
        points: rtTimes.map((d, i) => ({ t: formatReadable(d), value: rtValues[i] })),
        averageMs: rtAvg,
        timeWindowLabel: "Last 6 hours",
    }

    // Heap usage: last 1 hour, 5 points
    const heapOffsetsMin = [60, 45, 30, 15, 0]
    const heapValues = [65, 72, 78, 85, 92] // %
    const heapUsage = {
        points: heapOffsetsMin.map((m, i) => ({
            t: formatReadable(new Date(now.getTime() - m * 60 * 1000)),
            value: heapValues[i],
        })),
        timeWindowLabel: "Last 1 hour",
    }

    // GC pauses: last 30 minutes, 5 intervals, include a big spike >=1200ms
    const gcOffsetsMin = [30, 24, 18, 12, 6].reverse() // more recent at end
    const gcValues = [120, 180, 1300, 200, 150] // includes big spike
    const gcPauses = {
        points: gcOffsetsMin.map((m, i) => ({
            t: formatReadable(new Date(now.getTime() - m * 60 * 1000)),
            value: gcValues[i],
        })),
        timeWindowLabel: "Last 30 minutes",
        note: "GC pause p99 spike observed (>=1200 ms).",
    }

    // Threads: last 30 minutes with small variations; blocked > 10 in places
    const thrOffsetsMin = [30, 24, 18, 12, 6, 0]
    const threadsSeries = [190, 195, 205, 198, 202, 200]
    const blockedSeries = [6, 8, 12, 9, 11, 7]
    const threads = {
        points: thrOffsetsMin.map((m, i) => ({
            t: formatReadable(new Date(now.getTime() - m * 60 * 1000)),
            value: threadsSeries[i],
            threads: threadsSeries[i],
            blocked: blockedSeries[i],
        })),
        timeWindowLabel: "Last 30 minutes",
        highlight: "Blocked threads exceeded 10 at least once.",
    }

    // Logs: 20 recent lines descending
    const mkLog = (
        offsetSeconds: number,
        level: JvmLog["level"],
        thread: string,
        message: string,
        inst = "pricing-service-7f9d",
    ) =>
        ({
            timestamp: formatReadable(new Date(now.getTime() - offsetSeconds * 1000)),
            level,
            serviceInstance: inst,
            thread,
            message,
        }) as JvmLog

    const logs: JvmLog[] = [
        mkLog(
            5,
            "ERROR",
            "GC-Thread",
            "Full GC (Ergonomics) 1300ms; concurrent mark-sweep cycle triggered; heap before 90%, after 78%",
        ),
        mkLog(15, "WARN", "VM-Thread", "Long safepoint detected: 1220ms at SafepointSynchronize::begin"),
        mkLog(22, "INFO", "http-nio-8080-exec-12", "GET /api/v1/getPricing latency=1792ms customerId=48291"),
        mkLog(32, "INFO", "http-nio-8080-exec-3", "Cache hit for pricing key=region:us-east:sku:ABC-123"),
        mkLog(40, "WARN", "GC-Thread", "Concurrent mark-sweep cycle took 980ms; remark=410ms"),
        mkLog(48, "INFO", "scheduler-1", "Background refresh of pricing tiers completed"),
        mkLog(58, "INFO", "http-nio-8080-exec-15", "GET /api/v1/getPricing latency=842ms customerId=77410"),
        mkLog(75, "INFO", "Pool-Worker-3", "DB read p95=145ms for pricing_rules"),
        mkLog(82, "WARN", "MemoryManager", "Heap usage high: 91.5%; young gen promotions increasing"),
        mkLog(95, "INFO", "http-nio-8080-exec-4", "GET /healthz 200 OK"),
        mkLog(
            110,
            "ERROR",
            "GC-Thread",
            "OutOfMemory warning threshold reached: unable to expand eden; considering full collection",
        ),
        mkLog(125, "INFO", "http-nio-8080-exec-7", "GET /api/v1/getPricing latency=901ms customerId=11223"),
        mkLog(137, "WARN", "BlockingMonitor", "Blocked threads count=12 exceeding threshold=10"),
        mkLog(150, "INFO", "Pool-Worker-1", "External pricing provider latency p95=420ms"),
        mkLog(
            170,
            "INFO",
            "Deploy-Agent",
            "Recent deploy detected: pricing-service@2.4.18 at " + formatReadable(new Date(now.getTime() - 25 * 60 * 1000)),
        ),
        mkLog(190, "INFO", "http-nio-8080-exec-10", "GET /api/v1/getPricing latency=827ms customerId=91442"),
        mkLog(210, "WARN", "GC-Thread", "Concurrent mark-sweep remark pause 520ms"),
        mkLog(230, "INFO", "http-nio-8080-exec-9", "GET /api/v1/getPricing latency=905ms customerId=55311"),
        mkLog(250, "INFO", "Pool-Worker-2", "Cache hitrate last 5m=97%"),
        mkLog(270, "INFO", "MetricsReporter", "Emitted JVM metrics successfully"),
    ]

    const correlations = [
        {
            label: "Cache hitrate",
            value: "97% (normal)",
            status: "normal" as const,
            timestamp: formatReadable(new Date(now.getTime() - 5 * 60 * 1000)),
        },
        {
            label: "DB p95 (reads)",
            value: "145 ms (normal)",
            status: "normal" as const,
            timestamp: formatReadable(new Date(now.getTime() - 8 * 60 * 1000)),
        },
        {
            label: "External pricing provider latency",
            value: "p95 420 ms (anomalous)",
            status: "anomalous" as const,
            timestamp: formatReadable(new Date(now.getTime() - 12 * 60 * 1000)),
        },
        {
            label: "Recent deploy",
            value: "pricing-service@2.4.18",
            status: "normal" as const,
            timestamp: formatReadable(new Date(now.getTime() - 25 * 60 * 1000)),
        },
    ]

    const actions = {
        primary: {
            label: "Restart JVM",
            description: "Safely restart the JVM to clear heap pressure and recover from prolonged GC pauses.",
            whenToUse: "If full GCs or safepoints p99 > 500ms and heap > 90%.",
        },
        secondary: [
            { label: "Increase heap", description: "If metaspace/heap are exhausted or near limits." },
            { label: "Investigate recent deploy", description: "Correlate code/config changes with performance regression." },
            { label: "Collect thread dump and heap dump", description: "Capture JVM state for postmortem analysis." },
        ],
        quickActions: ["View Thread Dump", "Download Logs", "Acknowledge"],
    }

    return {
        alert: {
            title: "High latency detected",
            subtitle: "p99 1792 ms • JVM GC pause p99 1200 ms",
            status: "Critical",
            description:
                "Pricing microservice is experiencing long-tail latency. Evidence points to JVM runtime issues (GC pauses / heap pressure / thread contention).",
            affectedService: "Get OTP",
            endpoint: "GET /api/v1/getPricing",
            errorRate: "18%",
            firstSeen: minutesAgoLabel(43),
            currentSeverity: "Critical",
            runbookSnippet: ["check GC pause history", "check heap usage", "restart JVM if GC safepoints > 500ms."],
        },
        graphs: {
            responseTime,
            heapUsage,
            gcPauses,
            threads,
        },
        logs,
        correlations,
        actions,
    }
}
