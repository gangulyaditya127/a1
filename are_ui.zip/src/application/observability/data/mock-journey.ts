export const MOCK_JOURNEY = [
    {
        appName: "Application Reliability Engineering",
        className: 'col-span-2',
        journey: [
            {
                name: "Login & SignUp",
                activeUsers: 1678,
                happy: 89,
                unhappy: 10,
                frustated: 1,
                dropped: 74,
                availablity: 99.23
            },
            {
                name: "Landing Page",
                activeUsers: 1473,
                happy: 96,
                unhappy: 3,
                frustated: 1,
                dropped: 12,
                availablity: '96.70'
            },
            {
                name: "Open Saving Bank Account",
                activeUsers: 1250,
                happy: 76,
                unhappy: 16,
                frustated: 8,
                dropped: 110,
                availablity: 69.56
            },
            {
                name: "Pre-approved Personal Loan",
                activeUsers: 1200,
                happy: 89,
                unhappy: 8,
                frustated: 3,
                dropped: 17,
                availablity: 91.54
            },
            {
                name: "Fund Transfer",
                activeUsers: 976,
                happy: 93,
                unhappy: 2,
                frustated: 5,
                dropped: 23,
                availablity: 97.32
            },
            {
                name: "Credit Card",
                activeUsers: 982,
                happy: 94,
                unhappy: 4,
                frustated: 2,
                dropped: 43,
                availablity: 93.21
            },
            {
                name: "UPI Payments",
                activeUsers: 872,
                happy: 97,
                unhappy: 1,
                frustated:2,
                dropped: 3,
                availablity: 94.42
            },
            {
                name: "Bill Pay/Recharge/FASTag",
                activeUsers: 789,
                happy: 92,
                unhappy: 3,
                frustated: 5,
                dropped: 3,
                availablity: 96.71
            },
            {
                name: "Demat/Mutual Funds",
                activeUsers: 876,
                happy: 91,
                unhappy: 8,
                frustated: 1,
                dropped: 3,
                availablity: 91.43
            },
            {
                name: "Stocks/IPO",
                activeUsers: 763,
                happy: 96,
                unhappy: 3,
                frustated: 1,
                dropped: 3,
                availablity: 95.42
            },
            {
                name: "PPF",
                activeUsers: 876,
                happy: 93,
                unhappy: 4,
                frustated: 3,
                dropped: 3,
                availablity: 97.41
            },
        ]
    },
   
]