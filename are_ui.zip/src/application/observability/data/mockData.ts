function formatDate(date: Date) {
  return date.toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata', // IST
    hour: '2-digit',
    minute: '2-digit',
    day: '2-digit',
    month: 'short'
  });
}

// export function generateMockData(dataPoints: number, baseValue: number, variability: number) {
//   return Array.from({ length: dataPoints }, (_, i) => {
//     const date = new Date(Date.now() - (dataPoints - i - 1) * 5 * 60000);
//     const value = baseValue + (Math.random() - 0.5) * 2 * variability;
//     return {
//       date: formatDate(date),
//       value: Math.max(0, Math.round(value * 100) / 100)
//     };
//   });
// }

export function generateMockData(dataPoints: number, baseValue: number, variability: number) {
  return Array.from({ length: dataPoints }, (_, i) => {
    // const date = new Date(Date.now() + i * 5 * 60000);
    const date = new Date(Date.now() - (dataPoints - i - 1) * 5 * 60000);

    const firstSpikeStart = Math.floor(dataPoints * 0.3);
    const firstSpikeEnd = firstSpikeStart; // spike lasts 3 points
    const secondSpikeStart = Math.floor(dataPoints * 0.8);
    const secondSpikeEnd = secondSpikeStart;

    let value;
    if (i >= firstSpikeStart && i <= firstSpikeEnd) {
      // First spike
      value = baseValue * 2 + Math.random() * variability;
    } else if (i >= secondSpikeStart && i <= secondSpikeEnd) {
      // Second spike
      value = baseValue * 2.5 + Math.random() * variability;
    } else {
      // Normal values with slight randomness
      value = baseValue + (Math.random() - 0.5) * 2 * variability;
    }

    return {
      date: formatDate(date),
      value: Math.max(0, Math.round(value * 100) / 100)
    };
  });
}

export function generateMockLogs(count: number) {
  const logLevels = ['INFO', 'WARN', 'ERROR'];
  const services = ['OTP_GEN', 'OTP_VERIFY', 'AUTH', 'DB'];
  const messages = [
    'OTP generated successfully',
    'OTP verified successfully',
    'Invalid OTP attempt',
    'User authentication successful',
    'Database connection timeout',
    'High latency detected in OTP generation',
    'Unusual activity detected: multiple OTP requests',
    'System load approaching threshold',
  ];

  return Array.from({ length: count }, (_, i) => {
    const date = new Date(Date.now() - i * 2 * 60000);
    return {
      timestamp: formatDate(date),
      level: logLevels[Math.floor(Math.random() * logLevels.length)],
      service: services[Math.floor(Math.random() * services.length)],
      message: messages[Math.floor(Math.random() * messages.length)],
    };
  });
}
