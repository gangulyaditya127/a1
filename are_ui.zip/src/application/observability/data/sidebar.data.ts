import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Home",
          icon: "home",
          route: "/observability/home",
        },
      ],
    },
  ],
  bottomNavList: [
    {
      key: "2",
      content: "Exit",
      icon: "log-out",
      route: "/observability-user-onboard",
    },
  ],
};

export default SIDEBAR_DATA;
