export const PERFORMANCE = [
  {
    step: "Verify Aadhar & PAN",
    actions: [
      { name: "Register Mobile number", avgResp: "200", p95: "290", errorRate: "2", availability: "99.23" },
      { name: "Aadhar Consent", avgResp: "128", p95: "128", errorRate: "2", availability: "95.45" },
      { name: "Get OTP", avgResp: "5541", p95: "7234", errorRate: "18", availability: "69.56", warning: true },
      { name: "Validate OTP", avgResp: "111", p95: "212", errorRate: "2", availability: "94.66" },
      { name: "PAN consent", avgResp: "322", p95: "389", errorRate: "2", availability: "93.00" },
      { name: "PAN screening", avgResp: "310", p95: "398", errorRate: "8", availability: "93.00" },
      { name: "Dedup PAN", avgResp: "717", p95: "924", errorRate: "5", availability: "93.00" },
    ],
    metrics: { happy: 91, unhappy: 6, frustrated: 3 }
  },
  {
    step: "Get More Customer details",
    actions: [
      { name: "Prefetch Customer Data", avgResp: "58", p95: "258", errorRate: "2", availability: "96.30" },
      { name: "Save Data", avgResp: "382", p95: "403", errorRate: "7", availability: "94.08", warning: true },
      { name: "Preview employer data", avgResp: "678", p95: "854", errorRate: "9", availability: "93.55", warning: true },
    ],
    metrics: { happy: 92, unhappy: 3, frustrated: 4 }
  },
  {
    step: "Customer KYC",
    actions: [
      { name: "VKYC Consent", avgResp: "287", p95: "487", errorRate: "2", availability: "96.30" },
      { name: "Request URL", avgResp: "121", p95: "234", errorRate: "2", availability: "94.08" },
      { name: "KYC approved Webhook", avgResp: "89", p95: "189", errorRate: "2", availability: "93.55" },
    ],
    metrics: { happy: 100, unhappy: 0, frustrated: 0 }
  },
  {
    step: "Account Opening",
    actions: [
      { name: "CIF creation", avgResp: "123", p95: "323", errorRate: "2", availability: "94.08" },
      { name: "Account details", avgResp: "221", p95: "421", errorRate: "2", availability: "96.30" },
      { name: "PDF account opening form", avgResp: "692", p95: "930", errorRate: "9", availability: "94.08", warning: true },
    ],
    metrics: { happy: 93, unhappy: 6, frustrated: 1 }
  },
]