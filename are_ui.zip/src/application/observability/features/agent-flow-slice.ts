import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { ThunkAction, Action } from "@reduxjs/toolkit"
export type StepStatus = "idle" | "running" | "completed" | "error"
export type AgentStatus = "idle" | "running" | "completed"
import { RootState } from "@/lib/redux/store"

type Step = {
    key: string
    title: string
    description: string
    agent: string
    status: StepStatus
    details?: string
    startedAt?: number
    completedAt?: number
}

type Agent = {
    name: string
    role: string
    status: AgentStatus
    firstSeenAt?: number
    completedAt?: number
}

type LogItem = {
    ts: number
    scope: string
    message: string
}

type AgentFlowState = {
    running: boolean
    fixed: boolean
    startedAt?: number
    completedAt?: number
    steps: Step[]
    activeAgents: Agent[]
    activity: LogItem[]
}

const initialState: AgentFlowState = {
    running: false,
    fixed: false,
    steps: [
        {
            key: "analyze_issue",
            title: "Analyze the issue",
            description: "Analyze service get otp latency.",
            agent: "System Agent",
            status: "idle",
        },
        {
            key: "fetch_incidents",
            title: "Fetch incidents",
            description: "Query incident store for related latency issues.",
            agent: "Incident Agent",
            status: "idle",
        },
        {
            key: "issue_categorization",
            title: "Issue Categorization",
            description: "Classifies the incident into predefined categories for faster triage and routing.",
            agent: "Ticket Categorization Agent",
            status: "idle",
        },
        {
            key: "data_validation",
            title: "Data Validation",
            description: "Ensures the incident details and input data are accurate, complete, and consistent.",
            agent: "Data Quality Agent",
            status: "idle",
        },
        {
            key: "priority_validation",
            title: "Priority Validation",
            description: "Ensures the incident is assigned the correct priority based on impact and urgency.",
            agent: "Data Quality Agent",
            status: "idle",
        },
        {
            key: "log_extraction",
            title: "Log Extraction",
            description: "Collects relevant system/application logs to aid in troubleshooting.",
            agent: "Log extraction Agent",
            status: "idle",
        },
        {
            key: "historical_rca",
            title: "Historical RCA",
            description: "Analyzes past incidents and their resolutions to identify patterns and improve the RCA.",
            agent: "Root Cause Analysis Agent",
            status: "idle",
        },
        {
            key: "recommendation",
            title: "Recommendation",
            description: "Suggests the best possible resolution steps based on insights and past learnings.",
            agent: "Resolution Recommendation Agent",
            status: "idle",
        },
        {
            key: "automated_resolution",
            title: "Automated Resolution",
            description: "Executes predefined or AI-driven actions to resolve the issue without manual intervention.",
            agent: "Ticket Resolution Agent",
            status: "idle",
        },
        {
            key: "problem_record",
            title: "Create problem record",
            description: "Generate PRB record with root cause, resolution steps, and links to evidence.",
            agent: "Problem Record Creation Agent",
            status: "idle",
        },
    ],
    activeAgents: [],
    activity: [],
}

const slice = createSlice({
    name: "agentFlow",
    initialState,
    reducers: {
        startRun(state) {
            state.running = true
            state.startedAt = Date.now()
            state.activity.push({
                ts: Date.now(),
                scope: "System",
                message: "Auto-fix workflow started.",
            })
        },
        stepStarted(state, action: PayloadAction<{ index: number }>) {
            const step = state.steps[action.payload.index]
            step.status = "running"
            step.startedAt = Date.now()
            // Add agent if not present
            if (!state.activeAgents.find((a) => a.name === step.agent)) {
                state.activeAgents.push({
                    name: step.agent,
                    role: step.agent,
                    status: "running",
                    firstSeenAt: Date.now(),
                })
            } else {
                // Mark as running if it starts a new step
                const agent = state.activeAgents.find((a) => a.name === step.agent)!
                agent.status = "running"
            }
            state.activity.push({
                ts: Date.now(),
                scope: step.agent,
                message: `Starting step: ${step.title}`,
            })
        },
        stepCompleted(state, action: PayloadAction<{ index: number; details?: string }>) {
            const step = state.steps[action.payload.index]
            step.status = "completed"
            step.completedAt = Date.now()
            step.details = action.payload.details

            // Mark the agent complete for this step (they may run again later)
            const agent = state.activeAgents.find((a) => a.name === step.agent)
            if (agent) {
                agent.status = "completed"
                agent.completedAt = Date.now()
            }

            state.activity.push({
                ts: Date.now(),
                scope: step.agent,
                message: `Step completed: ${step.title}`,
            })
        },
        addLog(state, action: PayloadAction<LogItem>) {
            state.activity.push(action.payload)
        },
        markFixed(state) {
            console.log("Issue fixed and workflow completed.");

            state.running = false
            state.fixed = true
            state.completedAt = Date.now()
            state.activity.push({
                ts: Date.now(),
                scope: "System",
                message: "Issue fixed and workflow completed.",
            })
        },
    },
})

export const { startRun, stepStarted, stepCompleted, addLog, markFixed } = slice.actions

export default slice.reducer

export type AppThunk = ThunkAction<void, RootState, unknown, Action<string>>

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms))

export const runAutoFixFlow = (): AppThunk => {
    return async (dispatch, getState: () => {
        agentFlow: {
            fixed: boolean,
            running: boolean,
            steps: Step[],
            activeAgents: Agent[],
            activity: LogItem[]
        };
    }) => {
        const { agentFlow } = getState()
        if (agentFlow?.fixed || agentFlow?.running) return

        dispatch(startRun())

        const runStep = async (index: number, logMessages: string[], details: string) => {
            dispatch(stepStarted({ index }))
            for (const m of logMessages) {
                dispatch(
                    addLog({
                        ts: Date.now(),
                        scope: agentFlow.steps[index].agent,
                        message: m,
                    }),
                )
                await delay(700)
            }
            dispatch(stepCompleted({ index, details }))
            await delay(500)
        }

        // // 1) Analyze the issue
        // await runStep(
        //   0,
        //   ["Collecting JVM metrics (GC, heap, threads)...", "Analyzing latency trend for get_pricing..."],
        //   "Analysis indicates recurring GC pauses and thread contention.",
        // )

        // // 2) Fetch incidents
        // await runStep(
        //   1,
        //   [
        //     "Querying incident repository for pattern: *.latency.get_pricing",
        //     "Correlating incidents with JVM metrics time window...",
        //   ],
        //   "Fetched 3 related incidents in the last 2 hours.",
        // )

        // // 3) Problem identification
        // await runStep(
        //   2,
        //   [
        //     "Identifying root cause across logs and metrics...",
        //     "Correlated high JVM GC times with elevated service latency.",
        //   ],
        //   "Root cause identified: JVM degradation causing high latency.",
        // )

        // // 4) Automated resolution (JVM restart)
        // await runStep(
        //   3,
        //   ["Draining traffic from get_pricing instance...", "Restarting JVM...", "Validating warm-up and health checks..."],
        //   "JVM restarted successfully; service healthy.",
        // )

        // // 5) Problem record
        // await runStep(
        //   4,
        //   ["Compiling PRB document with evidence and timeline...", "Attaching metrics snapshots and incident links..."],
        //   "PRB created with resolution steps. PRB No.: 12943243",
        // )

        // 0) Analyze the issue
        await runStep(
            0,
            [
                "Collecting JVM metrics (GC, heap, threads)...",
                "Analyzing latency trend for get_pricing across last 30m...",
                "Computing p95/p99 and comparing with baseline...",
            ],
            "Analysis indicates recurring GC pauses and thread contention causing increased p99 latency.",
        );

        // 1) Fetch incidents
        await runStep(
            1,
            [
                "Querying incident repository for pattern: *.latency.get_pricing...",
                "Filtering incidents by time window: last 2 hours...",
                "Correlating incidents with JVM metrics and deploy timeline...",
            ],
            "Fetched 1 related incidents in the last 2 hours; one coincides with a deployment.",
        );

        // 2) Issue Categorization
        await runStep(
            2,
            [
                "Parsing incident title, tags and error signatures...",
                "Mapping observed symptoms to taxonomy: performance / resource / deployment...",
                "Assigning probable category using classifier and confidence score...",
            ],
            "Categorized as `performance` (confidence 87%) with secondary tag `resource-congestion`.",
        );

        // 3) Data Validation
        await runStep(
            3,
            [
                "Validating required fields: service id, timestamp, host, traces...",
                "Checking for missing or malformed timestamps and metric gaps...",
                "Cross-validating host IDs against inventory and topology service...",
            ],
            "Incident data validated — timestamps normalized; one host had missing tag which was inferred from inventory.",
        );

        // 4) Priority Validation
        await runStep(
            4,
            [
                "Computing impact: affected users, error rate, business transactions...",
                "Estimating urgency using SLAs and downstream dependencies...",
                "Comparing computed priority with ticket priority and business hours...",
            ],
            "Priority upgraded to `P1` due to high user impact on billing flow during business hours.",
        );

        // 5) Log Extraction
        await runStep(
            5,
            [
                "Identifying relevant log sources for service get_pricing (app, gateway, JVM)...",
                "Streaming logs for host list and time window (+/- 15m around anomaly)...",
                "Extracting stack traces, error codes, and warning patterns for quick analysis...",
            ],
            "Collected logs from 6 instances; extracted multiple GC warnings and repeated timeout stack traces.",
        );

        // 6) Historical RCA
        await runStep(
            6,
            [
                "Searching historical incidents for similar error signatures and categories...",
                "Retrieving previous PRBs and applied mitigations for matching patterns...",
                "Comparing root causes, fixes and recurrence intervals to current evidence...",
            ],
            "Found 2 previous RCAs pointing to JVM GC tuning and thread pool misconfiguration as root causes.",
        );

        // 7) Recommendation
        await runStep(
            7,
            [
                "Generating resolution candidates from playbook: increase heap, tune GC, adjust thread pool, restart faulty node...",
                "Scoring recommendations by risk, effort and expected impact...",
                "Selecting top recommendations and preparing rollback notes...",
            ],
            "Top recommendation: apply GC tuning + restart non-critical instances in a rolling window; mitigation reduces p99 by estimated 40%.",
        );

        // 8) Automated Resolution
        await runStep(
            8,
            [
                "Validating preconditions and runbook approvals for automated remediation...",
                "Executing playbook: apply GC flags to candidate hosts, perform rolling restart on 2 nodes...",
                "Monitoring post-action metrics and rollback if error threshold exceeded...",
            ],
            "Automated remediation executed on 2 nodes; p99 latency reduced and error rate returned to baseline — no rollback required.",
        );

        // 9) Create Problem Record
        await runStep(
            9,
            [
                "Assembling PRB: incident timeline, root cause evidence, logs and metrics snapshots...",
                "Populating resolution steps, changed configs and verification results into PRB template...",
                "Linking related incidents, commits, and runbook references for auditability...",
            ],
            "Problem record created with root cause `JVM GC + thread pool misconfig`, remediation steps, and links to logs/PRs.",
        );



        dispatch(markFixed())
    }
}
