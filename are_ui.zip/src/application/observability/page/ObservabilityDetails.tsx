import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { getFormatDate } from "@/lib/date.utils";
import { Link, useParams } from "react-router-dom";
// import JourneyChart from "../features/journey-chart";
// import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PERFORMANCE } from "../data/mock-performance";
import { cn } from "@/lib/tailwind.utils";
import { RootState } from "@/lib/redux/store"
import { useSelector } from "react-redux"
// import { generateLabels } from "../util";

export default function ObservabilityDetails() {

    const { journey } = useParams();
    // const [labels] = useState(() => generateLabels())

    return (
        <Container className="my-6 mb-12">
            <NavigateBackButton />
            <h4 className="text-sm font-medium uppercase text-muted-foreground">
                Journey Execution Experience
            </h4>
            <h3 className="text-2xl font-medium">{journey}</h3>
            <p className="text-sm text-muted-foreground min-h-8">
                {getFormatDate(new Date().toISOString())}
            </p>

            <div className="grid gap-4">
                <PerformanceTable journey={journey ?? ''} />
            </div>
        </Container>)
}


function PerformanceTable({
    journey
}: { journey: string }) {
    const { fixed } = useSelector((s: RootState) => s.agentFlow)
    console.log(useSelector((s: RootState) => s.agentFlow))
    return (
        <Table className="border">
            <TableHeader>
                <TableRow>
                    <TableHead className="w-[200px]">Steps</TableHead>
                    <TableHead className="text-center border-x" colSpan={3}>Happy + Unhappy + Frustrated</TableHead>
                    <TableHead className="text-left">Actions / API</TableHead>
                    <TableHead className="text-right border-r">Average Resp time</TableHead>
                    <TableHead className="text-right">P(95)</TableHead>
                    <TableHead className="text-center border-x">Error Rate</TableHead>
                    <TableHead className="text-right">Availability</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {PERFORMANCE.map((row, idx) => (
                    <>
                        <TableRow key={idx} className="group">
                            <TableCell className="font-medium border-r" rowSpan={row.actions.length + 1}>{row.step}</TableCell>
                            <TableCell className="text-center text-green-400 font-medium text-lg" rowSpan={row.actions.length + 1}>
                                {row.metrics.happy}%
                            </TableCell>
                            <TableCell className="text-center text-yellow-400 font-medium text-lg" rowSpan={row.actions.length + 1}>
                                {row.metrics.unhappy}%
                            </TableCell>
                            <TableCell className="text-center text-yellow-400 font-medium text-lg border-r" rowSpan={row.actions.length + 1}>
                                {row.metrics.frustrated}%
                            </TableCell>
                        </TableRow>
                        {
                            row.actions.map((action, actionIdx) => (

                                <TableRow key={`${idx}-${actionIdx}`} className={cn(action.warning ? "bg-red-950/5" : "", actionIdx != row.actions.length - 1 ? "border-0 border-b-0" : '')}>
                                    <TableCell className={cn(action.name === 'Get OTP' && !fixed && action.warning ? 'text-red-600 font-medium' : "")}>
                                        <Link to={`/observability/${journey}/timeline`}>{action.name}</Link>
                                    </TableCell>

                                    <TableCell
                                        className={cn(
                                            action.name === 'Get OTP' && !fixed && action.warning ? 'text-red-600 font-medium' : "",
                                            "text-right border-r"
                                        )}
                                    >
                                        {action.name === "Get OTP" && fixed ? `${200} ms` : `${action.avgResp} ms`}
                                    </TableCell>

                                    <TableCell
                                        className={cn(
                                            action.name === 'Get OTP' && !fixed && action.warning ? 'text-red-600 font-medium' : "",
                                            "text-right border-r"
                                        )}
                                    >
                                        {action.name === "Get OTP" && fixed ? `${382} ms` : `${action.p95} ms`}
                                    </TableCell>

                                    <TableCell
                                        className={cn(
                                            action.name === 'Get OTP' && !fixed && action.warning ? 'text-red-600 font-medium' : "",
                                            "text-right border-r"
                                        )}
                                    >
                                        {action.name === "Get OTP" && fixed ? `${2} %` : `${action.errorRate} %`}
                                    </TableCell>

                                    <TableCell
                                        className={cn(
                                            action.name === 'Get OTP' && !fixed && action.warning ? 'text-red-600 font-medium' : "",
                                            "text-right border-r"
                                        )}
                                    >
                                        {action.name === "Get OTP" && fixed ? `${93.25} %` : `${action.availability} %`}
                                    </TableCell>
                                </TableRow >

                            ))
                        }
                    </>

                ))}
            </TableBody>
        </Table >
    )
}