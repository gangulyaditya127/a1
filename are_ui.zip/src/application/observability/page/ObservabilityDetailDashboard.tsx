import { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { generateMockData, generateMockLogs } from '../data/mockData'
import { Chart } from '../features/chart'
import Container from '@/components/ui/container'
import { NavigateBackButton } from '@/components/ui/navigate-back-button'
import { generateJvmDetailView } from '../data/jvm-data'
import { useSelector } from 'react-redux'
import { RootState } from "@/lib/redux/store"
import AutofixButton from '@/components/ui/AutofixButton'

export default function Dashboard() {
    const [otpData, setOtpData] = useState<any>({
        generationRate: [],
        verificationSuccess: [],
        averageResponseTime: [],
        failedAttempts: []
    });
    const [systemData, setSystemData] = useState<any>({
        cpuUsage: [],
        memoryUsage: [],
        databaseConnections: [],
        networkLatency: []
    });
    const [securityData, setSecurityData] = useState<any>({
        unusualActivityDetections: [],
        failedLoginAttempts: [],
        successfulLogins: []
    });
    const [logs, setLogs] = useState<any>([]);
    const data = useMemo(() => generateJvmDetailView(), []);
    const { fixed } = useSelector((s: RootState) => s.agentFlow)
    useEffect(() => {
        setOtpData({
            generationRate: generateMockData(50, 100, 20),
            verificationSuccess: generateMockData(50, 95, 5),
            averageResponseTime: generateMockData(50, 200, 50),
            failedAttempts: generateMockData(50, 240, 20)
        });

        setSystemData({
            cpuUsage: generateMockData(50, 60, 15),
            memoryUsage: generateMockData(50, 70, 10),
            databaseConnections: generateMockData(50, 500, 100),
            networkLatency: generateMockData(50, 50, 20)
        });

        setSecurityData({
            unusualActivityDetections: generateMockData(50, 2, 2),
            failedLoginAttempts: generateMockData(50, 10, 5),
            successfulLogins: generateMockData(50, 50, 15)
        });

        setLogs(generateMockLogs(100));
    }, []);

    return (
        <Container className="mt-4 mb-16">
            <NavigateBackButton />
            <div className="flex items-center gap-2">
                {!fixed ? <p className="text-foreground text-3xl font-medium">{data.alert.title}</p> : <p className="text-foreground text-3xl font-medium">Latency issue resolved – OTP Service</p>}
                {fixed ? <span className="inline-block border border-green-500 bg-green-500/40 px-2 py-1 rounded-full text-xs ">Operational</span> : <span className="inline-block border border-red-500 bg-red-500/40 px-2 py-1 rounded-full text-xs ">Critical</span>}
            </div>
            {(
                <div className="flex justify-between items-center">
                    <div className="flex flex-wrap gap-3 text-sm mt-4 border w-fit rounded-lg">
                        <div className="rounded-md bg-card/50 text-foreground/80 px-3 py-2">
                            <span className="text-foreground font-medium">Affected service:</span> {data.alert.affectedService}
                        </div>
                        <div className="rounded-md bg-card/50 text-foreground/80 px-3 py-2">
                            <span className="text-foreground font-medium">Error Rate:</span> {data.alert.errorRate}
                        </div>
                        <div className="rounded-md bg-card/50 text-foreground/80 px-3 py-2">
                            <span className="text-foreground font-medium">First seen:</span> {data.alert.firstSeen}
                        </div>
                        <div className="rounded-md bg-card/50 text-foreground/80 px-3 py-2">
                            <span className="text-foreground font-medium">Current severity:</span>
                            {fixed ? <span className="text-green-500 font-medium"> Operational</span> : <span className="text-red-500 font-medium"> {data.alert.currentSeverity}</span>}
                        </div>
                    </div>
                    <AutofixButton />
                </div>
            )}
            <div className="grid grid-cols-6 gap-4 mt-4">
                <Chart
                    title="OTP Generation Rate"
                    description="OTPs generated per minute"
                    data={otpData.generationRate}
                    color="hsl(var(--chart-1))"
                    valueFormatter={(value) => `${value.toFixed(0)}/min`}
                    className='col-span-3'
                />
                <Chart
                    title="OTP Verification Success Rate"
                    description="Percentage of successful OTP verifications"
                    data={otpData.verificationSuccess}
                    color="hsl(var(--chart-2))"
                    valueFormatter={(value) => `${value.toFixed(2)}%`}
                    className='col-span-3'
                />
                <Chart
                    title="Average OTP Response Time"
                    description="Average time to generate and send OTP"
                    data={otpData.averageResponseTime}
                    color="hsl(var(--chart-3))"
                    valueFormatter={(value) => `${value.toFixed(0)}ms`}
                    className='col-span-2'
                />
                <Chart
                    title="Failed OTP Attempts"
                    description="Number of failed OTP verification attempts per minute"
                    data={otpData.failedAttempts}
                    color="hsl(var(--chart-5))"
                    valueFormatter={(value) => `${value.toFixed(0)}/min`}
                    className='col-span-2'
                />
                <Chart
                    title="CPU Usage"
                    description="Percentage of CPU utilization"
                    data={systemData.cpuUsage}
                    color="hsl(var(--chart-1))"
                    valueFormatter={(value) => `${value.toFixed(2)}%`}
                    className='col-span-2'
                />
                <Chart
                    title="Memory Usage"
                    description="Percentage of memory utilization"
                    data={systemData.memoryUsage}
                    color="hsl(var(--chart-3))"
                    valueFormatter={(value) => `${value.toFixed(2)}%`}
                    className='col-span-3'
                />
                <Chart
                    title="Active Database Connections"
                    description="Number of active connections to the database"
                    data={systemData.databaseConnections}
                    color="hsl(var(--chart-4))"
                    valueFormatter={(value) => `${value.toFixed(0)}`}
                    className='col-span-3'
                />
                <Chart
                    title="Network Latency"
                    description="Average network latency in milliseconds"
                    data={systemData.networkLatency}
                    color="hsl(var(--chart-1))"
                    valueFormatter={(value) => `${value.toFixed(2)}ms`}
                    className='col-span-2'
                />
                <Chart
                    title="Unusual Activity Detections"
                    description="Number of unusual activities detected per minute"
                    data={securityData.unusualActivityDetections}
                    color="hsl(var(--chart-5))"
                    valueFormatter={(value) => `${value.toFixed(0)}/min`}
                    className='col-span-2'
                />
                <Chart
                    title="Failed Login Attempts"
                    description="Number of failed login attempts per minute"
                    data={securityData.failedLoginAttempts}
                    color="hsl(var(--chart-1))"
                    valueFormatter={(value) => `${value.toFixed(0)}/min`}
                    className='col-span-2'
                />
                <Chart
                    title="Successful Logins"
                    description="Number of successful logins per minute"
                    data={securityData.successfulLogins}
                    color="hsl(var(--chart-2))"
                    valueFormatter={(value) => `${value.toFixed(0)}/min`}
                    className='col-span-3'
                />
                <Card className="col-span-3 h-[440px] overflow-y-scroll">
                    <CardHeader className='-mb-4'>
                        <CardTitle className='text-sm'>Logs</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Timestamp</TableHead>
                                    <TableHead>Level</TableHead>
                                    <TableHead>Service</TableHead>
                                    <TableHead>Message</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {logs.slice(0, 10).map((log: any, index: number) => (
                                    <TableRow key={index}>
                                        <TableCell>{log.timestamp}</TableCell>
                                        <TableCell>
                                            <Badge variant={log.level === 'ERROR' ? 'destructive' : log.level === 'WARN' ? 'destructive' : 'default'}>
                                                {log.level}
                                            </Badge>
                                        </TableCell>
                                        <TableCell>{log.service}</TableCell>
                                        <TableCell>{log.message}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>


        </Container>
    );
}