import Container from "@/components/ui/container";
import { getFormatDate } from "@/lib/date.utils";
import { MOCK_JOURNEY } from "../data/mock-journey";
import JourneyCard from "../features/journey-card";

export default function ObservabilityHome() {
    return <Container className="my-6 mb-12">
        <h4 className="text-sm font-medium uppercase text-muted-foreground">
            Cosumer Banking
        </h4>
        <h3 className="text-2xl font-medium">Observability Dashboard</h3>
        <p className="text-sm text-muted-foreground min-h-8">
            {getFormatDate(new Date().toISOString())}
        </p>

        <div className="grid grid-cols-2 gap-6 mt-6">
            {
                MOCK_JOURNEY.map(app => (
                    <JourneyCard appName={app.appName} journey={app.journey} className={app.className} />
                ))
            }
        </div>

    </Container>
}