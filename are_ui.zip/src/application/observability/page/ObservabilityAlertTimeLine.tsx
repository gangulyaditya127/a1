import Container from "@/components/ui/container"
import { Icon } from "@/components/ui/icon"
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
import { Link } from "react-router-dom"
import { RootState } from "@/lib/redux/store"
import { useSelector } from "react-redux"

export default function ObservabilityAlertTimeline() {
    return (
        <Container className="mt-6">
            <NavigateBackButton />
            <div className="h-[80vh] grid place-items-center">
                <Timeline />
            </div>
        </Container>
    )
}

function Timeline() {
    const { fixed } = useSelector((s: RootState) => s.agentFlow)
    return (
        <div className="flex items-center gap-4 ">
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="webhook" />
                </div>
                <p className="text-muted-foreground text-sm">API Gateway</p>
            </div>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="server-cog" />
                </div>
                <p className="text-muted-foreground text-sm">Middleware</p>
            </div>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="globe" />
                </div>
                <p className="text-muted-foreground text-sm">Service Mesh</p>
            </div>
            {fixed ?
                (
                    <>
                        <Icon name="move-horizontal" className="text-green-500 mb-6" />
                        <Link to='/observability/detail' className="grid place-items-center gap-2">
                            <div className="size-16 grid place-items-center bg-green-500 rounded-full">
                                <Icon name="notebook-tabs" />
                            </div>
                            <p className="text-muted-foreground text-sm">Common Registry</p>
                        </Link>
                        <Icon name="move-horizontal" className="text-green-500 mb-6" />
                    </>
                )
                :
                <>
                    <Icon name="move-horizontal" className="text-red-500 mb-6" />
                    <Link to='/observability/detail' className="grid place-items-center gap-2">
                        <div className="size-16 grid place-items-center bg-red-500 rounded-full">
                            <Icon name="notebook-tabs" />
                        </div>
                        <p className="text-muted-foreground text-sm">Common Registry</p>
                    </Link>
                    <Icon name="move-horizontal" className="text-red-500 mb-6" />
                </>
            }
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="user-round" />
                </div>
                <p className="text-muted-foreground text-sm">EIS</p>
            </div>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="rectangle-ellipsis" />
                </div>
                <p className="text-muted-foreground text-sm">UIDAI</p>
            </div>
        </div>
    )
}
