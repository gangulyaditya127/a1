import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useAppDispatch } from "@/lib/redux/hooks";
import { cn } from "@/lib/tailwind.utils";
import SIDEBAR_DATA from "../ismart/data/sidebar.data";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useEffect } from "react";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { resetSteps } from "../observability-neste/slice/nesteObservabilitySlice";
export default function ObservabilityCatalog() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
        dispatch(resetSteps())
    }, []);
    return (
        <Container className="mt-20 max-w-5xl">
            <NavigateBackButton />
            <Breadcrumb>
                <BreadcrumbList>
                    <BreadcrumbItem>
                        <Link to="/">Home</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <BreadcrumbPage>Observability</BreadcrumbPage>
                    </BreadcrumbItem>


                </BreadcrumbList>
            </Breadcrumb>
            <div className="grid grid-cols-3 border-t mt-6 border">
                <Feature title={"Consumer Banking"} description={"Observability dashboard for consumer banking"} icon={<Icon name="octagon" />} index={0} href="/observability"/>
                <Feature title={"Payments"} description={"Observability dashboard for payments account"} icon={<Icon name="dock" />} index={1} href="/observability-payments"/>
                <Feature title={"Energy"} description={"Observability dashboard for energy"} icon={<Icon name="cctv" />} index={2} href="/observability-energy"/>
                <Feature title={"Water Utility"} description={"Observability dashboard for water utiltiy account "} icon={<Icon name="cctv" />} index={3} href="/observability-utility"/>
                <Feature title={"MediCare"} description={"Observability dashboard for medicare "} icon={<Icon name="heart-plus" />} index={4} href="https://ismartams.tcsapps.com/medicare/" target="_blank"/>
                <Feature title={"Health Care"} description={"Observability dashboard for health care "} icon={<Icon name="heart-plus" />} index={4} href="https://ismartams.tcsapps.com/ebhub/" target="_blank"/>
                <Feature title={"Communication and Media"} description={"Observability dashboard for communication and media account "} className="col-span-3 border-t" icon={<Icon name="move-diagonal" />} index={5} href="/observability-communication/"/>
            </div>
        </Container>
    )
}

const Feature = ({
    title,
    description,
    icon,
    index,
    href,
    target,
    className
}: {
    title: string;
    description: string;
    icon: React.ReactNode;
    index: number;
    className?: string
    href?: string
    onClick?: () => void;
    target?:string
}) => {
    return (
        <Link
            to={href ?? ""}
            target={target??"_self"}
            className={cn(
                "flex flex-col lg:border-r  py-10 relative group/feature dark:border-neutral-800",
                (index === 0 || index === 4) && "lg:border-l dark:border-neutral-800",
                index < 4 && "lg:border-b dark:border-neutral-800 cursor-pointer",
                className
            )}
            
        >
            {index < 4 && (
                <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-t from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none" />
            )}
            {index >= 4 && (
                <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-b from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none" />
            )}
            <div className="mb-4 relative z-10 px-10 text-neutral-600 dark:text-neutral-400">
                {icon}
            </div>
            <div className="text-lg font-bold mb-2 relative z-10 px-10">
                <div className="absolute left-0 inset-y-0 h-6 group-hover/feature:h-8 w-1 rounded-tr-full rounded-br-full bg-neutral-300 dark:bg-neutral-700 group-hover/feature:bg-blue-500 transition-all duration-200 origin-center" />
                <span className="group-hover/feature:translate-x-2 transition duration-200 inline-block text-neutral-800 dark:text-neutral-100">
                    {title}
                </span>
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-xs relative z-10 px-10">
                {description}
            </p>
        </Link>
    );
};
