import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export type StepStatus = "pending" | "processing" | "completed" | "error"

export interface WorkflowStep {
    id: string
    name: string
    description: string
    status: StepStatus
    progress: number
    icon: string
    agent: string
    details?: string
}

export interface Agent {
    id: string
    name: string
    role: string
    status: "active" | "waiting" | "complete"
    avatar: string
}

export interface LogEntry {
    id: string
    timestamp: string
    agent: string
    action: string
    status: "in-progress" | "complete" | "info"
}

interface IncidentState {
    steps: WorkflowStep[]
    isAutoRunning: boolean
    currentActiveStep: string | null
    agents: Agent[]
    logs: LogEntry[]
    isIssueFixed: boolean
}

const initialAgents: Agent[] = [
    { id: "1", name: "Incident Agent", role: "Incident Agent", status: "waiting", avatar: "AA" },
    { id: "2", name: "Database Agent", role: "Database Agent", status: "waiting", avatar: "SA" },
    { id: "3", name: "System Agent", role: "System Agent", status: "waiting", avatar: "JE" },
    { id: "4", name: "Documentation Agent", role: "Documentation Agent", status: "waiting", avatar: "CL" },
]


const initalSteps: WorkflowStep[] = [
    {
        id: "initalize",
        name: "fetch_incidents",
        description: "Fetch incident from service now",
        status: "pending",
        progress: 0,
        icon: "",
        agent: "Incident Agent",
        details: "pattern: *.db_incident",
    },
    {
        id: "analysis",
        name: "incident_analysis",
        description: "Fetch and analyze incident report",
        status: "pending",
        progress: 0,
        icon: "",
        agent: "Incident Agent",
        details: "pattern: *.incident, directory: /reports",
    },
    {
        id: "identification",
        name: "problem_identification",
        description: "Identify root cause of database failure",
        status: "pending",
        progress: 0,
        icon: "",
        agent: "Database Agent",
        details: "Analyzing cluster disk and SQL server status",
    },
    {
        id: "resolution",
        name: "automated_resolution",
        description: "Execute disk restart and recovery sequence",
        status: "pending",
        progress: 0,
        icon: "refresh-pw",
        agent: "System Agent",
        details: "Restart cluster disks → Restore SQL server",
    },
    {
        id: "documentation",
        name: "problem_record",
        description: "Create problem record",
        status: "pending",
        progress: 0,
        icon: "file-text",
        agent: "Documentation Agent",
        details: "Generate PRB record with resolution steps. PRB No.: 12943243",
    },
]

export const initialState: IncidentState = {
    isIssueFixed: false,
    steps: initalSteps,
    isAutoRunning: false,
    logs: [
        {
            id: "1",
            timestamp: "14:32:15",
            agent: "System",
            action: "Database offline detected - Critical incident triggered",
            status: "info",
        },
    ],
    agents: initialAgents,
    currentActiveStep: null,
}

const nesteObservabilitySlice = createSlice({
    name: "nesteObservabilitySlice",
    initialState,
    reducers: {
        updateStepStatus: (state, action: PayloadAction<WorkflowStep[]>) => {
            state.steps = action.payload
        },
        updateStepProgress: (state, action: PayloadAction<{ stepId: string; progress: number }>) => {
            const step = state.steps.find((s) => s.id === action.payload.stepId)
            if (step) {
                step.progress = action.payload.progress
            }
        },
        updateSteps: (state, action: PayloadAction<WorkflowStep[]>) => {
            state.steps = action.payload
        },
        setAutoRunning: (state, action: PayloadAction<boolean>) => {
            state.isAutoRunning = action.payload
        },
        setCurrentActiveStep: (state, action: PayloadAction<string | null>) => {
            state.currentActiveStep = action.payload
        },
        addLog: (state, action: PayloadAction<LogEntry>) => {
            state.logs.push(action.payload)
        },
        resetSteps: (state) => {
            state.steps = initalSteps.map((step) => ({ ...step, progress: 0, status: "pending" as StepStatus }))
            state.logs = []
            state.currentActiveStep = null
        },
    }
})

export const {
    updateStepStatus,
    updateStepProgress,
    updateSteps,
    setAutoRunning,
    setCurrentActiveStep,
    addLog,
    resetSteps,

} = nesteObservabilitySlice.actions;

export default nesteObservabilitySlice.reducer