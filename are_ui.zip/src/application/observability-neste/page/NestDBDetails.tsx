import Container from "@/components/ui/container";
import { useEffect, useState } from "react";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Area, AreaChart, CartesianGrid, Line, LineChart, XAxis } from "recharts";
import { Activity, Clock, SparkleIcon, TrendingDown, TrendingUp, Users, ZapIcon, ZapOffIcon } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import IncidentResolutionDashboard from "./FixIssue";
import { useAppSelector } from "@/lib/redux/hooks";
import { cn } from "@/lib/tailwind.utils";
import { Button } from "@/components/ui/button";
const generateMockData = () => {
    const now = Date.now()
    return Array.from({ length: 24 }, (_, i) => ({
        time: new Date(now - (23 - i) * 60 * 60 * 1000).toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
        }),
        responseTime: Math.floor(Math.random() * 200) + 50,
        connections: Math.floor(Math.random() * 100) + 20,
        errors: Math.floor(Math.random() * 10),
        throughput: Math.floor(Math.random() * 1000) + 500,
        cpuUsage: Math.floor(Math.random() * 80) + 10,
        memoryUsage: Math.floor(Math.random() * 70) + 20,
    }))
}

const connectionTypes = [
    { name: "Active", value: 45, color: "hsl(var(--chart-1))" },
    { name: "Idle", value: 25, color: "hsl(var(--chart-2))" },
    { name: "Waiting", value: 15, color: "hsl(var(--chart-3))" },
    { name: "Blocked", value: 5, color: "hsl(var(--chart-4))" },
]

export default function NestDBDetails() {
    const [data, setData] = useState(generateMockData());
    useEffect(() => {
        const interval = setInterval(() => {
            setData((prevData) => {
                const newData = [...prevData.slice(1)]
                const lastTime = new Date()
                newData.push({
                    time: lastTime.toLocaleTimeString("en-US", {
                        hour: "2-digit",
                        minute: "2-digit",
                    }),
                    responseTime: Math.floor(Math.random() * 200) + 50,
                    connections: Math.floor(Math.random() * 100) + 20,
                    errors: Math.floor(Math.random() * 10),
                    throughput: Math.floor(Math.random() * 1000) + 500,
                    cpuUsage: Math.floor(Math.random() * 80) + 10,
                    memoryUsage: Math.floor(Math.random() * 70) + 20,
                })
                return newData
            })
        }, 5000)

        return () => clearInterval(interval)
    }, [])

    const currentMetrics = data[data.length - 1]
    const previousMetrics = data[data.length - 2]
    const getMetricTrend = (current: number, previous: number) => {
        if (current > previous) return { trend: "up", color: "text-red-500 font-medium" }
        if (current < previous) return { trend: "down", color: "text-primary" }
        return { trend: "stable", color: "text-muted-foreground" }
    }
    const responseTimeTrend = getMetricTrend(currentMetrics?.responseTime || 0, previousMetrics?.responseTime || 0)
    const connectionsTrend = getMetricTrend(currentMetrics?.connections || 0, previousMetrics?.connections || 0)
    const isIssueFixed = (useAppSelector((state) => state.nesteObservability.currentActiveStep) == "documentation")

    return (
        <Container className="mt-6 pb-12">
            <NavigateBackButton />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                <Card className="bg-secondary/10 border">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">Response Time</CardTitle>
                        <Clock className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{currentMetrics?.responseTime || 0}ms</div>
                        <div className={`flex items-center text-xs ${responseTimeTrend.color} mt-1`}>
                            {responseTimeTrend.trend === "up" ? (
                                <TrendingUp className="h-3 w-3 mr-1" />
                            ) : responseTimeTrend.trend === "down" ? (
                                <TrendingDown className="h-3 w-3 mr-1" />
                            ) : null}
                            {Math.abs((currentMetrics?.responseTime || 0) - (previousMetrics?.responseTime || 0))}ms from last
                            update
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-secondary/10 border">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">Active Connections</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{currentMetrics?.connections || 0}</div>
                        <div className={`flex items-center text-xs ${connectionsTrend.color} mt-1`}>
                            {connectionsTrend.trend === "up" ? (
                                <TrendingUp className="h-3 w-3 mr-1" />
                            ) : connectionsTrend.trend === "down" ? (
                                <TrendingDown className="h-3 w-3 mr-1" />
                            ) : null}
                            {Math.abs((currentMetrics?.connections || 0) - (previousMetrics?.connections || 0))} from last update
                        </div>
                    </CardContent>
                </Card>

                <Sheet>


                    <Card className={cn("bg-secondary/10 border")}>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-muted-foreground">Database Status</CardTitle>
                            <Activity className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="flex justify-between">
                                {
                                    isIssueFixed ? (
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <ZapIcon className="h-5 w-5 text-primary" />
                                                <span className="text-2xl font-bold text-primary">Online</span>
                                            </div>
                                            <div className="text-xs text-muted-foreground mt-1">All systems are offline</div>
                                        </div>
                                    ) : (

                                        <div className="">
                                            <div className="flex items-center gap-2 ">
                                                <ZapOffIcon className="h-5 w-5 text-red-500" />
                                                <span className="text-2xl font-bold text-red-500">Offline</span>
                                            </div>
                                            <div className="text-xs text-red-500 mt-1">All systems are offline</div>
                                        </div>
                                    )
                                }
                                <SheetTrigger asChild>
                                    <Button
                                        variant="outline"
                                        className="mt-auto"
                                        size="sm"
                                    >
                                        <SparkleIcon className="h-4 w-4 mr-1" />
                                        Auto-fix
                                    </Button>
                                </SheetTrigger>
                            </div>
                        </CardContent>
                    </Card>
                    <SheetContent className="w-1/2 sm:max-w-1/2">
                        <SheetHeader className="px-5">
                            <SheetTitle>Automated Resolution</SheetTitle>
                            <SheetDescription>
                                A self-driven workflow that detects, analyzes, and resolves incidents without manual intervention.                            </SheetDescription>
                        </SheetHeader>
                        <IncidentResolutionDashboard />
                    </SheetContent>
                </Sheet>

            </div>
            <div className="grid grid-cols-3 gap-4">
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Response Time Trend</CardTitle>
                        <CardDescription>Average query response time over the last 24 hours</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "Avg Response Time", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <LineChart
                                accessibilityLayer
                                margin={{ left: 12, right: 12 }}
                                data={data}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />

                                <Line
                                    type="monotone"
                                    dataKey="responseTime"
                                    stroke="hsl(var(--chart-1))"
                                    strokeWidth={1}

                                />
                            </LineChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Throughput</CardTitle>
                        <CardDescription>Queries processed per minute</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "Avg Response Time", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <AreaChart
                                accessibilityLayer

                                margin={{ left: 12, right: 12 }}
                                data={data}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />

                                <Area
                                    type="monotone"
                                    dataKey="throughput"
                                    stroke="hsl(var(--chart-5))"
                                    fill="hsl(var(--chart-5))"
                                    fillOpacity={0.3}

                                />
                            </AreaChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Connection Pool Usage</CardTitle>
                        <CardDescription>Active database connections over time</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "Avg Response Time", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <LineChart
                                accessibilityLayer
                                margin={{ left: 12, right: 12 }}
                                data={data}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />

                                <Line
                                    type="monotone"
                                    dataKey="connections"
                                    stroke="hsl(var(--chart-3))"
                                    strokeWidth={1}


                                />
                            </LineChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Connection Types</CardTitle>
                        <CardDescription>Distribution of connection states</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 gap-8 mt-auto">
                            {connectionTypes.map((type, index) => (
                                <div className="" key={index} >
                                    <p className="text-2xl">{type.value}</p>
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: type.color }} />
                                        <p className="text-sm text-muted-foreground">
                                            {type.name}
                                        </p>
                                    </div>

                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">CPU Usage</CardTitle>
                        <CardDescription>Database server CPU utilization</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "CPU Usage", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <AreaChart
                                accessibilityLayer
                                margin={{ left: 12, right: 12 }}
                                data={data}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />

                                <Area
                                    type="monotone"
                                    dataKey="connections"
                                    stroke="hsl(var(--chart-3))"
                                    strokeWidth={1}
                                    fill="hsl(var(--chart-3))"


                                />
                            </AreaChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="bg-secondary/10 border">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Memory Usage</CardTitle>
                        <CardDescription>Database server memory utilization</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "CPU Usage", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <AreaChart
                                accessibilityLayer
                                margin={{ left: 12, right: 12 }}
                                data={data}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />

                                <Area
                                    type="monotone"
                                    dataKey="connections"
                                    stroke="hsl(var(--chart-4))"
                                    fill="hsl(var(--chart-4))"

                                />
                            </AreaChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
            </div>
        </Container>
    )
}