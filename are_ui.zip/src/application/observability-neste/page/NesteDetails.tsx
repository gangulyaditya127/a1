import Container from "@/components/ui/container";
import { getFormatDate } from "@/lib/date.utils";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { TableRow, Table, TableHeader, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { useAppSelector } from "@/lib/redux/hooks";

export default function NesteDetails() {
    const currentActiveStep = useAppSelector((state) => state.nesteObservability.currentActiveStep);
    const isIssueFixed = currentActiveStep == "documentation"

    return (<Container className="my-6 mb-12">
        <NavigateBackButton />
        <h4 className="text-sm font-medium uppercase text-muted-foreground">
            Allegro CTRM
        </h4>
        <h3 className="text-2xl font-medium">
            User Journey
            {!isIssueFixed && <span className="text-xs -translate-y-1 w-fit font-base px-2 py-[1px] rounded-3xl normal-case text-red-300  bg-red-700/40 border border-red-500 inline-block ml-2">Critical</span>}
            {isIssueFixed && <span className="text-xs -translate-y-1 w-fit font-base px-2 py-[1px] rounded-3xl normal-case text-green-300  bg-green-700/40 border border-green-500 inline-block ml-2">Healthy</span>}
        </h3>
        <p className="text-sm text-muted-foreground min-h-8 mb-2">
            {getFormatDate(new Date().toISOString())}
        </p>

        <div className="border rounded-xl">
            <Table>
                <TableHeader>
                    <TableRow className="border-0 border-b-0 hover:bg-black">
                        <TableHead >
                            Journeys
                        </TableHead >
                        <TableHead className="border-x border-neutral-900 p-0 text-center dark:border-neutral-700 flex justify-center items-center">
                            <p>Linked Applications</p>
                        </TableHead>
                        <TableHead className="text-center">
                            Integrations
                        </TableHead>
                        {/* <TableHead className=" border-x border-neutral-900 p-0 text-center dark:border-neutral-700">
                        Dropped Off Users
                    </TableHead> */}
                        <TableHead className="text-center border-l">
                            Platform
                        </TableHead>
                        <TableHead className="text-center border-l">
                            Database
                        </TableHead>
                        <TableHead className="text-center border-l">
                            Interface
                        </TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {/* --- */}
                    <TableRow className="border-0 border-b-0">
                        <TableCell className={`cursor-pointer ${currentActiveStep == "documentation" ? "" : "bg-red-700/10"}`} rowSpan={3}>
                            <Link className="h-full w-full block" to="/observability-energy/allergo-ctrm/timeline">
                                Create Allegro Deals
                            </Link>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x"  >
                            <div className="h-full w-full block text-muted-foreground">
                                SAP
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x"  >
                            <div className="h-full w-full block text-muted-foreground">
                                SAP-Allegro: about 16 Biztalk integrations and one/1 SAP PI integration
                            </div>
                        </TableCell>
                        <TableCell className=" border-x text-muted-foreground" >
                            <div className="h-full w-full block ">
                                Allegro CTRM Prod
                            </div>
                        </TableCell>
                        <TableCell className={`border-x cursor-pointer ${currentActiveStep == "documentation" ? "text-muted-foreground" : "bg-red-700/10 text-red-200"}`} >
                            <Link className="h-full w-full block " to="/observability-energy/allergo-ctrm/details">
                                SQL
                            </Link>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Citrix
                            </div>
                        </TableCell>

                    </TableRow>
                    <TableRow className="border-0 border-b-0">
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                ZEMA (3rd party market data)
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                ZEMA - Allegro: 3 biztalk integrations
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" >
                            <div className="h-full w-full block text-muted-foreground">
                                Windows Server - IIS_Webserver1
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro Archive
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Neste Laptop
                            </div>
                        </TableCell>

                    </TableRow>
                    <TableRow className="border-0 border-b-0">
                        <TableCell className=" text-cyan-400 border-x border-t">
                            <div className="h-full w-full block text-muted-foreground">
                                Windows Server - IIS_Webserver2
                            </div>
                        </TableCell>
                    </TableRow>
                    {/* --- */}
                    {/* --- */}
                    <TableRow className="border-0 border-b-0 border-t">
                        <TableCell className="cursor-pointer" rowSpan={3}>
                            <Link className="h-full w-full block " to="">
                                Negotiate deal
                            </Link>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x "  >
                            <div className="h-full w-full block text-muted-foreground">
                                ZEMA
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x "  >
                            <div className="h-full w-full block text-muted-foreground">
                                SAP-Allegro: about 16 Biztalk integrations and one/1 SAP PI integration
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro CTRM Prod
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                SQL
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Citrix
                            </div>
                        </TableCell>

                    </TableRow>
                    <TableRow className="border-0 border-b-0">
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Neste Data Platform (NDP)
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro- NDP integration
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" >
                            <div className="h-full w-full block text-muted-foreground">
                                Windows Server - IIS_Webserver5
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro NDP
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x border-t" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                NDP Archive
                            </div>
                        </TableCell>

                    </TableRow>
                    <TableRow className="border-0 border-b-0">
                        <TableCell className=" text-cyan-400 border-x border-t">
                            <div className="h-full w-full block text-muted-foreground">
                                Windows Server - IIS_Webserver7
                            </div>
                        </TableCell>
                    </TableRow>
                    {/* --- */}
                    {/* --- */}
                    <TableRow className="border-0 border-b-0 border-t">
                        <TableCell className="cursor-pointer" rowSpan={2}>
                            <Link className="h-full w-full block" to="">
                                Manage paper deal pricing and invoices
                            </Link>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x"  >
                            <div className="h-full w-full block text-muted-foreground">
                                Neste Data Platform (NDP)
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x"  >
                            <div className="h-full w-full block text-muted-foreground">
                                SAP-Allegro: about 16 Biztalk integrations and one/1 SAP PI integration
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro CTRM Prod
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                SQL
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Citrix
                            </div>
                        </TableCell>

                    </TableRow>
                    <TableRow className="border-0 border-b-0 ">
                        <TableCell className=" text-cyan-400 border-x" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                ZEMA (3rd party market data)
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                ZEMA - Allegro: 3 biztalk integrations
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" >
                            <div className="h-full w-full block text-muted-foreground">
                                Windows Server - IIS_Webserver1
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Allegro Archive
                            </div>
                        </TableCell>
                        <TableCell className=" text-cyan-400 border-x" rowSpan={2}>
                            <div className="h-full w-full block text-muted-foreground">
                                Neste Laptop
                            </div>
                        </TableCell>

                    </TableRow>

                    {/* --- */}

                </TableBody>
            </Table>
        </div>

    </Container>)
}