import { FC, useCallback, useEffect } from 'react';
import {
    ReactFlow,
    addEdge,
    useNodesState,
    useEdgesState, Controls, Position,
    type Node,
    type Edge, type OnConnect,
    NodeTypes,
    Handle,
    Background,
    EdgeProps,
    getBezierPath,
    BaseEdge,
    EdgeLabelRenderer,
    EdgeTypes
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';
import useDerivedTheme from '@/lib/hooks/useDerivedTheme';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/tailwind.utils';
import { Link } from 'react-router-dom';
import { useAppSelector } from '@/lib/redux/hooks';

function ApplicationNode({ data }: { data: any }) {
    const { label, status, className } = data
    const hasError = status === "error"
    const hasWarn = status === "warn"
    const isEmpty = status === ""

    return (
        <div
            className={cn(
                "px-4 py-1 text-xs rounded-lg border-2 shadow-lg min-w-[120px] text-center transition-all duration-200 hover:shadow-xl",
                hasError
                    ? "bg-red-50 border-red-500 text-red-900 dark:bg-red-950 dark:border-red-400 dark:text-red-100"
                    : hasWarn ? "bg-amber-900/40 border-amber-500 text-amber-500 dark:border-amber-400 dark:text-amber-100" : "bg-white border-green-500 text-green-900 dark:bg-green-950 dark:border-green-400 dark:text-green-100",
                isEmpty && "py-1",
                className

            )}
        >
            <Link
                to="allergo"
                className="flex items-center justify-center gap-2 mb-1">
                {hasError || hasWarn ? <AlertTriangle className="w-4 h-4" /> : !isEmpty && <CheckCircle className="w-4 h-4" />}
                <span className="font-semibold text-sm">{label}</span>
            </Link>
            {/* <div className="text-xs opacity-75 capitalize">{type}</div> */}

            <Handle
                type="target"
                position={Position.Top}
                className=""
            />
            <Handle
                type="source"
                position={Position.Bottom}
                className=""
            />
        </div>
    )
}

function DependencyNode({ data }: { data: any }) {
    const { list, hasError, className } = data

    return (
        <div
            className={cn(
                "px-4 py-1 text-xs rounded-lg border-2 shadow-lg min-w-[120px] text-center transition-all duration-200 hover:shadow-xl",
                hasError ? "bg-red-50 border-red-500 text-red-900 dark:bg-red-950 dark:border-red-400 dark:text-red-100" : "bg-white border-green-500 text-green-900 dark:bg-green-950 dark:border-green-400 dark:text-green-100",
                className
            )}
        >
            <ul>
                {list.map((el: string, idx: number) => (
                    <li key={idx}>{el}</li>
                ))}
            </ul>
            {/* <div className="text-xs opacity-75 capitalize">{type}</div> */}

            <Handle
                type="target"
                position={Position.Top}
                className=""
            />
            <Handle
                type="source"
                position={Position.Bottom}
                className=""
            />
        </div>
    )
}

const CustomEdge: FC<EdgeProps<Edge<{ label: string }>>> = ({
    id,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    data,
}) => {
    const [edgePath, labelX, labelY] = getBezierPath({
        sourceX,
        sourceY,
        sourcePosition,
        targetX,
        targetY,
        targetPosition,
    });

    return (
        <>
            <BaseEdge id={id} path={edgePath} />
            <EdgeLabelRenderer>
                <div
                    style={{
                        transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
                    }}
                    className="edge-label-renderer__custom-edge nodrag nopan"
                >
                    {data?.label}
                </div>
            </EdgeLabelRenderer>
        </>
    );
};

const nodeTypes: NodeTypes = {
    applicationNode: ApplicationNode,
    dependencyNode: DependencyNode
}
const edgeTypes: EdgeTypes = {
    custom: CustomEdge,

}

const nodeDefaults = {
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
};

const initialNodes: Node[] = [
    {
        id: "1",
        type: "applicationNode",
        position: { x: 400, y: 0 },
        data: { label: "Allegro CTRM", status: "error", type: "web" },
        ...nodeDefaults,
    },
    {
        id: "1-2",
        type: "applicationNode",
        position: { x: 100, y: 130 },
        data: { label: "Linked Applications", status: "", type: "web", className: "bg-amber-50 border-amber-500 text-amber-900 dark:bg-amber-950 dark:border-amber-400 dark:text-amber-100" },
        ...nodeDefaults,
    },
    {
        id: "2",
        type: "applicationNode",
        position: { x: -100, y: 220 },
        data: { label: "SAP", status: "warn", type: "api" },
        ...nodeDefaults,
    },

    {
        id: "3",
        type: "applicationNode",
        position: { x: 50, y: 320 },
        data: { label: "Neste Data Platform (NDP)", status: "warn", type: "database" },
        ...nodeDefaults,
    },
    {
        id: "4",
        type: "applicationNode",
        position: { x: 380, y: 280 },
        data: { label: "ZEMA", status: "healthy", type: "api", className: "bg-blue-50 border-blue-500 text-blue-900 dark:bg-blue-950 dark:border-blue-400 dark:text-blue-100" },
        ...nodeDefaults,
    },
    {
        id: "5",
        type: "applicationNode",
        position: { x: 460, y: 220 },
        data: { label: "Web ICE & CME", status: "healthy", type: "api", className: "bg-blue-50 border-blue-500 text-blue-900 dark:bg-blue-950 dark:border-blue-400 dark:text-blue-100" },
        ...nodeDefaults,
    },
    {
        id: "6",
        type: "applicationNode",
        position: { x: 820, y: 130 },
        data: { label: "Platform", status: "", type: "web", className: "bg-red-50 border-red-500 text-red-900 dark:bg-red-950 dark:border-red-400 dark:text-red-100" },
        ...nodeDefaults,
    },
    {
        id: "7",
        type: "applicationNode",
        position: { x: 800, y: 220 },
        data: { label: "Allegro CTRM Prod", status: "", type: "web", className: "bg-red-50 border-red-500 text-red-900 dark:bg-red-950 dark:border-red-400 dark:text-red-100" },
        ...nodeDefaults,
    },
    {
        id: "8",
        type: "dependencyNode",
        position: { x: 670, y: 380 },
        data: {
            list: [
                "Windows Server - IIS_Webserver1",
                "Windows Server - IIS_Webserver2",
                "Windows Server - IIS_Webserver3",
                "....",
                "Windows Server - IIS_Webserver9"
            ],
            hasError: false
        },
        ...nodeDefaults,
    },
    {
        id: "9",
        type: "dependencyNode",
        position: { x: 950, y: 380 },
        data: {
            list: [
                "SQL Database",
                "Allegro Archive"
            ],
            hasError: true
        },
        ...nodeDefaults,
    },
    {
        id: "10",
        type: "dependencyNode",
        position: { x: 1080, y: 320 },
        data: {
            list: [
                "Citrix 7 Prod "
            ],
            hasError: false
        },
        ...nodeDefaults,
    },
    {
        id: "11",
        type: "dependencyNode",
        position: { x: 1080, y: 420 },
        data: {
            list: [
                "Citrix 7 On-Prem(Neste Laptop)"
            ],
            hasError: false
        },
        ...nodeDefaults,
    },
]


const initialEdges: Edge[] = [
    {
        id: "1-1-2",
        source: "1",
        target: "1-2",
        type: "smoothstep",
        style: {
            stroke: "#ef4444",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        animated: true,
        // label: "Linked application",
        labelStyle: {
            fill: "#ef4444",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "1-2-2",
        source: "1-2",
        target: "2",
        type: "smoothstep",
        style: {
            stroke: "#fbbf24",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "16 Biztalk integrations",
        labelStyle: {
            fill: "#155a30",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "1-2-3",
        source: "1-2",
        target: "3",
        type: "smoothstep",
        style: {
            stroke: "#fbbf24",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Allegro- NDP integration",
        labelStyle: {
            fill: "#155a30",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "1-2-4",
        source: "1-2",
        target: "4",
        type: "smoothstep",
        style: {
            stroke: "oklch(62.3% 0.214 259.815)",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "3 biztalk integrations",
        labelStyle: {
            fill: "#155a30",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "1-2-5",
        source: "1-2",
        target: "5",
        type: "smoothstep",
        style: {
            stroke: "oklch(62.3% 0.214 259.815)",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Exchange connector integration",
        labelStyle: {
            fill: "#155a30",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "1-6",
        source: "1",
        target: "6",
        type: "smoothstep",
        style: {
            stroke: "#ef4444",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        animated: true,
        // label: "Linked application",
        labelStyle: {
            fill: "#ef4444",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "6-7",
        source: "6",
        target: "7",
        type: "smoothstep",
        style: {
            stroke: "#ef4444",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        // label: "Linked application",
        labelStyle: {
            fill: "#ef4444",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "7-9",
        source: "7",
        target: "9",
        type: "smoothstep",
        style: {
            stroke: "#ef4444",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Databases",
        labelStyle: {
            fill: "#000",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "7-8",
        source: "7",
        target: "8",
        type: "smoothstep",
        style: {
            stroke: "oklch(72.3% 0.219 149.579)",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Servers",
        labelStyle: {
            fill: "#000",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "7-10",
        source: "7",
        target: "10",
        type: "smoothstep",
        style: {
            stroke: "oklch(72.3% 0.219 149.579)",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Interfaces",
        labelStyle: {
            fill: "#000",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
    {
        id: "10-11",
        source: "10",
        target: "11",
        type: "smoothstep",
        style: {
            stroke: "oklch(72.3% 0.219 149.579)",
            strokeWidth: 2,
            strokeOpacity: 1
        },
        label: "Interfaces",
        labelStyle: {
            fill: "#000",
            fontWeight: 600,
            fontSize: 12
        },
        labelBgStyle: {
            fill: "#ffffff",
            fillOpacity: 0.8
        }
    },
];

const ColorModeFlow = () => {
    // const [colorMode, setColorMode] = useState<ColorMode>('dark');
    const theme = useDerivedTheme();

    const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

    const isIssueFixed = useAppSelector((state) => state.nesteObservability.currentActiveStep) == "documentation";

    useEffect(() => {
        if (isIssueFixed) {
            setNodes(initialNodes.map((el) => ({ ...el, data: { ...el.data, className: "bg-white border-green-500 text-green-900 dark:bg-green-950 dark:border-green-400 dark:text-green-100" } })))
            setEdges(initialEdges.map((el) => ({ ...el, style: { ...el.style, stroke: "#3de57b" } })))
        }
    }, [isIssueFixed])


    const onConnect: OnConnect = useCallback(
        (params) => setEdges((eds) => addEdge(params, eds)),
        [setEdges],
    );



    return (
        <div className="border border-secondary/60">
            <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                colorMode={theme}
                nodeTypes={nodeTypes}
                fitView
                proOptions={{ hideAttribution: true }}
                edgeTypes={edgeTypes}
                className="bg-secondary/20"
            >
                {/* <MiniMap /> */}
                <Background />
                <Controls className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700" />
            </ReactFlow>
        </div>
    );
};

export default ColorModeFlow;