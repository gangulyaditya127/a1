
import { Icon } from "@/components/ui/icon";
import NumberTicker from "@/components/ui/number-ticker";
import { Separator } from "@/components/ui/seperator";
import { getFormatDate } from "@/lib/date.utils";

import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/tailwind.utils";
import { useAppSelector } from "@/lib/redux/hooks";

const Trend = ({ value, className }: { value: "up" | "down" | "nuteral" | string | any, className?: string }) => {
    if (value === 'up') return (
        <>
            <Icon name="arrow-up-right" className={cn("size-4", className)} />
            <p>from yesterday</p>
        </>
    )
    if (value === 'down') return (
        <>
            <Icon name="arrow-down-right" className={cn("size-4", className)} />
            <p>from yesterday</p>
        </>
    )
    return (<TooltipProvider>
        <Tooltip>
            <TooltipTrigger asChild>
                <div className="flex gap-1 items-center">
                    <Icon name="minus" className={cn("size-4", className)} />
                    <p>from yesterday</p>
                </div>
            </TooltipTrigger>
            <TooltipContent>
                <p>No change from yesterday</p>
            </TooltipContent>
        </Tooltip>
    </TooltipProvider>)
}

const ObservabilityDashboardHeader = () => {
    const isIssueFixed = useAppSelector((state) => state.nesteObservability.currentActiveStep) == "documentation";

    return (
        <div className="flex items-center justify-between">
            <div>
                <h4 className="text-sm flex items-center font-medium uppercase text-muted-foreground">
                    Energy
                </h4>
                <h3 className="text-2xl font-medium">Observability Dashboard</h3>
                <p className="text-sm text-muted-foreground min-h-8">
                    {getFormatDate(new Date().toISOString())}
                </p>
                {!isIssueFixed && <p className="text-xs -translate-y-1 w-fit font-base px-2 py-0.5 rounded-3xl normal-case text-red-300  bg-red-700/40 border border-red-500">Critical</p>}
                {isIssueFixed && <p className="text-xs -translate-y-1 w-fit font-base px-2 py-0.5 rounded-3xl normal-case text-amber-300  bg-amber-700/40 border border-amber-500">Warning</p>}


            </div>
            <div className="flex items-center gap-4">
                <div className="">
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Active Users</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0 "
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0 "
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        <NumberTicker className="" value={12847} />
                        {/* <span className="text-sm font-normal text-muted-foreground">
                            %
                        </span> */}
                    </p>
                    <div className="mt-2 flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="">
                            <span>
                                <NumberTicker className="" value={8} />
                            </span>
                            <span className="text-xs">%</span>
                        </p>
                        <Trend value={"up"} className={"text-green-400"} />
                    </div>
                </div>
                {/* <Separator orientation="vertical" className="h-12" />
                <div>
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Transaction Volume</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0"
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0"
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        <NumberTicker value={2.4} className="" />
                        <span className="">M</span>
                        <span className="text-sm font-normal text-muted-foreground">
                            $
                        </span>
                    </p>
                    <div className="mt-2 flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="">
                            <span>
                                <NumberTicker className="" value={23} />
                            </span>
                            <span className="text-xs">%</span>
                        </p>
                        <Trend value={"up"} className="text-green-400" />

                    </div>
                </div> */}
                <Separator orientation="vertical" className="h-12" />
                <div>
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Success Rate</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0"
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0"
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        <NumberTicker value={97} className="" />

                        <span className="text-sm font-normal text-muted-foreground">
                            %
                        </span>
                    </p>
                    <div className="mt-2 flex items-center gap-2 text-sm opacity-90 text-muted-foreground">
                        <p className="">
                            <span>
                                <NumberTicker className="" value={3} />
                            </span>
                            <span className="text-xs">%</span>
                        </p>
                        <Trend value={"up"} className="text-green-400" />

                    </div>
                </div>
            </div>
        </div>
    )
}
export default ObservabilityDashboardHeader;