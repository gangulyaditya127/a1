import { Icon } from "@/components/ui/icon";
import { Separator } from "@/components/ui/seperator";
import { getFormatDate } from "@/lib/date.utils";

export default function NesteObservabilityHeader() {
    return (
        <div className="flex items-center justify-between">
            <div className="">
                <h4 className="text-sm font-medium uppercase text-muted-foreground">
                    Energy
                </h4>
                <h3 className="text-2xl font-medium">Observability Dashboard</h3>
                <p className="text-sm text-muted-foreground min-h-8">
                    {getFormatDate(new Date().toISOString())}
                </p>
            </div>
            <div className="flex items-center gap-4">
                <div className="">
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Affected BU #</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0 text-red-400"
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0 text-red-400"
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        1
                    </p>

                </div>
                <Separator orientation="vertical" className="h-12" />
                <div>
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Supply Chain Sync</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0 text-green-400"
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0 text-green-400"
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        {97}
                        <span className="text-sm font-normal text-muted-foreground">
                            %
                        </span>
                    </p>

                </div>
                <Separator orientation="vertical" className="h-12" />
                <div>
                    <div className="flex gap-1">
                        <p className="text-muted-foreground">Golden Source Data</p>
                        <div className="flex -space-x-1">
                            <Icon
                                name="bar-chart-2"
                                className="size-5 p-0 text-red-400"
                            />
                            <Icon
                                name="bar-chart"
                                className="size-5 p-0 text-red-400"
                            />
                        </div>
                    </div>
                    <p className="text-2xl">
                        78
                        <span className="text-sm font-normal text-muted-foreground">
                            %
                        </span>
                    </p>

                </div>
            </div>
        </div>
    )
}