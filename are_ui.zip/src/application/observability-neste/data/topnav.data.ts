import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Observability Dashboard",
        route: "/observability-energy",
        key: "1",
    },
];
