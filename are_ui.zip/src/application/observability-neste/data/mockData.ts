function formatDate(date: Date): string {
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

export function generateMockData(dataPoints: number, baseValue: number, variability: number) {
  return Array.from({ length: dataPoints }, (_, i) => {
    const date = new Date(Date.now() - (dataPoints - i - 1) * 5 * 60000);
    const value = baseValue + (Math.random() - 0.5) * 2 * variability;
    return {
      date: formatDate(date),
      value: Math.max(0, Math.round(value * 100) / 100)
    };
  });
}

export function generateMockLogs(count: number) {
  const logLevels = ['INFO', 'WARN', 'ERROR'];
  const services = ['OTP_GEN', 'OTP_VERIFY', 'AUTH', 'DB'];
  const messages = [
    'OTP generated successfully',
    'OTP verified successfully',
    'Invalid OTP attempt',
    'User authentication successful',
    'Database connection timeout',
    'High latency detected in OTP generation',
    'Unusual activity detected: multiple OTP requests',
    'System load approaching threshold',
  ];

  return Array.from({ length: count }, (_, i) => {
    const date = new Date(Date.now() - i * 2 * 60000);
    return {
      timestamp: formatDate(date),
      level: logLevels[Math.floor(Math.random() * logLevels.length)],
      service: services[Math.floor(Math.random() * services.length)],
      message: messages[Math.floor(Math.random() * messages.length)],
    };
  });
}
