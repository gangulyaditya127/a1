export const MOCK_JOURNEY = [
    {
        appName: "Allegro CTRM",
        className: 'col-span-2',
        journey: [
            {
                name: "Order Management",
                activeUsers: 1678,
                happy: 89,
                unhappy: 10,
                frustated: 1,
                dropped: 74,
                availablity: 99.23
            },
            {
                name: "Trade Allocation",
                activeUsers: 1473,
                happy: 96,
                unhappy: 3,
                frustated: 1,
                dropped: 12,
                availablity: '96.70'
            },
            {
                name: "Risk Management",
                activeUsers: 1250,
                happy: 76,
                unhappy: 16,
                frustated: 8,
                dropped: 110,
                availablity: 69.56
            },
            {
                name: "Position Monitoring",
                activeUsers: 1200,
                happy: 89,
                unhappy: 8,
                frustated: 3,
                dropped: 17,
                availablity: 91.54
            },
            {
                name: "Clearing and Settlement",
                activeUsers: 976,
                happy: 93,
                unhappy: 2,
                frustated: 5,
                dropped: 23,
                availablity: 97.32
            },
            {
                name: "View Reports",
                activeUsers: 982,
                happy: 94,
                unhappy: 4,
                frustated: 2,
                dropped: 43,
                availablity: 93.21
            },
        ]
    },

]