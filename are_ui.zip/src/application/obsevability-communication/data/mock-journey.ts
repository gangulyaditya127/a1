export const MOCK_JOURNEY = [
    {
        appName: "Application Reliability Engineering",
        className: 'col-span-2',
        journey: [
            {
                name: "Strategy & Governance",
                activeUsers: 1678,
                p4: 89,
                p3: 10,
                p2: 1,
                p1: 0,
                availablity: 99.23
            },
            {
                name: "Commercials & Procurement",
                activeUsers: 1473,
                p4: 96,
                p3: 3,
                p2: 0,
                p1: 0,
                availablity: '96.70'
            },
            {
                name: "Marketing & Registration",
                activeUsers: 1250,
                p4: 76,
                p3: 16,
                p2: 0,
                p1: 0,
                availablity: 89.56
            },
            {
                name: "Creative & Program Design",
                activeUsers: 1200,
                p4: 89,
                p3: 8,
                p2: 3,
                p1: 0,
                availablity: 91.54
            },
            {
                name: "Speaker & Content Operations",
                activeUsers: 976,
                p4: 93,
                p3: 2,
                p2: 5,
                p1: 1,
                availablity: 97.32
            },
            {
                name: "Inbound Logistics & Exhibitor Delivery",
                activeUsers: 982,
                p4: 94,
                p3: 4,
                p2: 2,
                p1: 0,
                availablity: 93.21
            },
            {
                name: "Operations & Build",
                activeUsers: 872,
                p4: 97,
                p3: 1,
                p2: 0,
                p1: 0,
                availablity: 94.42
            },
            {
                name: "Operational Continuity & Resilience",
                activeUsers: 1543,
                p4: 66,
                p3: 15,
                p2: 18,
                p1: 5,
                availablity: 66.49
            },
            {
                name: "Live Event & Audience Engagement",
                activeUsers: 876,
                p4: 91,
                p3: 8,
                p2: 0,
                p1: 0,
                availablity: 91.43
            },
            {
                name: "Media Capture & Syndication",
                activeUsers: 763,
                p4: 96,
                p3: 3,
                p2: 1,
                p1: 0,
                availablity: 95.42
            },
            {
                name: "Tear Down & Sustainability",
                activeUsers: 1250,
                p4: 76,
                p3: 16,
                p2: 12,
                p1: 7,
                availablity: 86.74
            },
            {
                name: "Post-Event Insights & Knowledge Capture",
                activeUsers: 1678,
                p4: 89,
                p3: 10,
                p2: 1,
                p1: 0,
                availablity: 99.23
            },
        ]
    },

]