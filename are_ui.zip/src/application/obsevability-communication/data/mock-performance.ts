export const PERFORMANCE = [
  {
    step: "Attendee Registration & Movement",
    actions: [
      { name: "Attendee Registration & Movement", avgResp: "3822", p95: "4034", errorRate: "7", availability: "84.08", warning: true },
      // { name: "External Availability Check", avgResp: "58", p95: "258", errorRate: "2", availability: "96.30" },
    ],
    metrics: { happy: 92, unhappy: 3, frustrated: 4 }
  },
  {
    step: "Show Control & Backstage",
    actions: [
      { name: "Show Control & Backstage", avgResp: "200", p95: "290", errorRate: "2", availability: "99.23", warning: false },
    ],
    metrics: { happy: 91, unhappy: 6, frustrated: 3 }
  },
  {
    step: "Guest Services & Venue Ops",
    actions: [
      { name: "Guest Services & Venue Ops", avgResp: "287", p95: "487", errorRate: "2", availability: "96.30", warning: false },
    ],
    metrics: { happy: 100, unhappy: 0, frustrated: 0 }
  },
]