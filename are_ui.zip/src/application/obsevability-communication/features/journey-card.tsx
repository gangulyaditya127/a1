import { cn } from "@/lib/tailwind.utils"
import JourneyGridV2 from "./journey-grid-v2"



type Journey = {
    name: string,
    activeUsers: number | string,
    p4: number | string,
    p3: number | string,
    p2: number,
    p1: number,
    availablity: number | string
}

type JourneyCardProps = {
    appName?: string,
    journey: Journey[]
    className?: string
    gridClassName?: string
}
export default function JourneyCard({ journey, className, gridClassName }: JourneyCardProps) {
    return (
        <div className={
            cn("group relative flex flex-col overflow-hidden rounded-xl border shadow transition-all duration-200 ease-in-out hover:z-30", className)
        }>
            {/* <div className="items-center gap-2 relative z-20 flex border-b bg-card px-3 py-2.5 text-card-foreground">
                <h3 className="text-xs tracking-wider text-muted-foreground uppercase">{appName}</h3>
            </div> */}
            <div className={
                cn("relative z-10 [&>div]:rounded-none [&>div]:border-none [&>div]:shadow-none ", gridClassName)
            }>
                <JourneyGridV2 rowData={journey} />
                {/* <JourneyGrid rowData={journey} appName={appName}/> */}
            </div>
        </div>
    )
}

// h-[21rem]