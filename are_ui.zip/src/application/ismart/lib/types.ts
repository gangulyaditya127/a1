export type ApplicationDataType = {
  title: string;
  description: string;
  className?: string;
  img: string;
  openInNew: boolean;
  link: string;
};
