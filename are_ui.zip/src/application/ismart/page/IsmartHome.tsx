import Container from "@/components/ui/container";
import AppListContainer from "../features/AppListContainer";
import { Suspense, lazy, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppDispatch } from "@/lib/redux/hooks";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import SIDEBAR_DATA from "../data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { AuroraHero } from "../features/AuroraHero";
import Footer from "@/components/layout/Footer";
import HowItWorks from "../features/HowItWorks";
import Testimonials from "../features/Testimonials";
// import TestimonialBanner from "../features/TestimonialBanner";
const ExploreEcxcellence = lazy(() => import("../features/ExploreExcellence"));
const Accolades = lazy(() => import("../features/Accolades"));
export default function IsmartHome() {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(updateSideBarNavigation(SIDEBAR_DATA));
    dispatch(
      updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
    );
  }, []);


  return (
    <>
      {/* <TestimonialBanner /> */}
      <AuroraHero />
      <AppListContainer />
      <div className="-translate-y-12">
        <Suspense
          fallback={
            <Container className="flex flex-col mt-12 items-center justify-center">
              <Skeleton className="mb-4 h-12 w-full max-w-3xl rounded-xl" />
              <Skeleton className="h-96 w-full max-w-5xl rounded-xl" />
            </Container>
          }
        >
          <ExploreEcxcellence />
        </Suspense>
        <Suspense
          fallback={
            <Container className="item-center flex justify-center gap-1.5">
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </Container>
          }
        >
          <Accolades />
        </Suspense>
        <HowItWorks />
      </div>
      <Suspense>
        <Testimonials />
      </Suspense>
      <Footer />
    </>
  );
}
