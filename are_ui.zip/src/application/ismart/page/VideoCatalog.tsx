import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useAppDispatch } from "@/lib/redux/hooks";
import { Suspense, useEffect, useState } from "react";
import SIDEBAR_DATA from "../data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { z } from 'zod';

import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { VideoDialog } from "@/components/ui/video-player/video-dialog";
import { useToast } from "@/components/ui/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormMessage, FormControl } from "@/components/ui/form";
import { useTrackUserMutation } from "../slice/trackerSlice";
import { LoaderIcon } from "lucide-react";
const VIDEO_LIST = [
    {
        name: "Detailed Agentic Incident Management",
        path: "/assets/video/Incident-Management-Agentic-Detailed-No Sound-5 mins_1x.mp4",
        description: "",
        duration: 5
    },
    {
        name: "Agentic Incident Management Trailer",
        path: "/assets/video/Incident-Management-Agentic-Trailer-No Sound- 3 mins_1x.mp4",
        description: "",
        duration: 3
    },
    {
        name: "Agentic Incident Management Trailer",
        path: "/assets/video/Incident-Management-Agentic-v3-No Sound- Very Detailed Video - 11 mins_1x.mp4",
        description: "",
        duration: 11
    },
]

export default function VideoCatalog() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);

    return (
        <Container className="mt-24 pb-24">
            <NavigateBackButton />
            <AccessVerification />
            {/* <div style={{ maxWidth: 640 }}>
                <div
                    style={{
                        position: "relative",
                        paddingBottom: "56.25%",
                        height: 0,
                        overflow: "hidden"
                    }}
                >
                    <iframe
                        src="https://tcscomprod.sharepoint.com/sites/SEBLTransformation/_layouts/15/embed.aspx?UniqueId=54018909-b0e5-42f6-9cfb-999a21e39e86&embed=%7B%22ust%22%3Atrue%2C%22hv%22%3A%22CopyEmbedCode%22%7D&referrer=StreamWebApp&referrerScenario=EmbedDialog.Create"
                        width={640}
                        height={360}
                        frameBorder={0}
                        scrolling="no"
                        allowFullScreen
                        title="Incident-Management-Agentic-Detailed-No Sound-5 mins_1x.mp4"
                    />
                </div>
            </div> */}

            <div className="grid grid-cols-2 gap-6 my-8">
                {
                    VIDEO_LIST.map((el, idx) => (
                        <div className="border text-sm text-muted-foreground border-b-0 rounded-xl bg-secondary/30" key={idx}>
                            <div className="p-2 flex justify-between items-center">
                                <span>{el.name}</span>
                                <span>{el.duration} min</span>
                            </div>
                            <Suspense fallback={
                                <Skeleton className="h-[340px]" />
                            }>
                                <VideoDialog
                                    videoSrc={el.path}
                                    thumbnailSrc="/assets/video-thumbnail/agentic-incident.png"
                                    animationStyle='fade'
                                />
                            </Suspense>
                        </div>
                    ))
                }
            </div>
        </Container>
    )
}

const AccessVerification = () => {
    const [isOpen, setIsOpen] = useState(true);
    const [trigger, data] = useTrackUserMutation()
    const accessSchema = z.object({
        empid: z.string(),
        reason: z.string()
    })
    const accessForm = useForm<z.infer<typeof accessSchema>>({
        resolver: zodResolver(accessSchema),
        defaultValues: {
        },
    })

    useEffect(() => {
        if (data.isSuccess) {
            setIsOpen(false)
        }
        if (data.isError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to log access details, please try after sometime.",
            });
        }

    }, [data])

    const { toast } = useToast()
    return (
        <Dialog open={isOpen}>
            <DialogContent className="max-w-lg rounded-xl">
                <DialogHeader>
                    <DialogTitle>Access verification required</DialogTitle>
                    <DialogDescription>
                        The information is required for audit and compliance purpose.
                    </DialogDescription>
                </DialogHeader>
                <Form {...accessForm}>
                    <form onSubmit={accessForm.handleSubmit((details) => {
                        trigger({ ...details })

                    })}>
                        <FormField
                            control={accessForm.control}
                            name="empid"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Employee Id</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g. 2096742" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={accessForm.control}
                            name="reason"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel> Reason for access</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="e.g. Required for internal demo to operations team" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <DialogFooter className="sm:justify-start mt-4">
                            <DialogClose asChild>
                                <Button
                                    type="submit"
                                    disabled={data.isLoading}
                                    variant="primary"
                                >
                                    {data.isLoading && <LoaderIcon className="animate-spin h-4 w-4" />}
                                    Submit
                                </Button>
                            </DialogClose>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    )
}