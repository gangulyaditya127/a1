import Container from "@/components/ui/container";
import NEW_BUSINESS_IMG from '@/assets/appthumbnail/new_business_transition.jfif'
import MATURITY_ASSESMENT_IMG from '@/assets/appthumbnail/maturity_assesment.jfif'
import TALENDT_DEV_IMG from '@/assets/appthumbnail/talent_development.jfif'
import DATA_IMG from '@/assets/appthumbnail/data_litracy.jfif'
import CI_IMG from '@/assets/appthumbnail/continuous_improvement.jfif'
import { useTranslation } from "react-i18next";
import { AIAgentCard } from "./AIAgentCard";
function HowItWorks() {
  const { t } = useTranslation('ismartHome')
  return (
    <section
      id="__how_it_works"
      className="relative -translate-y-8 rounded-t-3xl bg-white pb-12 pt-16 dark:bg-neutral-950"
    >
      <Container className="grid max-w-5xl">
        <h4
          className={
            "text-4xl text-center  font-bold text-neutral-900 dark:text-neutral-200 font-tcs-title mb-20"
          }
        >
          {t('howitsWork.title')}
        </h4>
        <div className="flex flex-col gap-14">
          <div className="group/how-section grid grid-cols-[3fr_2fr] items-center gap-8 py-4">
            <div className="">
              <h4 className="mb-4 text-3xl font-tcs-title">{t('howitsWork.businessTransition.tagLine')}</h4>
              <p className="text-baseline dark:text-neutral-300">
                {t('howitsWork.businessTransition.title')}
                <br />
                {t('howitsWork.businessTransition.subTitle')}
              </p>
            </div>
            <div className="">
              <img
                className="h-52 w-full rounded-xl object-cover transition-transform duration-700 ease-in-out group-hover/how-section:scale-105"
                src={NEW_BUSINESS_IMG}
                alt=""
              />
            </div>
          </div>
          <div className="group/how-section grid grid-cols-[3fr_2fr] items-center gap-8 py-4">
            <div className="">
              <img
                className="h-52 w-full rounded-xl object-cover transition-transform duration-700 ease-in-out group-hover/how-section:scale-105"
                src={MATURITY_ASSESMENT_IMG}
                alt=""
              />
            </div>
            <div className="">
              <h4 className="mb-4 text-3xl font-tcs-title">{t('howitsWork.maturityAssessments.tagLine')}</h4>
              <p className="text-baseline dark:text-neutral-300">
                {t('howitsWork.maturityAssessments.title')}
                <br />
                {t('howitsWork.maturityAssessments.subTitle')}
              </p>
            </div>
          </div>
          <div className="group/how-section grid grid-cols-[3fr_2fr] items-center gap-8 py-4">
            <div className="">
              <h4 className="mb-4 text-3xl font-tcs-title">{t('howitsWork.talentDevelopment.tagLine')}</h4>
              <p className="text-baseline dark:text-neutral-300">
                {t('howitsWork.talentDevelopment.title')}
                <br />
                {t('howitsWork.talentDevelopment.subTitle')}
              </p>
            </div>
            <div className="">
              <img
                className="h-52 w-full rounded-xl object-cover transition-transform duration-700 ease-in-out group-hover/how-section:scale-105"
                src={TALENDT_DEV_IMG}
                alt=""
              />
            </div>
          </div>
          <div className="group/how-section grid grid-cols-[3fr_2fr] items-center gap-8 py-4">
            <div className="">
              <img
                className="h-52 w-full rounded-xl object-cover transition-transform duration-700 ease-in-out group-hover/how-section:scale-105"
                src={DATA_IMG}
                alt=""
              />
            </div>
            <div className="">
              <h4 className="mb-4 text-3xl font-tcs-title">{t('howitsWork.dataLiteracy.tagLine')}</h4>
              <p className="text-baseline dark:text-neutral-300">
                {t('howitsWork.dataLiteracy.title')}
                <br />
                {t('howitsWork.dataLiteracy.subTitle')}
              </p>
            </div>
          </div>
          <div className="group/how-section grid grid-cols-[3fr_2fr] items-center gap-8 py-4">
            <div className="">
              <h4 className="mb-4 text-3xl font-tcs-title">{t('howitsWork.continuousImprovements.tagLine')}</h4>
              <p className="text-baseline dark:text-neutral-300">
                {t('howitsWork.continuousImprovements.title')}
                <br />
                {t('howitsWork.continuousImprovements.subTitle')}
              </p>
            </div>
            <div className="">
              <img
                className="h-52 w-full rounded-xl object-cover transition-transform duration-700 ease-in-out group-hover/how-section:scale-105"
                src={CI_IMG}
                alt=""
              />
            </div>
          </div>
        </div>
      </Container>
      <Container className="mt-20">
        <AIAgentCard />
      </Container>
    </section>
  );
}

export default HowItWorks;
