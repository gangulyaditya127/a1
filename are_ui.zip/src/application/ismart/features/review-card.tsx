import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { VerifiedIcon } from "lucide-react";

interface ReviewCardProps {
    accountName: string,
    from: {
        name: string,
        email: string,
        designation: string,
    },
    content: string[],
    headline?: string
}

function ReviewCard({
    accountName,
    content,
    from
}: ReviewCardProps) {
    return (
        <div
            className={cn(
                "w-full p-1 rounded-2xl relative isolate overflow-hidden",
                "bg-white/5 dark:bg-black/90",
                "bg-gradient-to-br from-black/5 to-black/[0.02] dark:from-white/5 dark:to-white/[0.02]",
                "backdrop-blur-xl backdrop-saturate-[180%]",
                "border border-black/10 dark:border-white/10",
                "will-change-transform translate-z-0"
            )}
        >
            <div
                className={cn(
                    "w-full p-5 rounded-xl relative",
                    "",
                    "backdrop-blur-md backdrop-saturate-150",
                    "border border-black/[0.05] dark:border-white/[0.08]",
                    "text-black/90 dark:text-white",
                    "shadow-sm",
                    "will-change-transform translate-z-0",
                    "before:absolute before:inset-0 before:bg-gradient-to-br before:from-black/[0.02] before:to-black/[0.01] dark:before:from-white/[0.03] dark:before:to-white/[0.01] before:opacity-0 before:transition-opacity before:pointer-events-none",
                    "hover:before:opacity-100"
                )}
            >
                <div className="text-black dark:text-white/60 text-sm italic relative">
                    <Icon name="quote" strokeWidth={1}  className="absolute -top-3 left-0 h-10 w-10 opacity-10" />
                    {content.map((item, index) => (
                        <p
                            key={index}
                            className=""
                        >
                            {item}
                        </p>
                    ))}

                </div>

                <div className="flex gap-3 mt-2">
                    <div className="flex-1">
                        <div className="flex justify-between items-start">
                            <div className="flex flex-col">
                                <div className="flex items-center gap-1">
                                    <span className="font-semibold text-black dark:text-white/90 hover:underline cursor-pointer">
                                        {from.name}
                                    </span>
                                    <VerifiedIcon className="h-4 w-4 text-blue-400" />

                                </div>
                                <span className="text-black dark:text-white/60 text-sm">
                                    {from.designation} - {accountName}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}


export { ReviewCard }