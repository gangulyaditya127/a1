import { useRef } from "react";
import { cn } from "@/lib/tailwind.utils";
import {
  useMotionTemplate,
  useMotionValue,
  useSpring,
  motion,
} from "framer-motion";
import { Link } from "react-router-dom";
import { ApplicationDataType } from "../lib/types";
const ROTATION_RANGE = 4;
const HALF_ROTATION_RANGE = 4 / 2;

const TiltCard = ({
  title,
  link,
  img,
  description,
  openInNew,
  className,
}: ApplicationDataType) => {
  const ref = useRef<any>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const xSpring = useSpring(x);
  const ySpring = useSpring(y);

  const transform = useMotionTemplate`rotateX(${xSpring}deg) rotateY(${ySpring}deg)`;

  const handleMouseMove = (e: any) => {
    if (!ref.current) return [0, 0];

    const rect = ref.current.getBoundingClientRect();

    const width = rect.width;
    const height = rect.height;
    const mouseX = (e.clientX - rect.left) * ROTATION_RANGE;
    const mouseY = (e.clientY - rect.top) * ROTATION_RANGE;

    const rX = (mouseY / height - HALF_ROTATION_RANGE) * -1;
    const rY = mouseX / width - HALF_ROTATION_RANGE;
    x.set(rX);
    y.set(rY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: "preserve-3d",
        transform,
      }}
      className={cn("group relative h-80 w-full rounded-xl", className)}
    >
      <Link
        to={link}
        style={{
          transform: "translateZ(75px)",
          transformStyle: "preserve-3d",
        }}
        target={openInNew ? "_blank" : "_self"}
        className="absolute inset-4 cursor-pointer overflow-hidden rounded-xl bg-red-800 bg-white p-4 shadow-lg"
      >
        <img
          className="absolute inset-0 h-full w-full scale-105 object-cover transition-all"
          src={img}
          alt="Random image"
        />
        {/* <div className="absolute inset-0 inset-0 bg-gradient-to-r from-fuchsia-600 to-purple-600 opacity-50"></div> */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/[0.7] to-black/[0.1] opacity-20 transition-opacity group-hover:opacity-100"></div>
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/[0.7] to-black/[0.1] opacity-100 group-hover:opacity-20"></div>

        <h4
          style={{
            transform: "translateZ(90px)",
          }}
          className="relative text-xl font-medium text-slate-100"
        >
          {title}
        </h4>
        <p
          style={{
            transform: "translateZ(100px)",
          }}
          className="relative z-10 hidden translate-y-8 text-sm text-neutral-100 transition-all group-hover:block group-hover:translate-y-0"
        >
          {description}
        </p>
      </Link>
    </motion.div>
  );
};
export default TiltCard;
