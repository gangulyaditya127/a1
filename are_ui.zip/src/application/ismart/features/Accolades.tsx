import Container from "@/components/ui/container";
import { InfiniteMovingBlock } from "@/components/ui/infinite-moving-block";
import { useMemo } from "react";
import { useTranslation } from "react-i18next";


function Accolades() {
  const { t, i18n, ready } = useTranslation('ismartHome');
  if (!ready) return null;
  const testimonialList:any = useMemo(() => 
      t('testimonials',{returnObjects:true})
  , [i18n.language])
  return (
    <section className="dark relative flex flex-col items-center justify-center overflow-hidden bg-neutral-950 py-12 pb-16 antialiased">
      <Container>
        <InfiniteMovingBlock direction="left" speed="slow">
          {testimonialList?.map((item:any) => (
            <li
              className="h-[180px] w-[400px] max-w-full rounded-xl border border-black/[0.2] bg-slate-100/60 bg-white p-4 shadow-input transition duration-200 hover:shadow-sm dark:border-white/[0.2] dark:bg-black dark:shadow-none"
              key={item.id}
            >
              <div className="relative grid h-full w-full place-items-center overflow-hidden text-neutral-100">
                <div className="text-2xl text-neutral-100">{item.title}</div>
                <div className="pointer-events-none absolute -top-[90px] left-2 text-[200px] text-neutral-100 opacity-10">
                  {item?.count}
                </div>
              </div>
            </li>
          ))}
        </InfiniteMovingBlock>
      </Container>
    </section>
  );
}

// const testimonials_old = [
//   {
//     id: "1",
//     title: "Intellectual property (in-progress)",
//     count: 1,
//   },
//   {
//     id: "2",
//     title: "IP safe certification",
//     count: 1,
//   },
//   {
//     id: "3",
//     title: "Copyright",
//     count: 5,
//   },
//   {
//     id: "4",
//     title: "Nominated for TATA Innovista",
//   },
// ];
export default Accolades;
