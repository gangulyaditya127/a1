"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ReviewCard } from "./review-card"
import { cn } from "@/lib/tailwind.utils"
import Container from "@/components/ui/container"
import { Icon } from "@/components/ui/icon"
import { TESTIMONIAL } from "../constants/testimonial-data"



interface TestimonialsProps {
    maxDisplayed?: number
}

export default function Testimonials({
    maxDisplayed = 3,
}: TestimonialsProps) {
    const [showAll, setShowAll] = useState(false);
    const [testimonials] = useState(() => TESTIMONIAL)

    return (
        <Container className='grid place-items-center pb-56'>
            <h4 id="ams_home_testimonial_id" className="relative text-4xl w-fit font-bold mb-20 text-neutral-900 dark:text-neutral-200 font-tcs-title ">
                Real Experiences, Real Results
                <Icon name="quote" strokeWidth={1} className="absolute -top-6 right-0 h-20 w-20 opacity-10" />
            </h4>
            <div className="relative">
                <div
                    className={cn(
                        "space-y-6", //
                        !showAll &&
                        testimonials.length > maxDisplayed &&
                        "overflow-hidden",
                    )}
                >
                    {testimonials
                        .slice(0, showAll ? undefined : maxDisplayed)
                        .map((testimonial, index) => (
                            <ReviewCard {...testimonial} key={index} />
                        ))}
                </div>

                {testimonials.length > maxDisplayed && !showAll && (
                    <>
                        <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-background to-transparent" />
                        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-20">
                            <Button variant="secondary" onClick={() => {
                                setShowAll(true);
                            }} className="rounded-[300px] border-2 text-primary">
                                Show More
                                <Icon name="chevron-down" className="size-5" />
                            </Button>
                        </div>
                    </>
                )}
            </div>
        </Container>
    )
}
