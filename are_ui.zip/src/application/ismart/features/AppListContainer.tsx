import { Button } from "@/components/ui/button";
import Container from "@/components/ui/container";
import { Icon } from "@/components/ui/icon";
import { useMemo, useState } from "react";
import TiltCard from "./TiltCard";
import { ApplicationDataType } from "../lib/types";
import { useTranslation } from "react-i18next";
function AppListContainer() {
  const [expand, setExpand] = useState(false);
  const { ready, t, i18n } = useTranslation('/ismartHome')
  if (!ready) return null;
  const APPLICATION_LIST: any = useMemo(() =>
    t('appList', { returnObjects: true }), [i18n.language])
  return (
    <section
      className="relative bg-neutral-100 py-20 pb-32"
      id="ism_service"
    >
      <Container className="auto-rows grid grid-cols-4 gap-6 md:w-full xl:max-w-6xl">
        <h3 className="col-span-full font-medium uppercase tracking-widest text-slate-950">
          {t('application.subtitle')}
        </h3>
        <h2 className="col-span-full font-bold text-neutral-900 text-4xl font-tcs-title -mt-2 mb-4">
          {t('application.title')}
        </h2>
        {APPLICATION_LIST.slice(0, expand ? APPLICATION_LIST.length : 4).map(
          ({
            title,
            img,
            className,
            description,
            link,
            openInNew,
          }: ApplicationDataType) => (
            <TiltCard
              title={title}
              openInNew={openInNew}
              link={link}
              img={img}
              className={className}
              key={title}
              description={description}
            />
          ),
        )}
        <div className="align-center col-span-full flex justify-center mt-8" >
          <Button
            variant={"outline"}
            onClick={() => setExpand((prevState) => !prevState)}
            className="rounded-[300px] border-2 border-neutral-800 bg-transparent	text-neutral-900"
          >
            {!expand ? (
              <>
                <span>{t('appBtn.all')}</span>
                <Icon name="chevron-down" className="size-5" />
              </>
            ) : (
              <>
                <span>{t('appBtn.less')}</span>
                <Icon name="chevron-up" className="size-5" />
              </>
            )}
          </Button>
        </div>
      </Container>
    </section>
  );
}

export default AppListContainer;
