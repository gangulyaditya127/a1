import { Link } from "react-router-dom";
import { ApplicationDataType } from "../lib/types";

function Card({
  title,
  link,
  img,
  description,
  openInNew,
}: ApplicationDataType) {
  return (
    <Link
      to={link}
      target={openInNew ? "_blank" : "_self"}
      className="group relative h-[14rem] transform cursor-pointer overflow-hidden rounded-xl p-4 transition-all hover:-translate-y-2 hover:scale-105"
    >
      <h4 className="relative z-10 text-xl font-medium text-slate-100">
        {title}
      </h4>
      <p className="relative z-10 hidden translate-y-8 text-sm text-neutral-100 transition-all group-hover:block group-hover:translate-y-0">
        {description}
      </p>
      <img
        className="absolute inset-0 h-full w-full rounded-xl object-cover transition-all group-hover:scale-125"
        src={img}
        alt="Random image"
      />
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-fuchsia-600 to-purple-600 opacity-50"></div>
      <div className="pointer-events-none absolute inset-0 rounded-xl bg-gradient-to-b from-black/[0.7] to-black/[0.1] opacity-20 transition-opacity group-hover:opacity-100"></div>
      <div className="pointer-events-none absolute inset-0 rounded-xl bg-gradient-to-t from-black/[0.7] to-black/[0.1] opacity-100 group-hover:opacity-20"></div>
    </Link>
  );
}

export default Card;
