import { useEffect } from "react";
import {
  useMotionTemplate,
  useMotionValue,
  motion,
  animate,
  // MotionValue,
} from "framer-motion";
import Container from "@/components/ui/container";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";


import { useTranslation } from "react-i18next";
// import Accolades from "./Accolades";
import { InfiniteMovingBlock } from "@/components/ui/infinite-moving-block";
import { TESTIMONIAL } from "../constants/testimonial-data";
import { useNavigate } from "react-router-dom";

// const SpaceStars = lazy(() => import("./SpaceStars"));
const COLORS_TOP = ["#2469BC", "#93D180", "#8CBDFA"];

// const COLORS_TOP = ["#9333ea", "#db2777", "#7c3aed"];

export const AuroraHero = () => {
  const color = useMotionValue(COLORS_TOP[0]);
  useEffect(() => {
    animate(color, COLORS_TOP, {
      ease: "easeInOut",
      duration: 10,
      repeat: Infinity,
      repeatType: "mirror",
    });
  }, []);
  const backgroundImage = useMotionTemplate`radial-gradient(125% 125% at 50% 0%, #000 50%, ${color})`;
  const border = useMotionTemplate`1px solid ${color}`;
  const boxShadow = useMotionTemplate`0px 4px 24px ${color}`;
  const { t } = useTranslation('ismartHome');
  let navigate = useNavigate();

  return (
    <motion.section
      style={{
        backgroundImage,
      }}
      className="relative grid pt-0 grid place-items-center min-h-screen w-full w-screen overflow-hidden bg-grid-black/[0.2] dark:bg-grid-white/[0.2]"
      id="__ism_hero"
    >
      <Container className="relative z-30 flex flex-col place-items-center"> {/** -mt-14*/}
        <h1 className="font-baseline text-center text-lg text-slate-100">
          {t('hero.tagline')}
        </h1>
        <h1 className="font-bold text-center text-2xl text-slate-100 md:text-6xl mt-4 mb-2 font-tcs-title">
          {t('hero.title')}
        </h1>
        <Container className="my-2 mt-6 max-w-4xl">
          <Separator className="bg-neutral-100" />
        </Container>
        <p className="max-w-3xl text-center text-slate-200">
          {t('hero.subtitle')}
        </p>
        <motion.button
          style={{
            border,
            boxShadow,
          }}
          whileHover={{
            scale: 1.015,
          }}
          whileTap={{
            scale: 0.985,
          }}
          className="pointer bg-background-950/10 text-background-50 hover:bg-background-950/50 group relative mt-8 flex w-fit items-center gap-1.5 rounded-full px-4 py-2 text-sm text-neutral-100 transition-colors"
          onClick={() => {
            navigate('/doc/are-assets')
          }}
        >
          {t('hero.cta')}
          <Icon
            name="chevron-right"
            className="size-5 transition-transform group-hover:translate-x-1 group-active:translate-x-1"
          />
        </motion.button>
      </Container>
      <Testimonial />
      {/* <Suspense fallback="">
        <SpaceStars />
      </Suspense> */}
    </motion.section>
  );
};


const Testimonial = () => {
  return (
    <InfiniteMovingBlock
      className="mt-auto py-0  text-slate-200 text-xs absolute bottom-0"
      onClick={() => {
        console.log('onclick')
        const element = document.getElementById("ams_home_testimonial_id");
        element?.scrollIntoView({
          behavior: "smooth",
          block: "center",
          inline: "nearest",
        });
      }}
      containerClassName="py-0 " speed="extremeslow" pauseOnHover >
      {
        TESTIMONIAL.map(testimonial => (
          <li
            className="pointer bg-black/80 text-background-50 hover:bg-background-950/50 group relative flex w-[300px] flex-col h-[120px] gap-1.5 rounded-t-lg px-4 py-3 text-sm text-neutral-100 transition-colors cursor-pointer">
            <p className="font-medium text-white">{testimonial.bg} | {testimonial.accountName}</p>
            <p>{testimonial.headline}</p>
          </li>
        ))
      }
    </InfiniteMovingBlock>
  )
}