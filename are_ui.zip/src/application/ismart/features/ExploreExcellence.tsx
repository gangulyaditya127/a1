import { VideoPlayer } from "@/components/ui/video-player/video-player";
import PRODUCT_DEMO from "@/assets/Video/Doing Production Management is like_5.mp4";
import DEMO_VIDEO_THUMBNAIL from "@/assets/Video/thumbnail/Doing Production Management is like_5_Moment(2).jfif";
import Container from "@/components/ui/container";
import SectionHeaderSparkles from "./SectionHeaderSparkles";
import { useTranslation } from "react-i18next";
function ExploreEcxcellence() {
  const { t } = useTranslation('ismartHome')
  return (
    <section className="dark rounded-t-3xl bg-neutral-950 py-16 pt-20">
      <Container className="overflow-hidden max-w-4xl xl:max-w-5xl">
        {/* <h2>Explore our excellence</h2> */}
        <SectionHeaderSparkles title= {t('exploreExcelence.title')} />
        <div className="mt-6">
          <VideoPlayer
            src={PRODUCT_DEMO}
            autoPlay={false}
            loop={true}
            className="rounded-xl"
            thumbnail={DEMO_VIDEO_THUMBNAIL}
            title={t('exploreExcelence.title')}
          />
        </div>
      </Container>
    </section>
  );
}
export default ExploreEcxcellence;
