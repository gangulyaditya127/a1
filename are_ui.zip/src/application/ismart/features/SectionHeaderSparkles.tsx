// import { SparklesCore } from "@/components/ui/sparkles";
import { cn } from "@/lib/tailwind.utils";

const SectionHeaderSparkles = ({
  title,
  className,
}: {
  title: string;
  className?: string;
}) => (
  <div className="relative flex flex-col items-center justify-center mb-12">
    <h4 className={cn("text-4xl font-bold text-neutral-200 font-tcs-title", className)}>
      {title}
    </h4>
    {/* <div className="relative h-10 w-[40rem]">
      <div className="absolute inset-x-20 top-0 h-[2px] w-3/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent blur-sm" />
      <div className="absolute inset-x-20 top-0 h-px w-3/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent" />
      <div className="absolute inset-x-60 top-0 h-[5px] w-1/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent blur-sm" />
      <div className="absolute inset-x-60 top-0 h-px w-1/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent" />
      <SparklesCore
        background="transparent"
        minSize={0.4}
        maxSize={1}
        particleDensity={1200}
        className="h-full w-full"
        particleColor="#2469BC"
      />
      <div className="absolute inset-0 h-full w-full bg-neutral-950 [mask-image:radial-gradient(350px_200px_at_top,transparent_20%,white)]"></div>
    </div> */}
  </div>
);
export default SectionHeaderSparkles;
