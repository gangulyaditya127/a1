import { Banner } from "@/components/ui/banner";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Marquee } from "@/components/ui/marquee";
import { TESTIMONIAL } from "../constants/testimonial-data";

export default function TestimonialBanner() {
    return (
        <Banner variant="default" className="dark bg-black text-white mx-0 border-0 text-sm mt-14 border-b">
            <div className="flex gap-4 items-center">
                <p className="shrink-0 relative">
                    Real Experiences, Real Results
                    <Icon name="quote" strokeWidth={1} className="absolute -top-2 -scale-100 -left-4 h-8 w-8 opacity-50" />
                </p>
                <Marquee pauseOnHover className="[--duration:120s] py-0">
                    {
                        TESTIMONIAL.map(testimonial=>` -  ${testimonial.from.name},${testimonial.from.designation} | ${testimonial.headline}`)
                        .concat('')
                    }
                </Marquee>
                <Button variant="link" className="py-0 h-fit shrink-0 gap-1"
                    onClick={() => {
                        const element = document.getElementById("ams_home_testimonial_id");
                        element?.scrollIntoView({
                            behavior: "smooth",
                            block: "start",
                            inline: "nearest",
                        });
                    }}
                >
                    View
                    <Icon name="arrow-right" className="h-4 w-4" />
                </Button>
            </div>

        </Banner>
    )
}