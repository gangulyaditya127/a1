import { ApplicationDataType } from "../lib/types";
import ICRM_THUMB from "@/assets/appthumbnail/icrm.jfif";
import IRR_THUMB from "@/assets/appthumbnail/irr.jpg";
import GAMIFICATION_THUMB from "@/assets/appthumbnail/gamification.jpg";
import IADD_THUMB from "@/assets/appthumbnail/iadd.avif";
import IMBP_THUMB from "@/assets/appthumbnail/iprm.avif";
import IPRM_THUMB from "@/assets/appthumbnail/iprm.jfif";
import DAHC_THUMB from "@/assets/appthumbnail/dahc.avif";
import ONDEMAND_THUMB from "@/assets/appthumbnail/l1_dash_2.avif";
import LDASH_THUMB from "@/assets/appthumbnail/l1_dashboard.jpg";
import ICERT_THUMB from "@/assets/appthumbnail/icert.jfif";
import BATCH_THUMB from "@/assets/appthumbnail/batch_status.jpg";
import GLOBAL_THUMB from "@/assets/appthumbnail/global_planner.jpg";
import REGULATORY_THUMB from "@/assets/appthumbnail/regulatory.jpg";
import KNOWLEDGE_THUMB from "@/assets/appthumbnail/knowledge_amanagement.jpg";
import ONBOARD_THUMB from "@/assets/appthumbnail/app_onboarding.jpg";
import IPROMPT_THUMB from "@/assets/appthumbnail/iPrompt.jpg";

export const APPLICATION_LIST: ApplicationDataType[] = [
  {
    title: "Integrated Change Review Management",
    description:
      "Change with confidence, prevent downtime, streamline reviews.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: ICRM_THUMB,
    openInNew: false,
    link: "/doc/icrm",
  },
  {
    title: "Intelligent Resolution Recommender",
    description:
      "Resolve faster, smarter. Your ticket-solving copilot.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: IRR_THUMB,
    openInNew: false,
    link: "/doc/irr",
  },
  {
    title: "Gamification",
    description: "Unleash your inner hero. Boost productivity & teamwork.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: GAMIFICATION_THUMB,
    openInNew: false,
    link: "/doc/gamification",
  },
  {
    title: "Integrated Application Dependency Dashboard",
    description:
      "Unravel dependencies. Fix faster.  Illuminate application & infrastructure dependencies.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: IADD_THUMB,
    openInNew: false,
    link: "/doc/iadd",
  },
  {
    title: "Integrated Project Risk Management​",
    description:
      "Web based solution with workflow tracking mechanism to complete POA(Project Onboarding Assessment) or PRA(Project Risk Assesment) of new projects",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: IPRM_THUMB,
    openInNew: false,
    link: "/doc/iprm",
  },
  {
    title: "Daily Application Health Check",
    description: "Real time status of application health check.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: DAHC_THUMB,
    openInNew: false,
    link: "/doc/dahc",
  },
  {
    title: "L1 Dashboard",
    description:
      "Realtime status of incidents, MIM(Major Incident Management), change requests along with accountability matric, 13 months’ trend, LOB(Line of Business) & Country wise impact",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: LDASH_THUMB,
    openInNew: false,
    link: "/doc/l1-dashboard",
  },
  {
    title: "Automated Certificate Management",
    description:
      "Latest status of certificates being used in production ensuring RAG(Red, Amber, Green) status highlights upcoming certificate expiry. Month wise expiry depiction coupled with LOB(Line of Business) wise view",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: ICERT_THUMB,
    openInNew: false,
    link: "/doc/icert",
  },
  {
    title: "Batch Health Analyzer​",
    description:
      "Realtime batch status dashboard displaying current status of every batch along with errors occurred, disk space utilization status, card transaction status etc.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: BATCH_THUMB,
    openInNew: false,
    link: "/doc/batch-status",
  },
  {
    title: "Global Planner",
    description:
      "Handy list of upcoming planned global events like major releases, EOVS(End Of Version Support), monthly release dates etc.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: GLOBAL_THUMB,
    openInNew: false,
    link: "/doc/global-planner",
  },
  {
    title: "Intelligent Major Incident Briefing Paper",
    description:
      "Dashboard highlighting severity based MIM(Major Incident Management) count along with causal analysis with drill down capability to identify resolution",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: IMBP_THUMB,
    openInNew: false,
    link: "/doc/imbp",
  },
  {
    title: "Regulatory Data Lineage Dashboard",
    description:
      "Reduce email and ticket volume by keeping stakeholders updated on real time basis.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: REGULATORY_THUMB,
    openInNew: false,
    link: "/doc/regulatory",
  },
  {
    title: "Capture Hidden Knowledge",
    description:
      "Capture the missing knowledge using our GenAI(Generative Artificial Intelligence) based Chatbot",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: KNOWLEDGE_THUMB,
    openInNew: false,
    link: "/doc/knowledge-management",
  },
  {
    title: "New Application Onboarding",
    description:
      "Criticality, complexity & size estimation of a new application getting on boarded along with other rich features such as effort estimation, DD(Dependenncy Diagram) dube generation etc.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: ONBOARD_THUMB,
    openInNew: false,
    link: "/doc/nao",
  },
  {
    title: "Effort Calculator​",
    description:
      "Effort Calculator​ of applications in production, with gap analysis between estimated & actual support resources.",
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    img: IPROMPT_THUMB,
    openInNew: false,
    link: "/doc/iprompt",
  },
  {
    title: "Intelligent SLA management​",
    link: "/doc/isla",
    img: ONDEMAND_THUMB,
    openInNew: false,
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    description:
      "A comprehensive solution for intelligent SLA(Service Level Agreement) management, enabling organizations to proactively monitor and enforce service agreements, ultimately leading to improved service delivery and reduced operational costs",
  },
  {
    title: "Bots Family",
    link: "/doc/bots",
    img: IRR_THUMB,
    openInNew: false,
    className: "bg-gradient-to-br from-neutral-300 to-neutral-200",
    description:
      "A collaborative bot family leverages multiple bots to intelligently assign tickets, enrich tickets with log data, perform automatic root cause analysis",
  },
];
