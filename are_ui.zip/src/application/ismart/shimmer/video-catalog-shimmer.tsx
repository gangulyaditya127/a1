import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";

export default function VideoCatalogShimmer() {
    return (
        <Container className="mt-24 pb-24">
            <Skeleton className="h-4 w-10" />
            <div className="grid grid-cols-2 gap-6 my-8">
                {
                    [1, 2, 3].map((idx) => (
                        <Skeleton key={idx} className="h-[400px] rounded-lg"/>
                    ))
                }
            </div>
        </Container>
    )
}