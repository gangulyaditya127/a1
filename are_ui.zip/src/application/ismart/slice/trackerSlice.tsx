import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
export type trackUserProps = {
    empid: string,
    reason: string
}
export const trackerUserSlice = createApi({
    reducerPath: 'trackerSlice',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/user/` }),
    tagTypes: ['track_user'],
    endpoints: ({ mutation }) => ({
        trackUser: mutation<any, trackUserProps>({
            query: (queryParams) => ({ url: 'secretSubmit', params: queryParams, method: "POST" })
        }),
    }),
})

export const {
    useTrackUserMutation
} = trackerUserSlice