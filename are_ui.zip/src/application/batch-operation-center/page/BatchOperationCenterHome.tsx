
import { Activity, AlertTriangle, CheckCircle, Clock, TrendingUp, XCircle } from "lucide-react";

// import { Icon } from "@/components/ui/icon";
// import {icons} from "lucide-react";
import BatchOperationDashboard from "../features/dataDumpCategory";



const BatchOperationCenter = () => {

    const data = [
        {
            label: "RUNNING",
            value: 2,
            color: "text-blue-500",
            icon: <Activity className="text-blue-400 w-5 h-5" />,
            // icon: 'Activity',
        },
        {
            label: " COMPLETED",
            value: 1,
            color: "text-green-500",
            icon: <CheckCircle className="text-green-400 w-5 h-5" />,

            // icon: 'CheckCircle',
        },
        {
            label: " FAILED",
            value: 1,
            color: "text-red-500",
            icon: <XCircle className="text-red-400 w-5 h-5" />

            // icon: 'XCircle'
        },
        {
            label: "DELAYED",
            value: 2,
            color: "text-yellow-500",
            icon: <Clock className="text-yellow-400 w-5 h-5" />,

            // icon: 'Clock' 
        },
        {
            label: "SLA BREACHES",
            value: 2,
            color: "text-red-500",
            icon: <AlertTriangle className="text-red-400 w-5 h-5" />,

            // icon: 'AlertTriangle' 
        },
        {
            label: "AVG DELAY",
            value: "18m",
            color: "text-yellow-500",
            icon: <TrendingUp className="text-yellow-400 w-5 h-5" />,

            // icon: 'TrendingUp' 
        },

    ];

    return (
        <>
            <div className="p-6 bg-black-800">
                <div className="text-white">
                    <h1 className=" flex justify-between items-center text-2xl text-blue-600 font-bold mt-2 mb-3">BATCH OPERATION CENTER <span className="text-right ">14:23:45</span></h1>

                    <p className="flex justify-between items-center text-gray-400 text-sm">Real-time monitoring and SLA management <span> System Load: <span className="font-bold  text-yellow-600">56%</span></span></p>

                </div>
                <div className=" grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mt-6">
                    {
                        data.map((item, idx) => (
                            <div key={idx} className="bg-gray-900 rounded-xl shadow-lg p-5 flex flex-col item-center justify-center border border-gray-700 hover:shadow-xl transition">
                                {/* <div className="mb-2"><Icon name ={dynamic(dynamicIconImports[item.icon]): any} className="h-4 w-4" /></div> */}
                                <div className="mb-2">{item.icon}</div>
                                <h3 className={`text-3xl font-bold ${item.color}`}>  {item.value}</h3>
                                <p className="font-semibold text-gray-400 mt-1">{item.label}</p>


                            </div>
                        ))
                    }
                </div>

                <BatchOperationDashboard />


            </div>



        </>

    )
}
export default BatchOperationCenter;