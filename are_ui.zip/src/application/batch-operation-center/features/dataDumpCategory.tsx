
import { AlertTriangle, CheckCircle2, Hourglass } from "lucide-react";
import { dataDump } from "../data/dataDump";



// Card component for job
const JobCard = ({ job }: any) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "FAILED":
        return "bg-red-500 text-white";
      case "DELAYED":
        return "bg-yellow-500 text-black";
      case "WARNING":
        return "bg-yellow-400 text-black";
      case "QUEUED":
        return "bg-gray-700 text-white";
      case "SUCCESS":
        return "bg-green-500 text-white";
      default:
        return "bg-gray-300 text-black";
    }
  };

  const getRisksColor = (risk: string) => {
    switch (risk) {
      case "Critical Risk":
        return "bg-red-500 text-white";
      case "Medium Risk":
        return "bg-yellow-500 text-black";
      case "Low Risk":
        return "bg-green-500 text-white";
      default:
        return "hidden";
    }
  };

  return (

      <div className=" bg-gray-900 text-white p-4 rounded-2xl shadow-lg w-full relative shadow-[0_8px_30px_rgba(0,0,0,0.5)] after:content-[''] after:absolute after:inset-0 after:rounded-xl after:bg-gradient-to-b after:from-white/20 after:to-transparent after:opacity-20 after:blur-md after:-button-6">
        {/* Header */}
        <div className="flex justify-between items-center ">
          <h2 className="text-lg font-bold">{job.job_id}</h2>
          <span className={`px-2 py-1 rounded-md text-xs font-semibold  ${getStatusColor(job.job_status)}`}>
            {job.job_status}
          </span>
        </div>

        {/* Job Name */}
        <p className="text-sm text-gray-300">{job.job_name}</p>

        {/* Info Section */}
        <div className="mt-2 text-xs space-y-1">

          <div className="text-white mb-3">
            <h1 className=" flex justify-between items-center text-sm text-gray-300 font-semibold">🕒 Started:  <span className="text-right ">⏳ Duration:</span></h1>
            <p className="flex justify-between items-center  text-sm">{job.started} <span className="font-semibold  text-yellow-600">{job.duration}</span></p>
          </div>

          {/* {job.sla_deadline && (
          <> */}
          {/* </>
        )} */}
          <div className=" bg-gray-800 text-white mb-3 rounded-lg p-2">
            <h1 className=" flex justify-between items-center text-sm text-gray-300 font-semibold">SLA Deadline: <span className="text-right text-red-500">{job.time}</span></h1>
            <p className="flex justify-between items-center   text-sm">{job.sla_deadline} <span className={`px-2 py-1 rounded-md text-xs font-semibold  ${getRisksColor(job.SLA_status)}`}>
              {job.SLA_status}
            </span>
            </p>
          </div>
          <br></br>


          {job.delay && (
            <>
              <div className=" bg-yellow-300/40  text-white mb-3 rounded-lg p-1">

                <p className="font-bold text-md"> <AlertTriangle className="h-4 w-4 text-yellow-500" />Expected Delay </p>

                <p className="text-sm  text-yellow-500" > {job.delay}</p>
              </div>
            </>
          )}


          {job.dependencies && (
            <>
              <div className="mb-3">
                <p className="text-gray-300">Dependencies</p>
                <button className="bg-gray-800 rounded-lg font-semibold  p-1"> {job.dependencies}</button>
              </div>
            </>
          )}



          {job.downstream && (
            <>
              <div className="mb-3">
                <p className="text-gray-300">Downstream Impact </p>
                <button className="bg-gray-800 rounded-lg font-semibold text-gray-300 p-1"> {job.downstream}</button>
              </div>
            </>
          )}



          <br></br>

          <hr className="border-t border-gray-800 my-4 "></hr>


          {/* {job.impact && (
          )} */}

          <p className="italic text-gray-400"> {job.impact}</p>

        </div>


      </div>
  );
};




const BatchOperationDashboard = () => {
  const requiresAttention = dataDump.filter(
    (job) => job.job_status === "FAILED" || job.job_status === "DELAYED" || job.job_status === "WARNING"
  );
  const queued = dataDump.filter((job) => job.job_status === "QUEUED");
  const completed = dataDump.filter((job) => job.job_status === "SUCCESS");

  return (
    <div className="min-h-screen text-white ">

      {/* Requires Attention */}
      <div>
        <h2 className="text-red-400 text-xl font-semibold mb-3 flex items-center gap-2 mt-6 ">
          <AlertTriangle /> REQUIRES ATTENTION ({requiresAttention.length})
        </h2>
        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 ">
          {requiresAttention.map((job) => (
            <JobCard key={job.job_id} job={job} />
          ))}
        </div>
      </div>

      {/* Queued */}
      <div className="mt-8">
        <h2 className="text-gray-400 text-xl font-semibold mb-3 flex items-center gap-2">
          <Hourglass /> QUEUED ({queued.length})
        </h2>
        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4">
          {queued.map((job) => (
            <JobCard key={job.job_id} job={job} />
          ))}
        </div>
      </div>

      {/* Completed */}
      <div className="mt-8">
        <h2 className="text-green-400 text-xl font-semibold mb-3 flex items-center gap-2">
          <CheckCircle2 /> COMPLETED ({completed.length})
        </h2>
        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4">
          {completed.map((job) => (
            <JobCard key={job.job_id} job={job} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default BatchOperationDashboard;


