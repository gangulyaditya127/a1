// import { Activity } from "lucide-react";

// export const data = [
//         {
//             label: "RUNNING",
//             value: 2,
//             color: "text-blue-500",
//             // icon:<Activity className="text-blue-400 w-5 h-5"/>,
//             // icon: 'Activity',
//         },
//         {
//             label: " COMPLETED",
//             value: 1,
//             color: "text-green-500",
//             // icon : <CheckCircle className="text-blue-400 w-5 h-5" />,
            
//             // icon: 'CheckCircle',
//         },
//         {
//             label: " FAILED",
//             value: 1,
//             color: "text-red-500",
//             // icon : <XCircle className="text-blue-400 w-5 h-5" />
            
//             // icon: 'XCircle'
//         },
//         {
//             label: "DELAYED",
//             value: 2,
//             color: "text-yellow-500",
//             // icon : <Clock className="text-blue-400 w-5 h-5" />,
            
//             // icon: 'Clock' 
//         },
//         {
//             label: "SLA BREACHES",
//             value: 2,
//             color: "text-red-500",
//             // icon : <AlertTriangle className="text-blue-400 w-5 h-5" />,
            

//             // icon: 'AlertTriangle' 
//         },
//         {
//             label: "AVG DELAY",
//             value: "18m",
//             color: "text-yellow-500",
//             // icon : <TrendingUp className="text-blue-400 w-5 h-5" />,
            

//             // icon: 'TrendingUp' 
//         },

//     ];
export const dataDump = [
  {
    job_id: "PIN_001",
    job_name: "Financial Data Sync",
    job_status: "FAILED",
    started: "about 2 hours ago",
    duration: "12m / 30m",
    sla_deadline: "21:07:58",
    time:"91m overdue",
    SLA_status: "Critical Risk",
    downstream: "RPT_003",
    impact: "Synchronize financial data with external systems",
    risk: "Critical Risk",
  },
  {
    job_id: "RPT_002",
    job_name: "Customer Analytics",
    job_status: "DELAYED",
    started: "31 minutes ago",
    duration: "30m / 45m",
    sla_deadline: "00:07:58",
    time:"59m remaining",
    SLA_status: "Medium Risk",
    downstream: "DWH_001",
    dependencies:"ETL_001",
    impact: "Process customer behavior analytics and insights",
    risk: "Medium Risk",
    delay:"+25 minutes downstream",
  },
  {
    job_id: "BAK_001",
    job_name: "System Backup",
    job_status: "WARNING",
    started: "11 minutes ago",
    duration: "10m / 50m",
    sla_deadline: "08:07:58",
    time:"239m remaining",
    SLA_status: "Low Risk",
    downstream: "",
    impact: "Automated system backup and disaster recovery preparation",
    risk: "Low Risk",
    delay:"+20 minutes downstream",
  },
  {
    job_id: "RPT_001",
    job_name: "Regulatory Report Generation",
    job_status: "QUEUED",
    started: "in 30 minutes",
    duration: "~15m / 90m",
    sla_deadline: "02:07:58",
    time:"179m remaining",
    SLA_status: "Critical Risk",
    downstream: "",
    dependencies:"ETL_001",
    impact: "Generate daily regulatory compliance report for submission",
    risk: "High Risk",
    delay:"+15 minutes downstream",
  },
  {
    job_id: "JOB_0004",
    job_name: "Customer Data ETL",
    job_status: "SUCCESS",
    started: "1 hour ago",
    duration: "98m",
    sla_deadline: "23:37:53",
    time:"29m remaining",
     SLA_status: "Medium Risk",
    downstream: "RPT_001",
    impact: "Extract, Transform and load customer data from multiple sources.",
    risk: "None",
    delay:"+15 minutes downstream",
  },
  {
    job_id: "JOB_0009",
    job_name: "Data Warehouse Load",
    job_status: "SUCCESS",
    started: "25 minutes ago",
    duration: "25m",
    sla_deadline: "22:37:53",
    time:"31m overdue",
    SLA_status: "Low Risk",
    downstream: "",
    impact: "Load Processed data into enterprise data warehouse",
    risk: "None",
  },
];

// export const dataDump =[{
//     "current_jobs": [
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 08:07:00 GMT",
//             "dependencies": "['JOB_0003']",
//             "expected_duration_minutes": 98,
//             "job_id": "JOB_0004",
//             "job_name": "Monthly_Report_Generation",
//             "job_status": "SUCCESS",
//             "job_type": "Backup",
//             "last_run_timestamp": "Wed, 11 Jun 2025 08:07:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0004_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 06:27:00 GMT",
//             "scheduled_time": "06:27:00",
//             "triggered_by": "API_Call"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 25,
//             "job_id": "JOB_0009",
//             "job_name": "Weekly_Analytics_Dashboard_Update",
//             "job_status": "PENDING",
//             "job_type": "Analytics",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0009_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 06:32:00 GMT",
//             "scheduled_time": "06:32:00",
//             "triggered_by": "benjamingreen"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 06:49:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 12,
//             "job_id": "JOB_0017",
//             "job_name": "Hourly_Inventory_Sync",
//             "job_status": "FAILED",
//             "job_type": "Backup",
//             "last_run_timestamp": "Wed, 11 Jun 2025 06:49:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0017_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 06:35:00 GMT",
//             "scheduled_time": "06:35:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "['JOB_0003', 'JOB_0004']",
//             "expected_duration_minutes": 72,
//             "job_id": "JOB_0006",
//             "job_name": "Fraud_Detection_Model_Retrain",
//             "job_status": "PENDING",
//             "job_type": "ETL",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0006_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 07:56:00 GMT",
//             "scheduled_time": "07:56:00",
//             "triggered_by": "API_Call"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 09:41:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 82,
//             "job_id": "JOB_0010",
//             "job_name": "Customer_Data_Cleansing",
//             "job_status": "SUCCESS",
//             "job_type": "Reporting",
//             "last_run_timestamp": "Wed, 11 Jun 2025 09:41:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0010_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 08:10:00 GMT",
//             "scheduled_time": "08:10:00",
//             "triggered_by": "devinthompson"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 79,
//             "job_id": "JOB_0003",
//             "job_name": "Weekly_Analytics_Dashboard_Update",
//             "job_status": "PENDING",
//             "job_type": "Backup",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0003_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 08:22:00 GMT",
//             "scheduled_time": "08:22:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 10:06:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 26,
//             "job_id": "JOB_0005",
//             "job_name": "Hourly_Inventory_Sync",
//             "job_status": "FAILED",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "Wed, 11 Jun 2025 10:06:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0005_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 09:27:00 GMT",
//             "scheduled_time": "09:27:00",
//             "triggered_by": "kevin76"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 92,
//             "job_id": "JOB_0011",
//             "job_name": "Customer_Data_Cleansing",
//             "job_status": "PENDING",
//             "job_type": "Reporting",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0011_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 10:45:00 GMT",
//             "scheduled_time": "10:45:00",
//             "triggered_by": "Manual"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 15:24:00 GMT",
//             "dependencies": "['JOB_0006', 'JOB_0005']",
//             "expected_duration_minutes": 102,
//             "job_id": "JOB_0015",
//             "job_name": "User_Activity_Log_Processing",
//             "job_status": "SUCCESS",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "Wed, 11 Jun 2025 15:24:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0015_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 13:48:00 GMT",
//             "scheduled_time": "13:48:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "['JOB_0004']",
//             "expected_duration_minutes": 58,
//             "job_id": "JOB_0008",
//             "job_name": "Fraud_Detection_Model_Retrain",
//             "job_status": "PENDING",
//             "job_type": "ETL",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0008_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 15:10:00 GMT",
//             "scheduled_time": "15:10:00",
//             "triggered_by": "christinawatson"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 16:19:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 56,
//             "job_id": "JOB_0002",
//             "job_name": "Fraud_Detection_Model_Retrain",
//             "job_status": "FAILED",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "Wed, 11 Jun 2025 16:19:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0002_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 15:17:00 GMT",
//             "scheduled_time": "15:17:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 24,
//             "job_id": "JOB_0020",
//             "job_name": "Shipping_Manifest_Creator",
//             "job_status": "RUNNING",
//             "job_type": "ETL",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0020_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 16:05:00 GMT",
//             "scheduled_time": "16:05:00",
//             "triggered_by": "Manual"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "['JOB_0010']",
//             "expected_duration_minutes": 81,
//             "job_id": "JOB_0019",
//             "job_name": "User_Activity_Log_Processing",
//             "job_status": "PENDING",
//             "job_type": "Reporting",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0019_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 16:06:00 GMT",
//             "scheduled_time": "16:06:00",
//             "triggered_by": "Manual"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 109,
//             "job_id": "JOB_0018",
//             "job_name": "Fraud_Detection_Model_Retrain",
//             "job_status": "RUNNING",
//             "job_type": "Reporting",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0018_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 17:41:00 GMT",
//             "scheduled_time": "17:41:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "['JOB_0006']",
//             "expected_duration_minutes": 119,
//             "job_id": "JOB_0007",
//             "job_name": "Fraud_Detection_Model_Retrain",
//             "job_status": "RUNNING",
//             "job_type": "Backup",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0007_20250611.log",
//             "priority": "Low",
//             "scheduled_date": "Wed, 11 Jun 2025 17:42:00 GMT",
//             "scheduled_time": "17:42:00",
//             "triggered_by": "Scheduler"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 19:54:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 96,
//             "job_id": "JOB_0013",
//             "job_name": "Email_Campaign_Batch_Processor",
//             "job_status": "FAILED",
//             "job_type": "ETL",
//             "last_run_timestamp": "Wed, 11 Jun 2025 19:54:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0013_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 18:06:00 GMT",
//             "scheduled_time": "18:06:00",
//             "triggered_by": "Manual"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 19:08:00 GMT",
//             "dependencies": "['JOB_0008']",
//             "expected_duration_minutes": 22,
//             "job_id": "JOB_0014",
//             "job_name": "Product_Catalog_Update",
//             "job_status": "SUCCESS",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "Wed, 11 Jun 2025 19:08:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0014_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 18:48:00 GMT",
//             "scheduled_time": "18:48:00",
//             "triggered_by": "millerjustin"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 20:00:00 GMT",
//             "dependencies": "['JOB_0012', 'JOB_0007']",
//             "expected_duration_minutes": 46,
//             "job_id": "JOB_0016",
//             "job_name": "Financial_Reconciliation_Job",
//             "job_status": "SUCCESS",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "Wed, 11 Jun 2025 20:00:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0016_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 19:17:00 GMT",
//             "scheduled_time": "19:17:00",
//             "triggered_by": "Manual"
//         },
//         {
//             "completion_timestamp": "",
//             "dependencies": "[]",
//             "expected_duration_minutes": 80,
//             "job_id": "JOB_0001",
//             "job_name": "Website_Crawler_Update",
//             "job_status": "PENDING",
//             "job_type": "Data Processing",
//             "last_run_timestamp": "",
//             "log_file_path": "/var/log/batch_jobs/JOB_0001_20250611.log",
//             "priority": "High",
//             "scheduled_date": "Wed, 11 Jun 2025 19:54:00 GMT",
//             "scheduled_time": "19:54:00",
//             "triggered_by": "API_Call"
//         },
//         {
//             "completion_timestamp": "Wed, 11 Jun 2025 23:57:00 GMT",
//             "dependencies": "[]",
//             "expected_duration_minutes": 118,
//             "job_id": "JOB_0012",
//             "job_name": "Hourly_Inventory_Sync",
//             "job_status": "FAILED",
//             "job_type": "Reporting",
//             "last_run_timestamp": "Wed, 11 Jun 2025 23:57:00 GMT",
//             "log_file_path": "/var/log/batch_jobs/JOB_0012_20250611.log",
//             "priority": "Medium",
//             "scheduled_date": "Wed, 11 Jun 2025 21:52:00 GMT",
//             "scheduled_time": "21:52:00",
//             "triggered_by": "Scheduler"
//         }
//     ],
//     "endpoints": {
//         "POST /predict-cpu-utilization": {
//             "description": "Predict CPU utilization percent for current jobs",
//             "input": {
//                 "current_jobs": [
//                     {
//                         "priority": "string",
//                         "scheduled_start_time": "ISO8601 string",
//                         "status": "string"
//                     }
//                 ]
//             },
//             "output": [
//                 {
//                     "cpu_util_percent": 45.6,
//                     "index": 0
//                 }
//             ]
//         },
//         "POST /predict-failure": {
//             "description": "Predict failure probability for current jobs",
//             "input": {
//                 "current_jobs": [
//                     {
//                         "priority": "string",
//                         "scheduled_start_time": "ISO8601 string",
//                         "status": "string"
//                     }
//                 ]
//             },
//             "output": [
//                 {
//                     "failure_prob": 0.23,
//                     "index": 0
//                 }
//             ]
//         },
//         "POST /predict-job-completion": {
//             "description": "Predict job completion duration in seconds",
//             "input": {
//                 "current_jobs": [
//                     {
//                         "priority": "string",
//                         "scheduled_start_time": "ISO8601 string",
//                         "status": "string"
//                     }
//                 ]
//             },
//             "output": [
//                 {
//                     "index": 0,
//                     "predicted_duration_sec": 3600
//                 }
//             ]
//         }
//     },
//     "message": "Job Predictor API is running."
// }
//  ]