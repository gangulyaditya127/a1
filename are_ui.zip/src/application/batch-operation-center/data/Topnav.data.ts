import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Batch Operation Center",
        route: "/batch-operation-center",
        key: "1",
    },
];
