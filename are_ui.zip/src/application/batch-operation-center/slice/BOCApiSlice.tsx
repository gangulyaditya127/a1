import { createApi, fetchBaseQuery, } from '@reduxjs/toolkit/query/react'
export const BOCApi = createApi({
    reducerPath: 'serviceAPI',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/service-mgmt/` }),
    tagTypes: ['service_api'],
    endpoints: ({ query, mutation }) => ({
        getTicketTrend: query<any, any>({
            query: () => ({ url: 'plotChartLoggedResolvedOpenTicketAge3VS' })
        }),
        getOpenTicketStatusBreqkup: query<any, any>({
            query: (params) => ({ url: `pieChartDataLevelAgeWise`, params })
        }),
        getOpenTicketStateBreakup: query<any, any>({
            query: (params) => ({ url: `pieChartDataStatusAgeWise`, params })
        }),
        getValueStreamLoggedTicketTrend: query<any, any>({
            query: (params) => ({ url: `loggedTicketDataVS`, params })
        }),
        getApplicationLoggedTicketTrend: query<any, any>({
            query: (params) => ({ url: `loggedTicketDataApplication`, params })
        }),
        getValueStreamOpenTicketTrend: query<any, any>({
            query: (params) => ({ url: `openTicketAge3VS`, params })
        }),
        getTicketSeverityValueStream: query<any, any>({
            query: (params) => ({ url: `ticketSeverityAgeWiseVS`, params })
        }),
        downloadServiceTemplate: query<any, any>({
            query: () => (
                {
                    url: 'download-all-ticket-dump-template',
                    responseHandler: async (response) => {
                        if (!response.ok) {
                            throw new Error('Error in API response')
                        }
                        const fileBlob = await response.blob()
                        const url = window.URL.createObjectURL(fileBlob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.setAttribute('download', 'last_six_month_data_dum.xlsx')
                        document.body.appendChild(link)
                        link.click()
                        link.parentNode?.removeChild(link)
                        window.URL.revokeObjectURL(url)
                    }
                }
            )
        }),
        downloadResolvedServiceTemplate: query<any, any>({
            query: () => (
                {
                    url: 'download-resolve-ticket-dump-template',
                    responseHandler: async (response) => {
                        if (!response.ok) {
                            throw new Error('Error in API response')
                        }
                        const fileBlob = await response.blob()
                        const url = window.URL.createObjectURL(fileBlob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.setAttribute('download', 'last_day_resolved_ticket.xlsx')
                        document.body.appendChild(link)
                        link.click()
                        link.parentNode?.removeChild(link)
                        window.URL.revokeObjectURL(url)
                    }
                }
            )
        }),
        uploadTicketData: mutation({
            query: (body) => (
                {
                    url: 'submit-sixmonths-dump',
                    body,
                    method: 'POST',

                }
            ),
            invalidatesTags: ['service_api']
        }),
        getTopApplicationLevelWiseBreakup: query({
            query: (params) => ({ url: "ticketDataApplicationLevelStatus", params })
        }),
        getOverallWeeklyChange:query({
            query:()=>({url:'overallTicketWeeklyChange'})
        }),
        getOverallDailyChange:query({
            query:()=>({url:'overallTicketDailyChange'})
        }),
        getDailyStatusChange:query({
            query:()=>({url:"openTicketCardWithSameDay"})
        })
    })
})

export const {
    useGetTicketTrendQuery,
    useGetOpenTicketStatusBreqkupQuery,
    useGetOpenTicketStateBreakupQuery,
    useGetValueStreamLoggedTicketTrendQuery,
    useGetApplicationLoggedTicketTrendQuery,
    useGetValueStreamOpenTicketTrendQuery,
    useGetTicketSeverityValueStreamQuery,
    useLazyDownloadServiceTemplateQuery,
    useUploadTicketDataMutation,
    useGetTopApplicationLevelWiseBreakupQuery,
    useGetOverallDailyChangeQuery,
    useGetOverallWeeklyChangeQuery,
    useGetDailyStatusChangeQuery,
    useLazyDownloadResolvedServiceTemplateQuery
} = BOCApi