import Container from "@/components/ui/container"
import { Icon } from "@/components/ui/icon"
import { NavigateBackButton } from "@/components/ui/navigate-back-button"
import { Link, useParams } from "react-router-dom"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";

export default function ObservabilityAlertTimelineGlobalPay() {

    const { journey, appname } = useParams();

    return (
        <Container className="mt-6">
            <NavigateBackButton />
            <Breadcrumb>
                <BreadcrumbList>
                    <BreadcrumbItem>
                        <Link to="/observability-payments">Home</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <Link to="/observability-payments">{appname}</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <Link to={`/observability-payments/${appname}/${journey}`}>{journey} User Journey Execution Experience</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <BreadcrumbPage>Connected Components</BreadcrumbPage>
                    </BreadcrumbItem>
                </BreadcrumbList>
            </Breadcrumb>
            <div className="h-[80vh] grid place-items-center">
                <Timeline />
            </div>
        </Container>
    )
}

function Timeline() {
    const { journey, appname } = useParams();
    return (
        <div className="flex items-center gap-4 ">
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="webhook" />
                </div>
                <p className="text-muted-foreground text-sm">API Gateway</p>
            </div>

            <Icon name="move-horizontal" className="text-red-500 mb-6" />
            <Link to={`/observability-payments/${appname}/${journey}/detail`} className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-red-600 rounded-full">
                    <Icon name="globe" />
                </div>
                <p className="text-muted-foreground text-sm">Search Service</p>
            </Link>
            <Icon name="move-horizontal" className="text-red-500 mb-6" />
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-500 rounded-full">
                    <Icon name="database" />
                </div>
                <p className="text-muted-foreground text-sm">Database</p>
            </div>
            <Icon name="move-horizontal" className="text-green-500 mb-6" />
            <div className="grid place-items-center gap-2">
                <div className="size-16 grid place-items-center bg-green-600 rounded-full">
                    <Icon name="server-cog" />
                </div>
                <p className="text-muted-foreground text-sm">Recommendation Engine</p>
            </div>
        </div>
    )
}
