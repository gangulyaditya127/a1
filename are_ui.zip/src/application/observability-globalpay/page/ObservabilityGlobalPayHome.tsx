import Container from "@/components/ui/container";
import JourneyCard from "../features/journey-card";
import ObservabilityDashboardHeader from "../features/ObservabilityHeader";
import ObservabilityMetrics from "../features/ObservabilityMetrics";
import { MOCK_APP_DATA } from "../data/mock-appdata";
import { cn } from "@/lib/tailwind.utils";

export default function ObservabilityGlobalPayHome() {
    return <Container className="my-6 mb-12 flex flex-col gap-6">
        <ObservabilityDashboardHeader />
        <ObservabilityMetrics />
        <div className="">
            <p className="text-sm uppercase text-muted-foreground font-medium mb-3 mt-3">Application Health & User Journeys</p>
            <div className="grid grid-cols-2 gap-6 mt-1">
                {
                    MOCK_APP_DATA.map((el, idx) => (
                        <div key={idx} className={cn("bg-secondary/40 border py-3 px-2 rounded-xl flex flex-col gap-4")}>
                            <div className="flex gap-2">
                                <div className="h-10 w-10 grid bg-secondary/40 border grid place-items-center rounded-lg">
                                    {el.icon}
                                </div>
                                <div className="w-full">
                                    <p className="font-medium flex justify-between w-full">{el.name}
                                        <span className={cn("text-xs font-base px-2 py-0.5 rounded-3xl", el.statusClassName)}>
                                            {el.status}
                                        </span>
                                    </p>
                                    <p className="text-xs text-muted-foreground">{el.description}</p>
                                </div>
                            </div>
                            <JourneyCard
                                journey={el.userJourney}
                                appName={el.name}
                            />

                        </div>
                    ))
                }
            </div>
        </div>

    </Container>
}