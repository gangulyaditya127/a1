import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import Container from "@/components/ui/container";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useEffect, useState } from "react";
import { Area, AreaChart, CartesianGrid, Line, LineChart, XAxis } from "recharts";
import { generateErrorRateData, generateLogData, generateResponseTimeData, generateSearchMetrics } from "../data/mockData";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowRightIcon, SearchIcon } from "lucide-react";
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { SlashIcon } from "lucide-react";
import { Link, useParams } from "react-router-dom";

export default function DashboardGlobalPayments() {
    const [isAutoRefresh] = useState(true)
    const [responseTimeData, setResponseTimeData] = useState(generateResponseTimeData())
    const [errorRateData] = useState(generateErrorRateData())
    const [searchMetrics, setSearchMetrics] = useState(generateSearchMetrics())
    const [logData, setLogData] = useState(generateLogData())
    const [filteredLogs, setFilteredLogs] = useState(logData)
    const [logFilter, setLogFilter] = useState({ level: "all", search: "" })

    const { journey, appname } = useParams();

    useEffect(() => {
        if (!isAutoRefresh) return

        const interval = setInterval(() => {
            setResponseTimeData(generateResponseTimeData())
            setSearchMetrics(generateSearchMetrics())
            const newLogs = generateLogData()
            setLogData(newLogs)
            setFilteredLogs(newLogs)
        }, 5000)

        return () => clearInterval(interval)
    }, [isAutoRefresh])

    useEffect(() => {
        let filtered = logData

        if (logFilter.level !== "all") {
            filtered = filtered.filter((log) => log.level === logFilter.level)
        }

        if (logFilter.search) {
            filtered = filtered.filter(
                (log) =>
                    log.message.toLowerCase().includes(logFilter.search.toLowerCase()) ||
                    log.query.toLowerCase().includes(logFilter.search.toLowerCase()) ||
                    log.userId.toLowerCase().includes(logFilter.search.toLowerCase()),
            )
        }

        setFilteredLogs(filtered)
    }, [logData, logFilter]);

    return (
        <Container className="mt-6 pb-12">
            <NavigateBackButton />
            <Breadcrumb>
                <BreadcrumbList>
                    <BreadcrumbItem>
                        <Link to="/observability-payments">Home</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <Link to="/observability-payments">{appname}</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <Link to={`/observability-payments/${appname}/${journey}`}>{journey} User Journey Execution Experience</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <Link to={`/observability-payments/${appname}/${journey}/timeline`}>Connected Components</Link>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                        <SlashIcon></SlashIcon>
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                        <BreadcrumbPage>Search Service</BreadcrumbPage>
                    </BreadcrumbItem>
                </BreadcrumbList>
            </Breadcrumb>


            <div className="grid grid-cols-3 gap-4 my-4">
                <Card className="">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Response Time</CardTitle>
                        <CardDescription>Average, P95, and P99 response times over the last 30 minutes</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                responseTime: { label: "Avg Response Time", color: "hsl(var(--chart-1))" },
                                p95: { label: "P95", color: "hsl(var(--chart-2))" },
                                p99: { label: "P99", color: "hsl(var(--chart-3))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <LineChart
                                accessibilityLayer
                                margin={{ left: 12, right: 12 }}
                                data={responseTimeData}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                {/* <YAxis /> */}
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <Line
                                    type="natural"
                                    dataKey="responseTime"
                                    stroke="hsl(var(--chart-1))"
                                    strokeWidth={1}
                                />
                                <Line
                                    type="natural"
                                    dataKey="p95"
                                    stroke="hsl(var(--chart-2))"
                                    strokeWidth={1}
                                    strokeDasharray="5 5"
                                />
                                <Line
                                    type="natural"
                                    dataKey="p99"
                                    stroke="hsl(var(--chart-3))"
                                    strokeWidth={1}
                                    strokeDasharray="2 2"
                                />
                            </LineChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Search Performance</CardTitle>
                        <CardDescription>Query throughput and cache performance</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                queriesPerSecond: { label: "Queries/sec", color: "hsl(var(--chart-4))" },
                                cacheHitRate: { label: "Cache Hit Rate %", color: "hsl(var(--chart-5))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <LineChart data={searchMetrics}>
                                <CartesianGrid vertical={false} />
                                <XAxis
                                    tickLine={false}
                                    axisLine={false}
                                    tickMargin={8}
                                    dataKey="time" />
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <Line
                                    type="monotone"
                                    dataKey="queriesPerSecond"
                                    stroke="hsl(var(--chart-1))"
                                    strokeWidth={1}
                                />
                                <Line
                                    type="monotone"
                                    dataKey="cacheHitRate"
                                    stroke="hsl(var(--chart-2))"
                                    strokeWidth={1}
                                />
                            </LineChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
                <Card className="">
                    <CardHeader>
                        <CardTitle className="text-sm -mb-1">Error Rate</CardTitle>
                        <CardDescription>Hourly error rates and request volumes</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={{
                                errorRate: { label: "Error Rate %", color: "hsl(var(--destructive))" },
                                totalRequests: { label: "Total Requests", color: "hsl(var(--chart-1))" },
                            }}
                            className="min-h-[200px]"
                        >
                            <AreaChart data={errorRateData}>
                                <CartesianGrid vertical={false} />
                                <XAxis dataKey="hour" />
                                {/* <YAxis /> */}
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <Area
                                    type="monotone"
                                    dataKey="errorRate"
                                    stroke="hsl(var(--chart-5))"
                                    fill="hsl(var(--chart-5))"
                                    fillOpacity={0.3}
                                />
                            </AreaChart>
                        </ChartContainer>
                    </CardContent>
                </Card>
            </div>
            <Card className="col-span-2">
                <CardHeader>
                    <CardTitle className="text-sm -mb-1">Search Logs</CardTitle>
                    <CardDescription>Showing {filteredLogs.length} of {logData.length} log entries</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-4">
                    <div className="flex gap-4 mb-4">
                        <Select
                            value={logFilter.level}
                            onValueChange={(value) => setLogFilter((prev) => ({ ...prev, level: value }))}
                        >
                            <SelectTrigger className="w-[180px] h-9">
                                <SelectValue placeholder="Filter by level" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Levels</SelectItem>
                                <SelectItem value="ERROR">Error</SelectItem>
                                <SelectItem value="WARN">Warning</SelectItem>
                                <SelectItem value="INFO">Info</SelectItem>
                                <SelectItem value="DEBUG">Debug</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="*:not-first:mt-2 w-full">
                            <div className="relative">
                                <Input

                                    className="peer ps-9 pe-9 h-9"
                                    placeholder="Search log..."
                                    type="search"
                                    value={logFilter.search}
                                    onChange={(e) => setLogFilter((prev) => ({ ...prev, search: e.target.value }))}
                                />
                                <div className="text-muted-foreground/80 pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50">
                                    <SearchIcon size={16} />
                                </div>
                                <button
                                    className="text-muted-foreground/80 hover:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 absolute inset-y-0 end-0 flex h-full w-9 items-center justify-center rounded-e-md transition-[color,box-shadow] outline-none focus:z-10 focus-visible:ring-[3px] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50"
                                    aria-label="Submit search"
                                    type="submit"
                                >
                                    <ArrowRightIcon size={16} aria-hidden="true" />
                                </button>
                            </div>
                        </div>


                        {/* <Input
                            placeholder="Search logs..."
                            value={logFilter.search}
                            onChange={(e) => setLogFilter((prev) => ({ ...prev, search: e.target.value }))}
                            className="max-w-sm"
                        /> */}
                    </div>
                    <div className="overflow-x-auto h-[500px]">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b">
                                    <th className="text-left p-2">Timestamp</th>
                                    <th className="text-left p-2">Level</th>
                                    <th className="text-left p-2">User ID</th>
                                    <th className="text-left p-2">Query</th>
                                    <th className="text-left p-2">Response Time</th>
                                    <th className="text-left p-2">Status</th>
                                    <th className="text-left p-2">Message</th>
                                    <th className="text-left p-2">Trace ID</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredLogs.slice(0, 50).map((log) => (
                                    <tr key={log.id} className="border-b hover:bg-muted/50">
                                        <td className="p-2 font-mono text-xs">{new Date(log.timestamp).toLocaleString()}</td>
                                        <td className="p-2">
                                            <Badge
                                                variant={
                                                    log.level === "ERROR" ? "destructive" : log.level === "WARN" ? "secondary" : "outline"
                                                }
                                                className="text-xs"
                                            >
                                                {log.level}
                                            </Badge>
                                        </td>
                                        <td className="p-2 font-mono text-xs">{log.userId}</td>
                                        <td className="p-2 max-w-[200px] truncate">{log.query}</td>
                                        <td className="p-2">
                                            <span className={log.responseTime > 2000 ? "text-destructive font-semibold" : ""}>
                                                {log.responseTime}ms
                                            </span>
                                        </td>
                                        <td className="p-2">
                                            <Badge variant={log.statusCode === 200 ? "outline" : "destructive"} className="text-xs">
                                                {log.statusCode}
                                            </Badge>
                                        </td>
                                        <td className="p-2 max-w-[300px] truncate">{log.message}</td>
                                        <td className="p-2 font-mono text-xs">{log.traceId}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>


        </Container>
    )
}