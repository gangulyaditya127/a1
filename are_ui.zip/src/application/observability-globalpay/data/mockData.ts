export const generateResponseTimeData = () => {
  const now = Date.now()
  return Array.from({ length: 30 }, (_, i) => ({
    time: new Date(now - (29 - i) * 60000).toLocaleTimeString("en-US", { hour12: false }),
    responseTime: Math.random() * 2000 + 500 + (i > 20 ? Math.random() * 3000 : 0), // Spike in recent data
    p95: Math.random() * 3000 + 1000 + (i > 20 ? Math.random() * 4000 : 0),
    p99: Math.random() * 5000 + 2000 + (i > 20 ? Math.random() * 6000 : 0),
  }))
}

export const generateErrorRateData = () => {
  return Array.from({ length: 24 }, (_, i) => ({
    hour: `${String(i).padStart(2, "0")}:00`,
    errorRate: Math.random() * 15 + (i > 18 ? Math.random() * 25 : 0), // Higher errors in recent hours
    totalRequests: Math.floor(Math.random() * 10000) + 5000,
  }))
}

export const generateSearchMetrics = () => {
  const now = Date.now()
  return Array.from({ length: 12 }, (_, i) => ({
    time: new Date(now - (11 - i) * 300000).toLocaleTimeString("en-US", { hour12: false }),
    queriesPerSecond: Math.floor(Math.random() * 500) + 100,
    avgResultCount: Math.floor(Math.random() * 50) + 10,
    cacheHitRate: Math.random() * 40 + 60,
  }))
}

export const generateLogData = () => {
  const logLevels = ["ERROR", "WARN", "INFO", "DEBUG"]
  const errorMessages = [
    "Search index connection timeout",
    "Query parsing failed for complex search",
    "Elasticsearch cluster unreachable",
    "Rate limit exceeded for user",
    "Search result ranking service down",
    "Database connection pool exhausted",
    "Invalid search parameters provided",
    "Search cache invalidation failed",
  ]

  return Array.from({ length: 100 }, (_, i) => ({
    id: i + 1,
    timestamp: new Date(Date.now() - Math.random() * 3600000).toISOString(),
    level: logLevels[Math.floor(Math.random() * logLevels.length)],
    userId: `user_${Math.floor(Math.random() * 10000)}`,
    query: `search query ${i + 1}`,
    responseTime: Math.floor(Math.random() * 5000) + 100,
    statusCode: Math.random() > 0.8 ? (Math.random() > 0.5 ? 500 : 404) : 200,
    message:
      Math.random() > 0.7
        ? errorMessages[Math.floor(Math.random() * errorMessages.length)]
        : "Request processed successfully",
    traceId: `trace_${Math.random().toString(36).substr(2, 9)}`,
  }))
}