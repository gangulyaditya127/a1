import { GraduationCap, NetworkIcon, NfcIcon, School } from "lucide-react";

export const MOCK_APP_DATA = [
    {
        name: "School services",
        description: "Monitors student records",
        status: "Critical",
        icon: <School />,
        statusClassName: "bg-red-700/40 border border-red-500",
        userJourney: [
            {
                name: "Registration Flow",
                activeUsers: 2153,
                happy: 91,
                unhappy: 8,
                frustated: 1,
                dropped: 74,
                availablity: 99.23,
                statusClass: "bg-green-500"
            },
            {
                name: "Nutrition Planning",
                activeUsers: 1234,
                happy: 54,
                unhappy: 13,
                frustated: 33,
                dropped: 77,
                availablity: 59.23,
                statusClass: "bg-red-500"
            },
            {
                name: "Payment",
                activeUsers: 1028,
                happy: 80,
                unhappy: 7,
                frustated: 13,
                dropped: 13,
                availablity: 92.23,
                statusClass: "bg-green-500"
            },
        ]
    },
    {
        name: "Active Network",
        description: "Activity and participation management platform",
        status: "Critical",
        icon: <NetworkIcon />,
        statusClassName: "bg-red-700/40 border border-red-500",
        userJourney: [
            {
                name: "Registration Flow",
                activeUsers: 1278,
                happy: 89,
                unhappy: 10,
                frustated: 1,
                dropped: 74,
                availablity: 99.23,
                statusClass: "bg-green-500"
            },
            {
                name: "Payment Processing",
                activeUsers: 2278,
                happy: 57,
                unhappy: 10,
                frustated: 33,
                dropped: 87,
                availablity: 59.23,
                statusClass: "bg-red-500"
            },
            {
                name: "Event Booking",
                activeUsers: 3478,
                happy: 11,
                unhappy: 68,
                frustated: 21,
                dropped: 73,
                availablity: 49.23,
                statusClass: "bg-amber-500"
            },
        ]
    },
    {
        icon: <NfcIcon />,
        name: "ECSI",
        description: "Enterprise customer service integration",
        status: "Healthy",
        statusClassName: "bg-green-700/40 border border-green-500",
        userJourney: [
            {
                name: "Authentication",
                activeUsers: 3532,
                happy: 89,
                unhappy: 9,
                frustated: 2,
                dropped: 23,
                availablity: 99.23,
                statusClass: "bg-green-500"
            },
            {
                name: "Document Access",
                activeUsers: 2278,
                happy: 89,
                unhappy: 4,
                frustated: 7,
                dropped: 12,
                availablity: 99.53,
                statusClass: "bg-green-500"
            },
            {
                name: "Loan Processing",
                activeUsers: 3278,
                happy: 99,
                unhappy: 0,
                frustated: 1,
                dropped: 14,
                availablity: 99.83,
                statusClass: "bg-green-500"
            },
            {
                name: "Form Submission",
                activeUsers: 3278,
                happy: 99,
                unhappy: 0,
                frustated: 1,
                dropped: 14,
                availablity: 99.83,
                statusClass: "bg-green-500"
            },
        ]
    },
    {
        icon: <GraduationCap />,
        name: "TouchNet",
        description: "Education sector payment solutions for student services",
        status: "Critical",
        statusClassName: "bg-red-700/40 border border-red-500",
        userJourney: [
            {
                name: "Portal Access",
                activeUsers: 5278,
                happy: 17,
                unhappy: 53,
                frustated: 33,
                dropped: 87,
                availablity: 49.23,
                statusClass: "bg-red-500"
            },
            {
                name: "Course Catalog",
                activeUsers: 3278,
                happy: 99,
                unhappy: 0,
                frustated: 1,
                dropped: 14,
                availablity: 99.83,
                statusClass: "bg-red-500"
            },
            {
                name: "Checkout",
                activeUsers: 3532,
                happy: 89,
                unhappy: 9,
                frustated: 2,
                dropped: 23,
                availablity: 99.23,
                statusClass: "bg-red-500"
            },
            {
                name: "Confirmation",
                activeUsers: 3532,
                happy: 89,
                unhappy: 9,
                frustated: 2,
                dropped: 23,
                availablity: 99.23,
                statusClass: "bg-red-500"
            },
        ]
    },
]