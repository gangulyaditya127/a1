

export const PERFORMANCE = [
  {
    step: "Search Events",
    actions: [
      { name: "Load Homepage", avgResp: "150", p95: "250", errorRate: "1", availability: "99.50" },
      { name: "Search Event", avgResp: "420", p95: "650", errorRate: "3", availability: "98.90", warning: true },
      { name: "Filter Results", avgResp: "280", p95: "500", errorRate: "2", availability: "98.70" }
    ],
    metrics: { happy: 74, unhappy: 4, frustrated: 2 }
  },
  {
    step: "View Event Details",
    actions: [
      { name: "Open Event Page", avgResp: "310", p95: "520", errorRate: "2", availability: "98.20" },
      { name: "Load Event Images", avgResp: "620", p95: "980", errorRate: "5", availability: "97.00", warning: true },
      { name: "Fetch Related Events", avgResp: "450", p95: "720", errorRate: "3", availability: "97.80" }
    ],
    metrics: { happy: 90, unhappy: 6, frustrated: 4 }
  },
  {
    step: "Book Tickets",
    actions: [
      { name: "Select Ticket Type", avgResp: "200", p95: "320", errorRate: "1", availability: "99.10" },
      { name: "Enter Attendee Details", avgResp: "480", p95: "750", errorRate: "3", availability: "98.00" },
      { name: "Apply Discount Code", avgResp: "720", p95: "1020", errorRate: "8", availability: "96.20", warning: true }
    ],
    metrics: { happy: 88, unhappy: 8, frustrated: 4 }
  },
  {
    step: "Payment & Confirmation",
    actions: [
      { name: "Initiate Payment", avgResp: "640", p95: "950", errorRate: "4", availability: "97.50" },
      { name: "Process Payment", avgResp: "920", p95: "1500", errorRate: "10", availability: "95.80", warning: true },
      { name: "Generate Confirmation", avgResp: "310", p95: "500", errorRate: "2", availability: "98.50" }
    ],
    metrics: { happy: 85, unhappy: 10, frustrated: 5 }
  }
];


const PERFORMACE_SCHOOL = [
  {
    "step": "Search Foods",
    "actions": [
      {
        "name": "Load Planning Dashboard",
        "avgResp": "120",
        "p95": "220",
        "errorRate": "0.5",
        "availability": "99.80"
      },
      {
        "name": "Enter Nutrition Query",
        "avgResp": "350",
        "p95": "550",
        "errorRate": "15",
        "availability": "78.50",
        warning:true
      },
      {
        "name": "Apply School Guidelines Filter",
        "avgResp": "250",
        "p95": "450",
        "errorRate": "10",
        "availability": "89.00",
        "warning": true
      }
    ],
    "metrics": {
      "happy": 82,
      "unhappy": 12,
      "frustrated": 6
    }
  },
  {
    "step": "View Nutrition Details",
    "actions": [
      {
        "name": "Open Food Profile",
        "avgResp": "280",
        "p95": "480",
        "errorRate": "2",
        "availability": "98.00"
      },
      {
        "name": "Load Calorie Breakdown",
        "avgResp": "500",
        "p95": "750",
        "errorRate": "3",
        "availability": "97.50"
      },
      {
        "name": "Fetch Allergen Information",
        "avgResp": "400",
        "p95": "650",
        "errorRate": "2.5",
        "availability": "97.80",
        "warning": true
      }
    ],
    "metrics": {
      "happy": 88,
      "unhappy": 8,
      "frustrated": 4
    }
  },
  {
    "step": "Build Meal Plan",
    "actions": [
      {
        "name": "Add Food to Menu",
        "avgResp": "180",
        "p95": "300",
        "errorRate": "1",
        "availability": "99.20"
      },
      {
        "name": "Calculate Daily Nutrients",
        "avgResp": "450",
        "p95": "700",
        "errorRate": "14",
        "availability": "86.50",
        warning:true
      },
      {
        "name": "Adjust Portions for Students",
        "avgResp": "320",
        "p95": "520",
        "errorRate": "2",
        "availability": "98.00"
      }
    ],
    "metrics": {
      "happy": 78,
      "unhappy": 15,
      "frustrated": 7
    }
  },
  {
    "step": "Review and Approve Plan",
    "actions": [
      {
        "name": "Generate Compliance Report",
        "avgResp": "350",
        "p95": "550",
        "errorRate": "1.5",
        "availability": "98.50"
      },
      {
        "name": "Simulate Weekly Balance",
        "avgResp": "600",
        "p95": "850",
        "errorRate": "5",
        "availability": "95.00",
        "warning": true
      },
      {
        "name": "Export for School Services",
        "avgResp": "220",
        "p95": "400",
        "errorRate": "0.5",
        "availability": "99.50"
      }
    ],
    "metrics": {
      "happy": 92,
      "unhappy": 5,
      "frustrated": 3
    }
  }
]
 


export const getUserJourneySteps = (appName?: string) => {
  if (appName == "School services") return PERFORMACE_SCHOOL;

  return PERFORMANCE;
}