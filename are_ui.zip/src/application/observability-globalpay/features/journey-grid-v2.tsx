import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/tailwind.utils";
import { Link } from "react-router-dom";

export default function JourneyGridV2({
    rowData,
    appName
}: {
    rowData?: any,
    appName: string
}) {
    return (
        <Table>
            <TableHeader>
                <TableRow className="border-0 border-b-0 hover:bg-black">
                    <TableHead >
                        Journeys
                    </TableHead >
                    <TableHead className="border-x border-neutral-900 p-0 text-center dark:border-neutral-700 flex justify-center items-center">
                        <p>Active Users</p>
                    </TableHead>
                    <TableHead colSpan={3} className="text-center">
                        Happy + Unhappy + Frustated
                    </TableHead>
                    {/* <TableHead className=" border-x border-neutral-900 p-0 text-center dark:border-neutral-700">
                        Dropped Off Users
                    </TableHead> */}
                    <TableHead className="text-center border-l">
                        Availablity
                    </TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {rowData.map((row: any, idx: number) => (
                    <TableRow key={idx} className="border-0 border-b-0">
                        <TableCell className="cursor-pointer">
                            <Link className="h-full w-full block" to={`/observability-payments/${encodeURIComponent(appName)}/${encodeURIComponent(row.name)}`}>
                                {row.name}
                            </Link>
                        </TableCell>
                        <TableCell className="text-center text-cyan-400 border-x">{row.activeUsers}</TableCell>
                        <TableCell className="text-center text-green-400 font-medium">{row.happy}%</TableCell>
                        <TableCell className="text-center text-yellow-400 border-x font-medium">{row.unhappy}%</TableCell>
                        <TableCell className="text-center text-red-500 font-medium">{row.frustated}%</TableCell>
                        {/* <TableCell className="text-center text-orange-400 border-x">{row.dropped}</TableCell> */}
                        <TableCell className={cn("text-center font-medium border-l", row.availablity < 70 ? 'text-red-500' : 'text-green-400')}>{row.availablity}%</TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    )
}