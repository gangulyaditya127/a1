import { cn } from "@/lib/tailwind.utils";
import EChartsReact, { EChartsReactProps } from "echarts-for-react";
import { useEffect, useState } from "react";
import colors from "tailwindcss/colors";

type Props = {
    className?: string,
    parameter: string,
    chartClassName?: string,
    series?: any[],
    seriesCount?: number,
    labels?: string[]
}

export default function JourneyChart({
    className,
    parameter,
    chartClassName,
    series,
    labels
}: Props) {
    const [chartOptions, setChartOptions] = useState<EChartsReactProps | any>(
        {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                },
                backgroundColor: colors.neutral[950],
                textStyle: {
                    color: colors.neutral[400],
                    fontFamily: 'inherit',
                    fontSize: 12,
                },
                borderColor: colors.neutral[800],
            },
            color: [
                colors.blue[600],
                colors.green[600],
                colors.amber[600],
                colors.purple[600],
                colors.pink[500],
                colors.lime[500]
            ],
            legend: {
                show: true,
                type: 'scroll',
                textStyle: {
                    color: colors.neutral[400]
                },
                bottom: 0,

                formatter: (name: string) => {
                    if (name === "open") {
                        return "open (age>3)"
                    }
                    return name
                }
            },
            xAxis: [
                {
                    type: 'category',
                    axisTick: { show: false },
                    axisLine: {
                        show: false,
                    },
                }
            ],
            grid: {
                left: '2%',
                right: '2%',
                bottom: '20%',
                top: '10%'
            },
            toolbox: {
                show: false,
                orient: 'vertical',
                left: 'right',
                top: 'center',
                feature: {
                    saveAsImage: { show: true }
                }
            },
            yAxis: {
                axisLabel: {
                    show: false
                },
                axisLine: {
                    show: false,
                },
                splitLine: {
                    show: false,
                },
            },
            media: [{
                query: {
                    minHeight: 200
                }
            }],
            series: [
            ]
        }
    )
    useEffect(() => {
        if (series) {
            setChartOptions((prev: EChartsReactProps | any) => (
                {
                    ...prev,
                    // dataset: {
                    //     dimensions: ['day', 'resolved', 'open', 'logged'],
                    //     source: last10DayData
                    // },
                    xAxis: {
                        type: 'category',
                        axisTick: { show: false },
                        axisLine: {
                            show: false,
                        },
                        data: labels
                    },
                    series: series.map(el => (
                        {
                            type: 'line',
                            label: {
                                show: true,
                                position: 'top',
                                textStyle: {
                                    color: colors.neutral[400],
                                    fontFamily: 'inherit',
                                    fontSize: 12,
                                },
                            },
                            smooth: true,
                            emphasis: {
                                focus: 'series'
                            },
                            // markArea: {
                            //     itemStyle: {
                            //         color: 'rgba(255, 173, 177, 0.4)'
                            //     },
                            //     data: [
                            //         {
                            //             name: 'Forecase',
                            //             xAxis:  ''
                            //         },
                            //         {
                            //             xAxis:  ''
                            //         }
                            //     ],
                            // },
                            ...el
                        }
                    )),
                }
            ))
            console.log({ label: labels?.at(-1) })
        }
    }, [series])
    return (
        <div className={
            cn("group relative flex flex-col overflow-hidden rounded-xl border shadow transition-all duration-200 ease-in-out hover:z-30", className)
        }>
            <div className="items-center gap-2 relative z-20 flex border-b bg-card px-3 py-2.5 text-card-foreground">
                <h3 className="text-xs tracking-wider text-muted-foreground uppercase">
                    {parameter}
                </h3>
            </div>
            <div className={
                cn("relative z-10 [&>div]:rounded-none [&>div]:border-none [&>div]:shadow-none h-80", chartClassName)
            }>
                <EChartsReact option={chartOptions} className="mt-auto" notMerge={true} />
            </div>
        </div>
    )
}
