import { Area, AreaChart, CartesianGrid, XAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartConfig } from "@/components/ui/chart"

interface ChartProps {
    title: string;
    description: string;
    data: Array<{ date: string; value: number }>;
    color: string;
    valueFormatter?: (value: number) => string;
    className?: string
}

export function Chart({ title, description, data, color, className }: ChartProps) {
    const chartConfig = {
        value: {
            label: "Value",
            color: color,
        },
    } satisfies ChartConfig

    return (
        <Card className={className}>
            <CardHeader>
                <CardTitle className="text-sm -mb-1">{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <ChartContainer config={chartConfig}>
                    <AreaChart
                        accessibilityLayer
                        data={data}
                        margin={{
                            left: 12,
                            right: 12,
                        }}
                    >
                        <CartesianGrid vertical={false} />
                        <XAxis
                            dataKey="date"
                            tickLine={false}
                            axisLine={false}
                            tickMargin={8}
                            tickFormatter={(value) => {
                                const date = new Date(value);
                                return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
                            }}
                        />
                        <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
                        <defs>
                            <linearGradient id={`fill${title.replace(/\s+/g, '')}`} x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor={`var(--color-value)`} stopOpacity={0.8} />
                                <stop offset="95%" stopColor={`var(--color-value)`} stopOpacity={0.1} />
                            </linearGradient>
                        </defs>
                        <Area
                            dataKey="value"
                            type="natural"
                            fill={`url(#fill${title.replace(/\s+/g, '')})`}
                            fillOpacity={0.4}
                            stroke={`var(--color-value)`}
                        />
                    </AreaChart>
                </ChartContainer>
            </CardContent>
        </Card>
    )
}