export default function ObservabilityAppDetails() {
    return (<div className="grid grid-cols-3 gap-4">

    </div>)
}