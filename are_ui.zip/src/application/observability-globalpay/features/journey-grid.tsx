

import DataGrid from '@/components/ui/data-grid';
import { ColDef, ColGroupDef } from 'ag-grid-charts-enterprise'
import { LucideExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
export default function JourneyGrid({
    rowData,
    appName
}: {
    rowData: any,
    appName: string
}) {
    const columnDefs: (ColDef<any, any> | ColGroupDef<any>)[] = [
        {
            headerName: 'Journey',
            field: 'name',
            pinned: 'left',
        },
        {
            field: 'activeUsers',
            cellClass: ['bg-green-500/10', 'text-green-500', 'font-medium']
        },
        {
            field: 'happy',
            valueFormatter: p => p.value + "%",
            cellClass: ['bg-green-500/10', 'text-green-500', 'font-medium']
        },
        {
            field: 'unhappy',
            valueFormatter: p => p.value + "%",
            cellClass: ['bg-amber-500/10', 'text-amber-500', 'font-medium']

        },
        {
            field: 'frustated',
            valueFormatter: p => p.value + "%",
            cellClass: ['bg-red-500/10', 'text-red-500', 'font-medium']
        },
        {
            field: 'availablity',
            valueFormatter: p => p.value + "%",
            cellClass: params => {
                return params.value > 90 ? ['bg-green-500/10', 'text-green-500', 'font-medium'] : ['bg-amber-500/10', 'text-amber-500', 'font-medium'];
            },
        },
        {
            field: 'name',
            headerName: '',
            width: 50,
            cellRenderer: (params: any) => <LinkRenderer {...params} appName={appName} />,
            pinned: 'right',
        }
    ]
    return (<
        DataGrid
        rowData={rowData}
        columnDefs={columnDefs}
        domLayout='autoHeight' />
    )
}

const LinkRenderer = (props: any) => {
    console.log({ props })
    return (
        <Link to={`/observability/${props.data.name}`} className='h-full w-full grid place-items-center'>
            <LucideExternalLink className='h-4 w-4' />
        </Link>
    )
}