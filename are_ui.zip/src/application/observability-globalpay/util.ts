export const generateLabels = (): any[] => {
    let currentTimeEpoch = Date.now();
    let oneHourInEpoch = 36_00_000;
    return [
        getTime(currentTimeEpoch - 3 * oneHourInEpoch),
        getTime(currentTimeEpoch - 2 * oneHourInEpoch),
        getTime(currentTimeEpoch - oneHourInEpoch),
        getTime(currentTimeEpoch),
        getTime(currentTimeEpoch + oneHourInEpoch)
    ];
};

export function getTime(epochTime: number) {
    let timeString = new Date(epochTime);
    return timeString.toString().split(" ")[4]
}

export const generateData = (min: any, max: any) => {
    let dp: any[] = generateLabels();
    let data: any[] = [];
    dp.forEach((_) => {
        data.push(Math.floor((Math.random() * (max - min + 1)) + min));
    })
    return data
};