import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: false,
  sideBarNavList: [],
  bottomNavList: [],
};

export default SIDEBAR_DATA;
