import { useEffect } from "react";

import { useAppDispatch } from "@/lib/redux/hooks";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import SIDEBAR_DATA from "../data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { AuroraHero } from "../features/AuroraHero";
import  AgentsTable  from "../features/AgentsTable";
import  AgentCategory  from "../features/AgentCategory";
import Footer from "@/components/layout/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";


// import TestimonialBanner from "../features/TestimonialBanner";

export default function AgenticARE() {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(updateSideBarNavigation(SIDEBAR_DATA));
    dispatch(
      updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
    );
  }, []);


  return (
    <>
      {/* <TestimonialBanner /> */}
      <AuroraHero />
      <Tabs defaultValue="Agent Categories" className="space-y-4 mt-6">
        <TabsList className="mx-auto grid max-w-96 grid-cols-2">
          <TabsTrigger
            value="Agent Categories"
            className="font-normal uppercase tracking-wider data-[state=active]:text-white dark:font-normal"
          >
            Agent Workbook
          </TabsTrigger>
          <TabsTrigger
            value="Agent Catalog"
            className="font-normal uppercase tracking-wider data-[state=active]:text-white"
          >
            Agent Catalog
          </TabsTrigger>
        </TabsList>
        <TabsContent value="Agent Categories">
          < AgentCategory />
        </TabsContent>
        <TabsContent value="Agent Catalog">
          < AgentsTable />
        </TabsContent>
      </Tabs>
      <Footer />
    </>
  );
}
