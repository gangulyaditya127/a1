import { useEffect } from "react";
import { useAppDispatch } from "@/lib/redux/hooks";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import SIDEBAR_DATA from "../data/sidebar.data";
import { Icon } from "@/components/ui/icon";
import FeatureBento from "../features/FetureBento";
import { useNavigate } from "react-router-dom";
import Footer from "@/components/layout/Footer";

export default function AgenticAREV2() {
    const dispatch = useAppDispatch();
    const border = `1px solid #2469BC`;
    const boxShadow = `0px 4px 24px #2469BC`;
    const navigate = useNavigate();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);
    return (
        <div className="">
            <section className="dark h-[98vh] relative [--gradient:radial-gradient(50%_50%_at_50%_50%,oklch(0%_0_0)_90%,var(--gradient-color-1)_95%,var(--gradient-color-2)_97%,var(--gradient-color-3)_100%)] [--gradient-color-1:oklch(15%_0.15_280)] [--gradient-color-2:oklch(25%_0.12_250)] [--gradient-color-3:oklch(35%_0.10_230)]">
                <div className=" overflow-hidden">
                    <span className="pointer-events-none absolute inset-0 flex items-center justify-center">
                        <span className="absolute bottom-0 block aspect-square w-[600%] rounded-full [background:--gradient] lg:w-[400%] [box-shadow:0_0_6vw_0_rgba(255,255,255,0.6)_inset]"></span>
                    </span>
                </div>
                <div className="h-full grid place-items-center relative z-10">
                    <div className="flex flex-col items-center gap-8">
                        <div className="text-center space-y-4 flex flex-col items-center ">
                            <p className="rounded-full text-white bg-secondary/40 border px-4 py-[2px]">100+ Agents in action</p>
                            <h1 className="font-medium text-white font-tcs-title text-3xl md:text-7xl max-w-3xl">Shaping future of AMS with Agentic ARE</h1>
                            <p className="text-2xl text-white max-w-xl opacity-80">Orchestrating a revolution in production management - smarter, faster, always on</p>

                        </div>
                        <button
                            style={{
                                border,
                                boxShadow
                            }}
                            className="pointer bg-background-950/10 text-background-50 hover:bg-background-950/50 group relative my-18 flex w-fit items-center gap-1.5 rounded-full px-4 py-2 text-sm text-neutral-100 transition-colors"
                            onClick={() => {
                                navigate('/agentic-are-assets')
                            }}
                        >
                            {"Explore"}
                            <Icon
                                name="chevron-right"
                                className="size-5 transition-transform group-hover:translate-x-1 group-active:translate-x-1"
                            />
                        </button>
                    </div>
                </div>
            </section>
            <section className="text-center py-24 flex flex-col items-center">
                <p className="text-2xl text-balance text-muted-foreground max-w-3xl"><span className="text-foreground">AI Agents are not just automating AMS </span> - they are enabling smarter, faster, and more cost-effective IT operations, turning application reliability into a strategic driver of business growth and innovation</p>
            </section>
            <FeatureBento />
            <Footer />
        </div>
    )
}
