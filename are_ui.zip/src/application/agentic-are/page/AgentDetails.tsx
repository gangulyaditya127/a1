import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbList,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Worker } from '@react-pdf-viewer/core';
import Container from "@/components/ui/container";
import { Meteors } from "@/components/ui/meteors";
import { Link } from "react-router-dom";
//import QUICK_ASSESMENT_DOC from "@/assets/docs/ARE Quick Assessment.pdf?url";
import { Separator } from "@/components/ui/seperator";
import { Icon } from "@/components/ui/icon";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import PDFViewer from "@/components/ui/pdf-viewer";
import BlogHeader from "@/application/next-gen-ams/features/BlogHeader";
import { AgentsData } from "../data/areagent.data";
import { useParams } from "react-router-dom";
import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import SIDEBAR_DATA from "../data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
const AgentDetails = () => {
    const { tag } = useParams()
    const AgentDetailsData: any = AgentsData.find(agent => agent.slug === tag)
    const plansLists = AgentDetailsData?.OperationalEfficiency.split(".");
    const OperationalEfficiency = AgentDetailsData?.OperationalEfficiency.split(".");
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);
    return (
        <section className="py-16 pb-40">
            <Container className="relative mx-auto mt-6 max-w-4xl">
                <NavigateBackButton fallbackUrl="/" />
                <Breadcrumb>
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <Link to="/">Home</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/agentic-are">Agentic ARE</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <Link to="/agentic-are-assets">TCS Agentic ARE Assets</Link>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator>
                            <Icon name="slash"></Icon>
                        </BreadcrumbSeparator>
                        <BreadcrumbItem>
                            <BreadcrumbPage>{AgentDetailsData?.AgentName}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <BlogHeader
                    title={AgentDetailsData?.AgentName}
                    className=" mt-6 capitalize"
                />
                <Separator className="my-6" />
                <div className="leading-7 text-muted-foreground">
                    <div className="mb-4">
                        <h3 className="text-foreground font-medium mb-2">Description:</h3>
                        <p className="text-xm">{AgentDetailsData?.Description}</p>
                    </div>
                    <div className="mb-4">
                        <h3 className="text-foreground font-medium mb-2">Objective:</h3>
                        <p className="text-xm font-normal">{AgentDetailsData?.Objective}</p>
                    </div>
                    <div className="mb-4">
                        <h3 className="text-foreground font-medium mb-2">Operational Efficiency:</h3>
                        <ul className="pl-5">
                            {OperationalEfficiency.map((lists: any) => (
                                <li>{lists}</li>
                            ))}
                        </ul>
                    </div>
                    <div className="mb-4">
                        <h3 className="text-foreground font-medium mb-2">Plan:</h3>
                        <ul className="pl-5">
                            {plansLists.map((items: any) => (
                                <li>{items}</li>
                            ))}
                        </ul>
                    </div>
                    {
                        AgentDetailsData.file &&
                        <div className="mt-4">
                            <ul className="flex flex-col">
                                <Worker workerUrl='js/pdf.worker.min.js'>
                                    <PDFViewer
                                        fileUrl={`assets/areagentdoc/${AgentDetailsData?.file}`}
                                    />
                                </Worker>
                            </ul>
                        </div>
                    }
                </div>
            </Container>
            <Meteors number={5} />
        </section>
    );
};
export default AgentDetails;