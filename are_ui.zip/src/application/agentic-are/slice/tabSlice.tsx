import { createSlice } from '@reduxjs/toolkit';

interface TabSate {
    activeTab:string
}

const initialState: TabSate = {
    activeTab: "Capacity Management"
}

const tabSlice = createSlice({
    name: "tabs",
    initialState,
    reducers: {
        setActiveTab: (state, action: { payload: string}) => {
            state.activeTab = action.payload;
        }
    }
})

export const { setActiveTab } = tabSlice.actions;

export default tabSlice.reducer