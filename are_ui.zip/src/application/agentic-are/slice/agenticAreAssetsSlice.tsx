import { createSlice } from "@reduxjs/toolkit";


const initialState = {
    selectedTab: "all",
    search: "",
    selectedTag: "all"
}

const agenticAREAssetsSlice = createSlice({
    name: 'next-gen-agentic-are-assets-slice',
    initialState,
    reducers: {
        updateSelectedTab: (state, action) => {
            state.selectedTab = action.payload.selectedTab;
            state.search = "";
            state.selectedTag = "all";
        },
        updateSearch: (state, action) => {
            state.search = action.payload.search;
        },
        updateSelectedTag: (state, action) => {
            state.selectedTag = action.payload.selectedTag
        }

    }
});

export const {
    updateSearch,
    updateSelectedTag,
    updateSelectedTab
} = agenticAREAssetsSlice.actions;
export default agenticAREAssetsSlice.reducer;