export const TESTIMONIAL: {
    accountName: string,
    timestamp: string,
    bg: string,
    from: {
        name: string,
        email: string,
        designation: string,
    },
    content: string[],
    headline?: string,
}[] = [
        {
            accountName: "Culina",
            bg: "DEH - Cyber Security",
            from: {
                name: "SABINA MARY GERARD",
                email: "sabina.gerard@tcs.com",
                designation: "Delivery Head, BFSI Central Europe Insurance"
            },
            headline: "AI Powered Intelligent Knowledge Onboarder reduces 80% of effort to generate SOPs in Culina account.",
            content: [
                "kOnboard, an AI powered solution, capture information from across diverse knowledge sources that include document repositories, historical incident ticket logs and capture information from screens etc. This has been used to identify unique incident scenarios and the solution automation the development of SOPs for each scenario. kOnboard also helped create a consolidated Document of Understanding (DOU). Culina, a leading retail account has saved 80% of manual effort in this process."
            ],
            timestamp: "Jan 14, 2025"
        },
        {
            accountName: "Coop SE",
            timestamp: "Dec 24,2024",
            bg: "CBG-Retail",
            from: {
                name: "Ajay Singh",
                email: "ajaykumar.s@tcs.com",
                designation: "CBG Delivery Partner "
            },
            headline: "Successful renewal of strategic SAP portfolio at a leading Retail Chain in Switzerland account",
            content: [
                "Really appreciate the inputs & guidance that account team has got during the entire AMS renewal process. In collaboration with Coop, we are taking the journey further towards implementation of the identified ARE automation solutions.",
                "Thank you very much Srini & Team"
            ],
        },
        {
            accountName: "Baxter",
            bg: "LSHCERU",
            from: {
                name: "Bindu Gv",
                email: "bindu.gv@tcs.com",
                designation: "LSHCERU BG Delivery Head"
            },
            headline: "Stabilization of a  critical portfolio for a American multinational healthcare co.",
            content: [
                "As TCS commenced steady state operations, Customer CIO reached out to TCS executive leadership to perform a holistic review of current state and plan for improvements. This led to an opportunity for the account team to explore the ARE platform; this exploration provided valuable knowledge and possibilities for integration. The account team benefited significantly from the insights shared by the ARE team for ticket analysis and operations assessment. Essential insights regarding volumetric trends, MTTR / MTTF trends, ticket patterns, batch operations, and access management helped formulate an improvement plan.The implementation of the improvement plan was monitored closely to address risks related to access etc., in collaboration with customers.",
                "The results have been very significant. It was presented to customers in QBR."
            ],
            timestamp: "Dec 27, 2024",
        },
        {
            accountName: "Manufacturing Europe",
            bg: "MFG",
            from: {
                name: "Abhay Desai",
                email: "dheeraj.tak@tcs.com",
                designation: "Delivery Head, CMI"
            },
            headline: "Intelligent Insights from ITSM Analytics drives continuous improvement in European Manufacturing companies.",
            content: [
                "TCS ITSM Analytics helped analyze the operational health of systems across several strategic accounts in Manufacturing Europe unit. The landscape comprises of complex ERP systems nd the ticket patterns were unique. The insights derived from the analytics helped identify 38 ideas over a period of 3-4 months and this has helped improve our productivity. We have been able to reduce 30 associates and improve our quality of service. We observe a lot of potential and shall explore the range of automation solutions as we go ahead!"
            ],
            timestamp: "Jan 10, 2025"
        },
        {
            accountName: "Sony Pictures",
            bg: "Tech",
            from: {
                name: "Dheeraj Tak",
                email: "dheeraj.tak@tcs.com",
                designation: "Delivery Head, CMI"
            },
            headline: "Automating Access Requests for a multinational Mass Media and Entertainment co.",
            content: [
                "ARE enabled us with clear statistics on the ticket category which helped identify areas of automation and ticket elimination.Of the 980 tickets processed every month, ~20% of them were due to access requests. Further, this was analyzed as:",
                "- Mirror Access  Requests for Business Users (4%)",
                "- E-Form Access Process (8%) ",
                "- Requests for Authorized users to post, park, or reverse financial documents (5%)",
                "- Display & Other Critical Access (4%)",
                "On reviewing the analysis done by team, Customer decided to prioritize automation of “e-Form Access Request Process” as an immediate priority while other areas are still in discussion. This solution involved change in process to eliminate dependency on one team to  manage access requests by automating the request workflow using SAP ABAP framework with built in internal validations. This Solution was implemented by application team has reduced ticket volumes by around 10%. While these are preliminary results, more contextual automation solutions are planned for deployment."
            ],
            timestamp: "Jan 2, 2025"
        },
        {
            accountName: "Allianz",
            bg: "BFSI",
            from: {
                name: "ANUP KRISHNAN",
                email: "dheeraj.tak@tcs.com",
                designation: "Delivery Head, BFSI Central Europe Insurance"
            },
            headline: "ARE assists TCS in a strategic application maintenance services  consolidation for a European Insurance & Asset Management co.",
            content: [
                "TCS Allianz team leveraged the comprehensive ARE assessment framework and handbook to holistically assess the stability of systems, resilience of platforms and maturity of automation in the AMS lifecycle. The proposed solution articulated the current state maturity, the opportunity for improvement and the benefits delivered (improvements to effort, MTTR and costs). Given the tough competition in the RFP process, the ARE based solution articulation helped TCS win 6 of the 9 towers in the application maintenance services consolidation."
            ],
            timestamp: "Jan 14, 2025"
        },

    ]