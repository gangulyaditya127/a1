import { useEffect } from "react";
import {
  useMotionValue,
  motion,
  animate,
  // MotionValue,
} from "framer-motion";
import Container from "@/components/ui/container";
import { useTranslation } from "react-i18next";
import { VideoPlayer } from "@/components/ui/video-player/video-player";
//import Arrow from "@/assets/appthumbnail/arrow-img.png";
import PRODUCT_DEMO from "@/assets/Video/Agentic_incidednt.mp4";
import DEMO_VIDEO_THUMBNAIL from "@/assets/Video/thumbnail/agentic-incident.png";
// const SpaceStars = lazy(() => import("./SpaceStars")); Suspense lazy
const COLORS_TOP = ["#2469BC", "#93D180", "#8CBDFA"];

// const COLORS_TOP = ["#9333ea", "#db2777", "#7c3aed"];

export const AuroraHero = () => {
  const color = useMotionValue(COLORS_TOP[0]);
  useEffect(() => {
    animate(color, COLORS_TOP, {
      ease: "easeInOut",
      duration: 10,
      repeat: Infinity,
      repeatType: "mirror",
    });
  }, []);
  //const backgroundImage = useMotionTemplate`radial-gradient(125% 125% at 50% 0%, #000 50%, ${color})`;
  //const border = useMotionTemplate`1px solid ${color}`;
  //const boxShadow = useMotionTemplate`0px 4px 24px ${color}`;
  const { t } = useTranslation('ismartHome');
  //let navigate = useNavigate();

  return (
    <motion.section
      className="bg-[rgb(11_0_9)] relative grid pt-0 grid place-items-center min-h-screen w-full w-screen overflow-hidden"
      id="__ism_hero"
    >
      <Container className="relative z-30 flex flex-col place-items-left py-16"> {/** -mt-14*/}
        <div className="flex flex-col-2 gap-8">
          <div className="mt-12">
            <h1 className="font-bold text-lg text-slate-100 md:text-5xl mt-4 mb-2 font-tcs-title">
              {t('The Future Of Realibility - AI Agent')}
            </h1>
            <h1 className="font-baseline text-lg text-slate-200">
              {t('Orchestrating a revolution in production management - smarter, faster, always on')}
            </h1>
            <h1 className="text-2xl text-amber-500 md:text-4xl mt-4 mb-2 font-tcs-title">
              {t('100+ Agents in action')}
            </h1>
            <div className="flex gap-8 mt-8">
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Generic ARE / Utility Agents</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">33</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Incident Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">12</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Change Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">10</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Request Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">8</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Event Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">7</div>
              </div>
            </div>
            <div className="flex gap-8 mt-12">
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Certificate Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">5</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Observability</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">6</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>SRE</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">8</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Capacity Management</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">6</div>
              </div>
              <div className="relative inline-flex items-center p-4 w-32 text-sm font-medium text-center text-white  rounded-lg  focus:ring-4 focus:outline-none focus:ring-blue-300 border-t-8 border-cyan-400 border-l-8 border-cyan-400 border-b-8 border-cyan-400">
                <p>Cyber Security Ops</p>
                <span className="sr-only">Notifications</span>
                <div className="absolute inline-flex items-center justify-center w-16 h-10 text-lg  text-white bg-amber-500 border-2 border-white rounded-xl -top-6 -start-4 dark:border-gray-900">6</div>
              </div>
            </div>
          </div>
          <div className="mt-32 w-full">
            <p className="mt-12 text-xl mb-2 text-muted-foreground">Incident Mangement Agentic Solution</p>
            <VideoPlayer
              src={PRODUCT_DEMO}
              autoPlay={false}
              loop={true}
              className=""
              thumbnail={DEMO_VIDEO_THUMBNAIL}
              title={"videp"}
              
            />
            {/* <img src={HeroImage} alt="here-image" className="w-6xl ml-4 object-fill" /> */}
          </div>
        </div>
        {/* <div className="flex gap-4 w-full mt-8 justify-between">
          <div className="inline-flex items-center justify-center  h-10 text-lg font-bold text-black bg-sky-200 border-2 border-white rounded-xl p-8 dark:border-gray-900">Autonomous Optimization</div>
          <div className="inline-flex items-center justify-center  h-10 text-lg font-bold text-black bg-sky-200 border-2 border-white rounded-xl p-8 dark:border-gray-900">Adaptive Inteligence</div>
          <div className="inline-flex items-center justify-center  h-10 text-lg font-bold text-black bg-sky-200 border-2 border-white rounded-xl p-8 dark:border-gray-900">Predictive Control</div>
          <div className="inline-flex items-center justify-center  h-10 text-lg font-bold text-black bg-sky-200 border-2 border-white rounded-xl p-8 dark:border-gray-900">Continious Efficiency</div>
        </div> */}
      </Container>

      {/* <div>
            <h2 className="pt-3 pb-3  text-xl">ARE Agent Marketplace</h2>
          </div>
          <div>
            <img className="w-16 p-2" src={Arrow} alt="arrow-image" />
          </div> */}



    </motion.section>
  );
};


