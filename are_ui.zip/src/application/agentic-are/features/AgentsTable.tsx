import React, {
    useMemo,
    useState,
    useRef,
    useCallback
} from "react";

import {
    ColDef,
    ExcelExportParams,
    SizeColumnsToContentStrategy,
    SizeColumnsToFitGridStrategy,
    SizeColumnsToFitProvidedWidthStrategy,
} from "ag-grid-enterprise";
import Container from "@/components/ui/container";
import DataGrid from "@/components/ui/data-grid";
import { AgentsData } from "../data/areagent.data";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { AgGridReact, CustomCellRendererProps } from "ag-grid-react";
import { Link } from "react-router-dom";

export type HelpSubmissions = {
  id: number,
  location: string,
  employee_NAME: string,
  opportunity: string,
  progress_DATE: string,
  comments: string,
  stage: string,
  customer_INTERNAL_TEAM_NAME: string,
  agents: string,
  tcs_ID: number,
  bu_ISU: string,
  customer_APPROVAL: string
}
const AgentsTable: React.FC = () => {
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const gridRef = useRef<AgGridReact<any>>(null);
    const [columnDefs] = useState<ColDef[]>([
        { field: "AgentName", headerName: 'Agent Name', filter: 'agTextColumnFilter', minWidth: 250 ,maxWidth: 300, wrapText: true, cellRenderer: agentDetailsRender },
        { field: "PlaygroundAgentName", headerName: 'Playground Agent Name', filter: 'agTextColumnFilter',minWidth: 250, maxWidth: 250, wrapText: true, hide: true  },
        { field: "Category", headerName: 'Category', filter: 'agTextColumnFilter', maxWidth: 200  },
        { field: "Layer", headerName: 'Layer', filter: 'agTextColumnFilter', minWidth: 100, maxWidth: 150, wrapHeaderText: true },
        { field: "Objective", headerName: 'Objective', filter: 'agTextColumnFilter', wrapText: true, maxWidth:630 },
        { field: "OperationalEfficiency", headerName: 'Operational Efficiency', filter: 'agTextColumnFilter', wrapText: true,  hide: true },
        { field: "Plan", headerName: 'Plan', filter: 'agTextColumnFilter', wrapText: true, maxWidth: 600, hide: true },
        { field: "Description", headerName: 'Agent Description', filter: 'agTextColumnFilter', wrapText: true, hide: true },
    ]);
    const defaultColDef = useMemo<ColDef>(() => {
        return {
            flex: 1,
            autoHeight: true,
            autoHeaderHeight:true,
        };
    }, []);
    
    const exportExcel = useCallback(() => {
            gridRef.current!.api.exportDataAsExcel();
    }, []);

    const defaultExcelExportParams = useMemo<ExcelExportParams>(() => {
        return {
            allColumns:true,
            exportAsExcelTable: true,
            sheetName: 'Agentic ARE Catalog',
            fileName: 'Agentic ARE Catalog',

        }
    }, []);
   
    const autoSizeStrategy = useMemo<
        | SizeColumnsToFitGridStrategy
        | SizeColumnsToFitProvidedWidthStrategy
        | SizeColumnsToContentStrategy
    >(() => {
        return {
            type: "fitCellContents",
            defaultMinWidth: 100,
        };
    }, []);

    return (
        <section>
            <Container className="py-6">
                <div className="mt-4">
                    <div className="flex justify-between item-center">
                    <h2 className="my-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">Agents Catalog</h2>
                    <Button onClick={exportExcel} className="rounded-lg gap-2 text-xs font-normal	 font-baseline" variant={"outline"} size={"sm"}>
                        <Icon name="download" className="h-4 w-4" />
                        <p>Export</p>
                    </Button>
                    </div>
                    <div className="h-[500px]">
                        <div
                            style={gridStyle}
                        >
                            <DataGrid
                                autoSizeStrategy={autoSizeStrategy}
                                rowData={AgentsData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                masterDetail={true}
                                pagination={true}
                                paginationPageSize={10}
                                ref={gridRef}
                                defaultExcelExportParams={defaultExcelExportParams}
                            />
                        </div>
                    </div>
                </div>
            </Container>
        </section>
    );
    
}

const agentDetailsRender = ({ data }: CustomCellRendererProps) => {
    return (
        <div className="h-full flex items-center gap-2">
            <Link
            to={`/agentic-are/${data?.slug}`}
            className="h-full hover:underline"
            >
            {data?.AgentName}
            </Link>
        </div>
        )
}

export default AgentsTable

