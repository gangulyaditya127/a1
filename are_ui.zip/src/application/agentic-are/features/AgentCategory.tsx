import { useId } from "react";
import { Link } from "react-router-dom";
//import { GEN_AI_USECASES } from "./data.gen-ai-usecase";
import { AgentsData } from "../data/areagent.data";
import { useSelector, useDispatch } from "react-redux";
import { setActiveTab } from "../slice/tabSlice";
import { RootState, AppDispatch } from '@/lib/redux/store';

interface Agent {
    AgentName: string,
    Category: string,
    Description: string,
    Layer: string,
    Objective: string,
    OperationalEfficiency: string,
    Plan: string,
    PlaygroundAgentName: string
}

const groupByCategory = (AgentsData: Agent[]) => {
    const grouped = AgentsData.reduce((acc: any, agent: any) => {
        if(!acc[agent.Category]) {
            acc[agent.Category] = []
        }

        acc[agent.Category].push(agent);
        return acc;
    }, {} as Record<string, Agent[]>);

    const sortedCategories = Object.keys(grouped).sort()

    const result: Record<string, Agent[]> = {};
    sortedCategories.forEach(Category => {
        result[Category] = grouped[Category].sort((a: { Category: string; }, b: { Category: any; }) => 
            a.Category.localeCompare(b.Category)
        );
    })

    return result
}

export default function AgentsCategory() {
    const activeTab = useSelector((state: RootState) => state.tabs.activeTab);
    const dispatch = useDispatch<AppDispatch>();
    const groupedAgents = groupByCategory(AgentsData);
    //const defaultTab = "Capacity Management";
    const tabkeys = Object.keys(groupedAgents);
    const fisrtTabKey = tabkeys[0];
    const currentTab = activeTab || fisrtTabKey

    const handleTabChange = (tabkey: string) => {
        dispatch(setActiveTab(tabkey))
    }
    //const intialTab = defaultTab && groupedAgents[defaultTab] ? defaultTab : tabkeys[0]
    //const [activeTab, setActiveTab] = useState<string>(intialTab);
    return (
        <div className="w-full mt-6 px-6 h-auto">
            <h1 className="py-6 text-2xl">List of Agents Categories</h1>
            <div className="tabs-container flex flex-col md:flex-row mb-6">
                {/* Tab headers on the left */}
                <div className="tabs-header flex flex-col bg-muted">
                    {Object.keys(groupedAgents).map((category) => (
                            <button
                    key={category}
                                className={`tab-button py-4 px-6 text-left flex items-center space-x-3 border-l-2 hover:bg-white hover:text-black transition-colors ${
                    currentTab === category
                                    ? 'active text-white font-medium border-white bg-black'
                                    : 'text-white border-transparent'
                                }`}
                    onClick={() => handleTabChange(category)}
                            >
                                
                                <span>{category}</span>
                            </button>
                            ))}
                </div>
                {/* Tab content area */}
                <div className="tab-content-wrapper flex-1 px-6">
                    {Object.keys(groupedAgents).map((category) => (
                        <div key={category}
                            className={`tab-content transition-opacity duration-300 ${activeTab === category
                                        ? 'active opacity-100 visible h-[34rem] overflow-y-auto'
                                        : 'hidden invisible h-0 absolute'
                                    }`}
                        >
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10 md:gap-2 max-w-7xl mx-auto">
                                {groupedAgents[category].map((feature: any) => (
                                    
                                            <Link
                                                to={feature["slug"]}
                                                key={feature["slug"]}
                                                className="relative bg-gradient-to-b dark:from-neutral-900 from-neutral-100 dark:to-neutral-950 to-white p-6 rounded-lg overflow-hidden"
                                            >
                                                <Grid size={20} />
                                                <p className="text-base  text-white dark:text-white relative z-20 text-lg">
                                                    {feature["AgentName"]}
                                                </p>
                                                <p className="text-neutral-600 dark:text-neutral-400 mt-3 text-sm font-normal relative z-20 line-clamp-3 ">
                                                    {feature.Description}
                                                </p>
                                            </Link>
                                        
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            {/* {Object.keys(groupedAgents).map((category) => (
                <div key={category}>
                    <h2 className="ms-4 text-xl font-bold">{category}</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10 md:gap-2 max-w-7xl mx-auto mt-6">
                        {groupedAgents[category].map((feature: any) => (

                            <Link
                                to={feature["slug"]}
                                key={feature["slug"]}
                                className="relative bg-gradient-to-b dark:from-neutral-900 from-neutral-100 dark:to-neutral-950 to-white p-6 rounded-lg overflow-hidden"
                            >
                                <Grid size={20} />
                                <p className="text-base  text-white dark:text-white relative z-20 text-lg">
                                    {feature["AgentName"]}
                                </p>
                                <p className="text-neutral-600 dark:text-neutral-400 mt-3 text-sm font-normal relative z-20 line-clamp-3 ">
                                    {feature.Description}
                                </p>
                            </Link>
                        ))}
                    </div>
                </div>
            ))} */}
        </div>
    );
}

export const Grid = ({
    pattern,
    size,
}: {
    pattern?: number[][];
    size?: number;
}) => {
    const p = pattern ?? [
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
        [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    ];
    return (
        <div className="pointer-events-none absolute left-1/2 top-0  -ml-20 -mt-2 h-full w-full [mask-image:linear-gradient(white,transparent)]">
            <div className="absolute inset-0 bg-gradient-to-r  [mask-image:radial-gradient(farthest-side_at_top,white,transparent)] dark:from-zinc-900/30 from-zinc-100/30 to-zinc-300/30 dark:to-zinc-900/30 opacity-100">
                <GridPattern
                    width={size ?? 20}
                    height={size ?? 20}
                    x="-12"
                    y="4"
                    squares={p}
                    className="absolute inset-0 h-full w-full  mix-blend-overlay dark:fill-white/10 dark:stroke-white/10 stroke-black/10 fill-black/10"
                />
            </div>
        </div>
    );
};

export function GridPattern({ width, height, x, y, squares, ...props }: any) {
    const patternId = useId();

    return (
        <svg aria-hidden="true" {...props}>
            <defs>
                <pattern
                    id={patternId}
                    width={width}
                    height={height}
                    patternUnits="userSpaceOnUse"
                    x={x}
                    y={y}
                >
                    <path d={`M.5 ${height}V.5H${width}`} fill="none" />
                </pattern>
            </defs>
            <rect
                width="100%"
                height="100%"
                strokeWidth={0}
                fill={`url(#${patternId})`}
            />
            {squares && (
                <svg x={x} y={y} className="overflow-visible">
                    {squares.map(([x, y]: any) => (
                        <rect
                            strokeWidth="0"
                            key={`${x}-${y}`}
                            width={width + 1}
                            height={height + 1}
                            x={x * width}
                            y={y * height}
                        />
                    ))}
                </svg>
            )}
        </svg>
    );
}
