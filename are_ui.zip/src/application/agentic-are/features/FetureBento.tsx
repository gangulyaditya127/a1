import { Activity, Atom, Castle, Diameter, Gpu, HeartPlus, LoaderPinwheel, Logs, Map as MapIcon, PackageCheck, ScanHeart, Workflow } from 'lucide-react'
import Container from '@/components/ui/container'
import { VideoDialog } from '@/components/ui/video-player/video-dialog'
import PRODUCT_DEMO from "@/assets/Video/Agentic_incidednt.mp4"
import DEMO_VIDEO_THUMBNAIL from "@/assets/Video/thumbnail/agentic-incident.png"
import { cn } from '@/lib/tailwind.utils'
import { Marquee } from '@/components/ui/marquee'
import { TextLoop } from '@/components/ui/text-loop'
import { TextShimmer } from '@/components/ui/text-shimmer'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icon'
import { useNavigate } from 'react-router-dom'
export default function FeatureBento() {
    const navigate = useNavigate()
    return (
        <section className="pb-24">
            <Container className="mx-auto grid max-w-5xl border md:grid-cols-2">
                <div>
                    <div className="p-6 sm:p-12">
                        <span className="text-muted-foreground flex items-center gap-2">
                            <MapIcon className="size-4" />
                            Incident Mangement Agentic Solution
                        </span>
                        <p className="mt-8 text-xl">
                            <span className="text-muted-foreground">Watch how</span> intelligent agents <span className="text-muted-foreground">
                                handle incident triage, root cause analysis, and proactive resolution
                            </span>
                        </p>
                    </div>
                    <VideoDialog
                        videoSrc={PRODUCT_DEMO}
                        thumbnailSrc={DEMO_VIDEO_THUMBNAIL}
                        animationStyle='fade'
                        className='ml-8'
                    />
                </div>
                <div className="overflow-hidden border-t bg-zinc-50 p-6 sm:p-12 md:border-0 md:border-l dark:bg-transparent">
                    <div className="">
                        <span className="text-muted-foreground flex items-center gap-2">
                            <Workflow className="size-4" />
                            Agentic Workflow
                        </span>
                        <p className="mt-7 text-xl">
                            Automated diagnostics and remediation​<span className="text-muted-foreground">
                                powered by suite of ARE agents
                            </span>
                        </p>
                    </div>
                    <div className="h-[280px] [mask-image:radial-gradient(hsl(var(--background))_0%,transparent_100%)] mt-16">
                        <AIAgentSteps />
                    </div>
                </div>
                {/* <div className="col-span-full border-y p-12">
                    <p className="text-center text-4xl font-semibold lg:text-7xl">100% Customizable</p>
                </div> */}
                <div className="relative col-span-full border-y ">
                    <div className="absolute z-10 max-w-lg px-6 pr-12 pt-6 md:px-12 md:pt-12">
                        <span className="text-muted-foreground flex items-center gap-2">
                            <Activity className="size-4" />
                            Bridging the gap to the future of AMS
                        </span>

                        <p className="my-8 text-xl">
                            Transforming <span className="text-muted-foreground">traditional, SME intensive operations into intelligent, self-evolving systems</span>
                        </p>

                        <Button onClick={() => {
                            navigate('/agentic-are-assets')
                        }} variant="primary" className='rounded-3xl group mt-8'>
                            Explore
                            <Icon
                                name="chevron-right"
                                className="size-5 transition-transform group-hover:translate-x-1 group-active:translate-x-1"
                            />
                        </Button>
                    </div>
                    <div className="h-96 grid place-items-center relative">
                        <div className="flex text-muted-foreground flex-col items-center absolute right-16 ">
                            <div className="border p-3 rounded border-dashed w-96 -translate-x-20 flex items-center overflow-hidden gap-4">
                                <div className="w-9 h-9 rounded-full grid place-items-center">
                                    <LoaderPinwheel />
                                </div>
                                <div className="">
                                    <p className='text-foreground'>Future AMS Ops</p>
                                    <TextLoop>
                                        <span>Adaptive Learning and Continuous Improv..​</span>
                                        <span>Proactive and Predictive Capabilities​</span>
                                        <span>Automated Diagnostics and Remediation​</span>
                                        <span>Task Prioritization and Smart Resource Al..​</span>
                                    </TextLoop>
                                </div>
                            </div>
                            <DirectionPath />
                            <div className="border p-3 rounded border-dashed w-80 translate-x-20 flex items-center overflow-hidden gap-4">
                                <div className="w-9 h-9 rounded-full grid place-items-center">
                                    <Castle />
                                </div>
                                <div className="">
                                    <p className=''>Current AMS Ops</p>
                                    <TextLoop>
                                        <span>Highly SME-intensive​​</span>
                                        <span>Context-sensitive​​</span>
                                        <span>Process-driven​​</span>
                                        <span>Governance-focused​​</span>
                                    </TextLoop>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Container>
        </section>
    )
}

const DirectionPath = () => (
    <div className="relative">
        <div className="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2">
            <div className="w-[100px] p-1 py-0.5 bg-background rounded border">
                <TextShimmer className='font-medium'>
                    Agentic ARE
                </TextShimmer>
            </div>
        </div>
        <svg
            data-size="large"
            fill="none"
            height={152}
            viewBox="0 0 117 152"
            width={117}
        >
            <path
                d="M3.99999 4L3.99999 60C3.99999 66.6274 9.37258 72 16 72L104 72C110.627 72 116 77.3726 116 84L116 152"
                stroke="url(#paint0_linear_1364_100888)"
                strokeWidth={2}
            />
            <path
                d="M3.99999 4L3.99999 60C3.99999 66.6274 9.37258 72 16 72L104 72C110.627 72 116 77.3726 116 84L116 152"
                stroke="url(#paint1_linear_1364_100888)"
                strokeWidth={2}
            />
            <g clipPath="url(#clip0_1364_100888)">
                <path
                    clipRule="evenodd"
                    d="M4 0.5L8 7.5H0L4 0.5Z"
                    fill="#45DEC4"
                    fillRule="evenodd"
                />
            </g>
            <defs>
                <linearGradient
                    gradientUnits="userSpaceOnUse"
                    id="paint0_linear_1364_100888"
                    x1={116}
                    x2={4}
                    y1={72}
                    y2={72}
                >
                    <stop stopColor="#E5484D" />
                    <stop offset={0.5} stopColor="#FFC634" />
                    <stop offset={1} stopColor="#45DEC4" />
                </linearGradient>
                <linearGradient
                    gradientUnits="userSpaceOnUse"
                    id="paint1_linear_1364_100888"
                    x1={116}
                    x2={116}
                    y1={152}
                    y2={0.0000156712}
                >
                    <stop stopColor="var(--ds-background-200)" />
                    <stop
                        offset={0.322368}
                        stopColor="var(--ds-background-200)"
                        stopOpacity={0}
                    />
                </linearGradient>
                <clipPath id="clip0_1364_100888">
                    <rect fill="white" height={8} width={8} />
                </clipPath>
            </defs>
        </svg>
    </div>
);


const AI_AGENT_STEPS = [
    {
        name: "DQ Agent",
        task: "Incident data quality and completness check",
        icon: <PackageCheck />,
        className: "bg-blue-500",
    },
    {
        name: "Triage Agent​",
        task: "Assigns the ticket and starts the triaging process​",
        icon: <Diameter />,
        className: "bg-green-500",
    },
    {
        name: "Impact Analyzer Agent​​",
        task: "Impact analysis and incident priority determination​​",
        icon: <Atom />,
        className: "bg-amber-500",
    },
    {
        name: "Log Analyzer Agent​​",
        task: "Log analysis and root cause identification​​",
        icon: <Logs />,
        className: "bg-pink-500",
    },
    {
        name: "Resolution Agent​​​",
        task: "Checks past incidents, SOPs, run books / play books and propose short term and long-term solution​​​",
        icon: <Gpu />,
        className: "bg-green-500",
    },
    {
        name: "Self Healing Agent​​",
        task: "Auto execution of the incident healing steps and ticket closure​​",
        icon: <HeartPlus />,
        className: "bg-blue-500",
    },
    {
        name: "Health Check Agent​​",
        task: "Validates that the fix provided has helped restore the application​​​",
        icon: <ScanHeart />,
        className: "bg-purple-500",
    },
    {
        name: "Problem Record Agent​​​",
        task: "Create problem records in the ITSM tool​​​​",
        icon: <ScanHeart />,
        className: "bg-green-500",
    },
]

const AIAgentSteps = () => (
    <div className="flex flex-col gap-4">
        <Marquee
            vertical
            pauseOnHover
            dir='to_bottom'
        >
            {
                AI_AGENT_STEPS.reverse().map((el) => (
                    <div className="border rounded flex items-start gap-4 py-3 px-3" key={el.name}>
                        <div className={cn("grid place-items-center rounded-full aspect-square w-9 h-9 shrink-0 bg-red-500", el.className)}>
                            {el.icon}
                        </div>
                        <div className="">
                            <p>{el.name}</p>
                            <p className="text-muted-foreground line-clamp-1">
                                {el.task}
                            </p>
                        </div>
                    </div>
                ))
            }
        </Marquee>
    </div>
)