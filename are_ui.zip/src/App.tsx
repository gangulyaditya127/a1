import { SideNav } from "@/components/layout/SideNav";
import { TopNav } from "@/components/layout/TopNav";

import { useAppSelector } from "@/lib/redux/hooks";
import { cn } from "@/lib/tailwind.utils";

import { Outlet } from "react-router-dom";

function App() {
  const hasSideBar = useAppSelector((state) => state.sideNav.hasSideBar);
  return (
    <div
      className={cn(`min-h-screen w-full`, hasSideBar ? "pl-[56px]" : "")}
    >
      {hasSideBar && <SideNav />}
      <TopNav hasSideBar={hasSideBar} />
      <main className="">
        <Outlet />
        {/* <ScrollRestoration
          getKey={(location, _) => {
            return location.key;
          }} /> */}
      </main>
    </div>
  );
}

export default App;
