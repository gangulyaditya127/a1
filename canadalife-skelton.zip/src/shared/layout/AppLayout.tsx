import { Outlet } from "react-router-dom";
import { Sidebar } from "@/shared/layout/Sidebar";
import { Topbar } from "@/shared/layout/Topbar";
import type { AppManifest } from "@/shared/types";

/** Shared frame for every application: sidebar + topbar + routed content. */
export function AppLayout({ app }: { app: AppManifest }) {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar app={app} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar app={app} />
        <main className="scrollbar-thin flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1440px] px-4 py-5 md:px-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
