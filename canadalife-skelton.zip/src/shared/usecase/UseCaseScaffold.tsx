import { Bot, CheckCircle2, User } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { PageHeader } from "@/shared/components/PageHeader";
import { JourneyTimeline } from "@/shared/usecase/JourneyTimeline";
import { PlannedModuleCard } from "@/shared/usecase/PlannedModuleCard";
import { Badge } from "@/shared/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import type { UseCaseDef } from "@/shared/types";

/**
 * Shared skeleton for every use case that isn't fully built yet.
 * S6 demonstrates the fully-expanded pattern; these pages carry the same
 * shell, header treatment and data contracts so each can be promoted from
 * skeleton to full module without rework.
 */
export function UseCaseScaffold({ useCase }: { useCase: UseCaseDef }) {
  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow={`Use case ${useCase.code}`}
        title={useCase.title}
        description={useCase.tagline}
        actions={<Badge variant="info">{useCase.status}</Badge>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Scenario</CardTitle>
            <CardDescription>
              From the table-top planning session (v0.2)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-[13px] leading-relaxed text-foreground/90">
              {useCase.scenario}
            </p>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                ARE agents
              </span>
              {useCase.agents.map((a) => (
                <Badge key={a} variant="secondary">
                  <Bot className="h-3 w-3" />
                  {a}
                </Badge>
              ))}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              Tech lead: {useCase.lead}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Business outcomes</CardTitle>
            <CardDescription>What service owners get</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5">
              {useCase.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-2 text-[13px]">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Agentic journey</CardTitle>
            <CardDescription>How the flow runs end to end</CardDescription>
          </CardHeader>
          <CardContent>
            <JourneyTimeline steps={useCase.journey} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Planned modules</CardTitle>
            <CardDescription>
              Scaffolded in this shell — S6 shows the pattern fully built
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {useCase.plannedModules.map((m) => (
                <PlannedModuleCard key={m.title} module={m} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <AiInsight source="Portal shell">
        This application runs on the same shared frame, header and card system
        as Governance & Reporting. The planned modules above are already
        stubbed in this app's sidebar — promoting one means adding a page,
        data and (if needed) a slice inside this app's folder, then removing
        its "Soon" flag in the manifest.
      </AiInsight>
    </div>
  );
}
