/**
 * One place for chart colors so visuals stay coherent across pages.
 * Structural colors (grid, ticks, tooltip) reference CSS variables so every
 * chart adapts to light/dark automatically; the series palette is fixed and
 * chosen to read on both themes. Brand red is used sparingly — headline
 * series only.
 */
export const CHART = {
  red: "hsl(var(--brand))",
  ink: "hsl(var(--foreground) / 0.75)",
  slate: "#94A3B8",
  blue: "#3B82F6",
  sky: "#0EA5E9",
  green: "#10B981",
  amber: "#F59E0B",
  violet: "#8B5CF6",
  grid: "hsl(var(--border))",
} as const;

export const AXIS_TICK = {
  fontSize: 11,
  fill: "hsl(var(--muted-foreground))",
} as const;

export const TOOLTIP_STYLE = {
  contentStyle: {
    background: "hsl(var(--card))",
    borderRadius: 8,
    border: "1px solid hsl(var(--border))",
    boxShadow: "0 8px 24px rgb(0 0 0 / 0.16)",
    fontSize: 12,
    padding: "8px 10px",
    color: "hsl(var(--foreground))",
  },
  labelStyle: {
    fontWeight: 600,
    color: "hsl(var(--foreground))",
    marginBottom: 4,
  },
  cursor: {
    stroke: "hsl(var(--border))",
    fill: "hsl(var(--muted) / 0.5)",
  },
} as const;

export const LEGEND_STYLE = {
  fontSize: 12,
  paddingTop: 8,
  color: "hsl(var(--muted-foreground))",
} as const;
