import type { LucideIcon } from "lucide-react";

/* ---------------------------------- app ---------------------------------- */

export type TimeRange = "3m" | "6m" | "12m";

export type HealthStatus = "on-track" | "at-risk" | "breached";

/** Generic month point; series keys vary per chart. */
export interface MonthPoint {
  month: string;
  [series: string]: string | number;
}

/* ---------------------------------- SLA ---------------------------------- */

export interface SlaMetric {
  id: string;
  name: string;
  category: "response" | "resolution" | "availability" | "experience";
  target: string;
  targetPct: number;
  actualPct: number;
  deltaPts: number;
  status: HealthStatus;
  scope: string;
}

export interface BreachRisk {
  id: string;
  metric: string;
  application: string;
  predictedIn: string;
  confidence: number;
  impact: string;
  recommendation: string;
  acknowledged: boolean;
}

export interface XlaDriver {
  id: string;
  name: string;
  score: number;
  deltaPts: number;
}

export interface AppHealth {
  id: string;
  name: string;
  portfolio: string;
  tier: "Tier 1" | "Tier 2" | "Tier 3";
  sla: number;
  xla: number;
  openP1: number;
  openP2: number;
  risk: HealthStatus;
  deltaPts: number;
}

export interface SlaSummary {
  compliancePct: number;
  complianceDelta: number;
  metricsMet: number;
  metricsTotal: number;
  creditExposureCad: number;
  xlaScore: number;
  xlaDelta: number;
  csat: number;
  csatDelta: number;
}

/* ------------------------------ productivity ----------------------------- */

export interface ProductivitySummary {
  ticketsHandled: number;
  avgResolutionHrs: number;
  avgResolutionDeltaPct: number;
  automationCoveragePct: number;
  hoursSaved: number;
  savingsCad: number;
  backlog: number;
  backlogDeltaPct: number;
}

export interface AutomationRecord {
  id: string;
  name: string;
  tickets: number;
  hoursSaved: number;
  successPct: number;
}

export interface ShiftLeftRow {
  level: string;
  pct: number;
  deltaPts: number;
}

export interface AgingBucket {
  bucket: string;
  count: number;
}

/* --------------------------------- agents -------------------------------- */

export type AgentStatus = "live" | "pilot" | "planned";

export interface AgentRow {
  id: string;
  name: string;
  useCase: "S1" | "S2" | "S5" | "S6";
  status: AgentStatus;
  actions: number;
  acceptancePct: number;
  successPct: number;
  hoursSaved: number;
}

export interface AgentDecision {
  id: string;
  agent: string;
  summary: string;
  when: string;
  state: "pending" | "approved" | "rejected";
}

export interface HitlSummary {
  approved: number;
  modified: number;
  rejected: number;
}

/* ------------------------------ improvement ------------------------------ */

export type InitiativeStatus = "idea" | "in-progress" | "delivered";

export interface Initiative {
  id: string;
  title: string;
  category: string;
  owner: "TCS" | "Canada Life" | "Joint";
  status: InitiativeStatus;
  impact: string;
  eta: string;
}

export interface Recommendation {
  id: string;
  title: string;
  source: string;
  rationale: string;
  impact: string;
  category: string;
}

export interface GovMeeting {
  id: string;
  name: string;
  cadence: string;
  next: string;
  forum: string;
}

export interface GovAction {
  id: string;
  action: string;
  owner: "TCS" | "Canada Life" | "Joint";
  due: string;
  state: "open" | "closed";
}

export interface ImprovementSummary {
  inFlight: number;
  deliveredYtd: number;
  benefitsCad: number;
  repeatReductionPct: number;
}

/* -------------------------------- reports -------------------------------- */

export type ReportState = "ready" | "generating" | "scheduled";

export interface ReportDef {
  id: string;
  name: string;
  description: string;
  audience: string;
  frequency: string;
  lastGenerated: string | null;
  state: ReportState;
}

export interface ReportSubscription {
  id: string;
  report: string;
  recipients: string;
  cadence: string;
  nextRun: string;
  active: boolean;
}

/* ------------------------------- use cases ------------------------------- */

export interface PlannedModule {
  title: string;
  description: string;
}

export interface UseCaseDef {
  code: string;
  title: string;
  tagline: string;
  status: string;
  lead: string;
  scenario: string;
  agents: string[];
  journey: { step: string; detail: string }[];
  outcomes: string[];
  plannedModules: PlannedModule[];
}

/* ------------------------------- navigation ------------------------------ */

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  soon?: boolean;
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}
