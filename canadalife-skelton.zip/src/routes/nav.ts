import {
  Bot,
  FileText,
  Gauge,
  LayoutDashboard,
  Lightbulb,
  Microscope,
  Radar,
  ShieldCheck,
  Siren,
  Zap,
} from "lucide-react";
import type { NavGroup } from "@/types";

/**
 * One config drives the sidebar, the topbar title and the router.
 * The S6 group is fully built; S1/S2/S5 and the General track reuse the
 * shared skeleton page.
 */
export const NAV_GROUPS: NavGroup[] = [
  {
    label: "S6 · Governance & Reporting",
    items: [
      { label: "Overview", to: "/", icon: LayoutDashboard },
      { label: "SLA & XLA", to: "/governance/sla", icon: Gauge },
      { label: "Productivity", to: "/governance/productivity", icon: Zap },
      { label: "AI Agents", to: "/governance/agents", icon: Bot },
      { label: "Improvement", to: "/governance/improvement", icon: Lightbulb },
      { label: "Reports", to: "/governance/reports", icon: FileText },
    ],
  },
  {
    label: "Use cases",
    items: [
      { label: "S1 · Incident Triage", to: "/use-cases/incident-triage", icon: Siren, soon: true },
      { label: "S2 · Problem & RCA", to: "/use-cases/problem-rca", icon: Microscope, soon: true },
      { label: "S5 · Predictive Ops", to: "/use-cases/predictive-ops", icon: Radar, soon: true },
    ],
  },
  {
    label: "Platform",
    items: [
      { label: "AI Governance", to: "/platform/ai-governance", icon: ShieldCheck, soon: true },
    ],
  },
];

const FLAT = NAV_GROUPS.flatMap((g) => g.items);

export function titleForPath(pathname: string): string {
  const hit = FLAT.find((i) => i.to === pathname);
  return hit ? hit.label : "AMS Service Governance";
}
