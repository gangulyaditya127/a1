import { createBrowserRouter } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { OverviewPage } from "@/pages/governance/OverviewPage";
import { SlaCompliancePage } from "@/pages/governance/SlaCompliancePage";
import { ProductivityPage } from "@/pages/governance/ProductivityPage";
import { AgentPerformancePage } from "@/pages/governance/AgentPerformancePage";
import { ImprovementPage } from "@/pages/governance/ImprovementPage";
import { ReportsPage } from "@/pages/governance/ReportsPage";
import { IncidentTriagePage } from "@/pages/usecases/IncidentTriagePage";
import { ProblemRcaPage } from "@/pages/usecases/ProblemRcaPage";
import { PredictiveOpsPage } from "@/pages/usecases/PredictiveOpsPage";
import { AiGovernancePage } from "@/pages/usecases/AiGovernancePage";
import { NotFoundPage } from "@/pages/NotFoundPage";

/**
 * Route map
 * S6 (fully built):   /            overview
 *                     /governance/sla | productivity | agents | improvement | reports
 * Skeletons:          /use-cases/incident-triage | problem-rca | predictive-ops
 *                     /platform/ai-governance
 */
export const router = createBrowserRouter([
  {
    element: <AppLayout />,
    children: [
      { index: true, element: <OverviewPage /> },
      { path: "governance/sla", element: <SlaCompliancePage /> },
      { path: "governance/productivity", element: <ProductivityPage /> },
      { path: "governance/agents", element: <AgentPerformancePage /> },
      { path: "governance/improvement", element: <ImprovementPage /> },
      { path: "governance/reports", element: <ReportsPage /> },
      { path: "use-cases/incident-triage", element: <IncidentTriagePage /> },
      { path: "use-cases/problem-rca", element: <ProblemRcaPage /> },
      { path: "use-cases/predictive-ops", element: <PredictiveOpsPage /> },
      { path: "platform/ai-governance", element: <AiGovernancePage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);
