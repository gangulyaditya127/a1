import type { UseCaseDef } from "@/shared/types";

/** Content distilled from the Canada Life table-top planner (v0.2). */
export const useCase: UseCaseDef = {
  code: "S5",
  title: "Proactive & Predictive Operations",
  tagline: "Cut the noise, see risks early, heal before impact",
  status: "In discovery",
  lead: "Aditya (TCS)",
  scenario:
    "Thousands of events become a handful of real signals. Agents correlate and suppress noise, forecast emerging risks, recommend pre-emptive actions and — where approved — execute self-healing runbooks before users feel anything.",
  agents: ["Event Correlator & Forecaster", "Self-Healing Executor"],
  journey: [
    { step: "Noise reduction", detail: "Correlate and de-duplicate events into meaningful signals." },
    { step: "Predictive risk detection", detail: "Forecast incidents and SLA breaches with confidence." },
    { step: "Proactive recommendations", detail: "Pre-emptive actions ranked by impact." },
    { step: "Self-healing automation", detail: "Approved runbooks execute with full audit trail." },
    { step: "Continuous optimization", detail: "Models retrain on every outcome." },
  ],
  outcomes: [
    "Materially less alert noise",
    "Issues caught before user impact",
    "Lower incident volumes and faster recovery",
    "Higher availability on Tier 1 apps",
  ],
  plannedModules: [
    { title: "Alert noise funnel", description: "Raw events → correlated signals → actioned." },
    { title: "Risk forecasts", description: "Predicted incidents and breach risks with confidence." },
    { title: "Self-healing run log", description: "Every automated run, outcome and rollback." },
    { title: "Capacity outlook", description: "Where demand will outgrow headroom next." },
  ],
};
