import { useEffect } from "react";
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  AlertTriangle,
  BadgeCheck,
  CircleDollarSign,
  Gauge,
  Check,
} from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ChartCard } from "@/shared/components/ChartCard";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { TrendIndicator } from "@/shared/components/TrendIndicator";
import { Button } from "@/shared/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Progress } from "@/shared/ui/progress";
import { Skeleton } from "@/shared/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/shared/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import { AXIS_TICK, CHART, LEGEND_STYLE, TOOLTIP_STYLE } from "@/shared/lib/chart";
import { fmtCad } from "@/shared/lib/utils";
import { acknowledgeRisk, fetchSlaData } from "@/application/governance/state/slaSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

export function SlaCompliancePage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);

  useEffect(() => {
    dispatch(fetchSlaData(range));
  }, [dispatch, range]);

  const loading = sla.status !== "succeeded";
  const openRisks = sla.risks.filter((r) => !r.acknowledged);

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="SLA & XLA compliance"
        description="Contractual service levels and the experience behind them — with iSLA forecasting breaches before they land."
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard
          label="Overall compliance"
          value={sla.summary ? `${sla.summary.compliancePct}%` : "—"}
          icon={Gauge}
          loading={loading}
          trend={{ value: "+0.6 pts", direction: "up", positive: true }}
        />
        <KpiCard
          label="Metrics met"
          value={sla.summary ? `${sla.summary.metricsMet} / ${sla.summary.metricsTotal}` : "—"}
          icon={BadgeCheck}
          loading={loading}
          hint="this period"
        />
        <KpiCard
          label="Open breach risks"
          value={String(openRisks.length)}
          icon={AlertTriangle}
          loading={loading}
          hint="forecast by iSLA"
        />
        <KpiCard
          label="Credit exposure"
          value={sla.summary ? fmtCad(sla.summary.creditExposureCad) : "—"}
          icon={CircleDollarSign}
          loading={loading}
          trend={{ value: "−34%", direction: "down", positive: true }}
          hint="if risks materialize"
        />
      </div>

      <Tabs defaultValue="sla">
        <TabsList>
          <TabsTrigger value="sla">Service levels</TabsTrigger>
          <TabsTrigger value="xla">Experience (XLA)</TabsTrigger>
          <TabsTrigger value="risk">
            Breach risk
            {openRisks.length > 0 && (
              <span className="grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[9.5px] font-bold text-white">
                {openRisks.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ------------------------------ SLA tab ----------------------------- */}
        <TabsContent value="sla" className="space-y-4">
          <ChartCard
            title="Compliance by priority"
            subtitle="Resolution compliance %, monthly"
            loading={loading}
            height={260}
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sla.trendByPriority} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis domain={[88, 100]} tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
                <Tooltip {...TOOLTIP_STYLE} />
                <Legend wrapperStyle={LEGEND_STYLE} iconType="plainline" />
                <ReferenceLine y={95} stroke={CHART.amber} strokeDasharray="4 4" />
                <Line type="monotone" dataKey="P1" stroke={CHART.red} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="P2" stroke={CHART.blue} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="P3" stroke={CHART.violet} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="P4" stroke={CHART.slate} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          <Card>
            <CardHeader>
              <CardTitle>Metric detail</CardTitle>
              <CardDescription>All contracted service levels for the period</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-56 w-full" />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Metric</TableHead>
                      <TableHead>Target</TableHead>
                      <TableHead className="w-[180px]">Actual</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Scope</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sla.metrics.map((m) => (
                      <TableRow key={m.id}>
                        <TableCell className="font-medium">{m.name}</TableCell>
                        <TableCell className="num text-muted-foreground">{m.target}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={m.actualPct}
                              className="h-1.5 w-20"
                              indicatorClassName={
                                m.status === "on-track" ? "bg-emerald-500" : "bg-amber-500"
                              }
                            />
                            <span className="num text-xs font-medium">
                              {m.actualPct.toFixed(1)}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <TrendIndicator
                            trend={{
                              value: `${m.deltaPts > 0 ? "+" : ""}${m.deltaPts} pts`,
                              direction: m.deltaPts > 0 ? "up" : m.deltaPts < 0 ? "down" : "flat",
                              positive: m.deltaPts >= 0,
                            }}
                          />
                        </TableCell>
                        <TableCell className="text-muted-foreground">{m.scope}</TableCell>
                        <TableCell>
                          <StatusBadge status={m.status} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------ XLA tab ----------------------------- */}
        <TabsContent value="xla" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Experience score</CardTitle>
                <CardDescription>Blended XLA across journeys</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <Skeleton className="h-24 w-full" />
                ) : (
                  <>
                    <div className="flex items-end gap-2">
                      <span className="num text-4xl font-semibold tracking-tight">
                        {sla.summary?.xlaScore}
                      </span>
                      <span className="pb-1 text-xs text-muted-foreground">/ 100</span>
                      <TrendIndicator
                        className="mb-1.5 ml-auto"
                        trend={{ value: "+2 pts", direction: "up", positive: true }}
                      />
                    </div>
                    <Progress value={sla.summary?.xlaScore ?? 0} className="mt-3 h-2" indicatorClassName="bg-brand" />
                    <p className="mt-2 text-[11px] text-muted-foreground">
                      Target ≥ 85 · agreed in the experience-level addendum
                    </p>
                  </>
                )}
              </CardContent>
            </Card>

            <ChartCard
              title="CSAT trend"
              subtitle="Average rating on closed tickets"
              loading={loading}
              height={170}
              className="lg:col-span-2"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sla.csatTrend} margin={{ top: 6, right: 8, left: -24, bottom: 0 }}>
                  <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                  <YAxis domain={[3.5, 5]} tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
                  <Tooltip {...TOOLTIP_STYLE} />
                  <Line type="monotone" dataKey="csat" name="CSAT" stroke={CHART.green} strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Experience drivers</CardTitle>
              <CardDescription>What's moving the score, by journey</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-36 w-full" />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Driver</TableHead>
                      <TableHead className="w-[220px]">Score</TableHead>
                      <TableHead>Trend</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sla.xlaDrivers.map((d) => (
                      <TableRow key={d.id}>
                        <TableCell className="font-medium">{d.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={d.score} className="h-1.5 w-28" indicatorClassName={d.score >= 85 ? "bg-emerald-500" : d.score >= 80 ? "bg-sky-500" : "bg-amber-500"} />
                            <span className="num text-xs font-medium">{d.score}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <TrendIndicator
                            trend={{
                              value: `${d.deltaPts > 0 ? "+" : ""}${d.deltaPts} pts`,
                              direction: d.deltaPts > 0 ? "up" : d.deltaPts < 0 ? "down" : "flat",
                              positive: d.deltaPts >= 0,
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <AiInsight source="iSLA">
            Advisor response experience dipped 2 pts — driven by longer L2 queues
            on Advisor Workspace. The shift-left initiative (CI-3) targets this
            journey; expected recovery by September.
          </AiInsight>
        </TabsContent>

        {/* ----------------------------- Risk tab ----------------------------- */}
        <TabsContent value="risk" className="space-y-4">
          <AiInsight source="iSLA breach forecaster">
            Forecasts combine open-ticket aging, event trends (S5) and seasonal
            volume. Acknowledging a risk records your review in the governance
            audit trail — it does not silence monitoring.
          </AiInsight>

          {loading ? (
            <Skeleton className="h-40 w-full" />
          ) : (
            <div className="grid gap-3 lg:grid-cols-3">
              {sla.risks.map((r) => (
                <Card key={r.id} className={r.acknowledged ? "opacity-70" : ""}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between gap-2">
                      <CardTitle>{r.metric}</CardTitle>
                      <StatusBadge status={r.acknowledged ? "on-track" : "at-risk"} />
                    </div>
                    <CardDescription>
                      {r.application} · predicted breach in {r.predictedIn}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="mb-1 flex items-center justify-between text-[11px] text-muted-foreground">
                        <span>Forecast confidence</span>
                        <span className="num font-medium text-foreground">{r.confidence}%</span>
                      </div>
                      <Progress
                        value={r.confidence}
                        className="h-1.5"
                        indicatorClassName={r.confidence >= 75 ? "bg-red-500" : "bg-amber-500"}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">{r.impact}</p>
                    <p className="text-xs">
                      <span className="font-semibold">Recommended: </span>
                      {r.recommendation}
                    </p>
                    <Button
                      size="sm"
                      variant={r.acknowledged ? "secondary" : "default"}
                      disabled={r.acknowledged}
                      onClick={() => dispatch(acknowledgeRisk(r.id))}
                      className="w-full"
                    >
                      <Check className="h-3.5 w-3.5" />
                      {r.acknowledged ? "Acknowledged" : "Acknowledge risk"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
