import { useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  AlertTriangle,
  Bot,
  CalendarDays,
  CircleDollarSign,
  Download,
  Gauge,
  Smile,
  Sparkles,
} from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ChartCard } from "@/shared/components/ChartCard";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { TrendIndicator } from "@/shared/components/TrendIndicator";
import { Button } from "@/shared/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/shared/ui/table";
import { AXIS_TICK, CHART, LEGEND_STYLE, TOOLTIP_STYLE } from "@/shared/lib/chart";
import { fmtCad, fmtNum } from "@/shared/lib/utils";
import { fetchSlaData } from "@/application/governance/state/slaSlice";
import { fetchProductivityData } from "@/application/governance/state/productivitySlice";
import { fetchImprovementData } from "@/application/governance/state/improvementSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

export function OverviewPage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const sla = useAppSelector((s) => s.governance.sla);
  const prod = useAppSelector((s) => s.governance.productivity);
  const imp = useAppSelector((s) => s.governance.improvement);

  useEffect(() => {
    dispatch(fetchSlaData(range));
    dispatch(fetchProductivityData(range));
    dispatch(fetchImprovementData(range));
  }, [dispatch, range]);

  const loading = sla.status !== "succeeded";
  const prodLoading = prod.status !== "succeeded";

  const openRisks = sla.risks.filter((r) => !r.acknowledged);
  const lastMix = prod.volumeTrend[prod.volumeTrend.length - 1];
  const mixData = lastMix
    ? [
        { name: "Auto-resolved", value: Number(lastMix.autoResolved), color: CHART.green },
        { name: "AI-assisted", value: Number(lastMix.aiAssisted), color: CHART.blue },
        { name: "Manual", value: Number(lastMix.manual), color: CHART.slate },
      ]
    : [];

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="Service governance overview"
        description="How your AMS estate is performing, what needs your attention, and the value being returned — across the Canada Life application portfolio."
        actions={
          <>
            <Button variant="outline" size="sm" asChild>
              <Link to="/reports">
                <Download className="h-3.5 w-3.5" />
                June MSR
              </Link>
            </Button>
            <Button size="sm" asChild>
              <Link to="/improvement">
                <CalendarDays className="h-3.5 w-3.5" />
                Governance cadence
              </Link>
            </Button>
          </>
        }
      />

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <KpiCard
          label="SLA compliance"
          value={sla.summary ? `${sla.summary.compliancePct}%` : "—"}
          icon={Gauge}
          loading={loading}
          trend={{ value: "+0.6 pts", direction: "up", positive: true }}
          hint="vs last month"
        />
        <KpiCard
          label="Experience score (XLA)"
          value={sla.summary ? String(sla.summary.xlaScore) : "—"}
          icon={Smile}
          loading={loading}
          trend={{ value: "+2 pts", direction: "up", positive: true }}
          hint="of 100"
        />
        <KpiCard
          label="Open breach risks"
          value={String(openRisks.length)}
          icon={AlertTriangle}
          loading={loading}
          hint="forecast by iSLA"
        />
        <KpiCard
          label="Automation savings"
          value={prod.summary ? fmtCad(prod.summary.savingsCad) : "—"}
          icon={CircleDollarSign}
          loading={prodLoading}
          trend={{ value: "+18%", direction: "up", positive: true }}
          hint="quarter to date"
        />
        <KpiCard
          label="CSAT"
          value={sla.summary ? `${sla.summary.csat} / 5` : "—"}
          icon={Sparkles}
          loading={loading}
          trend={{ value: "+0.1", direction: "up", positive: true }}
          hint="closed tickets"
        />
      </div>

      <AiInsight source="iSLA · generated Jul 17, 06:00 ET">
        Compliance is trending up for the fourth consecutive month. Claims
        Processing drives 2 of the 3 open breach risks — the claim-status API
        fix scheduled for the Jul 24 patch window is expected to clear both.
      </AiInsight>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* left column */}
        <div className="space-y-4 lg:col-span-2">
          <ChartCard
            title="SLA compliance trend"
            subtitle="Portfolio-wide, against the 95% contractual floor"
            loading={loading}
            height={240}
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sla.trend} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="slaFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={CHART.red} stopOpacity={0.16} />
                    <stop offset="100%" stopColor={CHART.red} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis domain={[90, 100]} tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
                <Tooltip {...TOOLTIP_STYLE} />
                <ReferenceLine
                  y={95}
                  stroke={CHART.amber}
                  strokeDasharray="4 4"
                  label={{ value: "Target 95%", position: "insideBottomRight", fill: CHART.amber, fontSize: 11 }}
                />
                <Area
                  type="monotone"
                  dataKey="overall"
                  name="Compliance %"
                  stroke={CHART.red}
                  strokeWidth={2}
                  fill="url(#slaFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard
            title="How work got done"
            subtitle="Monthly ticket volume by resolution mode"
            loading={prodLoading}
            height={240}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prod.volumeTrend} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
                <Tooltip {...TOOLTIP_STYLE} />
                <Legend wrapperStyle={LEGEND_STYLE} iconType="circle" iconSize={8} />
                <Bar dataKey="autoResolved" name="Auto-resolved" stackId="v" fill={CHART.green} />
                <Bar dataKey="aiAssisted" name="AI-assisted" stackId="v" fill={CHART.blue} />
                <Bar dataKey="manual" name="Manual" stackId="v" fill={CHART.slate} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* right column */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Needs your attention</CardTitle>
              <CardDescription>Risks and decisions for service owners</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <>
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </>
              ) : (
                <>
                  {openRisks.slice(0, 2).map((r) => (
                    <Link
                      key={r.id}
                      to="/sla"
                      className="block rounded-md border px-3 py-2.5 transition-colors hover:bg-secondary/60"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold">
                          {r.metric} · {r.application}
                        </p>
                        <StatusBadge status="at-risk" />
                      </div>
                      <p className="mt-1 text-[11.5px] text-muted-foreground">
                        Predicted breach in {r.predictedIn} · {r.confidence}% confidence
                      </p>
                    </Link>
                  ))}
                  {imp.meetings[0] && (
                    <div className="rounded-md border px-3 py-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold">{imp.meetings[0].name}</p>
                        <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                      <p className="mt-1 text-[11.5px] text-muted-foreground">
                        {imp.meetings[0].next}
                      </p>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          <ChartCard
            title="Resolution mix"
            subtitle="Latest month"
            loading={prodLoading}
            height={200}
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={mixData}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={52}
                  outerRadius={76}
                  paddingAngle={2}
                  strokeWidth={0}
                >
                  {mixData.map((m) => (
                    <Cell key={m.name} fill={m.color} />
                  ))}
                </Pie>
                <Tooltip {...TOOLTIP_STYLE} />
                <Legend wrapperStyle={LEGEND_STYLE} iconType="circle" iconSize={8} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <Card>
            <CardHeader>
              <CardTitle>Value this quarter</CardTitle>
              <CardDescription>Returned to Canada Life</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="num text-lg font-semibold">
                  {prod.summary ? fmtNum(prod.summary.hoursSaved) : "—"}
                </p>
                <p className="text-[10.5px] text-muted-foreground">hours saved</p>
              </div>
              <div>
                <p className="num text-lg font-semibold">
                  {imp.summary ? fmtCad(imp.summary.benefitsCad) : "—"}
                </p>
                <p className="text-[10.5px] text-muted-foreground">benefits YTD</p>
              </div>
              <div>
                <p className="num text-lg font-semibold">
                  {imp.summary ? imp.summary.deliveredYtd : "—"}
                </p>
                <p className="text-[10.5px] text-muted-foreground">improvements shipped</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* portfolio health */}
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Portfolio health</CardTitle>
            <CardDescription>
              Application-level service view · {sla.portfolio.length} apps under AMS
            </CardDescription>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Bot className="h-3.5 w-3.5" />
            Risk column forecast by iSLA
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-48 w-full" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application</TableHead>
                  <TableHead>Portfolio</TableHead>
                  <TableHead>Criticality</TableHead>
                  <TableHead className="text-right">SLA</TableHead>
                  <TableHead className="text-right">XLA</TableHead>
                  <TableHead className="text-right">Open P1 / P2</TableHead>
                  <TableHead>Trend</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sla.portfolio.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">{app.name}</TableCell>
                    <TableCell className="text-muted-foreground">{app.portfolio}</TableCell>
                    <TableCell className="text-muted-foreground">{app.tier}</TableCell>
                    <TableCell className="num text-right">{app.sla.toFixed(1)}%</TableCell>
                    <TableCell className="num text-right">{app.xla}</TableCell>
                    <TableCell className="num text-right">
                      {app.openP1} / {app.openP2}
                    </TableCell>
                    <TableCell>
                      <TrendIndicator
                        trend={{
                          value: `${app.deltaPts > 0 ? "+" : ""}${app.deltaPts} pts`,
                          direction: app.deltaPts > 0 ? "up" : app.deltaPts < 0 ? "down" : "flat",
                          positive: app.deltaPts >= 0,
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={app.risk} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
