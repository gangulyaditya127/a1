import { useEffect } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Bot, Check, Clock, ThumbsUp, X, Zap } from "lucide-react";
import { AiInsight } from "@/shared/components/AiInsight";
import { ChartCard } from "@/shared/components/ChartCard";
import { KpiCard } from "@/shared/components/KpiCard";
import { PageHeader } from "@/shared/components/PageHeader";
import { StatusBadge } from "@/shared/components/StatusBadge";
import { Badge } from "@/shared/ui/badge";
import { Button } from "@/shared/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/shared/ui/card";
import { Progress } from "@/shared/ui/progress";
import { Skeleton } from "@/shared/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/shared/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import { AXIS_TICK, CHART, LEGEND_STYLE, TOOLTIP_STYLE } from "@/shared/lib/chart";
import { fmtNum } from "@/shared/lib/utils";
import { decide, fetchAgentsData } from "@/application/governance/state/agentsSlice";
import { useAppDispatch, useAppSelector } from "@/app/hooks";

const USE_CASE_LABEL: Record<string, string> = {
  S1: "S1 · Incident Triage",
  S2: "S2 · Problem & RCA",
  S5: "S5 · Predictive Ops",
  S6: "S6 · Governance",
};

export function AgentPerformancePage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const agents = useAppSelector((s) => s.governance.agents);

  useEffect(() => {
    dispatch(fetchAgentsData(range));
  }, [dispatch, range]);

  const loading = agents.status !== "succeeded";

  const live = agents.roster.filter((a) => a.status === "live").length;
  const totalActions = agents.roster.reduce((n, a) => n + a.actions, 0);
  const totalHours = agents.roster.reduce((n, a) => n + a.hoursSaved, 0);
  const weightedAcceptance = totalActions
    ? Math.round(
        agents.roster.reduce((n, a) => n + a.acceptancePct * a.actions, 0) /
          totalActions
      )
    : 0;

  const hitlData = agents.hitl
    ? [
        { name: "Approved as-is", value: agents.hitl.approved, color: CHART.green },
        { name: "Approved with edits", value: agents.hitl.modified, color: CHART.blue },
        { name: "Rejected", value: agents.hitl.rejected, color: CHART.red },
      ]
    : [];

  const valueByAgent = [...agents.roster]
    .sort((a, b) => b.hoursSaved - a.hoursSaved)
    .map((a) => ({ name: a.name, hours: a.hoursSaved }));

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="AI agent productivity"
        description="What the ARE agents are doing across S1–S6, how often humans accept their work, and the value they return."
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <KpiCard
          label="Agents live"
          value={loading ? "—" : `${live} of ${agents.roster.length}`}
          icon={Bot}
          loading={loading}
          hint="rest in pilot"
        />
        <KpiCard
          label="Agent actions"
          value={loading ? "—" : fmtNum(totalActions)}
          icon={Zap}
          loading={loading}
          trend={{ value: "+8% m/m", direction: "up", positive: true }}
        />
        <KpiCard
          label="Human acceptance"
          value={loading ? "—" : `${weightedAcceptance}%`}
          icon={ThumbsUp}
          loading={loading}
          hint="weighted by volume"
        />
        <KpiCard
          label="Automation success"
          value={loading ? "—" : "96.5%"}
          icon={Check}
          loading={loading}
          hint="completed without rework"
        />
        <KpiCard
          label="Hours returned"
          value={loading ? "—" : fmtNum(totalHours)}
          icon={Clock}
          loading={loading}
          hint="by agents, this period"
        />
      </div>

      <Tabs defaultValue="roster">
        <TabsList>
          <TabsTrigger value="roster">Agent roster</TabsTrigger>
          <TabsTrigger value="hitl">
            Human-in-the-loop
            {agents.decisions.some((d) => d.state === "pending") && (
              <span className="grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[9.5px] font-bold text-white">
                {agents.decisions.filter((d) => d.state === "pending").length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="value">Value attribution</TabsTrigger>
        </TabsList>

        {/* ----------------------------- Roster tab ---------------------------- */}
        <TabsContent value="roster" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Roster</CardTitle>
              <CardDescription>All nine ARE agents across the four use cases</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-64 w-full" />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Agent</TableHead>
                      <TableHead>Use case</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                      <TableHead className="w-[170px]">Acceptance</TableHead>
                      <TableHead className="text-right">Success</TableHead>
                      <TableHead className="text-right">Hours saved</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agents.roster.map((a) => (
                      <TableRow key={a.id}>
                        <TableCell className="font-medium">{a.name}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="whitespace-nowrap">
                            {USE_CASE_LABEL[a.useCase]}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={a.status} />
                        </TableCell>
                        <TableCell className="num text-right">{fmtNum(a.actions)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={a.acceptancePct}
                              className="h-1.5 w-20"
                              indicatorClassName={a.acceptancePct >= 90 ? "bg-emerald-500" : "bg-sky-500"}
                            />
                            <span className="num text-xs font-medium">{a.acceptancePct}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="num text-right">{a.successPct.toFixed(1)}%</TableCell>
                        <TableCell className="num text-right">{fmtNum(a.hoursSaved)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <ChartCard
            title="Adoption trend"
            subtitle="Agent actions per month (thousands)"
            loading={loading}
            height={210}
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={agents.adoptionTrend} margin={{ top: 6, right: 8, left: -24, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
                <Tooltip {...TOOLTIP_STYLE} />
                <Line type="monotone" dataKey="actions" name="Actions (K)" stroke={CHART.red} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </TabsContent>

        {/* ----------------------------- HITL tab ------------------------------ */}
        <TabsContent value="hitl" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3">
            <ChartCard
              title="Review outcomes"
              subtitle="Human decisions on agent proposals"
              loading={loading}
              height={220}
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={hitlData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={74}
                    paddingAngle={2}
                    strokeWidth={0}
                  >
                    {hitlData.map((h) => (
                      <Cell key={h.name} fill={h.color} />
                    ))}
                  </Pie>
                  <Tooltip {...TOOLTIP_STYLE} />
                  <Legend wrapperStyle={LEGEND_STYLE} iconType="circle" iconSize={8} />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Awaiting your review</CardTitle>
                <CardDescription>
                  Agent-proposed actions that need a human decision · decisions feed
                  the General governance audit trail
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {loading ? (
                  <Skeleton className="h-40 w-full" />
                ) : (
                  agents.decisions.map((d) => (
                    <div key={d.id} className="rounded-md border px-3 py-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Bot className="h-3.5 w-3.5 text-brand" />
                          <span className="text-xs font-semibold">{d.agent}</span>
                          <span className="text-[10.5px] text-muted-foreground">{d.when}</span>
                        </div>
                        <StatusBadge status={d.state} />
                      </div>
                      <p className="mt-1.5 text-xs text-muted-foreground">{d.summary}</p>
                      {d.state === "pending" && (
                        <div className="mt-2.5 flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => dispatch(decide({ id: d.id, decision: "approved" }))}
                          >
                            <Check className="h-3.5 w-3.5" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => dispatch(decide({ id: d.id, decision: "rejected" }))}
                          >
                            <X className="h-3.5 w-3.5" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          <AiInsight source="General track · feedback loop">
            Every approval, edit or rejection is logged with rationale and used
            to retrain the agent — acceptance has climbed 6 pts since March as a
            result.
          </AiInsight>
        </TabsContent>

        {/* ----------------------------- Value tab ----------------------------- */}
        <TabsContent value="value" className="space-y-4">
          <ChartCard
            title="Hours returned by agent"
            subtitle="This period, all use cases"
            loading={loading}
            height={300}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={valueByAgent}
                layout="vertical"
                margin={{ top: 0, right: 24, left: 8, bottom: 0 }}
              >
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis
                  type="category"
                  dataKey="name"
                  tick={{ ...AXIS_TICK, fill: CHART.ink }}
                  axisLine={false}
                  tickLine={false}
                  width={190}
                />
                <Tooltip {...TOOLTIP_STYLE} />
                <Bar dataKey="hours" name="Hours saved" fill={CHART.red} radius={[0, 4, 4, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <AiInsight source="Performance & Productivity agent">
            Resolution Recommender returns the most hours per action on complex
            P2s; Self-Healing Executor delivers the most consistent value on
            batch operations. Scaling the Comms Orchestrator out of pilot is the
            highest-leverage next step (est. +120 h/qtr).
          </AiInsight>
        </TabsContent>
      </Tabs>
    </div>
  );
}
