import type { MonthPoint, TimeRange } from "@/application/governance/types";
import * as sla from "@/application/governance/data/slaData";
import * as prod from "@/application/governance/data/productivityData";
import * as agents from "@/application/governance/data/agentsData";
import * as imp from "@/application/governance/data/improvementData";

/**
 * Mock service layer.
 * Every fetcher returns a Promise with realistic latency so the UI's loading
 * states are honest. Replace these with real API calls (same shapes) when the
 * portal is wired to live sources — the slices won't need to change.
 */

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

const RANGE_MONTHS: Record<TimeRange, number> = { "3m": 3, "6m": 6, "12m": 12 };

export function sliceMonths(series: MonthPoint[], range: TimeRange): MonthPoint[] {
  return series.slice(-RANGE_MONTHS[range]);
}

export async function fetchSla(range: TimeRange) {
  await delay(450);
  return {
    summary: sla.slaSummary,
    trend: sliceMonths(sla.slaTrend, range),
    trendByPriority: sliceMonths(sla.slaTrendByPriority, range),
    csatTrend: sliceMonths(sla.csatTrend, range),
    metrics: sla.slaMetrics,
    xlaDrivers: sla.xlaDrivers,
    risks: sla.breachRisks,
    portfolio: sla.portfolioHealth,
  };
}

export async function fetchProductivity(range: TimeRange) {
  await delay(500);
  return {
    summary: prod.productivitySummary,
    volumeTrend: sliceMonths(prod.volumeTrend, range),
    savingsTrend: sliceMonths(prod.savingsTrend, range),
    shiftLeft: prod.shiftLeft,
    aging: prod.agingBuckets,
    topAutomations: prod.topAutomations,
  };
}

export async function fetchAgents(range: TimeRange) {
  await delay(420);
  return {
    roster: agents.agentRoster,
    adoptionTrend: sliceMonths(agents.adoptionTrend, range),
    hitl: agents.hitlSummary,
    decisions: agents.pendingDecisions,
  };
}

export async function fetchImprovement(range: TimeRange) {
  await delay(380);
  return {
    summary: imp.improvementSummary,
    benefitsTrend: sliceMonths(imp.benefitsTrend, range),
    initiatives: imp.initiatives,
    meetings: imp.meetings,
    actions: imp.govActions,
    recommendations: imp.recommendations,
  };
}

export async function generateReportRemote(id: string) {
  await delay(1400);
  return { id, generatedAt: new Date().toISOString() };
}

export async function regenerateNarrativeRemote(currentIndex: number, pool: string[]) {
  await delay(1100);
  const next = (currentIndex + 1) % pool.length;
  return { index: next, text: pool[next], generatedAt: new Date().toISOString() };
}
