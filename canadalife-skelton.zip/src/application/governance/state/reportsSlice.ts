import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { ReportDef, ReportSubscription } from "@/application/governance/types";
import {
  NARRATIVES,
  initialNarrative,
  reports as seedReports,
  subscriptions as seedSubs,
} from "@/application/governance/data/reportsData";
import {
  generateReportRemote,
  regenerateNarrativeRemote,
} from "@/application/governance/services/api";

interface ReportsState {
  reports: ReportDef[];
  subscriptions: ReportSubscription[];
  narrative: {
    text: string;
    generatedAt: string;
    index: number;
    status: "idle" | "generating";
  };
}

const initialState: ReportsState = {
  reports: seedReports,
  subscriptions: seedSubs,
  narrative: { ...initialNarrative, index: 0, status: "idle" },
};

export const generateReport = createAsyncThunk(
  "reports/generate",
  async (id: string) => generateReportRemote(id)
);

export const regenerateNarrative = createAsyncThunk(
  "reports/narrative",
  async (currentIndex: number) =>
    regenerateNarrativeRemote(currentIndex, NARRATIVES)
);

const reportsSlice = createSlice({
  name: "reports",
  initialState,
  reducers: {
    toggleSubscription(state, action: PayloadAction<string>) {
      const s = state.subscriptions.find((x) => x.id === action.payload);
      if (s) s.active = !s.active;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(generateReport.pending, (state, action) => {
        const r = state.reports.find((x) => x.id === action.meta.arg);
        if (r) r.state = "generating";
      })
      .addCase(generateReport.fulfilled, (state, action) => {
        const r = state.reports.find((x) => x.id === action.payload.id);
        if (r) {
          r.state = "ready";
          r.lastGenerated = action.payload.generatedAt;
        }
      })
      .addCase(regenerateNarrative.pending, (state) => {
        state.narrative.status = "generating";
      })
      .addCase(regenerateNarrative.fulfilled, (state, action) => {
        state.narrative = {
          text: action.payload.text,
          generatedAt: action.payload.generatedAt,
          index: action.payload.index,
          status: "idle",
        };
      });
  },
});

export const { toggleSubscription } = reportsSlice.actions;
export default reportsSlice.reducer;
