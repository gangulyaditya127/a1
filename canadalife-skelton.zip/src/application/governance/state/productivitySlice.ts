import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type {
  AgingBucket,
  AutomationRecord,
  MonthPoint,
  ProductivitySummary,
  ShiftLeftRow,
  TimeRange,
} from "@/application/governance/types";
import { fetchProductivity } from "@/application/governance/services/api";

interface ProductivityState {
  status: "idle" | "loading" | "succeeded";
  summary: ProductivitySummary | null;
  volumeTrend: MonthPoint[];
  savingsTrend: MonthPoint[];
  shiftLeft: ShiftLeftRow[];
  aging: AgingBucket[];
  topAutomations: AutomationRecord[];
}

const initialState: ProductivityState = {
  status: "idle",
  summary: null,
  volumeTrend: [],
  savingsTrend: [],
  shiftLeft: [],
  aging: [],
  topAutomations: [],
};

export const fetchProductivityData = createAsyncThunk(
  "productivity/fetch",
  async (range: TimeRange) => fetchProductivity(range)
);

const productivitySlice = createSlice({
  name: "productivity",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProductivityData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchProductivityData.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.volumeTrend = action.payload.volumeTrend;
        state.savingsTrend = action.payload.savingsTrend;
        state.shiftLeft = action.payload.shiftLeft;
        state.aging = action.payload.aging;
        state.topAutomations = action.payload.topAutomations;
      });
  },
});

export default productivitySlice.reducer;
