import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type {
  AgentDecision,
  AgentRow,
  HitlSummary,
  MonthPoint,
  TimeRange,
} from "@/application/governance/types";
import { fetchAgents } from "@/application/governance/services/api";

interface AgentsState {
  status: "idle" | "loading" | "succeeded";
  roster: AgentRow[];
  adoptionTrend: MonthPoint[];
  hitl: HitlSummary | null;
  decisions: AgentDecision[];
}

const initialState: AgentsState = {
  status: "idle",
  roster: [],
  adoptionTrend: [],
  hitl: null,
  decisions: [],
};

export const fetchAgentsData = createAsyncThunk(
  "agents/fetch",
  async (range: TimeRange) => fetchAgents(range)
);

const agentsSlice = createSlice({
  name: "agents",
  initialState,
  reducers: {
    /** Human-in-the-loop decision on a pending agent action. */
    decide(
      state,
      action: PayloadAction<{ id: string; decision: "approved" | "rejected" }>
    ) {
      const d = state.decisions.find((x) => x.id === action.payload.id);
      if (d && d.state === "pending") {
        d.state = action.payload.decision;
        if (state.hitl) {
          if (action.payload.decision === "approved") state.hitl.approved += 1;
          else state.hitl.rejected += 1;
        }
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAgentsData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchAgentsData.fulfilled, (state, action) => {
        const decided = new Map(
          state.decisions
            .filter((d) => d.state !== "pending")
            .map((d) => [d.id, d.state] as const)
        );
        state.status = "succeeded";
        state.roster = action.payload.roster;
        state.adoptionTrend = action.payload.adoptionTrend;
        state.hitl = { ...action.payload.hitl };
        state.decisions = action.payload.decisions.map((d) => ({
          ...d,
          state: decided.get(d.id) ?? d.state,
        }));
      });
  },
});

export const { decide } = agentsSlice.actions;
export default agentsSlice.reducer;
