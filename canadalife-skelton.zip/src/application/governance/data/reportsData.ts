import type { ReportDef, ReportSubscription } from "@/application/governance/types";

export const reports: ReportDef[] = [
  {
    id: "rep1",
    name: "Monthly Service Report — June 2026",
    description: "Full-service view: SLA/XLA, volumes, automation savings, improvement pipeline and commentary.",
    audience: "Service owners",
    frequency: "Monthly",
    lastGenerated: "2026-07-03T06:00:00",
    state: "ready",
  },
  {
    id: "rep2",
    name: "Weekly SLA statement",
    description: "Metric-by-metric compliance with breach detail and credits position for the week.",
    audience: "Ops leads",
    frequency: "Weekly",
    lastGenerated: "2026-07-14T06:00:00",
    state: "ready",
  },
  {
    id: "rep3",
    name: "QBR pack — Q2 2026",
    description: "Executive quarter-in-review: outcomes, value realized, risks and next-quarter plan.",
    audience: "Executive sponsors",
    frequency: "Quarterly",
    lastGenerated: null,
    state: "scheduled",
  },
  {
    id: "rep4",
    name: "Transformation scorecard",
    description: "Automation coverage, shift-left, agent adoption and benefits versus the business case.",
    audience: "Executive sponsors",
    frequency: "Monthly",
    lastGenerated: "2026-07-05T06:00:00",
    state: "ready",
  },
  {
    id: "rep5",
    name: "Audit & compliance extract",
    description: "Agent action log, approvals and rollbacks for the period — supports the General governance track.",
    audience: "Risk & compliance",
    frequency: "On demand",
    lastGenerated: "2026-06-28T09:30:00",
    state: "ready",
  },
];

export const NARRATIVES: string[] = [
  "June closed at 96.8% SLA compliance (+0.6 pts m/m) with 34 of 36 metrics met. Automation resolved or assisted 51% of volume, returning about 1,240 hours this quarter. Two watch items: P2 resolution on Claims Processing and the Payments Hub batch window — both have fixes scheduled inside July's patch window. Improvement pipeline delivered CA$1.41M in cumulative benefits, tracking 12% ahead of the business case.",
  "Service performance strengthened again in June: compliance rose to 96.8% and the experience score reached 87 (+2). Agent adoption grew to ~12.8K actions/month with a 92% human-acceptance rate. Claims Processing remains the main SLA risk; the claim-status API fix lands Jul 24. Recommend confirming the Q3 automation pipeline at the Aug 6 MBR to hold the savings trajectory.",
];

export const initialNarrative = {
  text: NARRATIVES[0],
  generatedAt: "2026-07-14T06:00:00",
};

export const subscriptions: ReportSubscription[] = [
  { id: "s1", report: "Monthly Service Report", recipients: "Service owners (8)", cadence: "1st business day", nextRun: "Aug 4", active: true },
  { id: "s2", report: "Weekly SLA statement", recipients: "Ops distribution (23)", cadence: "Mondays 06:00 ET", nextRun: "Jul 20", active: true },
  { id: "s3", report: "Transformation scorecard", recipients: "Exec sponsors (5)", cadence: "1st Friday", nextRun: "Aug 7", active: true },
  { id: "s4", report: "Audit & compliance extract", recipients: "Risk & compliance (4)", cadence: "On demand", nextRun: "—", active: false },
];
