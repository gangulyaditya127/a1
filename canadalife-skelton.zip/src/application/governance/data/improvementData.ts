import type {
  GovAction,
  GovMeeting,
  ImprovementSummary,
  Initiative,
  MonthPoint,
  Recommendation,
} from "@/application/governance/types";
import { MONTHS } from "@/application/governance/data/slaData";

export const improvementSummary: ImprovementSummary = {
  inFlight: 12,
  deliveredYtd: 18,
  benefitsCad: 1410000,
  repeatReductionPct: 27,
};

/** Cumulative benefits realized (CA$ thousands). */
export const benefitsTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  benefits: [80, 170, 270, 390, 520, 660, 790, 930, 1060, 1180, 1290, 1410][i],
}));

export const initiatives: Initiative[] = [
  { id: "ci1", title: "Automate access & password service requests", category: "Automation", owner: "TCS", status: "delivered", impact: "620 h/yr returned", eta: "Done · Q1 2026" },
  { id: "ci2", title: "Self-healing for EOD batch failures", category: "Reliability", owner: "TCS", status: "in-progress", impact: "≈180 h/qtr · 40% fewer P2s", eta: "Aug 2026" },
  { id: "ci3", title: "Shift claims triage from L2 to L1", category: "Process", owner: "Joint", status: "in-progress", impact: "12% faster resolution", eta: "Sep 2026" },
  { id: "ci4", title: "Known-error base refresh (top 50 errors)", category: "Knowledge", owner: "TCS", status: "in-progress", impact: "MTTR −9%", eta: "Jul 2026" },
  { id: "ci5", title: "Chatbot deflection for enrolment FAQs", category: "Experience", owner: "Canada Life", status: "idea", impact: "≈900 tickets/yr deflected", eta: "Q4 2026" },
  { id: "ci6", title: "Retire 34 legacy report jobs", category: "Simplification", owner: "Joint", status: "idea", impact: "CA$45K/yr run cost", eta: "Q4 2026" },
  { id: "ci7", title: "Proactive certificate-expiry automation", category: "Reliability", owner: "TCS", status: "delivered", impact: "Zero cert-related P1s YTD", eta: "Done · Q1 2026" },
  { id: "ci8", title: "Observability rollout to Wealth apps", category: "Reliability", owner: "TCS", status: "in-progress", impact: "Earlier detection (feeds S5)", eta: "Oct 2026" },
];

export const meetings: GovMeeting[] = [
  { id: "gm1", name: "Weekly Service Review", cadence: "Weekly", next: "Tue, Jul 21 · 10:00 ET", forum: "Ops leads (TCS + Canada Life)" },
  { id: "gm2", name: "AI Governance Council", cadence: "Monthly", next: "Thu, Jul 30 · 14:00 ET", forum: "Joint — General track" },
  { id: "gm3", name: "Monthly Business Review", cadence: "Monthly", next: "Thu, Aug 6 · 11:00 ET", forum: "Service owners" },
  { id: "gm4", name: "Quarterly Business Review", cadence: "Quarterly", next: "Tue, Sep 15 · 13:00 ET", forum: "Executive sponsors" },
];

export const govActions: GovAction[] = [
  { id: "ga1", action: "Approve Jul 24 patch window for the Claims API fix", owner: "Canada Life", due: "Jul 24", state: "open" },
  { id: "ga2", action: "Share Q3 automation pipeline for sign-off", owner: "TCS", due: "Jul 31", state: "open" },
  { id: "ga3", action: "Confirm QBR agenda and attendee list", owner: "Joint", due: "Aug 28", state: "open" },
  { id: "ga4", action: "Publish June MSR to portfolio leads", owner: "TCS", due: "Jul 8", state: "closed" },
];

export const recommendations: Recommendation[] = [
  {
    id: "rec1",
    title: "Extend self-healing to the Claims document queue",
    source: "Self-Healing Executor",
    rationale: "Queue stalls caused 14 P3s in the last 90 days; runbook match confidence 93%.",
    impact: "≈60 h/qtr",
    category: "Reliability",
  },
  {
    id: "rec2",
    title: "Auto-draft problem records for repeat P2 clusters",
    source: "RCA Agent",
    rationale: "3 clusters recur ≥4× per quarter without a linked problem ticket.",
    impact: "Repeat incidents −15%",
    category: "Process",
  },
  {
    id: "rec3",
    title: "Tighten P3 triage rules ahead of enrolment season",
    source: "Intelligent Triage",
    rationale: "8% of GroupNet P3s were re-routed during last September's spike.",
    impact: "Response compliance +1.1 pts",
    category: "Process",
  },
];
