import type {
  AgentDecision,
  AgentRow,
  HitlSummary,
  MonthPoint,
} from "@/application/governance/types";
import { MONTHS } from "@/application/governance/data/slaData";

/**
 * The nine ARE agents across the four use cases.
 * Actions / hours reflect the selected reporting window (mock).
 */
export const agentRoster: AgentRow[] = [
  { id: "g1", name: "Intelligent Triage", useCase: "S1", status: "live", actions: 4120, acceptancePct: 94, successPct: 97.8, hoursSaved: 210 },
  { id: "g2", name: "Resolution Recommender", useCase: "S1", status: "live", actions: 3480, acceptancePct: 91, successPct: 95.4, hoursSaved: 260 },
  { id: "g3", name: "Comms Orchestrator", useCase: "S1", status: "pilot", actions: 640, acceptancePct: 88, successPct: 99.0, hoursSaved: 45 },
  { id: "g4", name: "RCA Agent", useCase: "S2", status: "live", actions: 182, acceptancePct: 86, successPct: 92.5, hoursSaved: 120 },
  { id: "g5", name: "Problem Record Creator", useCase: "S2", status: "live", actions: 210, acceptancePct: 95, successPct: 98.6, hoursSaved: 35 },
  { id: "g6", name: "Event Correlator & Forecaster", useCase: "S5", status: "live", actions: 2940, acceptancePct: 90, successPct: 96.2, hoursSaved: 95 },
  { id: "g7", name: "Self-Healing Executor", useCase: "S5", status: "live", actions: 1036, acceptancePct: 96, successPct: 97.4, hoursSaved: 180 },
  { id: "g8", name: "iSLA Reporting", useCase: "S6", status: "live", actions: 96, acceptancePct: 97, successPct: 99.1, hoursSaved: 60 },
  { id: "g9", name: "CI Recommender", useCase: "S6", status: "pilot", actions: 58, acceptancePct: 84, successPct: 93.0, hoursSaved: 25 },
];

/** Agent actions per month, in thousands. */
export const adoptionTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  actions: [2.1, 2.6, 3.4, 4.2, 5.1, 6.3, 7.4, 8.6, 9.8, 10.9, 11.8, 12.8][i],
}));

export const hitlSummary: HitlSummary = {
  approved: 1412,
  modified: 236,
  rejected: 74,
};

export const pendingDecisions: AgentDecision[] = [
  {
    id: "d1",
    agent: "Self-Healing Executor",
    summary:
      "Restart Payments Hub EOD batch step 4 (runbook RB-118) — projected to recover tonight's window.",
    when: "12 min ago",
    state: "pending",
  },
  {
    id: "d2",
    agent: "Resolution Recommender",
    summary:
      "Apply KB-2041 (claim-status cache flush) to INC1049233 — 93% match with 14 prior resolutions.",
    when: "38 min ago",
    state: "pending",
  },
  {
    id: "d3",
    agent: "Problem Record Creator",
    summary:
      "Open a problem record for the GroupNet login-timeout cluster (11 incidents, 3 weeks).",
    when: "1 h ago",
    state: "pending",
  },
];
