import type {
  AgingBucket,
  AutomationRecord,
  MonthPoint,
  ProductivitySummary,
  ShiftLeftRow,
} from "@/application/governance/types";
import { MONTHS } from "@/application/governance/data/slaData";

export const productivitySummary: ProductivitySummary = {
  ticketsHandled: 4812,
  avgResolutionHrs: 6.2,
  avgResolutionDeltaPct: -18,
  automationCoveragePct: 44,
  hoursSaved: 1240,
  savingsCad: 412000,
  backlog: 312,
  backlogDeltaPct: -12,
};

/** Monthly ticket volume split by how the work got done. */
export const volumeTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  manual: [520, 505, 488, 496, 452, 438, 421, 402, 378, 356, 330, 310][i],
  aiAssisted: [180, 192, 205, 214, 228, 241, 252, 264, 276, 288, 295, 300][i],
  autoResolved: [60, 72, 84, 92, 108, 122, 138, 152, 168, 184, 198, 210][i],
}));

/** Cumulative effort returned to the business (hours). */
export const savingsTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  hours: [120, 260, 420, 610, 830, 1080, 1370, 1690, 2040, 2430, 2860, 3320][i],
}));

export const shiftLeft: ShiftLeftRow[] = [
  { level: "L0 · Self-serve & auto", pct: 18, deltaPts: 6 },
  { level: "L1 · Service desk", pct: 34, deltaPts: 3 },
  { level: "L2 · App support", pct: 31, deltaPts: -5 },
  { level: "L3 · Engineering", pct: 17, deltaPts: -4 },
];

export const agingBuckets: AgingBucket[] = [
  { bucket: "0–3 days", count: 190 },
  { bucket: "4–7 days", count: 69 },
  { bucket: "8–14 days", count: 34 },
  { bucket: "> 14 days", count: 19 },
];

export const topAutomations: AutomationRecord[] = [
  { id: "t1", name: "Password & access resets", tickets: 1860, hoursSaved: 620, successPct: 99.2 },
  { id: "t2", name: "Batch job restart (EOD chain)", tickets: 412, hoursSaved: 310, successPct: 97.1 },
  { id: "t3", name: "Disk & queue cleanup", tickets: 388, hoursSaved: 96, successPct: 98.4 },
  { id: "t4", name: "Claim-status sync retry", tickets: 296, hoursSaved: 88, successPct: 96.8 },
  { id: "t5", name: "Certificate renewal", tickets: 240, hoursSaved: 120, successPct: 100 },
];
