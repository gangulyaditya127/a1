import {
  Bot,
  FileText,
  Gauge,
  LayoutDashboard,
  Lightbulb,
  Zap,
} from "lucide-react";
import type { AppManifest } from "@/shared/types";
import { OverviewPage } from "./pages/OverviewPage";
import { SlaCompliancePage } from "./pages/SlaCompliancePage";
import { ProductivityPage } from "./pages/ProductivityPage";
import { AgentPerformancePage } from "./pages/AgentPerformancePage";
import { ImprovementPage } from "./pages/ImprovementPage";
import { ReportsPage } from "./pages/ReportsPage";

/**
 * S6 · Governance & Reporting — the fully built application.
 * Routes are flat at the root (/sla, /productivity, …) per the portal's
 * URL scheme; this manifest is the single source of truth for them.
 */
export const governanceApp: AppManifest = {
  id: "governance",
  code: "S6",
  name: "Governance & Reporting",
  description:
    "The service owner's command centre: SLA & XLA compliance, productivity and savings, AI-agent performance, continuous improvement and executive reporting.",
  icon: Gauge,
  entry: "/governance",
  status: "live",
  usesTimeRange: true,
  stats: [
    { label: "SLA compliance", value: "96.8%" },
    { label: "Savings QTD", value: "CA$412K" },
    { label: "Agent actions / mo", value: "12.8K" },
  ],
  paths: ["/governance", "/sla", "/productivity", "/agents", "/improvement", "/reports"],
  nav: [
    { label: "Overview", to: "/governance", icon: LayoutDashboard },
    { label: "SLA & XLA", to: "/sla", icon: Gauge },
    { label: "Productivity", to: "/productivity", icon: Zap },
    { label: "AI Agents", to: "/agents", icon: Bot },
    { label: "Improvement", to: "/improvement", icon: Lightbulb },
    { label: "Reports", to: "/reports", icon: FileText },
  ],
  routes: [
    { path: "governance", element: <OverviewPage /> },
    { path: "sla", element: <SlaCompliancePage /> },
    { path: "productivity", element: <ProductivityPage /> },
    { path: "agents", element: <AgentPerformancePage /> },
    { path: "improvement", element: <ImprovementPage /> },
    { path: "reports", element: <ReportsPage /> },
  ],
};
