import type { UseCaseDef } from "@/shared/types";

/** Content distilled from the Canada Life table-top planner (v0.2). */
export const useCase: UseCaseDef = {
  code: "S2",
  title: "Problem Management & Root Cause",
  tagline: "Find the patterns, fix the cause, stop the repeats",
  status: "In discovery",
  lead: "Debasish (TCS)",
  scenario:
    "Recurring incidents hide a common cause. Agents detect the pattern, run root-cause discovery across logs and changes, draft the problem record, recommend the permanent fix and keep stakeholders aligned until it ships.",
  agents: ["RCA Agent", "Problem Record Creator"],
  journey: [
    { step: "Pattern detection", detail: "Cluster related incidents across apps and time." },
    { step: "Root-cause discovery", detail: "Correlate logs, changes and topology to a probable cause." },
    { step: "Knowledge & insight", detail: "Enrich the known-error base automatically." },
    { step: "Permanent-fix recommendation", detail: "Options with effort, risk and expected benefit." },
    { step: "Stakeholder alignment", detail: "Problem records and updates drafted for review." },
    { step: "Continuous learning", detail: "Fix outcomes sharpen future RCA." },
  ],
  outcomes: [
    "Faster, evidence-backed RCA",
    "Fewer repeat incidents quarter over quarter",
    "Lower cost of poor quality",
    "A living known-error base",
  ],
  plannedModules: [
    { title: "Recurrence clusters", description: "Incident families ranked by business impact." },
    { title: "RCA workbench", description: "Agent evidence trail: logs, changes, hypotheses." },
    { title: "Fix tracker", description: "Permanent fixes from recommendation to deployment." },
    { title: "Known-error base", description: "Auto-maintained errors with workarounds." },
  ],
};
