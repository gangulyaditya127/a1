import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type {
  GovAction,
  GovMeeting,
  ImprovementSummary,
  Initiative,
  InitiativeStatus,
  MonthPoint,
  Recommendation,
  TimeRange,
} from "@/types";
import { fetchImprovement } from "@/services/mockApi";

interface ImprovementState {
  status: "idle" | "loading" | "succeeded";
  summary: ImprovementSummary | null;
  benefitsTrend: MonthPoint[];
  initiatives: Initiative[];
  meetings: GovMeeting[];
  actions: GovAction[];
  recommendations: Recommendation[];
  /** ids of recommendations the user has dealt with (survives re-fetch) */
  handledRecs: string[];
  addedInitiatives: Initiative[];
}

const initialState: ImprovementState = {
  status: "idle",
  summary: null,
  benefitsTrend: [],
  initiatives: [],
  meetings: [],
  actions: [],
  recommendations: [],
  handledRecs: [],
  addedInitiatives: [],
};

export const fetchImprovementData = createAsyncThunk(
  "improvement/fetch",
  async (range: TimeRange) => fetchImprovement(range)
);

const improvementSlice = createSlice({
  name: "improvement",
  initialState,
  reducers: {
    setInitiativeStatus(
      state,
      action: PayloadAction<{ id: string; status: InitiativeStatus }>
    ) {
      const item = state.initiatives.find((i) => i.id === action.payload.id);
      if (item) item.status = action.payload.status;
    },
    toggleAction(state, action: PayloadAction<string>) {
      const a = state.actions.find((x) => x.id === action.payload);
      if (a) a.state = a.state === "open" ? "closed" : "open";
    },
    /** Move an agent recommendation into the initiative pipeline. */
    acceptRecommendation(state, action: PayloadAction<string>) {
      const rec = state.recommendations.find((r) => r.id === action.payload);
      if (!rec) return;
      const initiative: Initiative = {
        id: `new-${rec.id}`,
        title: rec.title,
        category: rec.category,
        owner: "TCS",
        status: "idea",
        impact: rec.impact,
        eta: "Scoping · Q3 2026",
      };
      state.initiatives.unshift(initiative);
      state.addedInitiatives.unshift(initiative);
      state.recommendations = state.recommendations.filter(
        (r) => r.id !== rec.id
      );
      state.handledRecs.push(rec.id);
    },
    dismissRecommendation(state, action: PayloadAction<string>) {
      state.recommendations = state.recommendations.filter(
        (r) => r.id !== action.payload
      );
      state.handledRecs.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchImprovementData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchImprovementData.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.benefitsTrend = action.payload.benefitsTrend;
        // Preserve locally-changed statuses and locally-added initiatives.
        const localStatus = new Map(
          state.initiatives.map((i) => [i.id, i.status] as const)
        );
        state.initiatives = [
          ...state.addedInitiatives,
          ...action.payload.initiatives.map((i) => ({
            ...i,
            status: localStatus.get(i.id) ?? i.status,
          })),
        ];
        const localActions = new Map(
          state.actions.map((a) => [a.id, a.state] as const)
        );
        state.actions = action.payload.actions.map((a) => ({
          ...a,
          state: localActions.get(a.id) ?? a.state,
        }));
        state.meetings = action.payload.meetings;
        state.recommendations = action.payload.recommendations.filter(
          (r) => !state.handledRecs.includes(r.id)
        );
      });
  },
});

export const {
  setInitiativeStatus,
  toggleAction,
  acceptRecommendation,
  dismissRecommendation,
} = improvementSlice.actions;
export default improvementSlice.reducer;
