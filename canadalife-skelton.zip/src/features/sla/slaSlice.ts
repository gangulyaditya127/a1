import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type {
  AppHealth,
  BreachRisk,
  MonthPoint,
  SlaMetric,
  SlaSummary,
  TimeRange,
  XlaDriver,
} from "@/types";
import { fetchSla } from "@/services/mockApi";

interface SlaState {
  status: "idle" | "loading" | "succeeded";
  summary: SlaSummary | null;
  trend: MonthPoint[];
  trendByPriority: MonthPoint[];
  csatTrend: MonthPoint[];
  metrics: SlaMetric[];
  xlaDrivers: XlaDriver[];
  risks: BreachRisk[];
  portfolio: AppHealth[];
}

const initialState: SlaState = {
  status: "idle",
  summary: null,
  trend: [],
  trendByPriority: [],
  csatTrend: [],
  metrics: [],
  xlaDrivers: [],
  risks: [],
  portfolio: [],
};

export const fetchSlaData = createAsyncThunk(
  "sla/fetch",
  async (range: TimeRange) => fetchSla(range)
);

const slaSlice = createSlice({
  name: "sla",
  initialState,
  reducers: {
    /** Service owner has seen the risk; keep it visible but mark it handled. */
    acknowledgeRisk(state, action: PayloadAction<string>) {
      const risk = state.risks.find((r) => r.id === action.payload);
      if (risk) risk.acknowledged = true;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSlaData.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchSlaData.fulfilled, (state, action) => {
        const keepAck = new Set(
          state.risks.filter((r) => r.acknowledged).map((r) => r.id)
        );
        state.status = "succeeded";
        state.summary = action.payload.summary;
        state.trend = action.payload.trend;
        state.trendByPriority = action.payload.trendByPriority;
        state.csatTrend = action.payload.csatTrend;
        state.metrics = action.payload.metrics;
        state.xlaDrivers = action.payload.xlaDrivers;
        state.risks = action.payload.risks.map((r) => ({
          ...r,
          acknowledged: keepAck.has(r.id) || r.acknowledged,
        }));
        state.portfolio = action.payload.portfolio;
      });
  },
});

export const { acknowledgeRisk } = slaSlice.actions;
export default slaSlice.reducer;
