import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { TimeRange } from "@/types";

interface UiState {
  timeRange: TimeRange;
  sidebarOpen: boolean;
}

const initialState: UiState = {
  timeRange: "6m",
  sidebarOpen: true,
};

const uiSlice = createSlice({
  name: "ui",
  initialState,
  reducers: {
    setTimeRange(state, action: PayloadAction<TimeRange>) {
      state.timeRange = action.payload;
    },
    toggleSidebar(state) {
      state.sidebarOpen = !state.sidebarOpen;
    },
    closeSidebar(state) {
      state.sidebarOpen = false;
    },
  },
});

export const { setTimeRange, toggleSidebar, closeSidebar } = uiSlice.actions;
export default uiSlice.reducer;
