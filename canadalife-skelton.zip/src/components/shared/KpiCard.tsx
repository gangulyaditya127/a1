import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendIndicator, type Trend } from "@/components/shared/TrendIndicator";
import { cn } from "@/lib/utils";

interface KpiCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  trend?: Trend;
  hint?: string;
  loading?: boolean;
  className?: string;
}

/** Headline metric tile — the top strip of every S6 page. */
export function KpiCard({
  label,
  value,
  icon: Icon,
  trend,
  hint,
  loading,
  className,
}: KpiCardProps) {
  return (
    <Card className={cn("min-w-0", className)}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-secondary text-muted-foreground">
            <Icon className="h-3.5 w-3.5" />
          </span>
        </div>
        {loading ? (
          <div className="mt-2 space-y-2">
            <Skeleton className="h-7 w-24" />
            <Skeleton className="h-3 w-16" />
          </div>
        ) : (
          <>
            <p className="num mt-1 text-2xl font-semibold tracking-tight">
              {value}
            </p>
            <div className="mt-1 flex items-center gap-2">
              {trend && <TrendIndicator trend={trend} />}
              {hint && (
                <span className="truncate text-[11px] text-muted-foreground">
                  {hint}
                </span>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
