import type { ReactNode } from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Signature treatment for anything an ARE agent produced: a quiet card with a
 * brand-red left rail. Used consistently so users learn to recognise
 * AI-generated content at a glance (feeds the "General" explainability track).
 */
export function AiInsight({
  children,
  source,
  className,
}: {
  children: ReactNode;
  source?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-start gap-2.5 rounded-md border border-l-2 border-l-brand bg-brand-soft/60 px-3.5 py-3",
        className
      )}
    >
      <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
      <div className="min-w-0 text-xs leading-relaxed text-foreground/90">
        <span className="mr-1.5 font-semibold text-accent-foreground">
          AI insight
        </span>
        {source && (
          <span className="mr-1.5 text-[11px] text-muted-foreground">
            · {source}
          </span>
        )}
        <span className="block pt-0.5">{children}</span>
      </div>
    </div>
  );
}
