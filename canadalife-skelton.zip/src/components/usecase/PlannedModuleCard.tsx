import { Hourglass } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { PlannedModule } from "@/types";

export function PlannedModuleCard({ module }: { module: PlannedModule }) {
  return (
    <div className="flex flex-col gap-1.5 rounded-lg border border-dashed bg-card/60 p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[13px] font-semibold leading-4">{module.title}</p>
        <Badge variant="muted" className="shrink-0">
          <Hourglass className="h-2.5 w-2.5" />
          Planned
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground">{module.description}</p>
    </div>
  );
}
