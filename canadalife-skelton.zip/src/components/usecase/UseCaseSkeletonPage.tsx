import { Bot, CheckCircle2, User } from "lucide-react";
import { AiInsight } from "@/components/shared/AiInsight";
import { PageHeader } from "@/components/shared/PageHeader";
import { JourneyTimeline } from "@/components/usecase/JourneyTimeline";
import { PlannedModuleCard } from "@/components/usecase/PlannedModuleCard";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { UseCaseDef } from "@/types";

/**
 * Shared skeleton for every use case that isn't fully built yet.
 * S6 demonstrates the fully-expanded pattern; these pages carry the same
 * shell, header treatment and data contracts so each can be promoted from
 * skeleton to full module without rework.
 */
export function UseCaseSkeletonPage({ useCase }: { useCase: UseCaseDef }) {
  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow={`Use case ${useCase.code}`}
        title={useCase.title}
        description={useCase.tagline}
        actions={<Badge variant="info">{useCase.status}</Badge>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Scenario</CardTitle>
            <CardDescription>
              From the table-top planning session (v0.2)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-[13px] leading-relaxed text-foreground/90">
              {useCase.scenario}
            </p>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                ARE agents
              </span>
              {useCase.agents.map((a) => (
                <Badge key={a} variant="secondary">
                  <Bot className="h-3 w-3" />
                  {a}
                </Badge>
              ))}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              Tech lead: {useCase.lead}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Business outcomes</CardTitle>
            <CardDescription>What service owners get</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5">
              {useCase.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-2 text-[13px]">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Agentic journey</CardTitle>
            <CardDescription>How the flow runs end to end</CardDescription>
          </CardHeader>
          <CardContent>
            <JourneyTimeline steps={useCase.journey} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Planned modules</CardTitle>
            <CardDescription>
              Scaffolded in this shell — S6 shows the pattern fully built
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {useCase.plannedModules.map((m) => (
                <PlannedModuleCard key={m.title} module={m} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <AiInsight source="Portal shell">
        This page reuses the shared layout, header, status and card system from
        S6 — promoting it to a full module means wiring data into these slots,
        not building a new screen.
      </AiInsight>
    </div>
  );
}
