import { NavLink } from "react-router-dom";
import { CanadaLifeLogo, TcsLogo } from "@/components/brand/Logos";
import { Badge } from "@/components/ui/badge";
import { NAV_GROUPS } from "@/routes/nav";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { closeSidebar } from "@/features/ui/uiSlice";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const open = useAppSelector((s) => s.ui.sidebarOpen);
  const dispatch = useAppDispatch();

  return (
    <>
      {/* mobile scrim */}
      <div
        className={cn(
          "fixed inset-0 z-30 bg-foreground/30 backdrop-blur-[2px] transition-opacity md:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={() => dispatch(closeSidebar())}
      />

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r bg-card transition-transform md:static md:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-14 items-center border-b px-4">
          <CanadaLifeLogo />
        </div>

        <nav className="scrollbar-thin flex-1 overflow-y-auto px-3 py-4">
          {NAV_GROUPS.map((group) => (
            <div key={group.label} className="mb-5">
              <p className="mb-1.5 px-2 text-[10.5px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                {group.label}
              </p>
              <ul className="space-y-0.5">
                {group.items.map((item) => (
                  <li key={item.to}>
                    <NavLink
                      to={item.to}
                      end={item.to === "/"}
                      onClick={() => dispatch(closeSidebar())}
                      className={({ isActive }) =>
                        cn(
                          "group relative flex items-center gap-2.5 rounded-md px-2 py-1.5 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
                          isActive && "bg-brand-soft text-accent-foreground"
                        )
                      }
                    >
                      {({ isActive }) => (
                        <>
                          {/* red square from the brand mark = active cue */}
                          <span
                            className={cn(
                              "absolute -left-[3px] top-1/2 h-2 w-2 -translate-y-1/2 rounded-[2.5px] bg-brand opacity-0 transition-opacity",
                              isActive && "opacity-100"
                            )}
                          />
                          <item.icon
                            className={cn(
                              "h-4 w-4 shrink-0",
                              isActive ? "text-brand" : "text-muted-foreground/70 group-hover:text-foreground"
                            )}
                          />
                          <span className="flex-1 truncate">{item.label}</span>
                          {item.soon && (
                            <Badge variant="muted" className="px-1.5 text-[9.5px]">
                              Soon
                            </Badge>
                          )}
                        </>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="border-t px-4 py-3">
          <p className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">
            Delivered by
          </p>
          <div className="flex items-center justify-between">
            <TcsLogo full />
            <span className="text-[10px] text-muted-foreground">v0.2 · table-top</span>
          </div>
        </div>
      </aside>
    </>
  );
}
