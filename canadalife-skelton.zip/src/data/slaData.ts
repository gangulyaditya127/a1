import type {
  AppHealth,
  BreachRisk,
  MonthPoint,
  SlaMetric,
  SlaSummary,
  XlaDriver,
} from "@/types";

/** Aug 2025 → Jul 2026 (Jul is month-to-date). */
export const MONTHS = [
  "Aug 25",
  "Sep 25",
  "Oct 25",
  "Nov 25",
  "Dec 25",
  "Jan 26",
  "Feb 26",
  "Mar 26",
  "Apr 26",
  "May 26",
  "Jun 26",
  "Jul 26",
] as const;

const series = (values: number[], key: string): MonthPoint[] =>
  MONTHS.map((month, i) => ({ month, [key]: values[i] }));

export const slaSummary: SlaSummary = {
  compliancePct: 96.8,
  complianceDelta: 0.6,
  metricsMet: 34,
  metricsTotal: 36,
  creditExposureCad: 18200,
  xlaScore: 87,
  xlaDelta: 2,
  csat: 4.4,
  csatDelta: 0.1,
};

export const slaTrend: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  overall: [94.1, 94.8, 95.2, 94.6, 95.9, 96.1, 95.4, 96.3, 96.8, 96.5, 97.1, 96.8][i],
}));

export const slaTrendByPriority: MonthPoint[] = MONTHS.map((month, i) => ({
  month,
  P1: [97.0, 97.6, 98.1, 97.2, 98.4, 98.8, 98.2, 98.9, 99.1, 98.8, 99.3, 99.2][i],
  P2: [92.4, 93.1, 93.8, 92.6, 94.2, 94.6, 93.1, 94.4, 95.0, 94.1, 94.8, 93.4][i],
  P3: [93.8, 94.4, 94.9, 94.2, 95.6, 95.9, 95.1, 96.2, 96.6, 96.4, 97.0, 95.8][i],
  P4: [95.2, 95.8, 96.1, 95.6, 96.6, 96.9, 96.2, 96.8, 97.3, 97.0, 97.4, 96.3][i],
}));

export const csatTrend: MonthPoint[] = series(
  [4.0, 4.0, 4.1, 4.1, 4.2, 4.2, 4.2, 4.3, 4.3, 4.3, 4.4, 4.4],
  "csat"
);

export const slaMetrics: SlaMetric[] = [
  { id: "m1", name: "P1 response", category: "response", target: "15 min · 99.5%", targetPct: 99.5, actualPct: 99.6, deltaPts: 0.2, status: "on-track", scope: "All Tier 1 apps" },
  { id: "m2", name: "P1 resolution", category: "resolution", target: "4 h · 95%", targetPct: 95, actualPct: 97.2, deltaPts: 0.8, status: "on-track", scope: "All Tier 1 apps" },
  { id: "m3", name: "P2 response", category: "response", target: "30 min · 98%", targetPct: 98, actualPct: 98.9, deltaPts: 0.3, status: "on-track", scope: "Portfolio-wide" },
  { id: "m4", name: "P2 resolution", category: "resolution", target: "8 h · 95%", targetPct: 95, actualPct: 93.4, deltaPts: -1.4, status: "at-risk", scope: "Claims Processing" },
  { id: "m5", name: "P3 resolution", category: "resolution", target: "5 bd · 90%", targetPct: 90, actualPct: 95.8, deltaPts: 0.4, status: "on-track", scope: "Portfolio-wide" },
  { id: "m6", name: "P4 resolution", category: "resolution", target: "10 bd · 90%", targetPct: 90, actualPct: 96.3, deltaPts: -0.2, status: "on-track", scope: "Portfolio-wide" },
  { id: "m7", name: "Availability — Tier 1", category: "availability", target: "99.90%", targetPct: 99.9, actualPct: 99.93, deltaPts: 0.01, status: "on-track", scope: "6 Tier 1 apps" },
  { id: "m8", name: "Batch completion by 06:00 ET", category: "availability", target: "98%", targetPct: 98, actualPct: 96.1, deltaPts: -0.9, status: "at-risk", scope: "Payments Hub" },
  { id: "m9", name: "First-contact resolution", category: "experience", target: "≥ 70%", targetPct: 70, actualPct: 74.0, deltaPts: 1.6, status: "on-track", scope: "Service desk" },
  { id: "m10", name: "CSAT", category: "experience", target: "≥ 4.2 / 5", targetPct: 84, actualPct: 88, deltaPts: 2.0, status: "on-track", scope: "All closed tickets" },
];

export const xlaDrivers: XlaDriver[] = [
  { id: "x1", name: "Portal availability experience", score: 92, deltaPts: 1 },
  { id: "x2", name: "Claim turnaround satisfaction", score: 84, deltaPts: 3 },
  { id: "x3", name: "Advisor response experience", score: 79, deltaPts: -2 },
  { id: "x4", name: "Enrolment journey completion", score: 81, deltaPts: 0 },
];

export const breachRisks: BreachRisk[] = [
  {
    id: "r1",
    metric: "P2 resolution",
    application: "Claims Processing",
    predictedIn: "≈ 3 days",
    confidence: 82,
    impact: "4 open P2s aging past the 6-hour mark; claim-status API timeouts recurring.",
    recommendation:
      "Pull the claim-status API fix into the Jul 24 patch window and add temporary L2 cover Mon–Wed.",
    acknowledged: false,
  },
  {
    id: "r2",
    metric: "Batch completion",
    application: "Payments Hub",
    predictedIn: "≈ 6 days",
    confidence: 74,
    impact: "End-of-day batch overran 06:00 ET twice this week during volume spikes.",
    recommendation:
      "Enable the validated self-healing restart runbook (S5 pilot) for the EOD batch chain.",
    acknowledged: false,
  },
  {
    id: "r3",
    metric: "P3 resolution",
    application: "GroupNet for Plan Members",
    predictedIn: "≈ 9 days",
    confidence: 61,
    impact: "Enrolment-season volume is building; duplicate tickets inflating the queue.",
    recommendation:
      "Deflect the top 3 FAQ intents to the portal assistant and auto-close confirmed duplicates.",
    acknowledged: false,
  },
];

export const portfolioHealth: AppHealth[] = [
  { id: "a1", name: "Policy Administration", portfolio: "Individual Insurance", tier: "Tier 1", sla: 98.2, xla: 89, openP1: 0, openP2: 1, risk: "on-track", deltaPts: 0.4 },
  { id: "a2", name: "Claims Processing", portfolio: "Group Benefits", tier: "Tier 1", sla: 93.4, xla: 84, openP1: 0, openP2: 4, risk: "at-risk", deltaPts: -1.2 },
  { id: "a3", name: "GroupNet for Plan Members", portfolio: "Group Benefits", tier: "Tier 1", sla: 96.9, xla: 88, openP1: 0, openP2: 2, risk: "at-risk", deltaPts: -0.3 },
  { id: "a4", name: "My Canada Life at Work", portfolio: "Group Retirement", tier: "Tier 2", sla: 97.8, xla: 90, openP1: 0, openP2: 0, risk: "on-track", deltaPts: 0.5 },
  { id: "a5", name: "Payments Hub", portfolio: "Corporate Services", tier: "Tier 1", sla: 95.6, xla: 82, openP1: 0, openP2: 2, risk: "at-risk", deltaPts: -0.8 },
  { id: "a6", name: "Advisor Workspace", portfolio: "Distribution", tier: "Tier 2", sla: 97.1, xla: 79, openP1: 0, openP2: 1, risk: "on-track", deltaPts: 0.2 },
  { id: "a7", name: "Wealth Platform", portfolio: "Individual Wealth", tier: "Tier 2", sla: 98.6, xla: 91, openP1: 0, openP2: 0, risk: "on-track", deltaPts: 0.7 },
  { id: "a8", name: "Document & Correspondence", portfolio: "Corporate Services", tier: "Tier 3", sla: 99.1, xla: 90, openP1: 0, openP2: 0, risk: "on-track", deltaPts: 0.1 },
];
