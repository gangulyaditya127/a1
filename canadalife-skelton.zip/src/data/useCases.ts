import type { UseCaseDef } from "@/types";

/**
 * Content distilled from the Canada Life table-top planner (v0.2).
 * These configs drive the shared UseCaseSkeletonPage — add a new use case by
 * adding an entry here and a route; no new page code required.
 */

export const s1IncidentTriage: UseCaseDef = {
  code: "S1",
  title: "Incident Triage & Resolution",
  tagline: "From alert to resolution with agent-guided triage and comms",
  status: "In discovery",
  lead: "Soumaydeep (TCS)",
  scenario:
    "A priority incident lands. Agents classify and enrich it instantly, retrieve the most relevant knowledge, coordinate across suppliers, guide the engineer through resolution and keep every stakeholder informed — then learn from the outcome.",
  agents: ["Intelligent Triage", "Resolution Recommender", "Comms Orchestrator"],
  journey: [
    { step: "Instant triage", detail: "Classify, prioritize and route the incident with full context attached." },
    { step: "Knowledge retrieval", detail: "Surface the most relevant KBs, past incidents and runbooks." },
    { step: "Cross-supplier coordination", detail: "One thread across TCS, Canada Life and third parties." },
    { step: "Guided resolution", detail: "Step-by-step recommendations with confidence and precedent." },
    { step: "Automated communications", detail: "Stakeholder updates drafted and sent on cadence." },
    { step: "Continuous learning", detail: "Outcomes feed back into triage and recommendation quality." },
  ],
  outcomes: [
    "Faster MTTA / MTTR on P1–P2 incidents",
    "Less analyst effort per ticket",
    "Consistent, auditable resolution steps",
    "SLA compliance protected during surges",
  ],
  plannedModules: [
    { title: "Live triage console", description: "Queue with agent classifications, confidence and routing." },
    { title: "War-room workspace", description: "Single pane for majors: timeline, actions, comms." },
    { title: "Comms composer", description: "Agent-drafted stakeholder updates with approval flow." },
    { title: "Post-incident learning", description: "What the agents learned from each resolution." },
  ],
};

export const s2ProblemRca: UseCaseDef = {
  code: "S2",
  title: "Problem Management & Root Cause",
  tagline: "Find the patterns, fix the cause, stop the repeats",
  status: "In discovery",
  lead: "Debasish (TCS)",
  scenario:
    "Recurring incidents hide a common cause. Agents detect the pattern, run root-cause discovery across logs and changes, draft the problem record, recommend the permanent fix and keep stakeholders aligned until it ships.",
  agents: ["RCA Agent", "Problem Record Creator"],
  journey: [
    { step: "Pattern detection", detail: "Cluster related incidents across apps and time." },
    { step: "Root-cause discovery", detail: "Correlate logs, changes and topology to a probable cause." },
    { step: "Knowledge & insight", detail: "Enrich the known-error base automatically." },
    { step: "Permanent-fix recommendation", detail: "Options with effort, risk and expected benefit." },
    { step: "Stakeholder alignment", detail: "Problem records and updates drafted for review." },
    { step: "Continuous learning", detail: "Fix outcomes sharpen future RCA." },
  ],
  outcomes: [
    "Faster, evidence-backed RCA",
    "Fewer repeat incidents quarter over quarter",
    "Lower cost of poor quality",
    "A living known-error base",
  ],
  plannedModules: [
    { title: "Recurrence clusters", description: "Incident families ranked by business impact." },
    { title: "RCA workbench", description: "Agent evidence trail: logs, changes, hypotheses." },
    { title: "Fix tracker", description: "Permanent fixes from recommendation to deployment." },
    { title: "Known-error base", description: "Auto-maintained errors with workarounds." },
  ],
};

export const s5PredictiveOps: UseCaseDef = {
  code: "S5",
  title: "Proactive & Predictive Operations",
  tagline: "Cut the noise, see risks early, heal before impact",
  status: "In discovery",
  lead: "Aditya (TCS)",
  scenario:
    "Thousands of events become a handful of real signals. Agents correlate and suppress noise, forecast emerging risks, recommend pre-emptive actions and — where approved — execute self-healing runbooks before users feel anything.",
  agents: ["Event Correlator & Forecaster", "Self-Healing Executor"],
  journey: [
    { step: "Noise reduction", detail: "Correlate and de-duplicate events into meaningful signals." },
    { step: "Predictive risk detection", detail: "Forecast incidents and SLA breaches with confidence." },
    { step: "Proactive recommendations", detail: "Pre-emptive actions ranked by impact." },
    { step: "Self-healing automation", detail: "Approved runbooks execute with full audit trail." },
    { step: "Continuous optimization", detail: "Models retrain on every outcome." },
  ],
  outcomes: [
    "Materially less alert noise",
    "Issues caught before user impact",
    "Lower incident volumes and faster recovery",
    "Higher availability on Tier 1 apps",
  ],
  plannedModules: [
    { title: "Alert noise funnel", description: "Raw events → correlated signals → actioned." },
    { title: "Risk forecasts", description: "Predicted incidents and breach risks with confidence." },
    { title: "Self-healing run log", description: "Every automated run, outcome and rollback." },
    { title: "Capacity outlook", description: "Where demand will outgrow headroom next." },
  ],
};

export const aiGovernance: UseCaseDef = {
  code: "General",
  title: "AI Adoption Governance",
  tagline: "Trustworthy agents: explainable, logged, permissioned, reversible",
  status: "Cross-cutting track",
  lead: "Ram (TCS)",
  scenario:
    "Every agent action across S1–S6 is explainable, traceable and reversible. This track gives Canada Life the controls to adopt AI with confidence: who approved what, why the agent acted, what it touched, and how to roll it back.",
  agents: ["Applies to all ARE agents"],
  journey: [
    { step: "Decision explainability", detail: "Plain-language 'why' for every agent decision." },
    { step: "Action logging & traceability", detail: "Immutable audit trail across systems." },
    { step: "Privilege & access management", detail: "Least-privilege execution with approvals." },
    { step: "Rollback management", detail: "One-click reversal for automated changes." },
    { step: "Human feedback loop", detail: "Corrections retrain agent behavior." },
    { step: "Governance dashboard", detail: "Adoption, risk and control posture in one view." },
  ],
  outcomes: [
    "Confident, auditable AI adoption",
    "Reduced operational and compliance risk",
    "Secure, least-privilege agent execution",
    "Governance that scales with adoption",
  ],
  plannedModules: [
    { title: "Explainability viewer", description: "Decision rationale, inputs and confidence." },
    { title: "Action audit trail", description: "Searchable log of every agent action." },
    { title: "Privilege manager", description: "Agent entitlements and approval chains." },
    { title: "Rollback console", description: "Reverse automated changes safely." },
    { title: "Feedback studio", description: "Route human corrections into training." },
  ],
};
