import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-background text-center">
      <span className="grid h-10 w-10 place-items-center rounded-[8px] bg-brand font-serif text-lg italic text-white">
        ?
      </span>
      <h1 className="text-lg font-semibold">This page isn't part of the demo</h1>
      <p className="max-w-sm text-sm text-muted-foreground">
        The table-top build ships five applications: Governance & Reporting in
        full, plus S1, S2, S5 and the AI-governance track as previews.
      </p>
      <Button asChild size="sm">
        <Link to="/">Back to all applications</Link>
      </Button>
    </div>
  );
}
