import type { AppManifest } from "@/shared/types";
import { governanceApp } from "@/application/governance/manifest";
import { incidentTriageApp } from "@/application/incident-triage/manifest";
import { problemRcaApp } from "@/application/problem-rca/manifest";
import { predictiveOpsApp } from "@/application/predictive-ops/manifest";
import { aiGovernanceApp } from "@/application/ai-governance/manifest";

/**
 * The only file that knows every application exists.
 * Adding an app to the portal = build it under src/application/<name>,
 * export a manifest, and list it here. Router, launcher and layout pick it
 * up automatically.
 */
export const APPS: AppManifest[] = [
  governanceApp,
  incidentTriageApp,
  problemRcaApp,
  predictiveOpsApp,
  aiGovernanceApp,
];

export function findAppByPath(pathname: string): AppManifest | null {
  return APPS.find((a) => a.paths.includes(pathname)) ?? null;
}
