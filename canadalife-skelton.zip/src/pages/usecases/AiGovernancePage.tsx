import { UseCaseSkeletonPage } from "@/components/usecase/UseCaseSkeletonPage";
import { aiGovernance } from "@/data/useCases";

export function AiGovernancePage() {
  return <UseCaseSkeletonPage useCase={aiGovernance} />;
}
