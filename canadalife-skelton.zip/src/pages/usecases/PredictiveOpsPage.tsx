import { UseCaseSkeletonPage } from "@/components/usecase/UseCaseSkeletonPage";
import { s5PredictiveOps } from "@/data/useCases";

export function PredictiveOpsPage() {
  return <UseCaseSkeletonPage useCase={s5PredictiveOps} />;
}
