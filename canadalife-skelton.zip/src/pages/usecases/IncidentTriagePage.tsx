import { UseCaseSkeletonPage } from "@/components/usecase/UseCaseSkeletonPage";
import { s1IncidentTriage } from "@/data/useCases";

export function IncidentTriagePage() {
  return <UseCaseSkeletonPage useCase={s1IncidentTriage} />;
}
