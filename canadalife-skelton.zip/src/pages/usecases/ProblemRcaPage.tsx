import { UseCaseSkeletonPage } from "@/components/usecase/UseCaseSkeletonPage";
import { s2ProblemRca } from "@/data/useCases";

export function ProblemRcaPage() {
  return <UseCaseSkeletonPage useCase={s2ProblemRca} />;
}
