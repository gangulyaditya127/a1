import { useEffect } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Clock, Inbox, Timer, TrendingUp, Zap } from "lucide-react";
import { AiInsight } from "@/components/shared/AiInsight";
import { ChartCard } from "@/components/shared/ChartCard";
import { KpiCard } from "@/components/shared/KpiCard";
import { PageHeader } from "@/components/shared/PageHeader";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AXIS_TICK, CHART, LEGEND_STYLE, TOOLTIP_STYLE } from "@/lib/chart";
import { fmtNum } from "@/lib/utils";
import { fetchProductivityData } from "@/features/productivity/productivitySlice";
import { useAppDispatch, useAppSelector } from "@/store/hooks";

const SHIFT_COLORS = [CHART.green, CHART.blue, CHART.violet, CHART.slate];

export function ProductivityPage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const prod = useAppSelector((s) => s.productivity);

  useEffect(() => {
    dispatch(fetchProductivityData(range));
  }, [dispatch, range]);

  const loading = prod.status !== "succeeded";

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="Productivity & automation savings"
        description="Where effort goes, what automation has taken off the queue, and the hours returned to Canada Life."
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <KpiCard
          label="Tickets handled"
          value={prod.summary ? fmtNum(prod.summary.ticketsHandled) : "—"}
          icon={Inbox}
          loading={loading}
          hint="this period"
        />
        <KpiCard
          label="Avg resolution time"
          value={prod.summary ? `${prod.summary.avgResolutionHrs} h` : "—"}
          icon={Timer}
          loading={loading}
          trend={{ value: "−18%", direction: "down", positive: true }}
          hint="vs last year"
        />
        <KpiCard
          label="Automation coverage"
          value={prod.summary ? `${prod.summary.automationCoveragePct}%` : "—"}
          icon={Zap}
          loading={loading}
          trend={{ value: "+9 pts", direction: "up", positive: true }}
          hint="auto + AI-assisted"
        />
        <KpiCard
          label="Hours saved"
          value={prod.summary ? fmtNum(prod.summary.hoursSaved) : "—"}
          icon={Clock}
          loading={loading}
          hint="quarter to date"
        />
        <KpiCard
          label="Backlog"
          value={prod.summary ? fmtNum(prod.summary.backlog) : "—"}
          icon={TrendingUp}
          loading={loading}
          trend={{ value: "−12%", direction: "down", positive: true }}
          hint="open items"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="Volume & resolution mix"
          subtitle="Monthly tickets by how they were resolved"
          loading={loading}
          height={250}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={prod.volumeTrend} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={40} />
              <Tooltip {...TOOLTIP_STYLE} />
              <Legend wrapperStyle={LEGEND_STYLE} iconType="circle" iconSize={8} />
              <Bar dataKey="autoResolved" name="Auto-resolved" stackId="v" fill={CHART.green} />
              <Bar dataKey="aiAssisted" name="AI-assisted" stackId="v" fill={CHART.blue} />
              <Bar dataKey="manual" name="Manual" stackId="v" fill={CHART.slate} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Effort returned"
          subtitle="Cumulative hours saved by automation & agents"
          loading={loading}
          height={250}
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={prod.savingsTrend} margin={{ top: 6, right: 8, left: -12, bottom: 0 }}>
              <defs>
                <linearGradient id="hoursFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={CHART.green} stopOpacity={0.2} />
                  <stop offset="100%" stopColor={CHART.green} stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={46} />
              <Tooltip {...TOOLTIP_STYLE} />
              <Area
                type="monotone"
                dataKey="hours"
                name="Hours (cumulative)"
                stroke={CHART.green}
                strokeWidth={2}
                fill="url(#hoursFill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title="Shift-left position"
          subtitle="Share of volume by resolution level, with YoY movement"
          loading={loading}
          height={210}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={prod.shiftLeft}
              layout="vertical"
              margin={{ top: 0, right: 24, left: 8, bottom: 0 }}
            >
              <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" tick={AXIS_TICK} axisLine={false} tickLine={false} unit="%" />
              <YAxis
                type="category"
                dataKey="level"
                tick={{ ...AXIS_TICK, fill: "#334155" }}
                axisLine={false}
                tickLine={false}
                width={148}
              />
              <Tooltip {...TOOLTIP_STYLE} />
              <Bar dataKey="pct" name="Share of volume" radius={[0, 4, 4, 0]} barSize={18}>
                {prod.shiftLeft.map((row, i) => (
                  <Cell key={row.level} fill={SHIFT_COLORS[i % SHIFT_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Backlog aging"
          subtitle="Open items by age bucket"
          loading={loading}
          height={210}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={prod.aging} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="bucket" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={36} />
              <Tooltip {...TOOLTIP_STYLE} />
              <Bar dataKey="count" name="Open items" fill={CHART.blue} radius={[3, 3, 0, 0]} barSize={36} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top automations</CardTitle>
          <CardDescription>Highest-impact automated resolutions this period</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-44 w-full" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Automation</TableHead>
                  <TableHead className="text-right">Tickets handled</TableHead>
                  <TableHead className="text-right">Hours saved</TableHead>
                  <TableHead className="text-right">Success rate</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {prod.topAutomations.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.name}</TableCell>
                    <TableCell className="num text-right">{fmtNum(a.tickets)}</TableCell>
                    <TableCell className="num text-right">{fmtNum(a.hoursSaved)}</TableCell>
                    <TableCell className="num text-right">{a.successPct.toFixed(1)}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <AiInsight source="Performance & Productivity agent">
        Password resets and batch restarts account for 61% of auto-resolved
        volume. The next best candidates by frequency × effort are claim
        document re-index (est. 140 h/qtr) and advisor access provisioning
        (est. 90 h/qtr) — both queued in the improvement pipeline.
      </AiInsight>
    </div>
  );
}
