import { Download, FileText, RefreshCw, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { fmtDateTime } from "@/lib/utils";
import {
  generateReport,
  regenerateNarrative,
  toggleSubscription,
} from "@/features/reports/reportsSlice";
import { useAppDispatch, useAppSelector } from "@/store/hooks";

export function ReportsPage() {
  const dispatch = useAppDispatch();
  const { reports, subscriptions, narrative } = useAppSelector((s) => s.reports);

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="Executive reporting"
        description="Board-ready reports assembled by iSLA from live service data — generated on demand or on schedule, with a narrative your executives can read in a minute."
      />

      {/* AI narrative */}
      <Card className="border-l-2 border-l-brand">
        <CardHeader className="flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-brand" />
              Executive narrative — June 2026
            </CardTitle>
            <CardDescription>
              Drafted by iSLA · generated {fmtDateTime(narrative.generatedAt)} · reviewed
              before distribution
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            disabled={narrative.status === "generating"}
            onClick={() => dispatch(regenerateNarrative(narrative.index))}
          >
            <RefreshCw
              className={
                narrative.status === "generating" ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"
              }
            />
            {narrative.status === "generating" ? "Drafting…" : "Regenerate"}
          </Button>
        </CardHeader>
        <CardContent>
          <p className="max-w-4xl text-[13px] leading-relaxed text-foreground/90">
            {narrative.text}
          </p>
        </CardContent>
      </Card>

      {/* report library */}
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {reports.map((r) => (
          <Card key={r.id} className="flex flex-col">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-2">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-secondary">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </span>
                <StatusBadge status={r.state} />
              </div>
              <CardTitle className="pt-1">{r.name}</CardTitle>
              <CardDescription>{r.description}</CardDescription>
            </CardHeader>
            <CardContent className="mt-auto space-y-1 pb-3 text-[11px] text-muted-foreground">
              <p>
                <span className="font-medium text-foreground/80">Audience:</span> {r.audience}
                <span className="mx-1.5">·</span>
                <span className="font-medium text-foreground/80">Cadence:</span> {r.frequency}
              </p>
              <p>
                <span className="font-medium text-foreground/80">Last generated:</span>{" "}
                {r.lastGenerated ? fmtDateTime(r.lastGenerated) : "Not yet — first run Sep 8"}
              </p>
            </CardContent>
            <CardFooter className="gap-2 border-t pt-3">
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                disabled={r.state === "generating"}
                onClick={() => dispatch(generateReport(r.id))}
              >
                <RefreshCw
                  className={r.state === "generating" ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"}
                />
                {r.state === "generating" ? "Generating…" : "Generate now"}
              </Button>
              <Button size="sm" className="flex-1" disabled={r.state !== "ready"}>
                <Download className="h-3.5 w-3.5" />
                Download
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Separator />

      {/* subscriptions */}
      <Card>
        <CardHeader>
          <CardTitle>Distribution & schedule</CardTitle>
          <CardDescription>
            Who receives what, and when — toggle a subscription to pause it
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Report</TableHead>
                <TableHead>Recipients</TableHead>
                <TableHead>Cadence</TableHead>
                <TableHead>Next run</TableHead>
                <TableHead className="text-right">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {subscriptions.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.report}</TableCell>
                  <TableCell className="text-muted-foreground">{s.recipients}</TableCell>
                  <TableCell className="text-muted-foreground">{s.cadence}</TableCell>
                  <TableCell className="num text-muted-foreground">{s.nextRun}</TableCell>
                  <TableCell className="text-right">
                    <button
                      onClick={() => dispatch(toggleSubscription(s.id))}
                      className="inline-flex"
                      aria-label={s.active ? "Pause subscription" : "Resume subscription"}
                    >
                      <Badge variant={s.active ? "success" : "muted"} className="cursor-pointer">
                        {s.active ? "Active" : "Paused"}
                      </Badge>
                    </button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
