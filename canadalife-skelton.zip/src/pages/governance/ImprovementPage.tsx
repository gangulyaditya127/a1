import { useEffect } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  CalendarDays,
  Check,
  CircleDollarSign,
  Lightbulb,
  Plus,
  Repeat,
  Rocket,
  X,
} from "lucide-react";
import { AiInsight } from "@/components/shared/AiInsight";
import { ChartCard } from "@/components/shared/ChartCard";
import { KpiCard } from "@/components/shared/KpiCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AXIS_TICK, CHART, TOOLTIP_STYLE } from "@/lib/chart";
import { fmtCad } from "@/lib/utils";
import {
  acceptRecommendation,
  dismissRecommendation,
  fetchImprovementData,
  setInitiativeStatus,
  toggleAction,
} from "@/features/improvement/improvementSlice";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import type { InitiativeStatus } from "@/types";

const STATUS_OPTIONS: { value: InitiativeStatus; label: string }[] = [
  { value: "idea", label: "Idea" },
  { value: "in-progress", label: "In progress" },
  { value: "delivered", label: "Delivered" },
];

export function ImprovementPage() {
  const dispatch = useAppDispatch();
  const range = useAppSelector((s) => s.ui.timeRange);
  const imp = useAppSelector((s) => s.improvement);

  useEffect(() => {
    dispatch(fetchImprovementData(range));
  }, [dispatch, range]);

  const loading = imp.status !== "succeeded";
  const inFlight = imp.initiatives.filter((i) => i.status === "in-progress").length;

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="S6 · Governance & Reporting"
        title="Continuous improvement"
        description="The joint TCS–Canada Life pipeline: what's being improved, the benefits landing, and the governance cadence that keeps it honest."
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard
          label="Initiatives in flight"
          value={loading ? "—" : String(inFlight)}
          icon={Rocket}
          loading={loading}
          hint={`${imp.initiatives.length} in pipeline`}
        />
        <KpiCard
          label="Delivered YTD"
          value={imp.summary ? String(imp.summary.deliveredYtd) : "—"}
          icon={Check}
          loading={loading}
        />
        <KpiCard
          label="Benefits realized"
          value={imp.summary ? fmtCad(imp.summary.benefitsCad) : "—"}
          icon={CircleDollarSign}
          loading={loading}
          trend={{ value: "+12% vs case", direction: "up", positive: true }}
        />
        <KpiCard
          label="Repeat incidents"
          value={imp.summary ? `−${imp.summary.repeatReductionPct}%` : "—"}
          icon={Repeat}
          loading={loading}
          hint="year over year"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Initiative pipeline</CardTitle>
            <CardDescription>
              Update status inline — changes flow to the MBR pack automatically
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-72 w-full" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Initiative</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Expected impact</TableHead>
                    <TableHead>ETA</TableHead>
                    <TableHead className="w-[140px]">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {imp.initiatives.map((i) => (
                    <TableRow key={i.id}>
                      <TableCell>
                        <p className="font-medium leading-4">{i.title}</p>
                        <p className="mt-0.5 text-[11px] text-muted-foreground">{i.category}</p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{i.owner}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{i.impact}</TableCell>
                      <TableCell className="num text-xs text-muted-foreground">{i.eta}</TableCell>
                      <TableCell>
                        <Select
                          value={i.status}
                          onValueChange={(v) =>
                            dispatch(
                              setInitiativeStatus({ id: i.id, status: v as InitiativeStatus })
                            )
                          }
                        >
                          <SelectTrigger className="h-7 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_OPTIONS.map((o) => (
                              <SelectItem key={o.value} value={o.value} className="text-xs">
                                {o.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <ChartCard
            title="Benefits realized"
            subtitle="Cumulative, CA$ thousands"
            loading={loading}
            height={180}
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={imp.benefitsTrend} margin={{ top: 6, right: 8, left: -14, bottom: 0 }}>
                <defs>
                  <linearGradient id="benefitsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={CHART.red} stopOpacity={0.16} />
                    <stop offset="100%" stopColor={CHART.red} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={AXIS_TICK} axisLine={false} tickLine={false} />
                <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={44} />
                <Tooltip {...TOOLTIP_STYLE} />
                <Area
                  type="monotone"
                  dataKey="benefits"
                  name="CA$K (cumulative)"
                  stroke={CHART.red}
                  strokeWidth={2}
                  fill="url(#benefitsFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          <Card>
            <CardHeader>
              <CardTitle>Governance cadence</CardTitle>
              <CardDescription>Upcoming forums</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {loading ? (
                <Skeleton className="h-32 w-full" />
              ) : (
                imp.meetings.map((m) => (
                  <div key={m.id} className="flex items-start gap-2.5 rounded-md border px-3 py-2">
                    <CalendarDays className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold leading-4">{m.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {m.next} · {m.forum}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Actions tracker</CardTitle>
            <CardDescription>Open items from governance forums</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {loading ? (
              <Skeleton className="h-36 w-full" />
            ) : (
              imp.actions.map((a) => (
                <div
                  key={a.id}
                  className="flex items-center justify-between gap-3 rounded-md border px-3 py-2"
                >
                  <div className="min-w-0">
                    <p
                      className={
                        a.state === "closed"
                          ? "text-xs font-medium text-muted-foreground line-through"
                          : "text-xs font-medium"
                      }
                    >
                      {a.action}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {a.owner} · due {a.due}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant={a.state === "closed" ? "secondary" : "outline"}
                    onClick={() => dispatch(toggleAction(a.id))}
                    className="shrink-0"
                  >
                    <Check className="h-3.5 w-3.5" />
                    {a.state === "closed" ? "Reopen" : "Mark done"}
                  </Button>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-1.5">
              <Lightbulb className="h-4 w-4 text-brand" />
              Recommended by the agents
            </CardTitle>
            <CardDescription>
              CI Recommender proposals — accept to add them to the pipeline
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading ? (
              <Skeleton className="h-36 w-full" />
            ) : imp.recommendations.length === 0 ? (
              <div className="rounded-md border border-dashed px-3 py-6 text-center">
                <p className="text-xs font-medium">All caught up</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  New recommendations appear here as the agents find them.
                </p>
              </div>
            ) : (
              imp.recommendations.map((r) => (
                <div key={r.id} className="rounded-md border border-l-2 border-l-brand px-3 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold">{r.title}</p>
                    <Badge variant="brand" className="shrink-0">
                      {r.impact}
                    </Badge>
                  </div>
                  <p className="mt-1 text-[11.5px] text-muted-foreground">{r.rationale}</p>
                  <p className="mt-1 text-[10.5px] text-muted-foreground">
                    Source: {r.source}
                  </p>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" onClick={() => dispatch(acceptRecommendation(r.id))}>
                      <Plus className="h-3.5 w-3.5" />
                      Add to plan
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => dispatch(dismissRecommendation(r.id))}
                    >
                      <X className="h-3.5 w-3.5" />
                      Dismiss
                    </Button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <AiInsight source="CI Recommender">
        Delivered initiatives are compounding: repeat incidents are down 27%
        YoY and the benefits run-rate is 12% ahead of the business case.
        Approving the Q3 automation pipeline at the Aug 6 MBR keeps that
        trajectory.
      </AiInsight>
    </div>
  );
}
