import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 text-center">
      <span className="grid h-10 w-10 place-items-center rounded-[8px] bg-brand font-serif text-lg italic text-white">
        ?
      </span>
      <h1 className="text-lg font-semibold">This page isn't part of the demo</h1>
      <p className="max-w-sm text-sm text-muted-foreground">
        The table-top build covers S6 in full and scaffolds S1, S2, S5 and the
        AI governance track.
      </p>
      <Button asChild size="sm">
        <Link to="/">Back to overview</Link>
      </Button>
    </div>
  );
}
