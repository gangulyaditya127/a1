import { configureStore } from "@reduxjs/toolkit";
import uiReducer from "@/features/ui/uiSlice";
import slaReducer from "@/features/sla/slaSlice";
import productivityReducer from "@/features/productivity/productivitySlice";
import agentsReducer from "@/features/agents/agentsSlice";
import improvementReducer from "@/features/improvement/improvementSlice";
import reportsReducer from "@/features/reports/reportsSlice";

export const store = configureStore({
  reducer: {
    ui: uiReducer,
    sla: slaReducer,
    productivity: productivityReducer,
    agents: agentsReducer,
    improvement: improvementReducer,
    reports: reportsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
