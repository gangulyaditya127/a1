/**
 * One place for chart colors so visuals stay coherent across pages.
 * Brand red is used sparingly — headline series only.
 */
export const CHART = {
  red: "#FF0018",
  ink: "#334155",
  slate: "#94A3B8",
  blue: "#2563EB",
  sky: "#0284C7",
  green: "#059669",
  amber: "#D97706",
  violet: "#7C3AED",
  grid: "#E5E7EB",
} as const;

export const AXIS_TICK = { fontSize: 11, fill: "#64748B" } as const;

export const TOOLTIP_STYLE = {
  contentStyle: {
    borderRadius: 8,
    border: "1px solid #E2E8F0",
    boxShadow: "0 8px 24px rgba(15, 23, 42, 0.08)",
    fontSize: 12,
    padding: "8px 10px",
  },
  labelStyle: { fontWeight: 600, color: "#0F172A", marginBottom: 4 },
} as const;

export const LEGEND_STYLE = { fontSize: 12, paddingTop: 8 } as const;
