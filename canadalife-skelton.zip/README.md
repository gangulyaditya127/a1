# Canada Life · AMS Service Console (table-top mockup)

A React + TypeScript mockup for the Canada Life table-top exercise, organized
as a **multi-application portal**: a launcher home page opens five independent
applications, each owning its own folder under `src/application/`.
**Governance & Reporting (S6)** is fully built; **S1, S2, S5** and the
**AI adoption governance** track ship as previews on a shared scaffold.
Light and dark themes are supported throughout.

> Demo persona: *Sarah Mitchell, Service Owner — Group Benefits* · mock data
> only, July 2026 context, no real Canada Life figures.

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173
```

Requires Node 18+. Other scripts: `npm run build` (vite bundle),
`npm run typecheck` (strict TS, run separately), `npm run preview`.

## URL scheme

| Route | Application | Depth |
| --- | --- | --- |
| `/` | Launcher — one card per application | — |
| `/governance` | Governance & Reporting — overview | Full |
| `/sla` | Governance — SLA & XLA (metrics, XLA drivers, AI breach forecasts) | Full |
| `/productivity` | Governance — volumes, savings, shift-left, top automations | Full |
| `/agents` | Governance — agent roster, HITL approve/reject, value | Full |
| `/improvement` | Governance — initiative pipeline, cadence, recommendations | Full |
| `/reports` | Governance — AI narrative, generate/download, subscriptions | Full |
| `/incident-triage` | S1 · Incident Triage & Resolution | Preview |
| `/problem-rca` | S2 · Problem & Root Cause | Preview |
| `/predictive-ops` | S5 · Proactive & Predictive Ops | Preview |
| `/ai-governance` | General · AI Adoption Governance | Preview |

The governance app's reporting window (3/6/12 months, in the topbar)
re-slices every chart. Interactions are real Redux flows and survive a
range change: acknowledging a risk, approving an agent action, moving an
initiative, accepting a recommendation, generating a report.

## Architecture

```
src/
├── app/                    ROOT COMPOSITION — the only place that knows all apps
│   ├── registry.ts         imports every manifest → APPS list, path lookup
│   ├── router.tsx          launcher + app routes from manifests
│   ├── store.ts            ui slice + one reducer per app
│   ├── hooks.ts            typed useAppDispatch / useAppSelector
│   ├── RootLayout.tsx      theme sync (html.dark + localStorage)
│   ├── AppFrame.tsx        resolves active app → shared AppLayout
│   └── NotFoundPage.tsx
├── shared/                 CROSS-APP LIBRARY — no app-specific knowledge
│   ├── ui/                 shadcn/ui primitives
│   ├── components/         KpiCard, ChartCard, AiInsight, StatusBadge, Logos…
│   ├── usecase/            UseCaseScaffold + journey/planned-module pieces
│   ├── layout/             Sidebar, Topbar, AppLayout, ThemeToggle
│   ├── state/uiSlice.ts    theme · reporting window · sidebar
│   ├── lib/                cn, formatters, theme-aware chart tokens
│   └── types.ts            TimeRange, MonthPoint, NavItem, AppManifest…
└── application/            ONE FOLDER = ONE APPLICATION
    ├── launcher/           home page (cards driven by manifests)
    ├── governance/         manifest · pages · state (5 slices) · data ·
    │                       services/api.ts · types.ts        ← fully built
    ├── incident-triage/    manifest · pages · data           ← preview
    ├── problem-rca/        〃
    ├── predictive-ops/     〃
    └── ai-governance/      〃
```

### Dependency rules (enforced by review, documented here)

- `application/X` may import from `shared/` and `app/` (hooks) — **never from
  `application/Y`**. There are zero cross-app imports in this codebase.
- `shared/` never imports from `application/` or `app/` — it receives app
  context (the manifest) as props.
- `app/` is the only layer that imports every application, and only their
  `manifest` / `state` barrels.

### The manifest contract

Each app exports one `AppManifest` (`shared/types.ts`): id, code, name,
description, icon, `entry`, `paths` it owns, per-app `nav` (including
disabled "Soon" items for planned modules), `routes`, `status`, optional
launcher `stats` and `usesTimeRange`. **Adding an application** = create
`src/application/<name>/`, export a manifest, list it in
`src/app/registry.ts`. Router, launcher and layout pick it up automatically.
**Promoting a preview**: add pages/data/state inside its folder, extend its
manifest nav/routes, flip `status` to `live` — the governance app is the
reference implementation.

## Theming (light / dark)

- Toggle in every topbar and on the launcher; initial value = saved choice →
  system preference; persisted to `localStorage` (`cl-theme`); a tiny inline
  script in `index.html` applies it before first paint (no flash).
- All colors are CSS variables (`:root` and `.dark` in `src/index.css`);
  Tailwind reads them, and chart structure (grid, axes, tooltips) uses the
  same variables via `shared/lib/chart.ts`, so Recharts adapts too.
- Brand red stays `hsl(354 100% 50%)` in light and lifts slightly in dark for
  contrast. Logos in `shared/components/Logos.tsx` remain coded placeholders —
  swap in licensed assets there.

## Notes & limitations

- All figures are illustrative; content mirrors the table-top planner (v0.2)
  but the numbers are invented.
- `npm run build` skips type-checking for speed; run `npm run typecheck` in CI.
- No backend, auth or persistence beyond the theme choice — data state resets
  on refresh by design.
