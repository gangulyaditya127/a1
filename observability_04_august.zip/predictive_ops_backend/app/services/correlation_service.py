import re
from datetime import datetime, timedelta
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import text


def generalize_desc(desc: str) -> str:
    """Apply the pattern identification logic to generalize a short description."""
    if not desc:
        return "UNKNOWN"
    desc = str(desc).upper()

    # Domain specific masking
    desc = re.sub(r'USER \w+', 'USER <USER_ID>', desc)
    desc = re.sub(r'REGION \w+', 'REGION <REGION>', desc)
    desc = re.sub(r'TRANSACTION \w+', 'TRANSACTION <JOB_NAME>', desc)
    desc = re.sub(r'JOB \w+', 'JOB <JOB_NAME>', desc)

    # Generic alphanumeric ID masking
    desc = re.sub(r'\b[A-Z0-9]*\d[A-Z0-9]*\b', '<ID>', desc)
    desc = re.sub(r'\s+', ' ', desc).strip()

    return desc


def fetch_incidents_for_window(db: Session, subjourney_id: str, window_start: datetime, window_end: datetime) -> list:
    """Fetch incidents from the DB for a given subjourney within a time window,
    filtered by Caller='ITSI Event Management' and Channel='Monitoring'."""
    query = text("""
        SELECT number, opened, short_description, parent_incident, 
               assignment_group, service, priority, state
        FROM incidents
        WHERE subjourney_id = :sub_id
          AND caller = 'ITSI Event Management'
          AND channel = 'Monitoring'
          AND opened >= :start
          AND opened < :end
        ORDER BY opened ASC
    """)
    result = db.execute(query, {
        "sub_id": subjourney_id,
        "start": window_start,
        "end": window_end
    })
    rows = result.fetchall()
    incidents = []
    for row in rows:
        incidents.append({
            "number": row[0],
            "opened": row[1].isoformat() if row[1] else None,
            "short_description": row[2],
            "parent_incident": row[3],
            "assignment_group": row[4],
            "service": row[5],
            "priority": row[6],
            "state": row[7]
        })
    return incidents


def build_clusters(subjourney_id: str, opened_datetime: datetime, db: Session) -> list:
    """
    Core clustering logic:
    1. Fetch 1 hour of data before `opened_datetime` (current window).
    2. Cluster by generalized pattern. Keep clusters with count > 2.
    3. For each qualifying cluster, fetch another previous hour (hour -2 to hour -1).
    4. If the same pattern exists in the previous hour, merge those incidents into the cluster.
    5. From all merged incidents, find the earliest one:
       - If it has a parent_incident field, use that as the parent ID for all.
       - If not, use the earliest incident itself as the parent.
    6. If no matching incidents exist in the previous hour, use the earliest incident
       in the current cluster as the parent.
    7. Return the list of clusters.
    """

    # ---- STEP 1: Fetch current hour window ----
    current_window_end = opened_datetime
    current_window_start = opened_datetime - timedelta(hours=1)

    current_incidents = fetch_incidents_for_window(db, subjourney_id, current_window_start, current_window_end)

    if not current_incidents:
        return []

    # ---- STEP 2: Cluster by pattern ----
    pattern_groups = {}
    for inc in current_incidents:
        pattern = generalize_desc(inc["short_description"])
        if pattern not in pattern_groups:
            pattern_groups[pattern] = []
        pattern_groups[pattern].append(inc)

    # Filter: only clusters with more than 2 incidents
    qualifying_clusters = {p: incs for p, incs in pattern_groups.items() if len(incs) > 2}

    if not qualifying_clusters:
        return []

    # ---- STEP 3: For each cluster, check previous hour ----
    prev_window_end = current_window_start
    prev_window_start = current_window_start - timedelta(hours=1)

    prev_incidents = fetch_incidents_for_window(db, subjourney_id, prev_window_start, prev_window_end)

    # Group previous hour incidents by pattern
    prev_pattern_groups = {}
    for inc in prev_incidents:
        pattern = generalize_desc(inc["short_description"])
        if pattern not in prev_pattern_groups:
            prev_pattern_groups[pattern] = []
        prev_pattern_groups[pattern].append(inc)

    # ---- STEP 4 & 5 & 6: Determine parent for each cluster ----
    cluster_results = []

    for pattern, current_cluster_incidents in qualifying_clusters.items():
        prev_matching = prev_pattern_groups.get(pattern, [])

        if prev_matching:
            # Merge previous hour incidents into the cluster
            all_incidents = prev_matching + current_cluster_incidents

            # Find the earliest incident across both windows
            all_incidents_sorted = sorted(all_incidents, key=lambda x: x["opened"] or "")
            earliest = all_incidents_sorted[0]

            if earliest.get("parent_incident") and earliest["parent_incident"].strip():
                # The earliest incident already has a parent — use that parent ID
                parent_id = earliest["parent_incident"]
                parent_incident_obj = earliest  # The earliest is still the reference
            else:
                # The earliest incident itself becomes the parent
                parent_id = earliest["number"]
                parent_incident_obj = earliest
        else:
            # No matching incidents in previous hour
            all_incidents = current_cluster_incidents
            all_incidents_sorted = sorted(all_incidents, key=lambda x: x["opened"] or "")
            earliest = all_incidents_sorted[0]
            parent_id = earliest["number"]
            parent_incident_obj = earliest

        # Build the children list (everything except the parent incident itself)
        children = []
        for inc in all_incidents_sorted:
            if inc["number"] == parent_incident_obj["number"]:
                continue
            # Calculate delta from the parent/earliest
            delta_str = ""
            if inc["opened"] and parent_incident_obj["opened"]:
                try:
                    inc_time = datetime.fromisoformat(inc["opened"])
                    parent_time = datetime.fromisoformat(parent_incident_obj["opened"])
                    delta_minutes = int((inc_time - parent_time).total_seconds() / 60)
                    delta_str = f"{delta_minutes} min"
                except Exception:
                    delta_str = "N/A"

            children.append({
                "id": inc["number"],
                "time": inc["opened"],
                "description": inc["short_description"],
                "delta": delta_str,
                "assigned_parent_id": parent_id
            })

        cluster_results.append({
            "pattern": pattern,
            "incident_count": len(all_incidents),
            "has_previous_hour_match": len(prev_matching) > 0,
            "previous_hour_incident_count": len(prev_matching),
            "parent": {
                "id": parent_id,
                "incident_number": parent_incident_obj["number"],
                "time": parent_incident_obj["opened"],
                "description": parent_incident_obj["short_description"],
                "is_inherited_parent": bool(
                    parent_id != parent_incident_obj["number"]
                )
            },
            "children": children
        })

    # Sort clusters by incident count descending
    cluster_results.sort(key=lambda x: x["incident_count"], reverse=True)

    return cluster_results

def build_enriched_top_cluster(subjourney_id: str, opened_datetime: datetime, db: Session) -> Optional[dict]:
    """
    Fetches clusters, takes the top one, and enriches it into the exact JSON format expected by the UI.
    """
    clusters = build_clusters(subjourney_id, opened_datetime, db)
    if not clusters:
        return None

    # Take the top cluster (already sorted by incident_count descending in build_clusters)
    top = clusters[0]
    
    # 1. Extract dynamic entities from parent description
    parent_desc = top["parent"]["description"]
    extracted_job = "Unknown Job"
    
    # Look for 'TRANSACTION [JOB_NAME]' or 'JOB [JOB_NAME]'
    job_match = re.search(r'(?:TRANSACTION|JOB) (\w+)', parent_desc, re.IGNORECASE)
    if job_match:
        extracted_job = job_match.group(1)

    region_match = re.search(r'REGION (\w+)', parent_desc, re.IGNORECASE)
    extracted_region = region_match.group(1) if region_match else "Unknown Region"

    # Define grammar name based on pattern string (naive mapping for UI)
    grammar = "TRANSACTION_ABEND" if "TRANSACTION" in top["pattern"] else "GENERIC_ABEND"
    if "HEALTH SCORE" in top["pattern"]:
        grammar = "HEALTH_SCORE_ALERT"

    # Construct RCA HTML
    if grammar == "TRANSACTION_ABEND":
        root_cause_desc = f"Transaction Abend detected for job <b>{extracted_job}</b> in region <b>{extracted_region}</b>. This matches the known {grammar} pattern family."
    else:
        root_cause_desc = f"Cluster detected matching the known <b>{grammar}</b> pattern family."

    # 2. Enrich children with confidence and boosters
    enriched_children = []
    # Fetch original parent incident to compare attributes
    parent_incident_data = next(
        (inc for inc in fetch_incidents_for_window(db, subjourney_id, opened_datetime - timedelta(hours=2), opened_datetime) 
         if inc["number"] == top["parent"]["incident_number"]), 
        None
    )
    
    # We'll map the raw db objects again for the children to get their full attributes for booster comparison.
    # To do this efficiently, we fetch the full 2 hour window of incidents.
    all_window_incidents = fetch_incidents_for_window(db, subjourney_id, opened_datetime - timedelta(hours=2), opened_datetime)
    incidents_by_id = {inc["number"]: inc for inc in all_window_incidents}

    for child in top["children"]:
        child_inc = incidents_by_id.get(child["id"])
        
        base_confidence = 0.70
        boosters = []
        
        if parent_incident_data and child_inc:
            if parent_incident_data.get("service") and child_inc.get("service") == parent_incident_data.get("service"):
                boosters.append("Same Service")
                base_confidence += 0.10
                
            if parent_incident_data.get("assignment_group") and child_inc.get("assignment_group") == parent_incident_data.get("assignment_group"):
                boosters.append("Same Assignment Group")
                base_confidence += 0.10
        
        # Check delta proximity
        if child["delta"] != "N/A":
            try:
                minutes = int(child["delta"].split()[0])
                if minutes < 15:
                    boosters.append("< 15m proximity")
                    base_confidence += 0.10
            except ValueError:
                pass
                
        # Cap confidence at 0.99
        confidence = min(0.99, base_confidence)
        
        enriched_children.append({
            "id": child["id"],
            "time": child["time"].replace("T", " ") if child["time"] else "",
            "description": child["description"],
            "delta": child["delta"],
            "confidence": round(confidence, 2),
            "boosters": boosters
        })

    # Assemble the final enriched JSON
    corr_data = {
        "incident": {
            "id": top["parent"]["id"],
            "root_cause": parent_desc,
            "root_cause_desc": root_cause_desc,
            "raw_alerts_grouped": len(top["children"]),
            "tools_contributing": 1,
            "correlation_confidence_pct": 94,
            "frustrated_user_count": top["incident_count"] * 50  # Mock business impact metric
        },
        "parent": {
            "id": top["parent"]["id"],
            "time": top["parent"]["time"].replace("T", " ") if top["parent"]["time"] else "",
            "description": parent_desc,
            "grammar": grammar,
            "extractedJob": extracted_job,
            "service": parent_incident_data.get("service") if parent_incident_data else "Unknown"
        },
        "children": enriched_children
    }

    return corr_data

def build_dynamic_enriched_top_cluster(subjourney_id: str, opened_datetime: datetime, db: Session) -> Optional[dict]:
    """
    Fetches clusters, takes the top one, and enriches it dynamically using the root cause template from the database.
    """
    from app.models.models import PatternFamily
    
    clusters = build_clusters(subjourney_id, opened_datetime, db)
    if not clusters:
        return None

    top = clusters[0]
    parent_desc = top["parent"]["description"]
    
    # Extract ALL potential dynamic variables dynamically using regex matching on the actual description
    # This matches anything that looks like an all-caps alphanumeric with at least one letter, or simple values.
    # We will just sequentially replace {var_1}, {var_2} in the template.
    # To do this robustly, we retrieve the exact pattern from DB.
    pattern_family = db.query(PatternFamily).filter(PatternFamily.pattern_name == top["pattern"]).first()
    
    grammar = "DYNAMIC_PATTERN"
    root_cause_desc = "Cluster detected matching a known pattern family."
    
    if pattern_family and pattern_family.root_cause_template:
        root_cause_desc = pattern_family.root_cause_template
        
        # We need to extract the variables from parent_desc based on the pattern string.
        # Let's turn the pattern into a regex capture group.
        pattern_str = pattern_family.pattern_name
        # Escape regex special characters in pattern string except our placeholders
        escaped_pattern = re.escape(pattern_str)
        # Replace placeholders like <ID>, <JOB_NAME> etc with capture groups
        # Note: Python 3.7+ re.escape does not escape '<' and '>'
        regex_pattern = re.sub(r'<.*?>', r'(.+?)', escaped_pattern)
        
        # Try to match the actual description against this regex
        match = re.match(regex_pattern + '$', parent_desc, re.IGNORECASE)
        if match:
            # We have captured all the variables!
            groups = match.groups()
            for i, val in enumerate(groups):
                # {var_1}, {var_2}, etc.
                placeholder = f"{{var_{i+1}}}"
                root_cause_desc = root_cause_desc.replace(placeholder, val)

    # 2. Enrich children with confidence and boosters (same logic as before)
    enriched_children = []
    all_window_incidents = fetch_incidents_for_window(db, subjourney_id, opened_datetime - timedelta(hours=2), opened_datetime)
    incidents_by_id = {inc["number"]: inc for inc in all_window_incidents}
    
    parent_incident_data = incidents_by_id.get(top["parent"]["incident_number"])

    for child in top["children"]:
        child_inc = incidents_by_id.get(child["id"])
        base_confidence = 0.70
        boosters = []
        
        if parent_incident_data and child_inc:
            if parent_incident_data.get("service") and child_inc.get("service") == parent_incident_data.get("service"):
                boosters.append("Same Service")
                base_confidence += 0.10
            if parent_incident_data.get("assignment_group") and child_inc.get("assignment_group") == parent_incident_data.get("assignment_group"):
                boosters.append("Same Assignment Group")
                base_confidence += 0.10
                
        if child["delta"] != "N/A":
            try:
                minutes = int(child["delta"].split()[0])
                if minutes < 15:
                    boosters.append("< 15m proximity")
                    base_confidence += 0.10
            except ValueError:
                pass
                
        confidence = min(0.99, base_confidence)
        
        enriched_children.append({
            "id": child["id"],
            "time": child["time"].replace("T", " ") if child["time"] else "",
            "description": child["description"],
            "delta": child["delta"],
            "confidence": round(confidence, 2),
            "boosters": boosters
        })

    corr_data = {
        "incident": {
            "id": top["parent"]["id"],
            "root_cause": parent_desc,
            "root_cause_desc": root_cause_desc,
            "raw_alerts_grouped": len(top["children"]),
            "tools_contributing": 1,
            "correlation_confidence_pct": 94,
            "frustrated_user_count": top["incident_count"] * 50
        },
        "parent": {
            "id": top["parent"]["id"],
            "time": top["parent"]["time"].replace("T", " ") if top["parent"]["time"] else "",
            "description": parent_desc,
            "grammar": grammar,
            "extractedJob": "Dynamic Extraction",
            "service": parent_incident_data.get("service") if parent_incident_data else "Unknown"
        },
        "children": enriched_children
    }

    return corr_data

def get_splunk_children(parent_id: str, db: Session) -> List[str]:
    """
    Fetches all child incident IDs natively grouped by Splunk under a given parent_id.
    """
    query = text("""
        SELECT number 
        FROM incidents
        WHERE parent_incident = :parent_id
    """)
    result = db.execute(query, {"parent_id": parent_id})
    return [row[0] for row in result.fetchall()]
