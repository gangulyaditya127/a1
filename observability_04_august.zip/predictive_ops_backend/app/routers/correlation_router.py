from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.database import get_db
from app.services import correlation_service

router = APIRouter(prefix="/api/correlation", tags=["correlation"])


@router.get("/clusters")
def get_clusters(
    subjourney_id: str = Query(..., description="The subjourney ID (e.g. S3_2)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-06-15T12:00:00)"),
    db: Session = Depends(get_db)
):
    """
    Identify incident clusters for a given subjourney around a specific time.
    
    This endpoint:
    1. Fetches 1 hour of monitoring incidents before the given datetime.
    2. Clusters them by generalized short-description patterns.
    3. For clusters with >2 incidents, checks the previous hour for recurring patterns.
    4. Assigns a parent incident to each cluster based on recurrence logic.
    5. Returns the full cluster list with parent/child relationships.
    """
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'. Use ISO format like '2026-06-15T12:00:00'."}

    clusters = correlation_service.build_clusters(subjourney_id, ref_time, db)

    return {
        "subjourney_id": subjourney_id,
        "reference_datetime": opened_datetime,
        "window": f"{(ref_time - timedelta(hours=1)).isoformat()} to {ref_time.isoformat()}",
        "previous_window": f"{(ref_time - timedelta(hours=2)).isoformat()} to {(ref_time - timedelta(hours=1)).isoformat()}",
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }

@router.get("/top_cluster")
def get_top_cluster(
    subjourney_id: str = Query(..., description="The subjourney ID (e.g. S3_2)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-06-15T12:00:00)"),
    db: Session = Depends(get_db)
):
    """
    Returns the enriched top cluster mapped exactly to the UI's CorrelationExecutionView structure.
    """
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'. Use ISO format like '2026-06-15T12:00:00'."}

    enriched_cluster = correlation_service.build_dynamic_enriched_top_cluster(subjourney_id, ref_time, db)
    
    if not enriched_cluster:
        # Return a 404-like empty object if no clusters found
        return {"error": "No clusters found for the given subjourney and time window."}
        
    return enriched_cluster

@router.get("/splunk_children")
def get_splunk_children(
    parent_id: str = Query(..., description="The parent incident ID to search for"),
    db: Session = Depends(get_db)
):
    """
    Returns a list of incident IDs natively grouped by Splunk under a given parent_id.
    """
    return correlation_service.get_splunk_children(parent_id, db)
