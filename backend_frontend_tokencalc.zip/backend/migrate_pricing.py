import os
import pandas as pd
from app import app, db, ModelPricing, EXCEL_PATH

def migrate_pricing():
    print(f"Reading from {EXCEL_PATH}...")
    try:
        df = pd.read_excel(EXCEL_PATH, sheet_name='Configuration')
        
        models_data = []
        model_row = df.iloc[3]
        input_row = df.iloc[4]
        output_row = df.iloc[5]
        
        for col_idx in range(1, len(model_row)):
            model_name = str(model_row.iloc[col_idx]).strip()
            if model_name and model_name != 'nan':
                models_data.append({
                    'model': model_name,
                    'input_price': float(input_row.iloc[col_idx]),
                    'output_price': float(output_row.iloc[col_idx])
                })
                
        with app.app_context():
            # Check existing models to avoid duplicates
            existing_models = [m.model_name for m in ModelPricing.query.all()]
            added_count = 0
            
            for item in models_data:
                if item['model'] not in existing_models:
                    new_model = ModelPricing(
                        model_name=item['model'],
                        input_price=item['input_price'],
                        output_price=item['output_price']
                    )
                    db.session.add(new_model)
                    added_count += 1
            
            db.session.commit()
            print(f"Successfully migrated {added_count} models to the database.")
            
    except Exception as e:
        print(f"Migration failed: {e}")

if __name__ == "__main__":
    migrate_pricing()
